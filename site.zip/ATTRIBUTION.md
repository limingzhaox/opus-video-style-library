# 来源、署名与再发布

本资料库收集了两个风格项目的 84 项案例，并索引原 PDF 提到的 7 个 GitHub 项目。作者原文与代码仍归原作者；中文任务模板、中文摘要及编排由本次整理新增。参考文档完整快照与原始 LICENSE 保存在 sources/upstream/，精确提交和文件哈希见 sources/source-inventory.json。

## LemoLab

来源：https://github.com/lemomo-ai/lemo-opuscar  
作者：LemoLab / Lemomo。

孟菲斯微缩景观（memphis-diorama）的贡献者为 [EianLu](https://x.com/EianLu)，按上游 README 保留署名。

按上游 README 的 Licence：
- 代码和文档：MIT。分发副本时保留原 LICENSE 与版权说明。
- 示例影片及静帧：CC BY 4.0。须署名 LemoLab、链接原仓库，并说明改动。本库图片经过缩放、压缩、拼版；未声称为自己创作。
- 用库创作的自己的影片，上游说明无需给库署名；你采用的第三方素材仍须单独处理。
- 示例中的第三方资产保持其自身许可，详见各示例 CREDITS；本库未收齐每份资产的全部 CREDITS，链接回原工程核对。

CC BY 4.0：https://creativecommons.org/licenses/by/4.0/

当前固定版本的上游明确排除六项示例旁白：Chalkboard、Circuit Board、Desktop Flythrough、Isometric Picture Book、Printed Long Take 使用的 Microsoft Edge TTS，以及 Broadcast News Package 使用的 Doubao TTS（火山引擎）。这些声音不适用影片的 CC BY 4.0 授权，不要直接抽取复用；自己创作时重新生成有权使用的声音。详见 [固定版本 README 的许可说明](https://github.com/lemomo-ai/lemo-opuscar/blob/9eb7739a0fca4c6990fe966cb8b87b1930f7193a/README.md#license)，各影片的 CREDITS.md 另列第三方素材与署名要求。

Game Show Flat 与 Paper-cut Lightbox 当前示例已改用 Kokoro，故不再列于上述六项例外；这不改变历史下载版本中 macOS 系统语音或 Edge TTS 的使用条件。旧副本仍须核对对应提交的 README 与 CREDITS。图册的播放按钮连接作者原发布视频，没有另行分发这些音轨。

## Miranda Dixon-Luinenburg

来源：https://github.com/cyborggirl963/opus-5.5-music-video-art-styles  
作者：Miranda Dixon-Luinenburg。  
仓库根 LICENSE：MIT，Copyright (c) 2026 Miranda Dixon-Luinenburg。

本库保留原 LICENSE 与每风格 README；18 张示范图来自其 styles/<slug>/img/hero.jpg，并进行了缩放与重新编排。歌曲、诗、外部字体、引用素材等仍按各自来源处理。中文“使用模板”由本库根据工程说明整理，没有声称是作者原始提示词对话。

## 其余参考项目

仅作链接、仓库元数据与 README 快照索引，不把其全部媒体重新打包分发：
- https://github.com/yihui-dev/awesome-opus5-5-videos
- https://github.com/joeseesun/opus-video-prompts
- https://github.com/JohnHeibel/PDoomVideo
- https://github.com/JohnHeibel/ClaudeAnimationBase
- https://github.com/mexicat/pdoom-video

公开精简包不包含这五份 README 的全文副本。引用、改编或复用其素材前请阅读各仓库自己的许可。

