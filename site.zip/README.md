# Opus 视频风格资料库

77 个风格条目：59 个 Lemo 影片风格 + 18 个手作 MV 引擎。每项提供作者示范画面、来源、完整可用任务模板与注意事项。不同库的相近媒介保留各自条目，不意味着 77 种互不重叠的艺术流派。

## 给人

打开 [图册](index.html) 看图、观看作者视频、复制完整提示词或下载 TXT。

- [完整提示词索引](完整提示词总册.md)
- [使用指南](使用指南.md)
- [案例索引](案例索引.md)
- [分享与外部访问](分享与外部访问.md)
- [更新说明](更新说明.md)
- [作者与素材署名](ATTRIBUTION.md)

## 给 AI

从 [llms.txt](llms.txt) 开始。用 [styles.json](styles.json) 查找风格及单项 promptFile，再读取对应 prompts/*.md。[prompts.json](prompts.json) 包含所有完整文本，体积较大，建议按项读取。

Lemo 作者 STYLE.md 保留全文；手作库的中文使用模板根据引擎说明整理，并非作者原始对话。提示词包含代码渲染工作流，需要相应执行工具；本资料库本身不是生成视频的服务。

## 来源与维护

两个主要来源：[LemoLab](https://github.com/lemomo-ai/lemo-opuscar)、[Miranda Dixon-Luinenburg](https://github.com/cyborggirl963/opus-5.5-music-video-art-styles)。

固定提交见 sources/upstreams.json，文件哈希见 sources/source-inventory.json。遵守上游许可与署名，见 ATTRIBUTION.md。当前仅在本机生成；对外分享包准备完成不等于已发布到公网。

每周核对两主库与五个参考仓库，保留自己的修改在「我的提示词/」。新风格需要补中文要点并校验后再作为完成更新交付。详情见更新说明。

