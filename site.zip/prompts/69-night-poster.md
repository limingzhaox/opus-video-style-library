# 69 · 夜色海报插画 / Night poster

来源类型：根据作者引擎说明整理的使用模板；并非作者原始创作提示词  
原作者：Miranda Dixon-Luinenburg  
上游原文：https://github.com/cyborggirl963/opus-5.5-music-video-art-styles/tree/main/styles/night-poster  
固定版本：801b3548c54765ecf932ce8b7f3cf4b29fb7a8bf  
抓取核对日期：2026-11-03  
本库改动：中文任务模板、中文摘要与编排；原文全文保留。

## 使用前先看

- 夜色通过向深蓝混色并降亮度实现，不只旋转色相；浅色道具须在夜景中单独验色。
- 白天保留更丰富的中间色；天空承担时间感，不要被高楼和树完全填没。

- 这是代码渲染工作流；聊天文本本身不会自动产生 MP4，需有可执行的项目环境。
- 先看预览再做长片；不要把示例素材的许可自动套到自己的歌曲、照片、字体和品牌上。
- 下方复制区包含全部风格与公共规范，不要求 AI 另外从本机隐藏路径读取文件。

## 完整复制区

你是一位能写代码、检查画面并渲染成片的动画导演。请用“夜色海报插画 / Night poster”制作一个属于我的视频。

【我的需求；把花括号内容换成实际值】
主题与一句话故事：{{填写主题和结尾变化}}
用途与观众：{{例如面向普通观众的科普短片}}
内容依据或已有脚本：{{填写；没有则说明需要你写}}
音频、歌词、图片、数据、品牌素材路径：{{填写；没有写“无”}}
素材使用权限与需显示的署名：{{填写来源与许可；不清楚请列待确认项}}
目标时长：30 秒起步；MV 以实测歌曲时长为准
画幅与清晰度：默认横屏 16:9、1920×1080；帧率按本风格原文与引擎规范，未规定时24fps；竖屏须重新构图，不直接裁横屏
语言：简体中文；配音需求：{{有/无、声线与语速}}
必须出现的内容：{{填写}}
禁止出现的内容：{{填写}}
预算与速度：先做低成本验证，再渲染完整片
个人工程名：my-video（可改为英文短名）
确认方式：先给 3 张由真实渲染代码产出的样帧和 5–10 秒预览；我确认风格后再做完整成片

【本风格的核心实现】
用中世纪中叶旅行海报式平涂、单块硬阴影和天空色阶表达昼夜。
特别检查：
- 夜色通过向深蓝混色并降亮度实现，不只旋转色相；浅色道具须在夜景中单独验色。
- 白天保留更丰富的中间色；天空承担时间感，不要被高楼和树完全填没。

【工程与流程】
1. 在工作区单独克隆 https://github.com/cyborggirl963/opus-5.5-music-video-art-styles ，检出 801b3548c54765ecf932ce8b7f3cf4b29fb7a8bf。将 styles/night-poster/ 复制到 projects/my-video/，保留引擎，按该风格 README 指定的文件替换示例场景。不要直接修改 styles/ 中的母版。
建立 Python 虚拟环境，阅读 requirements.txt 后安装渲染依赖；需分析音频时再安装 requirements-audio.txt。使用 Chrome 或项目支持的 Chromium。使用 python tools/serve.py 提供本地 HTTP，不用 file:// 打开渲染页面。
2. 先检查机器的 Python、Node/浏览器、FFmpeg、字体与 GPU 能力。Lemo 当前要求 FFmpeg 7+；先用 ffmpeg -version 核对。缺少工具或访问权限时明确报告缺什么，不能只描述完成、伪造文件或把截图称为已渲染视频。
3. 把我的需求写成 PLAN.md 或 TREATMENT.md：一句话故事、分镜、逐镜秒数、镜头运动、文字位置、音乐与声音 cue、所需素材、预计成本。涉及事实和数据时写 FACTS.md；没有来源的数字不填。
4. 如果是 MV，先取得音频与实际演唱歌词，测量段落、停顿、节拍与词时间；不得沿用 37.5 秒示例诗的时间轴。未提供音乐时不要假装已经完成歌词对齐，可先制作无歌词短预览。
5. 先完成 3 张代表开头、关键变化、结尾的样帧，逐张检查；再渲染 5–10 秒低清短段，检查字幕、运动、音画同步与控制台。复杂慢风格先计时，再估算整片。
6. 随机效果固定种子；有历史累积的媒介按顺序渲染。并行前先比较随机抽帧与连续渲染是否一致。
7. 正式导出使用项目文档中的工具与参数，不臆造命令。交付可播放 MP4、720p 预览、源代码、素材清单与许可、字幕（有台词时）、复现说明；保留最终片长、帧率、音频响度与实际渲染耗时。
8. 实际打开并检查成片开头、中间、转场、结尾及全片联系表，确认没有空帧、字体回退、遮挡、裁字、爆音或无意复制的作者片尾签名。交代尚未完成的检查。

下面是完整风格参考与公共制作规范。它们是上游参考资料，不代表我的主题或逐字台词；我的具体需求优先。风格中明确的声音、镜头和媒介限制优先于公共建议，例如无声电影不添加旁白或拟音。遇到 macOS/Linux 示例命令时按当前系统等价转换，不直接在 PowerShell 粘贴 bash 命令。相对资源路径以完整克隆的上游工程为准。


===== 完整风格原文：styles/night-poster/README.md =====

# Night poster

Flat-colour illustration in the manner of a mid-century travel poster: every shape is one flat fill cut by one
hard-edged shadow shape, with no gradients inside shapes. The shadow isn't painted on; it is the band that a copy of
the shape, shifted toward the light, fails to cover, so every form gets a clean shadow side for free. Nights are
indigo and ultramarine: ordinary colours are darkened and cooled by mixing toward navy (not by rotating the hue),
while lamps, lit windows and the moon keep their brightness, throw crisp-edged pools of light and put a warm rim on
whatever stands near them. The same painter has a daylight setting, so one scene can be drawn by night, at dawn, by
day and at dusk. People are drawn from contour points in feet, with two-bone arms and legs posed by where the hands
and feet (and, when it matters, the elbows) should be. Scenes sit on pages of panels with wavy seams, and one camera
moves over them: it pulls back until the frame is the page and pushes into another panel, slides across a seam to a
neighbour, or goes through a lit door in a warm flash. Pulled back far enough, a page's panels can turn out to be
the lit windows of a building.

*Good for:* everyday life, towns and streets, many moments in one frame, a place seen over years.

![A figure under a street lamp at night, a red umbrella blown inside out above them, the tree over the lamp lit gold](img/hero.jpg)

The demo sets Christina Rossetti's "Who Has Seen the Wind?" on a small-town street on a windy autumn evening. Stanza
one is the night: someone walking home under an umbrella that turns inside out on "wind?", the leaves by the lamp
trembling, a door opening. Then the page pulls back to the same street at four hours, a gust running through all
four at once, and pushes into the day for stanza two: washing on a line, a kite flyer on a hill opening on a seam of
its own in soft shapes for "Neither you nor I", the trees bowing on "bow", and a sheet torn off the line that blows
across a seam into the dusk panel and catches in a tree there. At the end the camera keeps pulling back past the
page, and the four hours turn into the four lit windows of a house on a hill at night, the wind still in its trees.

| | |
|---|---|
| ![The street at night, dawn, day and dusk in four panels with wavy seams](img/seams.jpg) | ![Washing blowing on a line by day, someone pegging it out](img/day.jpg) |
| ![A kite flyer on a hill in soft shapes, opened on a seam beside the day street](img/hill.jpg) | ![The four panels fading into the lit windows of a house on a hill at night](img/house.jpg) |

## Looks in this family

The [style lab](lab/index.html) draws the same scene descriptions with each look; only the Painter changes.

- **Night poster** (the demo): no outlines, darker and bluer, strong shadow shapes, lights kept bright. ![The street at night in the night poster look](img/look-night.jpg)
- **Night poster, by day**: the same painter with its daylight value at 1, warm mid-tones and cool violet shadows. ![The street by day](img/look-day.jpg)
- **Soft shapes**: no outlines, paler colour, a light band as well as a shadow band on every shape, more grain. The demo uses it for the hill. ![The street at night in soft shapes](img/look-soft.jpg)
- **Ink line**: heavy even outlines round every shape, flat fills, one flat shadow tone. ![The street at night in ink line](img/look-ink.jpg)

## Run the demo

```bash
python tools/serve.py
```

Then open `http://localhost:8000/styles/night-poster/index.html`. Play, or press Space; drag the bar to scrub.
Add `#t12.5` to the address for a still of 12.5 s with the page around it hidden (after editing code, reload with a
new query, `index.html?r=2#t12.5`, because changing only the `#` part doesn't reload).

```bash
python tools/still.py styles/night-poster/index.html 2 6 12.5 0:37.5:2.5 --sheet   # stills and a contact sheet
python tools/render_mp4.py styles/night-poster/index.html --fast                    # renders/night-poster-720p.mp4
python tools/render_mp4.py styles/night-poster/index.html                           # 1080p and 720p
```

It plays live, a little unevenly: close shots draw in 15-35 ms, but the four-panel page and the pull-back to the
house take 80-140 ms a frame and stutter. The MP4 is the smooth version: a `--fast` render of the 37.5 s takes about
a minute on an Apple-silicon Mac (about 67 ms a frame, encoding included), longer when other renders share the
machine.

## How it works

Plain scripts that share global names, loaded in this order by `index.html`:

| File | Job |
|---|---|
| `../../examples/poem/lyrics_data.js` | `window.SONG`: the lines, word times and beat grid |
| `core.js` | sizes (`W`, `H`), maths, seeded random `rng(seed)`, colour (`mix`, `hslAdj`, `rgba`), path builders, the pinhole camera, value noise |
| `paint.js` | the looks (`STYLES`) and the `Painter`, which draws every shape |
| `elements.js` | scenery: sky bands, stars, moon, clouds, mountains, pines, street lamps; the things wind shows up in: a tree that bows, loose leaves, chimney smoke, long grass, cloth on a line or snagged on a branch. Also aurora, snowbanks and falling snow |
| `fig.js` | figures: the frame and contour helpers, heads and hair, two-bone arms and legs, a walk, a figure in a coat (`figWalker`), one seen from behind (`figBack`), an umbrella, and the general figure `figPerson` (standing, walking, sitting, crouching, kneeling; side, back or front; tops, hair) |
| `props.js` | rooms and what's in them, as cheap flat faces: a box room, ceiling lights, a window onto the weather, a clock, paper in squiggles, binders, a phone, shelves, carts, cards, posters, a whiteboard, a hanging sign, a plant, furniture, stickers, and `revisit`. The lab loads it; the demo doesn't need it |
| `scene_street.js` | `SC_STREET`: the demo's street, one description drawn at four hours |
| `scene_hill.js` | `SC_HILL`: the hill in the soft inset |
| `scene_house.js` | `SC_HOUSE`: the house on the hill whose window grid sits under the page (by night, or `day`) |
| `scene_room.js` | `SC_ROOM`: a workroom that fills up by stage (the lab's; not loaded by the demo) |
| `engine.js` | scenes, pages and their seams, the camera's path, overlays (flash, opening seam of light), backdrops, half-size panel pictures, insets, loose things carried across a page, the lyric strip, the title card, `window.__video` |
| `shots.js` | this video: the wind, the figures' moves, the scenes, the page, the camera's path, the inset |
| `index.html` | the page and the player |

**The camera and scenes.** A scene is laid out in feet (x right, y up, z away from the viewer) and projected by a
pinhole camera, so it can be shot at any size:

```js
const cam = makeCam(1100, 960, 640, 5);  // focal length in px, screen x straight ahead, horizon y, eye height in feet
prj(cam, X, Y, Z)                        // -> [x, y] on the 1920x1080 scene: y = 640 - 1100 * (Y - 5) / Z
sAt(cam, Z)                              // pixels per foot at depth Z, for sizing figures and props
wquad(cam, [[X, Y, Z], ...])             // a flat shape given by its corners in feet
```

A scene function `SC_NAME(P, S)` draws a whole 1920x1080 frame through a Painter `P` from a state object `S` (all
optional, so `SC_STREET(P)` draws a sensible still) and returns anything the engine needs to know, here the lamp and
tree positions: `SC_STREET(P, { t, tod: 'night', wind: x => .6, walker: {...}, door: 1 })`. Rooms use a kit from
`props.js`: `const K = kit(makeCam(1080, 960, 470, 5.4))` gives `K.pr(X, Y, Z)`, `K.q(points)`, `K.s(Z)` and
`K.fAt(X, 0, Z, dir)` (a figure standing there).

**The Painter.** `new Painter(ctx, style, u)` with `style` one of `'night'`, `'poster'` (the night poster with the
daylight value `u`, 0 night to 1 day), `'soft'`, `'ink'`. It paints with the context's current transform, so a
zoomed camera stays crisp.

```js
P.part(paths, colour, { L: [-.6, -.8], sh: 10, hl: 0, rim: { L: [1, -.3], w: 3, c: '#ffcf86' }, em: false, flat: false })
P.flat(paths, colour, { a, em, raw })  // no shading, no outline: skies, light pools, glass, props (raw: colour already mapped)
P.stroke(path, width, colour, o)       // detail lines: ink in the ink look, a darker tone of the colour otherwise
P.glow(x, y, r, colour, alpha)         // a soft light (screen blend)
P.finish()                             // grain and vignette over the frame
P.col(colour, emissive), P.shade(colour, k), P.hi(colour, k)   // the look's colour, its shadow tone, its light tone
```

`paths` is a `Path2D` or a list of them, painted as one union. `L` points toward the light, `sh` is the shadow band's
width, `hl` a light band's, `rim` one or more coloured light bands (a lamp beside a figure), `em` marks something that
gives light and keeps its brightness at night. Path builders (`curve(points, closed, tension)` with `[x, y, 'c']` for a
corner, `poly`, `rect`, `ell`, `circ`, `capsule`) record the box they cover, so a shape only composites that part of
the frame. `alpha` multiplies with the context's own, so a whole scene can be drawn faded.

**Figures.** `frame(x, y, pxPerFoot, dir)` places a figure's feet on the screen; everything else is in feet from
there, facing +x (`dir: -1` mirrors it). Arms and legs are solved from a target, or posed exactly with an elbow:

```js
figWalker(P, frame(x, y, sAt(cam, Z)), {
  feet: walkFeet(phase),                  // or [[x, y, toe], [x, y, toe]] for a stance
  hands: [[.62, 3.72], [.3, 3.2]],        // near and far hand, in the body's own frame
  lean: .22, look: .5, flap: .8,          // lean into the wind, head tilted up, coat and scarf streaming
  prop: (P, f) => umbrella(P, f, [.62, 3.72], .38, { inv: 1 }),
});
figBack(P, frame(...), { hands: [[-.5, 6.9], [.55, 6.95]] })   // seen from behind, reaching up to a washing line
figPerson(P, K.fAt(5.6, 0, 10.6, -1), {                        // the general figure: sitting on a chair, reading
  pose: 'sit', view: 'side', top: { kind: 'sweater' }, hair: 'bun', head: { tilt: .25 },
  arms: { near: { h: [1.25, 3.05], e: [.85, 2.55] }, far: { h: [1.1, 3.1], e: [.68, 2.6] } },   // hands, and elbows
  hold: (P, f) => sheet(P, [f.T(1.05, 3.6), f.T(1.75, 3.45), f.T(1.62, 2.72), f.T(.95, 2.85)], { lines: 5 }),
});
```

`figPerson` takes `pose` ('stand', 'walk', 'sit', 'crouch', 'kneel'), `view` ('side', 'back', 'front'), `top.kind`
('tunic', 'sweater', 'coat', 'dress', 'robe', 'jacket', with `hem`, `sleeves`, `print`, `collar`, `belt`), `legs`
('pants', 'skirt', 'none'), `hair` ('bun', 'short', 'crop', 'pony', 'long', 'curls', 'hood', 'none'), `head.tilt`,
`scale` (0.6 for a child) and three drawing hooks: `under` (behind the whole figure: a chair back), `hold` (between
the arms) and `front` (over everything: a marker in the hand). It returns the shoulders, hips, head and each arm's
elbow and hand. `limbArm(P, fr, shoulder, hand, o)` and `limbLeg(P, fr, hip, foot, o)` draw one limb (`o.elbow` places
the elbow); `armBlend(shoulder, poseA, poseB, u)` moves an arm between two `{ h, e }` poses by turning each bone, so it
keeps its length; `walkFeet(phase, stride)` gives the ankles for a walk where each foot lands on phase 0 and 0.5, so
a stride timed to two beats puts a step on every beat. Moving the body at `stride / (0.6 * strideTime)` keeps the
planted foot from sliding. `bodyPt(K, fr, X, Y, Z)` turns a point of the room into the figure's own feet, for putting
a hand on a thing at another depth.

**Scenes, pages, the camera.** `engine.js` holds the machinery; `shots.js` fills it in. A scene is registered once and
can sit on any page:

```js
scene('night', { style: 'poster', u: 0, label: 'night',            // label: the caption while the camera is inside it
  draw: (P, t, cell) => SC_STREET(P, { t, tod: 'night', wind: windFor(cell, t), walker: walkerAt(t) }) });
scene('duskday', { style: 'poster', layers: t => [[.42, 1], [1, ramp(t, 7.5, 8.5)]],   // a dissolve, dusk into day
  draw: (P, t, cell, u) => SC_STREET(P, { t, tod: u > .5 ? 'day' : 'dusk' }) });
```

A page is a grid of scene ids, any number of rows and columns (1920x960 page units each, a wavy seam between
neighbours; each panel draws its whole scene at 1.04x so it covers where its seams bulge):

```js
page('street', [['night', 'dawn'], ['dusk', 'day']], { v: [[.0052, .6, 2]], h: [[.0031, 2.1, .4]],   // seam shapes
  backdrop: houseBackdrop, backdropScene: 'house', thumbBelow: .38,
  cellAlpha: (cam, t) => t < 33 ? 1 : clamp((cam.z * KP - .2) / (.36 - .2), 0, 1) });
```

The camera's path is a list of stretches, each on one page, each key `[time, view, ease]`:

```js
seg('street', [
  [0, V('night', 960, 520, 1.14)],             // scene point (960, 520) at the centre, 1.14 screen px per scene px
  [B(9), V('night', 840, 555, 1.62)],           // "wind?" (beat 9): closer on the walker as the gust hits
  [12.7, V('night', 1110, 350, 1.95)],          // up into the tree by the lamp
  [16.25, A(PW, PH, .5)],                        // page units: the whole page, four panels at half size
  [LINE(4), V('day', 740, 600, 1.72)],           // push into the day panel on line 5
  [34.2, A(PW - 19, PH + 86, .393), 'in'],       // the pull-back to the house, gathering speed...
  [35.4, A(PW - 4, PH + 370, .185), 'lin'],      // ...steady while the panels fade...
  [36.4, A(...housePt(960, 520), HOUSE_Z), 'out'],   // ...settling on the house
]);
```

Views: `V(sceneId, x, y, zoom, { free })` frames a panel in its own scene pixels (zoom 1 shows the scene's full
width); `A(x, y, z)` is in page units; `ALL(margin)` fits the page; `CELLS([ids], margin)` fits some panels. A close
`V` view is kept `SEAM_M` inside its panel on every side that has a neighbour, so the neighbour never peeks in at an
edge; `free` turns that off (the demo uses it where the hill's inset covers that edge). Eases: `'io'` (the default),
`'lin'`, `'in'` (gathering speed: into a door), `'out'` (settling); zoom interpolates in log. When one stretch ends
and the next begins, give both keys the same time and the same view of a panel both pages hold: the page change
doesn't show, and pulling back out of that panel finds it in new company.

The moves:
- **Pull back and push in:** a key on a panel, a key on `A(...)` or `ALL()` of its page, a key on another panel.
- **Slide:** a key on one panel, the next on its neighbour. Seam lines are drawn whenever they're on screen.
- **Through a lit door:** a key zooming into the lit opening with ease `'in'`, `flash(t0, peak, t1)` (the picture
  whites out to lamplight by `peak`), and the next stretch starting at `peak` on another page.
- **The building:** give the page a `backdrop` drawn in page units under the grid (the demo's draws `SC_HOUSE` scaled
  so its window grid, `HOUSE_WG`, lies exactly on the page) and a `cellAlpha` that fades the panels as the camera
  pulls back. Below `thumbBelow` panels are drawn from half-size pictures, which fade cleanly as whole pictures;
  `thumbT` draws those pictures once at a fixed time, for a quilt of dozens of panels.
- **The opening:** `seamOpen(t0, t1)` starts the picture as black with one line of warm light down the middle that
  widens like parting doors. The demo opens on a fade instead.

`overlay(t0, t1, fn)` is the general form: `fn(t, cam, page)` draws over the picture in screen pixels. An inset is a
second scene opening over the picture on a seam from the left: `SHOTS.insets = [{ style: 'soft', open: t => seamX,
view: t => [sceneX, sceneY, zoom], draw: (P, t) => ... }]`. `shots.js` ends with `const SHOTS = { ... }`, and
everything in it is optional: `over(P, t, cell, info)`
draws page-space things over each panel in that panel's light, `look(t, cam, page)` and `caption(t, cam, page)`
override the grain's look and the strip's caption, `build()` runs once at load, `poster` is the time shown on load.

**Moves inside a shot.** Most of a shot list is `tween(t, keys)`, a value eased between `[time, value]` keys
(numbers or arrays):

```js
inv: [[B(9) - .08, 0], [B(9) + .1, 1], [B(15) - .06, 1], [B(15) + .08, 0]],  // inside out on "wind?", back on "you"
```

**Wind.** `windAt(t, pageX, pageY)` in `shots.js` is a breeze that changes by section (`BREEZE`) plus gust fronts
(`GUSTS`) that sweep the page from right to left at `GUST_V`. Every scene gets `wind: x => ...` for its own screen x,
so a front crossing the page bends the trees panel after panel. Loose leaves live in page units and are stepped
through the wind once at load (`buildDrift`); `over()` draws them in every panel they cross, with that panel's
Painter, so a leaf changes its light as it crosses a seam. The torn sheet flies the same way along a fixed curve.

**Rooms that fill up.** `SC_ROOM(P, { stage })` is a workroom drawn at stage 0 (a desk, a chair, a clock, the window)
to 3 (shelves, cards, a whiteboard, a cart, a plant, posters, a hanging sign, stickers on everything, a second
person). Each prop checks the stage it arrives at. Props are flat faces (`wbox` draws a box as the faces turned to
the camera, shaded by the look), so a full room costs little more than a bare one. Coming back to a room later,
`revisit(P, t, a, b, (later, P) => SC_ROOM(P, { stage: later ? 3 : 1 }))` dissolves the old room into the fuller one
while the camera travels. The stickers (`sticker(P, x, y, r, 'star')`, `stickerQuad` for one lying on a wall or a page)
are plain stationery: star, heart, raindrop, leaf, snowflake, sun, and plain shapes; they mean whatever your video
needs.

**Lyrics.** The strip under the picture (120 px under a 1920x960 picture) shows one line at a time, each word fading
in as it's sung (`SONG.lines[i].words`), from the line's first word until the next line starts or 2.4 s after its
last word. Lines in a section whose name starts with `chorus` are set in amber italics. A caption at the right shows
the label of the panel the camera is in. `SONG.title` and `SONG.credit` are set in the sky until the first word is
sung.

**Determinism.** A frame is a pure function of `t`: every random choice comes from `rng(seed)` with a fixed seed (or a
seed keyed to the frame, like the drizzle's), and the leaves are integrated once at load, so `step(t)` and
`renderAt(t)` draw the same picture in any order. The caches are each Painter's colour table, the grain tile and,
with `thumbT`, the half-size panel pictures; the Painter's two offscreen buffers, the layer buffer and live panel
pictures are scratch space redrawn every frame.

## Make your own video in this style

1. Copy the folder and your song: `cp -r styles/night-poster projects/my-song`, `cp ~/Music/my-song.mp3
   projects/my-song/song.mp3` (see [docs/your-own-video.md](../../docs/your-own-video.md)).
2. Time your lyrics ([docs/timing.md](../../docs/timing.md)) so you end up with `projects/my-song/lyrics_data.js`
   (written by `tools/audio/to_js.py`), and in `index.html` change `../../examples/poem/lyrics_data.js` to
   `lyrics_data.js`. The page now plays the demo under your song.
3. Keep `core.js`, `paint.js`, `elements.js`, `fig.js`, `props.js`, `engine.js` and the player. Rewrite `shots.js` and
   write your own scenes; the street, the hill, the house and the room are there to borrow from.
4. **A scene:** a new file with `function SC_KITCHEN(P, S = {})`. Make a camera (or a `kit` for a room), lay things
   out in feet with `wquad`, `prj` and `sAt`, paint them with `P.part` and `P.flat` (and the props), and put people in
   with `figPerson`, `figWalker` or `figBack`. Give each thing its daylight colour and let the Painter's `u` make it
   night; for a scene seen at several hours, keep a small table of skies and tints like `STREET_TOD` and mix every
   colour toward the hour's tint (`C()` in the street and the house). Load the file in `index.html` before
   `engine.js`, and try it in the lab first (add it to `LAB_SCENES` in `lab/lab.js`).
5. **Register it and put it on a page:** `scene('kitchen', { style: 'poster', u: 1, label: 'morning', draw: (P, t,
   cell) => SC_KITCHEN(P, { t }) })`, then `page('p1', [['kitchen', 'street'], ...])`. The same scene function can
   sit behind several ids with different times or states (the kitchen at breakfast and at night).
6. **The camera:** one `seg` per page, keys `[t, view, ease]`. Keep a close view's zoom at about 1.12 or more; the
   clamp keeps it off its neighbours. To change page, end one stretch and start the next with the same key in a
   panel both pages hold; to leave through a door, zoom into it with `'in'` under a `flash`.
7. **Timing:** `B(n)` is beat n, `LINE(i)` is line i's start, `SONG.lines[i].words[k][1]` is word k's time. Put hits
   (an umbrella going, a sheet tearing) on beats and changes (a new shot, a push) on line starts. A gust that should
   land on a word needs its front to reach that spot a little early: set its time in `GUSTS` about 0.1 s before the
   word, at the page x of the thing it should hit.
8. **Knobs:** `BREEZE`, `GUSTS` and `GUST_V` (the wind); the tree's bend is `-(0.1 + 0.55w + 0.45w²)`, so a breeze
   leans and a gust bows; `KP`, `AMP`, `SEAM_M`, `SEAM_DARK`, `SEAM_LIGHT` (the pages); `thumbBelow`, `cellAlpha`
   (the building finale); `STREET_TOD` (each hour's sky, tint, lit windows, lamps); `Painter.nightT` and `dayT` (how
   the looks move colour); `grain` in `STYLES`; the strip's font and colours in `drawStrip`; the title's in
   `drawTitle`.

## Lab

Open `http://localhost:8000/styles/night-poster/lab/index.html` and pick a scene and a look;
`?scene=street&style=soft` opens on a pair. The scenes: the street, the hill, three hours of the street side by side
on seams, the house (by night, and by day in the day look), a lineup of the general figure, and the room filling up
(stages 0 to 3 on a page of panels). To render every pair:

```bash
python tools/lab_stills.py styles/night-poster/lab/index.html --all --sheet
```

| | |
|---|---|
| ![The general figure: standing, walking, sitting to read, from behind, from the front with hands on hips, crouching, kneeling, a child](img/lab-people.jpg) | ![One workroom at four stages on a page of panels: bare, a shelf and a first card, a whiteboard and a cart, then full](img/lab-room.jpg) |

What each look's Painter does to the same drawing:

- **Night poster** (`night`): each colour loses 12% saturation and 38% lightness, then goes 20% of the way to navy;
  shadow bands go 46% toward near-black blue; emissive colours keep their lightness; a strong vignette.
- **By day** (`poster`, u = 1): colours stay nearly true with 7% of a warm cream; shadow bands go toward blue-violet
  rather than black, light bands toward warm white; a lighter vignette. In between (dawn at 0.6, dusk at 0.42) it
  mixes the two, and the scene adds its own sky and tint for the hour.
- **Soft shapes** (`soft`): lightness lifted (up to 0.9) and saturation up 10%; every shape gets a light band half as
  wide as its shadow band; more grain, no vignette.
- **Ink line** (`ink`): each shape is stroked in dark ink at twice its line weight before its fill goes on, so a union
  of shapes gets one outer line; detail lines are ink; a violet shadow tone. Props drawn as flat faces get a thin
  ink outline per face.

## Performance

- Measured in headless Chrome on an Apple-silicon Mac: a close shot (one panel) draws in 15-35 ms, about 45 ms with
  the inset open; the four-panel page 80-140 ms (four whole scenes, around 900 shaded shapes); the pull-back to the
  house 60-140 ms (the house plus four half-size panels); the house alone about 8 ms. The mean over the demo is about
  42 ms.
- The cost is in `P.part`: a shape with a shadow, a light band or a rim is composited through two offscreen buffers,
  and the cost is proportional to the shape's box. Flat, unlit shapes are filled straight onto the frame. A path you
  build by hand (`new Path2D()` then `moveTo`...) has no box and composites the whole frame; start it with
  `emptyPath()` and add to it with the builders (or `leafPath`), or set `path.bb` yourself. For many small things
  (props in a room), use `P.flat` and `wbox`.
- Pages of many panels: below `thumbBelow` a panel is drawn from a 960x540 picture instead of in full, and with
  `thumbT` that picture is made once. A 7x7 quilt is then 49 image draws rather than 49 scenes.
- Memory: two 1920x1080 offscreen canvases shared by all painters (about 16 MB), a third for layer dissolves (8 MB,
  made when first needed), 2 MB per panel picture, and the leaf table (90 leaves x 1850 steps x 3 floats, about 2 MB).
- A whole `--fast` render takes about a minute for the 900 frames. Render a slice while you work on a stretch:
  `python tools/render_mp4.py styles/night-poster/index.html --start 15 --end 19 --fast`.
- Measure in a fresh page. After many `getImageData` readbacks Chrome may move a canvas to software rendering, which
  is several times slower and antialiases slightly differently.

## Lessons and gotchas

- **Night by mixing, not by hue.** Darkening by rotating hue toward blue turned cream walls red. Mix toward navy and
  lower the lightness instead, and mark lights as emissive so they keep their brightness.
- **Pale props shift hardest at night.** A pale blue blanket went royal blue under the night transform and a cream
  one went mustard; a cream house front came out ochre. Check pale things in the night look, pick them a little
  greyer, and give each night scene its own tint (the street and the house mix every colour toward the hour's tint
  before the Painter's night transform).
- **Day needs its own palette.** Mixing everything toward cream read as washed out and too close to soft shapes.
  Richer mid-tones and cool violet shadows fixed it, with the scene supplying its own colours for the hour (sky, a
  tint, which windows are lit) and the Painter doing the rest.
- **Keep the sky.** A tall building or big trees filling the top of the frame hid the sky, and in a poster the sky
  carries the hour. Three trees in the street, not five.
- **A tree that bends on a circular arc only slides its crown sideways.** To read as bowing, bend more toward the top
  (the angle at height s is `bend * s^1.9`), let the crown stream out downwind, and make the bend grow faster than
  the wind, so a breeze is a lean and a hard gust a bow.
- **Don't multiply time by a rate read from the wind.** Clouds drifting at `t * speed * wind(now)` raced across the
  sky as a gust arrived and ran backwards as it died down, and smoke, washing and a windmill driven the same way
  skipped. Anything that accumulates (a drift, a phase, an angle) needs a steady rate or the wind integrated over
  time (`buildDrift` does that for the leaves); the wind's strength can still set a bend, a lean or an amplitude.
- **Rim lights are in scene pixels.** A fixed width looks fat on a small figure and in a close-up; scale it to the
  figure (`w: fr.s * .1`). Aim it from the lamp to the figure, and it moves as they walk past.
- **Smoke puffs spaced wider than they are big look like beads.** Overlap them, and let the wind lay the plume over
  rather than stretch it.
- **Cloth is a flag.** A tumbling rounded rectangle read as a cushion. Draw it pinned along one edge with waves
  running out to the free end (`flag`).
- **Elbows.** Solving the elbow from the hand with a fixed side put a resting arm's elbow up in the air, and a
  resting figure's arms crossed in an X. `bend: 'down'` picks whichever elbow hangs lower, which suits a relaxed
  arm; for a pose that matters (resting on a table, hands on hips, arms hanging straight) give the elbow as well.
- **Blend arm poses by turning each bone**, not by blending positions: a straight blend shrinks the arm mid-move
  (`armBlend`). Targets solved by `limbArm` keep bone lengths anyway.
- **Two hands near the face read as someone holding their head.** When a figure holds something overhead, put the
  hands clear above the head.
- **Hair on a head lying down** read as a ball, then as leaves: draw it falling back from the forehead and spreading
  along the pillow.
- **A general figure's defaults must lose to the garment's own.** A shared hem default made every coat hip-length,
  and a sleeve default made sweaters short-sleeved; `figPerson` looks a garment's hem and sleeves up by its kind.
- **Figures are flat at their own depth.** A hand drawn at the figure's depth can't rest on a desk top nearer the
  camera; aim it at the thing with `bodyPt`, or slightly below the surface's height. Draw someone standing behind a
  desk before the desk, so it hides their legs.
- **Side walls barely show** from a camera looking down a room: posters there must sit near the back wall to be in
  shot. And props placed in front of the camera's near plane land huge or off the edge.
- **Capsules and arcs.** An arc drawn the long way round left circles at every elbow; `capsule()` draws both ends the
  short way.
- **Splitting points into several paths:** choose the path once per point and use it for both `moveTo` and `arc`, or
  snowflakes and flowers get joined into huge triangles.
- **A curve that must continue a path** (a panel outline made of two seams) needs `curve(..., path, true)`, which
  starts with a line instead of a new subpath.
- **Panels peek in.** Full-frame views showed the neighbouring panel at an edge where a seam bulges. Close views are
  now clamped inside their panel (`SEAM_M`); a view that does show a neighbour must show its seam line too (a
  neighbour without a seam line looks like a glitch), which is why seam lines are drawn whenever they're on screen,
  slides included.
- **Seams in one path.** Stroking each seam separately let the second seam's dark edge cut across the first one's
  light line where they cross; all of a page's seams are stroked as one path.
- **Page seams go under insets.** Drawn after the inset, a page seam crossed over the inset's picture.
- **Clip panels to the page.** A panel draws its whole scene larger than itself; at a page's outer edge nothing
  clipped it, and once the camera pulled back past the page (onto a backdrop) the scenes showed ragged edges.
- **Fading a scene.** A scene drawn at partial alpha shows its own shapes through each other (the sky through the
  houses). Fade whole pictures instead: a panel below `thumbBelow` is a picture, and a scene's later `layers` are
  drawn whole into a buffer and laid over. A shape's own `alpha` multiplies with the context's, or a dissolve drops
  the shapes that set one.
- **The building finale.** The panels came back in the windows whenever the camera passed that zoom again, until
  their fade was tied to time as well as zoom (`t < 33 ? 1 : ...`); and a backdrop that only drew when zoomed out
  blacked out a push back into it. The engine draws the backdrop whenever the view reaches past the page or the
  panels have faded. Keep the pull-back's speed even through the fade: an eased-in-and-out key on each side of it
  stops the camera there, so use `'in'`, `'lin'`, `'out'` with zooms chosen so the speed carries across the keys.
- **A scene drawn small inside its panel** (a wide view of somewhere) left hard edges where its hills stopped: run
  its ground and sky past the frame.
- **Compose an inset for the part its seam uncovers,** and don't time anything important under it: an early inset put
  its figures behind its seam, and an action landed while the inset still covered it.
- **A curve through too few points overshoots** (a line looping past where it should stop): add points.
- **Don't mutate what `tween` returns:** before the first key and after the last it hands back the key's own array.
- **One bad value in a gradient blanks the frame.** Check the console after every load; the still tool prints it.
- **Stale scripts:** serve with `tools/serve.py` (no caching), and reload with a new query after an edit.
- **Nothing still for long.** A hold of more than a beat or two reads as the player freezing; keep a camera drift,
  clouds, smoke or leaves moving through every held shot.



===== 完整公共规范：CLAUDE.md =====

# Instructions for Claude

This repository makes music videos in code: each style in `styles/` is an engine that draws every frame on an HTML
canvas (or WebGL / three.js) in a hand-made-looking medium, timed to a song, and `tools/` renders them to MP4. Read
`README.md` for the map, then the doc for whatever you're doing.

## When someone wants a video for their song

Follow [docs/workflow.md](docs/workflow.md). It's a conversation, not a build order to rush through:

1. **Get the inputs:** the song (mp3), the lyric sheet as sung, and ask whether they have stems and MIDI (Suno and
   stem splitters provide them) and any reference images.
2. **Ask the concept questions before building anything:** who is singing, who "you" is, whose voice the chorus is,
   what the key images (especially the ending) mean, how much the video may show, what stays out. Don't guess at
   these; an open question is better than a confident wrong answer. If the song belongs to a larger world, read
   whatever they give you about it, and keep a list of every detail the video invents, flagged as unconfirmed.
3. **Measure the song** ([docs/timing.md](docs/timing.md)): tempo, sections, stops and hits, and every word's time.
   Time to the audio, not to the lyric sheet's markings.
4. **Pitch three looks and recommend one:** the medium and why it suits this song, the organizing object, a small
   visual grammar and an arc, a section-by-section plan keyed to timestamps, and the open questions. The styles in
   `styles/` are the starting points (each README says what it's good at); a new medium is fine too
   ([docs/engine-patterns.md](docs/engine-patterns.md)).
5. **Style lab:** the same three or four moments drawn in each candidate look. Show the stills.
6. **Checkpoint:** build one section (20-90 s), render it (`--fast`), send it, get notes.
7. **Build the rest** section by section, then render the final MP4s. The MP4 is what gets shared.

Build a project in `projects/<song-slug>/`, copied from a style folder ([docs/your-own-video.md](docs/your-own-video.md)).
Don't change `styles/` for one person's video. Keep notes in `projects/<song-slug>/PLAN.md` as you go: their answers
and rulings, the measured sections and sync points, the shot list, the invented details, and their feedback on each
round. A later session should be able to pick up from that file alone.

## Working practices

- **Look at what you render.** Make stills and contact sheets (`tools/still.py ... --sheet`) and open the images.
  Check every frame on the sheet: edges, blank frames, the camera inside things, covered text, long freezes.
- **Read the console output** the tools print. A single bad canvas gradient value blanks a frame.
- **Preview slices with `--fast`**; render the full 1080p only at the end. Styles that carry state between frames
  must be rendered in order (the tools do this).
- **Keep it deterministic:** seeded randomness keyed to the frame, never `Math.random()` per frame.
- **Follow the page contract** in [docs/rendering.md](docs/rendering.md) (`window.__video`, `window.SONG`,
  `<canvas id="film">`, `#t<seconds>` stills) so the tools work.
- Apply the lessons in [docs/workflow.md](docs/workflow.md#what-the-notes-taught-true-for-every-style): busy
  enough, no long freezes, obvious changes, varied choruses, whole figures rather than close-up hands.
- The person's audio is git-ignored. If their lyrics or story are private, keep the project out of any public
  remote (add it to `.git/info/exclude`, or keep it outside the repo and pass `--root` to the tools).

## Setup

```bash
python3 -m venv .venv && .venv/bin/pip install -r requirements.txt -r requirements-audio.txt
```

Google Chrome must be installed (or `.venv/bin/python -m playwright install chromium`). To preview in the desktop
app's browser pane, create `.claude/launch.json` running `python3 tools/serve.py 8000` on port 8000 (git-ignored).
Use the server, never `file://`: module pages don't load from files and a plain server caches stale scripts.



===== 完整公共规范：docs/workflow.md =====

# How a video gets made

These videos were made in conversation: a person with a song and a clear sense of what it's about, and Claude
writing and rendering the code. The process below is what worked over a dozen songs. It suits working with Claude
Code (see [CLAUDE.md](../CLAUDE.md), which tells Claude to follow it), and it works just as well by hand.

The short version: **decide what the song is about, measure it, pitch three looks, test the look on a few scenes,
build one section, get notes, then build the rest.** Each step is cheap next to the one after it, so mistakes get
caught while they're still cheap.

## 1. Gather the inputs

- **The song** as an mp3 (or anything ffmpeg reads).
- **The lyric sheet** as plain text, one sung line per line, with `#section` markers (see
  [examples/poem/lyrics.txt](../examples/poem/lyrics.txt)). Write it the way it's sung: if the singer repeats a line
  that isn't on the sheet, add it.
- **Stems, if you have them.** An isolated vocal stem makes transcription far cleaner. Suno exports stems as audio
  and as MIDI per instrument; the MIDI's tempo map gives an exact beat grid, and the vocal MIDI gives note onsets to
  snap words to (see [timing.md](timing.md)).
- **Reference images, if any.** Mood boards and concept art are useful for content (what's in the world, what
  people wear, what the place looks like) even when the style will be different.

## 2. Decide what the song is about

Before any pictures, answer the questions that decide the concept. A video can't be good if these are guesses.

- **Who is singing,** and to whom? Who is "you"? It's often not who it seems, and it can change between verses.
- **Whose voice is the chorus?** The singer's, an imagined audience's, a crowd's, a custom's?
- **What do the key images mean?** Especially the closing one.
- **How much may the video show?** If the song belongs to a larger story, what would be a spoiler?
- **What stays out?** Eras, events, people, kinds of imagery.

If the song is part of a larger world (a novel, a game, a band's mythology), read up on it first, and **keep a list
of every detail the video invents**: a place's layout, what a prop says, who stands where. Show that list to
whoever owns the world, and treat nothing on it as settled until they say so.

## 3. Measure the song

Time the video to what the audio does, not to what the lyric sheet says. (AI song generators in particular ignore
markings like "quiet" or "almost unaccompanied".) With the tools in [timing.md](timing.md):

- tempo, and whether it changes;
- the sections and their loudness: which chorus is the big one, where it drops to almost nothing;
- **the stops and hits.** Musical stops, dropouts and the hit that ends a bridge make the best sync points: the
  place to freeze, cut, switch a light off, or change the whole picture;
- every word's time.

## 4. Pitch three looks

Offer three directions and recommend one. For each:

- **the medium** (paper cut, embroidery, marbled paper...) and why it suits this song. The strongest choices mean
  something: marbled paint for a song about water, where nothing stays put; a lantern lecture for a song sung by
  someone lecturing; a desk of files and stamps for a song about a record that doesn't add up;
- **the organizing object:** the one thing the whole video is, such as a desk under a lamp, a hanging read along
  its length, a printed sheet, a painted wagon's panels, a board of pasted-up photographs;
- **a small visual grammar:** a few rules that give the images meaning (stamps are the audience's verdicts, frost
  is the stillness, the camera's date flickers between years), and an **arc** over the song (clean to decayed,
  night to morning, empty to crowded);
- a **section-by-section plan** keyed to timestamps, giving each section one main image;
- the questions still open.

The [styles/](../styles) folder has eighteen engines to start from, and each one's README says what it's good at.
A new song can also want a new medium: the engines share their patterns ([engine-patterns.md](engine-patterns.md)),
so a new one is less work than it sounds.

## 5. Style lab

Draw the same three or four key moments in each candidate look, side by side, as stills (and a few seconds of motion
if the look depends on how it moves). Comparing like with like makes the choice easy, and it shows the problems
early: people who look like mannequins, faces that look ill, a palette that turns cute. Every family here with more
than one look has a lab page (`styles/<family>/lab/`) built this way.

Expect the first choice to be refined: "this look, but with the other one's colours", or "this, for the scenes in the
other world only". Mixing is fine.

## 6. Checkpoint

Build a real section before the whole song: 20-30 seconds of the section that carries the concept, or the first
90 seconds. Render it as an MP4 and get notes on the look, the pace, the figures, the text. This is where most of
the useful notes arrive, and they're cheap to act on now.

## 7. Build the whole song

Section by section. After each, render stills across it (`tools/still.py ... a:b:2 --sheet`) and look at every one:
frame edges, blank frames, things the camera cuts through, text that's unreadable or covered. Fix, then move on.
When it's all there, render the MP4, then scan it at one frame every two seconds.

## 8. Notes, and fixing a stretch

Notes on a full video are usually local: one stretch feels empty, one chorus repeats the last, a transition jerks.
Re-render only that slice and splice it in ([rendering.md](rendering.md#fixing-one-stretch)).

## 9. Deliver an MP4

Share the MP4, not the web page. A browser player's pause and scrub can feel unreliable, and people give up on it.
`tools/render_mp4.py` writes a 1080p file and a smaller 720p one for sending.

## 10. Revising a finished video

A second or third pass (new conventions, a list of fixes, a stretch that needs more going on) works best as: a short
written plan of every change; then before/after sheets, stills from the old render and the new build at the same song
times side by side; then the full render. The sheets let the notes land on exactly what changed. When picking stills
for review, catch short effects at their peak: a flash or a bolt that lasts half a second is easy to miss.

## What the notes taught (true for every style)

- **Busy enough.** Something new on nearly every beat, or at least every line. A stretch with nothing happening
  reads as a mistake, not a rest. When a stretch feels empty, fill it with callbacks (translucent overlays of earlier
  scenes) and background life (children, animals, people passing) rather than restaging it.
- **No long freezes.** A four-second still reads as the player stalling. Keep holds to a beat or two, or keep
  something drifting: a slow camera move, breathing light, smoke.
- **Make small changes obvious.** A face swapping for another face, a detail changing on a paper: if it matters,
  make it big and push the camera in on it. Subtle changes go unseen.
- **Too clean reads as dead.** A video that stays tidy all the way through can feel flat; give it an arc.
- **Vary the repeats.** The second chorus shouldn't replay the first. New scenes, with brief flashes back to the
  first chorus's pictures on key words, keep the echo without the repetition. A motif that does something different
  each chorus (ribbons that knot, then plait, then slip) works well.
- **Whole figures beat close-up hands.** Big silhouettes of hands and arms read as clubs, poles or chess pieces. A
  whole figure, even small and mostly still, carries a beat better.
- **Faces:** realistic halftone or heavy shading can make people look ill. Stylized faces (dot eyes, lowered lids
  when looking down) for close figures and blank faces for crowds read better.
- **What makes a look cute** (sometimes wanted, often not): flat candy fills, rounded sack-shaped figures with blob
  heads, even lighting, bobbing walks. For solemn songs, use weight, texture, uneven light and stillness instead.
- **Real texts make good props.** A period document, a real letter or hymn, an actual map give a scene weight even if nobody
  can read them.
- **Impossible places need ordinary things in them.** Floating or folded land only reads as land when it carries
  trees, lit windows, snow on its ground side, smoke going the "wrong" way.
- **Decide about text in the picture.** A lyric band under the picture is one choice; no readable text at all
  (squiggles for writing) is another; either way, be consistent. Captions that only repeat the lyric are redundant.
- **Fake text is worse than no text.** A card of invented glyphs that flickers reads as a screen of foreign writing.
  Use pictograms, squiggles, or nothing. Likewise on-screen read-outs (temperatures, timecodes) in a "technical"
  medium: keep them only if they mean something.
- **Show the medium working.** When a look risks feeling static (a photograph, a print, a drawing), let the viewer
  watch it being made: a plate exposing, inks printing in on the beats, stitches sewn in, a slide pushed into the
  lantern. It answers "static and unclear" without changing the look.
- **Vary what leads a scene.** In a medium with a life of its own (liquid light, marbling, sand), let some scenes be
  led by the pictures and some by the medium, rather than the same mix throughout.
- **Props must sit in hands.** A rope, a ring, a cloth or a cup that floats near a hand reads as broken. Anchor held
  things to the rig's hand points and check every one in stills.
- **Arms that move naturally:** pose them by where the hand and elbow should be, blend joint angles rather than
  positions, let the forearm trail the upper arm, and add breathing and small weight shifts. Arms that slide
  straight between poses look like a puppet's.
- **Bodies carry identity.** In silhouette, heat or other outline-first looks the outline is all a viewer gets: if
  someone is heavily built, or small and round, the shape must show it. Keep sizes consistent (an animal is as big in
  every shot).
- **Shapes read as other shapes.** A figure lying flat reads as a collapsed body (have them sit or doze upright unless
  a death is meant); a pyramid of sacks in a lit doorway reads as a hooded head; a fan of hair strands reads as a
  feathered headdress. Look at every silhouette as a stranger would.



===== 完整公共规范：docs/timing.md =====

# Timing a song

Everything in a video hangs off the song's clock: the lyric band lights each word as it's sung, pieces land on
beats, scenes change on line starts, the lamp goes out in a dropout. This page is how to get those times. The tools
are in [tools/audio/](../tools/audio); each prints its own help with `--help`.

Setup (once): `pip install -r requirements-audio.txt` (librosa, scipy, faster-whisper, mido). The Whisper model
downloads the first time it's used.

## The pipeline

```bash
# 1. the shape of the song: tempo, loudness, sections
python tools/audio/analyze.py song.mp3

# 2. words with timestamps, from the vocal stem if you have one
python tools/audio/transcribe.py vocals.mp3 --lyrics lyrics.txt --out whisper.json

# 3. your lyric sheet matched to Whisper's words
python tools/audio/align.py lyrics.txt whisper.json --out lines.json

# 4. snap each word to where the voice starts it (vocal MIDI and/or vocal audio)
python tools/audio/snap.py lines.json --midi vocals.mid --audio vocals.mp3 --out snapped.json

# 5. the page's data file
python tools/audio/to_js.py snapped.json --out projects/my-song/lyrics_data.js --title "My Song" \
    --audio song.mp3 --audio-file projects/my-song/song.mp3 --bpm 96 --beats-per-bar 4
```

Then open the video with the lyrics showing and listen through. Fix what's off by editing `lyrics_data.js`
directly: it's plain data.

## Step by step

### 1. The shape of the song

`analyze.py` prints the global tempo and the local tempo every 20 s, a table of loudness, brightness and rhythmic
busyness every few seconds, and guesses at section boundaries. Read it next to the lyric sheet. You're looking for:

- which sections are loud and which drop out: the video's big and quiet moments should follow them;
- tempo changes (a slow intro, a half-time bridge);
- **stops and hits.** `onsets.py song.mp3 --from 140 --to 155` zooms in on a stretch: the strongest onsets, the
  beats, and the loudness every quarter second, so a dropout shows as a run of low numbers. These are the best
  sync points a song offers: the place for everything to freeze, for a cut, for a light to go off.

`sections.py song.mp3 --lines lines.json` compares the sections' loudness, drums and tonal energy once you know
where they are.

### 2. Transcribe

`transcribe.py` runs faster-whisper with word timestamps. Give it the **vocal stem** if there is one; sung vocals
over a full mix transcribe much worse. The `small` model is usually enough and takes about a minute. `--lyrics`
passes the start of your lyric sheet as a prompt, so names and odd words come out spelled your way. `medium` can
rescue mumbled lines, but over a long song it can drift further than `small`.

Expect Whisper's times to run **early**, typically a few tenths of a second and sometimes by more than a second,
and to hear some words wrong, especially names and unusual words. Step 3 doesn't care about wrong words; steps 4 and
the listen-through fix the times.

### 3. Align

`align.py` lines your sheet up against Whisper's words (a sequence match, so misheard or missing words don't break
it; unmatched words get times interpolated from their neighbours). It prints each line with a match count like
`m7/9`. Low counts are where to listen first. Watch for:

- **numbers:** Whisper writes "1974" as one token for three sung words. The script spells out years and small
  numbers before matching, but check them;
- **hyphenated words** and contractions;
- **a misheard last line** ("Let it go" for "Letting go"): the end of a song, over a fade, is where Whisper guesses;
- **repeats and ad-libs** the singer added: put them on the sheet as sung, or they'll be squeezed between
  neighbours.

### 4. Snap to the voice

`snap.py` moves each word to the nearest sung-note onset within 0.32 s: note onsets from the **vocal MIDI** first
(if you have it), then onsets detected in the **vocal audio**. It first reports the median offset between the words
and the onsets; if Whisper ran early across the whole song, pass that back as `--shift` so everything moves before
snapping.

After snapping, some things still need a human ear:

- **line starts that land in silence** or on the tail of the previous word: move them to where the voice comes in;
- **choruses and held notes:** a melisma or a long held word confuses onsets;
- **MIDI quantization:** Suno's MIDI is quantized to sixteenth notes and can sit about 0.3 s off the voice.

For those, `onsets.py vocals.mp3 --from 25 --to 27 --pitch` prints the sung pitch and loudness every 50 ms: the
word starts where the pitch appears and the loudness jumps.

### 5. Write the page data

`to_js.py` writes `lyrics_data.js`, which sets `window.SONG`:

```js
window.SONG = {
  title: "My Song", credit: "", audio: "song.mp3", duration: 212.4,
  bpm: 96, beatsPerBar: 4, firstBeat: 0.35,
  sections: [["verse1", 12.3, 41.0], ...],
  beats: [0.35, 0.975, ...],            // only with --beats: exact beat times
  lines: [{section: "verse1", text: "Who has seen the wind?", t0: 12.3, t1: 14.9,
           words: [["Who", 12.3], ["has", 12.9], ...]}, ...],
};
SONG.beat(n)  // the time of beat n
```

Every style in this repo reads that shape (see [examples/poem/lyrics_data.js](../examples/poem/lyrics_data.js)).

## Beats

For a steady song, `--bpm` and `--first-beat` (the time of the first downbeat) are enough: `SONG.beat(n)` is
`firstBeat + n * 60 / bpm`. Find the first beat with `onsets.py` on the song's opening seconds.

If the tempo drifts or changes, use exact beat times instead:

- **from MIDI stems:** Suno writes a tempo event on every beat, so the tempo map is an exact beat grid.
  `midi.py drums.mid --beats-out beats.json` (any of the song's MIDI files will do);
- **from the audio:** `analyze.py song.mp3 --beats-out beats.json` (librosa's estimate; check it).

Pass the file to `to_js.py --beats beats.json`; `SONG.beat(n)` then reads from the list.

## Hits and loudness

Some styles pulse, flash or move with the music itself rather than the words: a lamp that breathes with the mix, a
ring on every drum hit, mouths that open with the voice. `pulses.py` measures those:

```bash
python tools/audio/pulses.py song.mp3 --percussion perc.mp3 --drums drums.mp3 --vocals vocals.mp3 --out projects/my-song/audio_data.js
```

It writes `window.AUDIO = {fps, ticks, kicks, env, venv, vdb}`: small hits (`ticks`) and big ones (`kicks`) as
`[time, strength]`, the mix's and the voice's loudness 24 times a second (`env`, `venv`, 0..1), and the voice's
loudness in decibels mapped to 0..1 (`vdb`, better for mouths). Stems give much cleaner hits than the mix; without
them everything comes from the mix. The liquid light show reads this file as it is; any style can read the arrays.

## Suno specifics

- The stem download gives an audio file and a MIDI file per instrument. The lead vocal stem transcribes cleanly.
- The MIDI files carry a key-signature event that the `mido` library can't decode (it raises
  `KeySignatureError`). `tools/audio/midi.py` patches mido to read it as C; import `load()` from it in your own
  scripts to get the fix.
- The MIDI tempo map has one event per beat: an exact beat grid, including tempo changes after an intro.
- Vocal MIDI notes are quantized and can sit up to ~0.3 s off the voice: good anchors for snapping, not ground truth.
- Suno ignores dynamics on the lyric sheet ("quiet", "spoken", "almost unaccompanied"). Measure.

## Checking by eye and ear

Open the page, play it with the sound on, and watch the lyric band. Words that light up early are the common
fault. For a close look, `#t25.3` on the page's URL shows the frame at 25.3 s with the band as it is then.



===== 完整公共规范：docs/rendering.md =====

# Previewing and rendering

Every video here is a web page that draws its frames on a canvas. You watch it in a browser while you work, and
when it's done a script steps through it frame by frame in headless Chrome and pipes the frames to ffmpeg. This
page covers the page contract the tools rely on, previewing, stills, MP4s, and fixing a stretch.

Setup (once): `pip install -r requirements.txt` (Playwright, imageio-ffmpeg, Pillow, numpy). The tools drive your
installed Google Chrome; if you don't have it, `python -m playwright install chromium` gets Playwright's own.
imageio-ffmpeg bundles an ffmpeg with x264 and AAC, so there's nothing else to install.

## The page contract

A video page (a style's `index.html`, or a copy of one for your song):

- draws into `<canvas id="film" width="1920" height="1080">`;
- loads its song data as `window.SONG` (see [timing.md](timing.md#5-write-the-page-data)) and plays `SONG.audio`
  in an `<audio>` element, falling back to a silent clock if the audio can't load;
- sets `window.__video`:
  - `ready`: true once everything is built;
  - `duration`: the song's length in seconds;
  - `step(t)`: draw song time `t` the way playback does. The MP4 renderer calls it at 24 fps, strictly in order;
  - `renderAt(t)`: draw a still of time `t` from a fresh state (catching up whatever the frames before it built);
  - either may return a Promise (a page that builds scenes asynchronously); the tools wait for it;
  - `error`: set this to the error text if building fails, and the tools stop and print it;
  - optionally `shots` and `probe(t)` for 3D pages (see `tools/probe.py`);
- shows a still when the URL ends in `#t<seconds>` (e.g. `index.html#t12.5`), with the page chrome hidden;
- draws only while playing: a paused player shouldn't keep redrawing its frame on every animation frame (the tools
  draw and read back each frame in one call, but a page that redraws on its own fights anything else that draws);
- is **deterministic**: all randomness comes from seeded generators keyed to the frame number, never
  `Math.random()` per frame, so a given moment always draws the same picture. An MP4 depends on it.

A style-lab page sets `window.__lab = { ready, scenes, styles, render(scene, style) }`, where `render` draws one
scene in one look and returns the canvas.

## Previewing

```bash
python tools/serve.py            # serves the repository at http://localhost:8000/ and lists the demo pages
```

Open a page from the list. Use this server rather than `python -m http.server` or opening the file directly:

- pages that use ES modules or load files **don't work from `file://`**;
- a plain server lets the browser **cache scripts**, so after an edit you can be looking at the old code. This
  server sends no-cache headers;
- audio and video only seek when the server answers **Range requests**; this one does.

**Stills in the browser:** add `#t<seconds>` to the URL. Changing only the `#` part doesn't reload the page, so
after editing code, reload with a new query (`index.html?r=2#t30`).

**Always check the console** after a load. One bad value in a canvas gradient (a NaN colour stop) throws, and the
whole frame goes blank.

**In Claude Code's desktop app**, the preview pane can run the server for you: create `.claude/launch.json` with
```json
{ "version": "0.0.1", "configurations": [
  { "name": "videos", "runtimeExecutable": "python3", "runtimeArgs": ["tools/serve.py", "8000"], "port": 8000 } ] }
```
(it's git-ignored).

## Stills and contact sheets

```bash
python tools/still.py styles/paper-cut/index.html 5 12.5 30          # three stills
python tools/still.py styles/paper-cut/index.html 0:37.5:2.5 --sheet # a frame every 2.5 s, tiled into one image
python tools/lab_stills.py styles/embroidery/lab/index.html --all --sheet
```

Output goes to `renders/` (git-ignored). The contact sheet is the fastest way to review a whole video: look at every
frame on it, not just the ones you changed. Things to look for: frame edges showing the end of the world, blank or
black frames, the camera inside an object, text covered or cut off, two scenes' seams, something frozen too long.

## MP4s

```bash
python tools/render_mp4.py styles/marbling/index.html                    # renders/marbling.mp4 and -720p.mp4
python tools/render_mp4.py projects/my-song/index.html --out "renders/My Song.mp4"
python tools/render_mp4.py projects/my-song/index.html --start 60 --end 90 --fast   # quick preview of a slice
```

- Two files: 1080p (x264 `slow`, CRF 23, AAC 192k: roughly 5 Mbps for a busy picture) and `-720p` (CRF 25: about
  1 Mbps, small enough to send).
- `--fast` writes only the 720p with the `veryfast` preset. Busy, grainy frames can take many times longer to
  encode with the slow preset than to draw, so use `--fast` for previews and the normal mode for the final.
- The audio comes from `SONG.audio` unless you pass `--audio`. A slice gets short audio fades.
- **Fonts:** the styles load their type from Google Fonts. If a font request fails (a flaky network), canvas text
  silently falls back to a default font, so `render_mp4.py` and `render_frames.py` check the page's fonts after it
  builds and stop if any failed. Run again, or pass `--allow-font-fallback` if you really mean it. The still tools
  print a warning instead.
- 24 fps. Frames are rendered **in order**: many styles draw each frame over the one before (frost that grows,
  ghosting, marbled paint that keeps its history), so a frame can't be drawn on its own.
- Speed depends on the style and on how much the machine is doing: from about 40 ms a frame (paper cut, painted
  enamel, archive desk) to 250 ms or more (sand, the pinscreen, screenprint's printing), including reading the frame
  back and encoding. Each style's README gives its numbers. A four-minute song is 5,760 frames: a few minutes for the
  fast styles, half an hour or more for the slow ones (see the next section for splitting a render across browsers).

## Long renders: frames on disk, resumable, in parallel

For a long song in a slow style, render the frames to a folder instead of straight into ffmpeg:

```bash
python tools/render_frames.py projects/my-song/index.html --dir renders/frames/my-song --jobs 3
python tools/encode.py renders/frames/my-song --out "renders/My Song.mp4"
```

- Frame `i` is `<dir>/<i:05d>.jpg` and shows song time `(i + 0.5) / 24`. Frames already on disk are skipped, so an
  interrupted render continues where it stopped when you run the same command again, and deleting a stretch's
  frames and re-running redoes just that stretch.
- `--jobs N` renders N runs of frames in N browsers at once. Each run starts with `renderAt()` at its first frame,
  which catches up styles whose frames depend on earlier ones, then steps in order. (Tested: a resumed run's frames
  match a straight-through render pixel for pixel.) GPU-heavy styles gain less, since the browsers share one GPU.
- `encode.py` takes the audio from the folder's `meta.json` (the page's `SONG.audio`), cuts it to the frames on
  disk, and writes the same 1080p and 720p files as `render_mp4.py`.
- **A render that sits before its first frame** is usually the machine, not the page: with other renders or heavy
  WebGL pages running, Chrome can take minutes to start or to build a page. `render_mp4.py` prints the page's URL when
  it's loaded and a progress line every 240 frames.
- **Heavy 3D pages:** building every set of a long WebGL video at once can hang the GPU. Render such a video in
  segments (`--start`/`--end` runs into the same frame folder, each run building only what its stretch needs), and
  on a machine that other renders are sharing, run one segment at a time.

## Fixing one stretch

A full render can take a while. To fix one stretch, render only that slice at full quality and splice it into the
finished file at whole frames:

```bash
python tools/render_mp4.py projects/my-song/index.html --start 120 --end 135 --out renders/fix.mp4
python tools/splice.py "renders/My Song.mp4" renders/fix.mp4 --at 120 --out "renders/My Song v2.mp4"
```

A slice opens with `renderAt(t)`, which catches up styles whose frames build on earlier ones, so its frames match the
full render's and the splice is seamless.

## Checking a 3D video's framing

`python tools/probe.py styles/diorama/index.html` asks the page, for the start, middle and end of every shot,
whether anything stands between the camera and its subject, or whether the camera is inside something. In a crowded
set it finds blocked views much faster than contact sheets.

## Sharing

Share the MP4. If you also want a review page (the video with notes around it), keep in mind that some hosts cap
file sizes: split a long 720p video into parts at scene changes and play them in sequence against the song, and
serve it from something that answers Range requests.



===== 完整公共规范：docs/your-own-video.md =====

# Making a video for your own song

The hands-on steps, from an mp3 to an MP4. For the creative side (what to decide before building, how to pick a
look) see [workflow.md](workflow.md). If you're working with Claude Code, you can just ask it to make a video for
your song: [CLAUDE.md](../CLAUDE.md) walks it through all of this.

## 1. Set up

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt            # rendering
pip install -r requirements-audio.txt      # timing a song (Whisper, librosa, MIDI)
```

You need Google Chrome installed (or run `python -m playwright install chromium`).

## 2. Start a project folder from a style

Pick a style from the [gallery](../README.md#the-styles) and copy its folder:

```bash
cp -r styles/paper-cut projects/my-song
cp ~/Music/my-song.mp3 projects/my-song/song.mp3
```

Audio files are git-ignored, so your song stays out of the repository.

In `projects/my-song/index.html`, change the lyrics script from the demo's
```html
<script src="../../examples/poem/lyrics_data.js"></script>
```
to your own
```html
<script src="lyrics_data.js"></script>
```
(Relative paths from `projects/my-song/` resolve just as they did from `styles/<style>/`, so anything else the
page loads from the repo keeps working.)

## 3. Time the lyrics

Write the lyric sheet (`projects/my-song/lyrics.txt`, one sung line per line, `#section` markers), then run the
pipeline in [timing.md](timing.md). It ends with `projects/my-song/lyrics_data.js`.

## 4. Look at it

```bash
python tools/serve.py
```

Open `http://localhost:8000/projects/my-song/index.html`. The demo's scenes now play under your lyrics for as long as
the demo lasts. That's the moment to decide the plan: which scene goes where, which line lands on which image.

## 5. Replace the demo's scenes with yours

Every style's README has a "Make your own video in this style" section that says which files are the demo (its
scenes, sets, shots or timeline) and which are the engine. Keep the engine; rewrite the demo files. Work a section
at a time:

```bash
python tools/still.py projects/my-song/index.html 30:60:2 --sheet   # stills every 2 s across 0:30-1:00
```

Look at every still on the sheet. Check the console output printed at the end.

## 6. Render

```bash
python tools/render_mp4.py projects/my-song/index.html --start 30 --end 60 --fast   # a quick 720p preview
python tools/render_mp4.py projects/my-song/index.html --out "renders/My Song.mp4"  # the final, 1080p + 720p
```

To fix one stretch later without re-rendering everything, see
[rendering.md](rendering.md#fixing-one-stretch).



===== 完整公共规范：docs/engine-patterns.md =====

# How the engines are built

The eighteen engines in [styles/](../styles) share no code at run time: each folder is self-contained, written for one
song in one medium (a few began as copies of another's files, such as the 3D pipeline or the ray-marched figure). But they
share a shape, and knowing it makes any of them easy to read and a new one quicker to write. This page is that
shape, plus the browser gotchas that cost the most time.

## Simulate the process, not the look

Each engine models how its medium is physically made, and the imperfections come out right on their own:

| medium | what the code does |
| --- | --- |
| screenprint | each ink is a stencil mask plus a halftone; inks are pulled one at a time and multiplied onto paper, each a little out of register, with squeegee streaks and pinholes |
| linocut | a block is a list of gouge cuts and inked areas; the key block prints black over watercolour washes |
| wool embroidery | wool is laid and couched from tiles, outlines are stem-stitched, light is couched gold thread |
| marbled paper | paint floats as closed outlines on a bath; drops, combs and swirls are exact maps applied to every point |
| magic lantern | slides are baked as tinted glass; a frame stacks glass by multiplying and throws it through a lens |
| painted enamel | two-colour bristle strokes with a highlight flick toward the light, then gold leaf |
| paper cut | cut shapes with a lit rim and a soft shadow, layered in depth and lit from behind |
| mosaic | tesserae are laid in rows along the outlines, then grouted |
| sand on a lightbox | sand thickness is a density field; the lamp shows through as `exp(-k * thickness)`; fingers clear lines |
| carved diorama | each piece is a signed-distance sculpture meshed in the browser; tool marks are a bump in the piece's own space |
| photomontage | photographs are painted in greys, then given a print's grain, halation and tone curve, and cut out with drifting scissors |
| pinscreen | a field of pins at different heights, lit from a low angle, each pin's shadow falling on the next |
| archive desk | every paper is pre-rendered with its shadow, grain, foxing and torn fibres; stamps are inked, then eroded |
| night poster | a shape's shadow is the band a shifted copy of it fails to cover; night mixes colours toward navy while lamps keep their brightness |
| batik | a real 3D set lit by two coloured lamps is rendered into buffers; wax resists where both lamps reach, each dye takes where only one does, and the wax cracks |
| long-exposure glass plate | each frame integrates many light drawings over the exposure, so whatever moved is a smear and whatever stood still is sharp; then halation, dust and the emulsion's edge |
| silverpoint | even hatching whose weight follows the tone; lines can't be erased, and tarnish from grey to brown with age |
| carved relief | the scene becomes a height field, shaded by a raking light with its own cast shadows |
| liquid light show | oil, water and dye in a dish on a projector: warped-noise dye bands, metaball oil drops with a meniscus, and drawn transparencies whose black ink really blocks the lamp |
| thermal camera | a scene rendered as temperatures and mapped through a camera palette, with a thin visible-light edge overlay, warm breath and fading heat prints |
| showboat stage | painted flats given brushwork by a sampled-stroke pass, lit by a light map in which the actors are lit through their own silhouettes |

A filter that makes a clean digital picture look like linocut never convinces for long. A few rules about how the
real thing is made go much further.

## One frame

Almost every engine's frame function looks like this:

```
renderFrame(t):
  shot = the shot covering t
  set  = shot.set, baked on first use           (the still layers: land, buildings, background)
  cam  = shot.cam(t)                            (keyframed, eased)
  draw the set's layers through the camera       (parallax: nearer layers move more)
  draw what moves at t                           (figures, props, light, weather)
  post: light (a multiplied lamp or light map), grain, vignette, the medium's texture
  if t is inside a transition: draw the next shot too and mix (dissolve, wipe, push)
  the lyric band / margin / caption for t
  fade in and out at the ends
```

The canvas is 1920x1080. Several styles keep the picture above a band for the lyrics (e.g. 1920x960 + 120).

## Sets, shots, cameras

- **Sets** (or scenes, worlds, plates) are places. Their still parts are drawn once into offscreen canvases the first
  time they're needed ("baked"), then only composited. Keep a memory budget: the whole song's sets rarely fit at
  once, so drop the least recently used. Bake at load what the first seconds need, so playback doesn't hitch.
- **Shots** are stretches of song time: `{t0, t1, set, cam, ...}` plus a function that poses what moves.
- **Camera keys** are `[time, x, y, zoom, ...]` with easing between them. Two useful rules:
  - push in with **lens zoom**, not by travelling into the layers: depth travel blows the nearest layer up (snow
    becomes moons);
  - **never let the camera see past the edge** of what's drawn. Check the frame corners on every new camera.
- **Transitions:** dissolves, drop wipes (a new picture spreading inside a drop), push and pull (from a room to the
  picture on its screen), panels (pull back to a page of panels, push into another), re-laying one medium as another
  past a moving line.

## Time: on twos, and in step with the song

- Hand-made animation moves **on twos**: pose changes at 12 fps inside 24 fps video. Several engines step motion at
  12 fps (`tm12 = Math.floor(t * 12) / 12`) while the camera moves at the full 24, which keeps the hand-made feel
  without a juddering camera. Texture "boil" (grain, ink noise) often changes at 8 fps.
- **Ease into fast moves**, or drive them with real time: a move that starts at full speed jumps at 12 fps.
- **Hits on beats, changes on lines.** `SONG.beat(n)` and each line's `t0` and word times are the anchors. A word
  lighting in the lyric band typically fades up over `[t - 0.04, t + 0.16]`.
- **Keep something moving.** A hold longer than a beat or two reads as the player freezing. A slow drift, a breathing
  light or drifting smoke keeps a still picture alive.

## Determinism and frame-to-frame state

- All randomness comes from seeded generators (`mulberry32(seed)`) and noise keyed to the frame number. Never call
  `Math.random()` while drawing a frame. The same `t` must give the same picture, or an MP4 won't match what you
  checked.
- Some styles **carry state from frame to frame**: frost that grows, ghosting of the previous frame, a charcoal
  drawing that's erased and redrawn, marbled paint whose outlines remember every comb. Those must be stepped in
  order. `renderAt(t)` then means "rebuild the state from the start of this scene up to t", and each engine's README
  says how it does that.
- When a view steps backwards in time (a camera effect that holds frames, a scrub), keep what's already baked rather
  than rebuilding it from scratch each step, or rendering crawls.

## Figures

- **Whole figures**, posed. Every engine has a rig: jointed silhouettes, contour-drawn people, ray-marched signed
  distance bodies, carved 3D pieces. Most use **two-bone IK** for arms (and often legs), so a hand can be put exactly
  on a rope, a cup or another hand. Each rig spells it its own way: `reachArm()` in paper cut, an arm given as
  `{t: [x, y]}` in embroidery or `{at: [x, y]}` in painted enamel; the style READMEs show how.
- Build **every figure of a kind from one model**, so its anatomy is the same in every shot; vary only pose,
  clothing and age.
- Things that make figures read wrong, all hit at least once: round heads read as teddy bears (give them a muzzle
  or a jaw); coats that hang along the body turn a crouching figure into a plank (hang them toward world-down);
  digitigrade legs with a long stride look like sitting on a stool; two figures leaving the same way merge into one
  blob; close-up arm silhouettes read as clubs or poles.

## Light

- A **lamp** is a radial gradient drawn with `multiply` (or a light map multiplied onto the whole picture). Its
  warmth and brightness carry most of a scene's mood.
- **Self-lit things** (flames, lit windows, glowing marks) go in their own layer drawn after the light map, plus a
  glow. A reflective shape in front should erase the self-lit layer behind it.
- On pale paper, `screen` adds almost nothing; `soft-light` plus a weaker `screen` shows coloured light.
- Glass only darkens: a moving piece has to pass over light glass, or it vanishes.

## Text in the picture

- Load fonts before drawing and wait for them (`document.fonts.load(...)` for each face and script you use), or text
  falls back to a default font. `document.fonts.load` resolves even when the font never arrived, so check the
  result (or `document.fonts.check(...)`) before building. Put `<meta charset="utf-8">` at the top of the page for
  any non-ASCII text.
- **Start building only when every script has loaded** (`DOMContentLoaded`, or put the start call at the end of the
  last script). A build started from a font promise plus a short timer can win the race against later scripts when
  the fonts come from cache, and the page fails to build only sometimes.
- Keep the lyrics readable: if the camera zooms, keep the text out of the zoom (a band or margin drawn in screen
  space).

## Browser gotchas that cost hours

- **One bad gradient value kills the frame.** `addColorStop` with a NaN or an out-of-range offset throws, and nothing
  after it draws. Check the console after every change.
- **`destination-out` uses the current fill's alpha.** A fill left translucent from the last wash only half-erases.
  Set `fillStyle = '#000'` before erasing.
- **`[hidden]` loses to `display: grid`.** Add `.gate[hidden] { display: none }` for overlay elements.
- **Globals collide.** Plain scripts share one global scope; a helper named like an existing function (`hand`,
  `line`) silently replaces it.
- **Tiling seams:** a texture tiled from a sampled corner shows seams on big pieces; downsample the whole texture.
- **WebGL:** GLSL has reserved words you'd never guess (`patch`); creating a texture while another is bound can
  overwrite a texture unit (create textures on a scratch unit such as TEXTURE15); a three.js `InstancedMesh` keeps the
  bounds of its first draw unless `frustumCulled = false`.
- **Headless loads:** wait for the page with `wait_until='commit'` and your own ready flag; a page that builds a lot
  at load can time out waiting for the load event.
- **Grain that changes every frame bloats the MP4.** Change it on twos.

## Starting a new engine

1. Copy the style closest to what you want. Keep its player (`index.html`, the playback and `window.__video` parts
   of its engine) and its lyric code.
2. Write the medium: the few functions that turn a shape into your medium's marks. Test them on stills first, on a
   page that just draws one scene (a lab page).
3. Draw the same key scenes in your medium and in one or two alternatives. Choose.
4. Then sets, shots and the song.



## 原作者媒介陷阱与经验摘录

## Lessons and gotchas

- **Night by mixing, not by hue.** Darkening by rotating hue toward blue turned cream walls red. Mix toward navy and
  lower the lightness instead, and mark lights as emissive so they keep their brightness.
- **Pale props shift hardest at night.** A pale blue blanket went royal blue under the night transform and a cream
  one went mustard; a cream house front came out ochre. Check pale things in the night look, pick them a little
  greyer, and give each night scene its own tint (the street and the house mix every colour toward the hour's tint
  before the Painter's night transform).
- **Day needs its own palette.** Mixing everything toward cream read as washed out and too close to soft shapes.
  Richer mid-tones and cool violet shadows fixed it, with the scene supplying its own colours for the hour (sky, a
  tint, which windows are lit) and the Painter doing the rest.
- **Keep the sky.** A tall building or big trees filling the top of the frame hid the sky, and in a poster the sky
  carries the hour. Three trees in the street, not five.
- **A tree that bends on a circular arc only slides its crown sideways.** To read as bowing, bend more toward the top
  (the angle at height s is `bend * s^1.9`), let the crown stream out downwind, and make the bend grow faster than
  the wind, so a breeze is a lean and a hard gust a bow.
- **Don't multiply time by a rate read from the wind.** Clouds drifting at `t * speed * wind(now)` raced across the
  sky as a gust arrived and ran backwards as it died down, and smoke, washing and a windmill driven the same way
  skipped. Anything that accumulates (a drift, a phase, an angle) needs a steady rate or the wind integrated over
  time (`buildDrift` does that for the leaves); the wind's strength can still set a bend, a lean or an amplitude.
- **Rim lights are in scene pixels.** A fixed width looks fat on a small figure and in a close-up; scale it to the
  figure (`w: fr.s * .1`). Aim it from the lamp to the figure, and it moves as they walk past.
- **Smoke puffs spaced wider than they are big look like beads.** Overlap them, and let the wind lay the plume over
  rather than stretch it.
- **Cloth is a flag.** A tumbling rounded rectangle read as a cushion. Draw it pinned along one edge with waves
  running out to the free end (`flag`).
- **Elbows.** Solving the elbow from the hand with a fixed side put a resting arm's elbow up in the air, and a
  resting figure's arms crossed in an X. `bend: 'down'` picks whichever elbow hangs lower, which suits a relaxed
  arm; for a pose that matters (resting on a table, hands on hips, arms hanging straight) give the elbow as well.
- **Blend arm poses by turning each bone**, not by blending positions: a straight blend shrinks the arm mid-move
  (`armBlend`). Targets solved by `limbArm` keep bone lengths anyway.
- **Two hands near the face read as someone holding their head.** When a figure holds something overhead, put the
  hands clear above the head.
- **Hair on a head lying down** read as a ball, then as leaves: draw it falling back from the forehead and spreading
  along the pillow.
- **A general figure's defaults must lose to the garment's own.** A shared hem default made every coat hip-length,
  and a sleeve default made sweaters short-sleeved; `figPerson` looks a garment's hem and sleeves up by its kind.
- **Figures are flat at their own depth.** A hand drawn at the figure's depth can't rest on a desk top nearer the
  camera; aim it at the thing with `bodyPt`, or slightly below the surface's height. Draw someone standing behind a
  desk before the desk, so it hides their legs.
- **Side walls barely show** from a camera looking down a room: posters there must sit near the back wall to be in
  shot. And props placed in front of the camera's near plane land huge or off the edge.
- **Capsules and arcs.** An arc drawn the long way round left circles at every elbow; `capsule()` draws both ends the
  short way.
- **Splitting points into several paths:** choose the path once per point and use it for both `moveTo` and `arc`, or
  snowflakes and flowers get joined into huge triangles.
- **A curve that must continue a path** (a panel outline made of two seams) needs `curve(..., path, true)`, which
  starts with a line instead of a new subpath.
- **Panels peek in.** Full-frame views showed the neighbouring panel at an edge where a seam bulges. Close views are
  now clamped inside their panel (`SEAM_M`); a view that does show a neighbour must show its seam line too (a
  neighbour without a seam line looks like a glitch), which is why seam lines are drawn whenever they're on screen,
  slides included.
- **Seams in one path.** Stroking each seam separately let the second seam's dark edge cut across the first one's
  light line where they cross; all of a page's seams are stroked as one path.
- **Page seams go under insets.** Drawn after the inset, a page seam crossed over the inset's picture.
- **Clip panels to the page.** A panel draws its whole scene larger than itself; at a page's outer edge nothing
  clipped it, and once the camera pulled back past the page (onto a backdrop) the scenes showed ragged edges.
- **Fading a scene.** A scene drawn at partial alpha shows its own shapes through each other (the sky through the
  houses). Fade whole pictures instead: a panel below `thumbBelow` is a picture, and a scene's later `layers` are
  drawn whole into a buffer and laid over. A shape's own `alpha` multiplies with the context's, or a dissolve drops
  the shapes that set one.
- **The building finale.** The panels came back in the windows whenever the camera passed that zoom again, until
  their fade was tied to time as well as zoom (`t < 33 ? 1 : ...`); and a backdrop that only drew when zoomed out
  blacked out a push back into it. The engine draws the backdrop whenever the view reaches past the page or the
  panels have faded. Keep the pull-back's speed even through the fade: an eased-in-and-out key on each side of it
  stops the camera there, so use `'in'`, `'lin'`, `'out'` with zooms chosen so the speed carries across the keys.
- **A scene drawn small inside its panel** (a wide view of somewhere) left hard edges where its hills stopped: run
  its ground and sky past the frame.
- **Compose an inset for the part its seam uncovers,** and don't time anything important under it: an early inset put
  its figures behind its seam, and an action landed while the inset still covered it.
- **A curve through too few points overshoots** (a line looping past where it should stop): add points.
- **Don't mutate what `tween` returns:** before the first key and after the last it hands back the key's own array.
- **One bad value in a gradient blanks the frame.** Check the console after every load; the still tool prints it.
- **Stale scripts:** serve with `tools/serve.py` (no caching), and reload with a new query after an edit.
- **Nothing still for long.** A hold of more than a beat or two reads as the player freezing; keep a camera drift,
  clouds, smoke or leaves moving through every held shot.


