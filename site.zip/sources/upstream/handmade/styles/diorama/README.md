# Carved diorama

Carved and painted pieces on a relief-map table, in real 3D (three.js). Every piece is a signed-distance model
(a tree, a figure on its stand, a mill, a boat) meshed in the browser when the page loads, so there are no
model files at all. The carving is in the shading: each material adds tool marks and wood grain as a bump in the
piece's own space, and fades that detail out when it gets smaller than a few pixels, so it never sparkles. The
board is a painted relief map with inked contour lines, standing on a walnut table in a dark room, under one lamp
that is keyed from the camera's upper left in every shot. Ambient occlusion, a shallow depth of field (the
miniature look), a little bloom and a warm-and-cool grade finish it. Pieces move on twos, twelve steps a second,
like stop-motion, while the camera glides; a figure walks by swapping between meshed poses, the way a stop-motion
puppet is re-posed, or is meshed afresh for every step from keyframed poses (`Actor`). The demo is a gusty day by
the sea: the wind is never seen, only the things it moves.

![A cloaked figure stops at a garden gate; washing on the line and a mill turning beyond](img/hero.jpg)

| | |
|---|---|
| ![The whole table under the lamp](img/table.jpg) | ![Leaves blown off a tree toward the washing line](img/leaves.jpg) |
| ![A boat heeling among rows of carved waves](img/boat.jpg) | ![A row of trees bowing as a gust runs along it](img/trees.jpg) |

This family has one look. The model lineup (`index.html?check=lineup`) shows every piece in the kit:

![Every model in the kit, in rows on the bare table](img/models.jpg)

## Run the demo

```
python tools/serve.py
```

Then open http://localhost:8000/styles/diorama/index.html and press Play (or Space). The page has to be served
(ES modules and module workers don't run from `file://`); `tools/serve.py` also stops the browser caching old
scripts. It plays live, but not at full speed: each 1920x1080 frame takes 40-90 ms on an Apple M4, so the player
shows 11-24 frames a second. It picks frames by the audio clock, so it drops frames rather than drifting out of
time, and since the pieces only step 12 times a second it still reads; render an MP4 to share it. The first load
takes 13-50 s while a pool of workers meshes the pieces; the label in the corner says what it is building.

- `index.html#t12.5` shows a still at 12.5 s (the player is hidden, the canvas fills the window).
- `index.html?check=lineup` plays the model lineup instead of the film (six 1-second views; `#t5.5` is the overview).
- `index.html?check=poses` plays a figure posed from keyframes (three 2-second views: it walks, stops, looks up and
  waves, then leans into the wind; `#t3.4` is the wave). See "Posing a figure from keyframes" below.

Stills and MP4 (from the repository root):

```
python tools/still.py styles/diorama/index.html 2 6 12.5 0:37.5:2.5 --sheet
python tools/render_mp4.py styles/diorama/index.html --fast
python tools/probe.py styles/diorama/index.html
```

A `--fast` 720p render of the 37.5-second demo takes about 80 s here: a 13 s load, then 900 frames
at 0.075-0.1 s each, including reading the canvas back. `probe.py` lists shots where something stands between the
camera and its subject.

## How it works

`index.html` loads EB Garamond, an import map for three.js 0.170 from jsDelivr, the song timing
(`../../examples/poem/lyrics_data.js`, which sets `window.SONG`), and then `engine.js` as a module. Everything else
is imported from there.

| File | Job |
|---|---|
| `engine.js` | Renderer and passes (render, GTAO ambient occlusion, bokeh depth of field, bloom, grade, output), shot playback with cuts, dissolves and fades, the lyric band, the player, and `window.__video`. |
| `sets.js` | The sets a shot can name: `{ hill, lineup, poses }`. |
| `sets/hill.js` | The demo board: its relief and painted map, the pieces on it, the wind, and `pose(t)`, which sets every piece for song time t. |
| `sets/lineup.js` | A check set: every model in rows, with its own six shots (its meshes merged with `mergeStatic`). |
| `sets/poses.js` | A check set: one figure posed from keyframes with an `Actor`, three shots. The example to copy. |
| `shots.js` | The shot list. |
| `shotkit.js` | Helpers for shots: easing, `twos`, beat and word times, points on the board, `orbit` cameras, walking and toppling pieces. |
| `models.js` | Every piece as a signed-distance model, and the colour table. No three.js here, so the workers can import it. |
| `sdf.js` | Signed-distance modelling and the mesher (block-sparse surface nets). |
| `mesher.js` | The module worker: builds one model and meshes it. |
| `pieces.js` | `need()`: sends mesh requests to a pool of workers and returns three.js geometries; `needOne()` and `assign()` for meshes made on demand. |
| `mats.js` | The carved materials, and canvas-texture helpers (a seeded random, walnut). |
| `world.js` | The room's reflections, the table, the lamp, projector lights, relief boards and their painting, backdrops. |
| `kit.js` | Helpers for building sets: placing pieces, paths, threads and ropes, textures, a registry of named objects, `keyLamp`, `Actor` with `keyed` and `blend`, `mergeStatic`. |
| `paper.js` | Canvas textures for papers in an invented script (ledger pages, handwritten and typed sheets). |

### Modelling and meshing

A model is an ordered list of operations on primitives, each with a smooth-blend radius `k` and a colour:

```js
const M = new Model();
M.add(P.cyl([0, 6, 0], 0.25, 6), { col: C('iron') });                                // a post, 12 tall
M.add(P.box([0, 12.5, 0], [0.6, 0.5, 0.6], 0.1), { k: 0.1, col: C('brass'), mat: 1 }); // metal lamp head
M.sub(P.box([0, 12.5, 0], [0.45, 0.35, 0.8], 0.05), { k: 0.02, col: C('lit'), mat: 2 }); // glowing windows
M.paint(P.fn((x, y) => y - 1), C('dark'), { soft: 0.2 });                              // colour only: below y = 1
return { model: M, bounds: autoBounds(M, 0.3) };
```

- Primitives (`sdf.js`, `P`): `sphere(c, r)`, `capsule(a, b, r)`, `cone(a, b, r1, r2)` (a round cone), `ellipsoid(c,
  radii, M)`, `box(c, halfSize, round, M)`, `cyl(c, r, halfHeight, round, M)`, `torus(c, R, r, M)`, `plane(p, n)`,
  `slab(p, n, w)`, `shell(prim, out, clip)` (a raised band, for straps), `bumpy(prim, amount, noise)` and `fn(d,
  boundingSphere)` for anything else. `M` is an optional 3x3 rotation (`rx`, `ry`, `rz`, `m3m`).
- `Model`: `add`, `sub`, `inter` and `paint`. Colours are 0-1 sRGB; `mat` 1 makes a part metal, 2 makes it glow;
  `rough` nudges the roughness. Where two parts meet, colour and roughness blend across the smooth seam, but the
  material code is taken from whichever part wins at each point, and it reaches the shader as a `flat` varying (one
  code per triangle): a code blended between plain (0) and glow (2) would pass through metal (1) and half glow.
- `meshModel(model, bounds, h)` meshes it with cells `h` wide, evaluating the field only in 4-cell blocks near the
  surface and only over the operations whose bounding spheres reach each cell. Normals come from the field, and a
  little patina is baked into the hollows as darker vertex colour.
- A model function takes `(params, h)` and returns `{model, bounds}`; `MODELS` maps names to them. Sizes are in
  table centimetres: a tin figure stands 4.8 tall at scale 1 (the demo scales its people up to about 7). Figures
  face +z, stand with their base top at y = 0 (the tin stand is 0.14 deep, the carved base 0.28) and take pose
  parameters (`stride`, `lean`, `headYaw`, `headPitch`, `armL: {fwd, out, bend}`, ...).
- `need({ name: [type, params, h], ... })` resolves to `{ name: BufferGeometry }`. Identical requests share one
  mesh. `h` is the main cost knob: 0.03 for a figure seen close, 0.05-0.09 for trees and buildings, 0.2 for big
  smooth shapes like clouds and waves.

The kit: figures (`tinFigure`, a painted tin townsperson in a long coat and a hat or headscarf, who can stride, lean
into the wind, look up, carry a staff and wear a cloak that streams in the wind; `hoodedFigure`, stout and bundled,
with a child, lantern, seated and packs), `sheep`, trees (`trunk` and `crown` as two pieces so a tree can bend,
`spruce`, `cypress`, `grassTuft`, `leafChip`), buildings (`cottage`, `windmill` with separate `sails`, `house`,
`shelter`, `storefront`, `gatehouse`, `palisade`, `doorway`, `canopy`, `pillar`, `island` for floating land) and
props (`garment` in four kinds and any billow, `linePost`, `fence`, `gardenGate`, `boat`, `waveRow`, `kite`, `bow`,
`puff` of smoke, `cloudBank`, `vanePost` and `vaneArrow`, `sled`, `sack`, `cabinet`, `chair`, `cairn`, `lantern`,
`door`, `banner`, `longTable`, `car`, `pole`, `ledger`, `bridge`, `trinket`, `crate`, `gateLeaf`).

### Materials

`carved(kind, o)` (in `mats.js`) is a `MeshStandardMaterial` patched in `onBeforeCompile`. It takes the colour from
the mesh's vertex colours and adds a procedural surface in object space, so the marks stay put when a piece moves:
`carveH` is a bump (tool marks, grain, pores) and `carveC` a colour grain. Each feature of frequency f is multiplied
by `L(f)`, which goes to zero before the feature gets smaller than about three pixels. The kinds are `bone`,
`wood`, `antler`, `stone`, `soap`, `cloth`, `paint` and `snow`; `kit.js`'s `mats()` makes one of each. `surfaced()`
does the same for ordinary textured geometry (the table, the board). `FROST` holds shared uniforms for frost
spreading from a point and for painting a snowy board as bare earth; the demo leaves them off.

### Sets

A set is an async function that returns an object:

```js
import { THREE, mats, place, keyLamp } from '../kit.js';
import { table, lamp, board, paintFields } from '../world.js';
import { need } from '../pieces.js';
const twos = (t) => Math.floor(t * 12) / 12;

export async function buildPond(ctx) {
  const M = mats(), s = new THREE.Scene();
  s.background = new THREE.Color(0x0a0908);
  s.add(table({ w: 600, d: 400 }));
  const B = board({ w: 120, d: 80, at: [0, 0.6, 0], height: (x, z) => 2 + Math.sin(x * 0.05),
    paint: (g, W, H, api) => paintFields(g, W, H, api) });
  s.add(B);
  const hy = (x, z) => B.userData.height(x, z);                  // ground height at a board point
  const G = await need({ bush: ['crown', { seed: 4, r: 4, hgt: 5 }, 0.08],
                         walker: ['tinFigure', { hat: 'cap' }, 0.03] });
  place(s, G.bush, M.wood, -20, 0, { y: hy(-20, 0) });
  const walker = place(s, G.walker, M.paint, 0, 10, { y: hy(0, 10) + 0.14 });
  const L = lamp({ intensity: 3.4, far: 600 }); s.add(L, L.target);
  return {
    scene: s, ap: 0.001, exposure: 1.0,
    pose(t, shot, cam) {                                          // called before every render
      keyLamp(L, shot, 150, null, cam);
      walker.position.x = twos(t) * 3;                             // on twos: 12 steps a second
    },
  };
}
```

`pose(t, shot, cam)` must set everything that moves from `t` alone. The demo's `hill.js` drives it all from one
wind field, `wind(x, z, t)`: a breeze plus gust fronts (`GUSTS`, each `[time it crosses x = 0, strength, width]`)
that sweep across the board toward the land at 60 cm/s. Trees bow at the trunk's foot and again at the crown's
pivot; 260 leaf chips on the big tree tremble on their stalks (an `InstancedMesh`, placed by marching the crown's
distance field); 60 leaves are released in the gusts on flights worked out at load; grass tufts lean; the mill's
sails turn by the integral of the wind; washing lifts and swaps between three billow meshes; the gate swings; smoke
puffs stream off the chimney; the kite flies a figure of eight; rows of carved waves rock out of step like a theatre
wave machine, and the boat heels. The walker swaps between four walk meshes and four standing ones.

Optional set fields: `O` and `pieces` (named objects, used by `probe`), `ap` (aperture), `exposure`, `bloom`,
`bloomThreshold`, `vignette`, `envIntensity`, and for a check set `shots`. `pose()` may return a Promise (see the next
section).

### Posing a figure from keyframes

Swapping between a few meshed poses (the walker's four walk frames and four standing ones) is quick and reads as
stop-motion, but only those poses exist. An `Actor` (in `kit.js`) is meshed afresh for every step it's given, so a
figure can move through any pose, blended from keyframes, twelve steps a second:

```js
import { Actor, keyed } from '../kit.js';
const A = new Actor(scene, 'tinFigure', { hat: 'cap', coat: 'coatCamel', cloak: true });   // what never changes
A.mesh.scale.setScalar(1.5);
const KEYS = [[2.0, { wind: 0.3 }],                                                         // [song time, pose]
              [2.6, { headPitch: -0.5, headYaw: 0.35 }],                                    // looks up
              [3.1, { headPitch: -0.45, headYaw: 0.35, armR: { fwd: 2.7, out: 0.25, bend: 0.15 } }]];
// in the set's pose(t): place A.mesh, then
return A.at(t, (tt) => keyed(tt, KEYS));
```

- `keyed(t, keys)` eases (smoothstep) between the two keys around t with `blend(a, b, u)`: numbers and arrays
  interpolate, objects blend key by key, and anything else (a hat, a colour) switches at the midpoint. A value a key
  leaves out blends from its default in `POSE_DEF` (tinFigure's own), so it eases back instead of jumping.
- `A.at(t, poseAt)` rounds t to twos, asks for that pose (`A.set(pose)`, which meshes it at the front of the worker
  queue if it's new) and meshes the next six steps ahead. It returns a Promise; `pose()` returns it, and `step()` and
  `renderAt()` wait for it, so renders and stills show exactly the pose asked for. The live player doesn't wait: a
  figure keeps its last pose until the new one is ready. The last pose asked for always wins, even when an older one
  finishes meshing later.
- The meshes come from `needOne(type, params, h, urgent)` in `pieces.js`: a cache of recent poses that drops the
  oldest ones no mesh is showing (`assign(mesh, geometry)` keeps count), and never drops a set's own pieces. Poses
  are rounded to four places so a pose asked for twice is meshed once.

`sets/poses.js` is a complete example (`index.html?check=poses`): a procedural walk for two seconds, then keyframes.

### Merging static meshes

Every mesh is a draw call in every pass that draws the scene. A set with hundreds of small pieces that never move
(fence rails, stones, a street of houses) draws faster merged: `mergeStatic(group)` bakes the meshes under `group`
into one mesh per material, shadow setting and vertex layout. Only merge what never moves, hides or changes (a
merged piece can't be posed, and `probe` can't name it). The lineup merges its whole table this way (from 172-277
draw calls a frame to 44-53).

### Shots and the camera

A shot is a plain object. From the demo:

```js
{ t0: 11.25, t1: 18.75, set: 'hill', ap: 0.0016, lampD: 150, lampFollow: true, breath: 0.2,
  cam: [[11.25, [42, 22, 54], [60, 19, 24], 28],    // [time, camera position, look-at point, fov]
        [14.3,  [40, 21, 52], [58, 18, 24], 28],
        [18.75, [6, 15, 50],  [24, 10, 14], 30]],
  focus: (t) => { const u = sm(14.3, 18.75, t); return [55 - 33 * u, 19 - 9 * u, 31 - 15 * u]; } },
```

- `cam`: keys the camera eases between (smoothstep per segment; `linear: true` for constant speed), plus a slow
  `breath` (cm) so no shot sits dead still.
- `focus`: the depth-of-field focus point, fixed or a function `(t, S)`; default the look-at point. `ap` is the
  aperture (0.0004 for a whole table, 0.0015 for a close-up), `maxblur` caps the blur.
- `fadeIn`, `fadeOut` (seconds, with `fadeFrom` / `fadeTo` for how much picture shows at the ends), `black`,
  `dissolve` (cross-fades from the previous shot, drawing both).
- `exposure`, `bloom`, `vignette` override the set's.
- `fn(t, S, u, shot)`: anything extra, after `pose()`. The demo's first shot brings the lamp up on the first beat.
- Keys the demo's `pose()` reads: `lamp` (the lamp's target), `lampD` (distance), `lampAngle`, `lampI`,
  `lampFollow` (key the lamp from the camera as it moves, rather than from its first key), `keyOff`, `keyEl`,
  `lampPos`, `cloudI`, `hemiI`.

`shotIndex` finds the shot for a time by `t0`, so shots must be sorted and should cover the song.

### The lyric band

The picture is 1920x960; the band is the 120-pixel strip beneath it. During the intro it shows `SONG.title` in
italics and `SONG.credit` in spaced capitals; then each line of `SONG.lines` appears 0.2 s before its start and
fades out as the next begins (or 1.2 s after its end). Change `drawBand` in `engine.js` for another layout.

### Determinism and caching

Every frame is computed from the song time alone: pieces step on twos (`twos(t) = floor(12 t) / 12`), the film
grain changes on twos, the random numbers come from fixed seeds, and anything with a history (the leaves' flights,
the sails' angle) is worked out once at load. So `step(t)` and `renderAt(t)` are the same function, and any slice
of the film renders exactly. A set's meshes are made once at load and cached by request; an `Actor`'s poses are
meshed as they're needed and kept in a cache of recent ones, and both calls wait for them.

`window.__video` also offers `probe(t)` (what stands between the camera and its focus), `shots`, `sets`, and
`view(t, pos, look, fov)`, which draws time t from any camera. Use it from the browser console to find shots.

## Make your own video in this style

1. **Copy the folder**: `cp -r styles/diorama projects/my-song`, and put your mp3 in it as `song.mp3` (see
   [docs/your-own-video.md](../../docs/your-own-video.md) for the whole process). Relative paths work the same from
   `projects/my-song/`, and the tools serve it at http://localhost:8000/projects/my-song/index.html.
2. **Your song**: make its `lyrics_data.js` with the timing pipeline in [docs/timing.md](../../docs/timing.md) (it
   ends with `tools/audio/to_js.py`, which writes the same `window.SONG` shape), then point the page at it: in
   `index.html`, change `../../examples/poem/lyrics_data.js` to `lyrics_data.js`. `SONG.audio` is the mp3's path
   relative to the page (`song.mp3` by default). Change the page title and heading.
3. **Keep** `engine.js`, `sdf.js`, `mesher.js`, `pieces.js`, `mats.js`, `world.js`, `kit.js`, `paper.js` and
   `models.js`. **Replace** `sets/hill.js` with your own board(s), `shots.js` with your shot list, and the imports at
   the top of `shotkit.js` (it takes `ROAD`, `groundY` and `twos` from the demo's set).
4. **Add a set**: write `sets/mine.js` exporting `async function buildMine(ctx)` (the skeleton above), and add it to
   `sets.js`. `?sets=mine` builds only that set, which is quicker while you work.
5. **Add a model**: write a function in `models.js` returning `{model, bounds}` and add it to `MODELS`. Put it in
   `sets/lineup.js` and check it with `?check=lineup` before using it. For a piece that changes shape (a walk, a
   flapping sheet), mesh a few poses and show one at a time, on twos; for a figure that has to act (look up, reach,
   turn), key its poses and let an `Actor` mesh every step (copy `sets/poses.js`).
6. **Add a shot**: add an object to `SHOTS`. Cut on line starts (`SONG.lines[i].t0`), put hits on beats. Build
   cameras around the subject: `orbit(point, distance, azimuth, elevation)` from `shotkit.js`; a whole figure wants
   the camera 20 or more away. Run `tools/probe.py` to find blocked views.
7. **Time a move to a word or beat**: `word(i, k)` (from `shotkit.js`, both counted from 0) is the time of word k of
   line i, and `beat(n)` the time of beat n.
   For example, a door that swings shut over the word "down" (line 6, word 5): in `fn(t, S)`,
   `S.door.rotation.y = 1.2 * (1 - sm(word(6, 5) - 0.1, word(6, 5) + 0.25, twos(t)))`.
8. **Useful knobs**: `GUSTS` and `SPEED` (the wind), the lamp keys on each shot, `ap` (how miniature it looks),
   `exposure`, `breath`, a model's `h` (detail against load time), the material kind of each piece.

## Performance

On an Apple M4 (the tools run headless Chrome with the GPU on):

- **Load**: 13-50 s (13 s when the machine is otherwise idle), most of it meshing 57 models in eight workers. The
  slowest are the big tree's crown (3 s), the cottage (2 s), the mill and the smaller crowns (1-1.5 s each); a
  figure takes about 0.5 s. Painting the board's 4096-pixel map takes a few seconds on the main thread. The lineup
  check loads in under 10 s.
- **Frames**: 40-90 ms to draw, 0.075-0.1 s each in an MP4 render including reading the canvas back; a full `--fast`
  render of the demo is about 80 s. The demo draws around 8 million vertices when everything is in view; the
  relief board alone is 600,000. It makes 190-620 draw calls a frame. The shadow maps are drawn once per frame, by
  the render pass (`renderer.shadowMap.autoUpdate` is off and `renderShot` asks for them): left to three.js, the AO
  and depth-of-field passes redrew them too, since every `render()` call does, which was a third to a half of the
  draw calls (899 down to 615 at 2.2 s, 356 down to 188 at 20.6 s). The picture is the same.
- **Posed figures**: an `Actor` costs a new figure mesh every other frame (about 0.35 s of worker time each at
  `h` 0.03), but meshing six steps ahead keeps a render from waiting: the poses check's 144 frames run at about
  37 ms each, the same as a set that doesn't mesh anything. Played live, the workers can fall behind and the figure
  lags its keys; the render is always exact.
- **Memory**: 83 distinct meshes, 2.9 million vertices, about 170 MB of vertex and index data (in the JS heap, and
  again on the GPU), plus about 110 MB of textures (mostly the board's 4096-pixel map) and the lamp's 4096-square
  shadow map. The page's JS heap is about 200 MB. A finer board (`seg`) or a bigger map (`tex`) grows it quickly.
- **What makes it slow**: small `h` (vertices grow with the surface area over h squared), shadow maps (the lamp's
  is 4096 square), ambient occlusion, dissolves (they draw two shots), and many separate meshes (a draw call each in
  every pass; `mergeStatic` the ones that never move). `?off=ao,dof,bloom,grade,shadow` turns passes off to see what
  each costs.
- **A slice**: `python tools/render_mp4.py styles/diorama/index.html --start 11 --end 15 --fast`. Because every frame
  depends only on its time, a slice can be spliced into a full render with `tools/splice.py`.

## Lessons and gotchas

- **Keep figures far enough away.** The demo's people are about 7 tall; cameras closer than about 20 cut off
  heads. Place cameras around the subject with a distance and an angle rather than by eye.
- **Key the lamp from the camera, every shot.** With one fixed lamp most pieces end up backlit. For a long camera
  move, key it from the moving camera (`lampFollow`), or the end of the move is lit for the start.
- **Fade surface detail with pixel size**, or fine noise aliases into rings and speckles (`L(f)` in `mats.js`).
- **Features thinner than about two mesh cells give zero normals**, which render as NaN pixels, and the bloom
  pass spreads each one into a black rectangle. `sdf.js` now falls back to a wider gradient, but keep features two
  cells thick, and suspect a thin part first when black blocks appear.
- **Don't refine vertices onto the surface**: it folded triangles, so `refine` is off.
- **Give every model a full set of defaults.** One missing pose value made NaN positions.
- **Colours**: the table in `models.js` is 0-255 and converted once; colours anywhere else are 0-1. A 0-255 colour
  in the wrong place renders white.
- **Paint regions are half-spaces unless you bound them.** `paint(P.fn((x, y) => y - 6), ...)` paints everything
  below y = 6, walls included; combine it with `max()` to limit it.
- **A smooth blend also blends colour.** A wide `k` on a white lip bled white over half of every wave. Shape with the
  blend, then colour with a sharp paint.
- **Shapes read as other things.** A heap of equal spheres reads as popcorn and a stack of layers as a cliff; a few
  big uneven lobes read as cloud. Floating land with a smooth underside reads as a spinning top; give it a rugged
  one. Coursed blocks read as brick; a stretched Voronoi pattern reads as fieldstone.
- **Flat things vanish edge-on.** A sail or a banner seen along its plane is a line: check the camera against which
  way it faces (the demo's boat is mirrored with `scale.x = -1` so its sail faces the beach cameras).
- **Match scales.** At scale 1 a tin figure is 4.8 tall and a hooded one 3.9, but a bedsheet on the line is 6;
  the demo scales its people by 1.45-1.55 so they match each other, the washing and the gate.
- **An `InstancedMesh` keeps the bounds of its first draw**; set `frustumCulled = false` or it vanishes when it moves.
- **`rotateOnWorldAxis` assumes an unrotated parent.** For a child (a crown on a bowed trunk), turn the axis into the
  parent's frame first.
- **Crowded boards hide their subjects.** `tools/probe.py` finds blocked views far faster than contact sheets.
- **Grain that changes every frame bloats the MP4**; change it on twos, with the pieces.
- **Nothing may sit still**: a hold longer than a beat or two reads as the player freezing. Keep a drift on the
  camera, a breath on the lamp, and something moving in every shot.
- **Don't start or end on pure black**: the first frame of a fade from black is blank. `fadeFrom` / `fadeTo` keep some
  picture; the demo also brings the lamp up on the first beat and down over the last bars.
- **Judge colour at full size.** Thin bright lines average out in contact-sheet thumbnails; look at the full frame
  before changing a material.
- **Painted backdrops**: the camera only ever sees a low band of the backdrop, so keep what matters low on it.
- **Load the page without waiting for `load`**: with many workers and big textures that event can time out; the
  tools wait with `wait_until='commit'` and poll `__video.ready`.
- **Hide the play overlay properly**: `display: grid` beats the `hidden` attribute, so the page adds
  `.gate[hidden] { display: none }`.
- **Material codes must never blend.** Blended like a colour, the code between a plain part (0) and a glowing one
  (2) passes through 1 (metal) and 1.5 (half glow), so every lit window got a bright metal rim; interpolated across a
  triangle it does the same at the scale of the mesh. `sdf.js` takes the winning part's code, and the shader reads it
  as a `flat` varying. Any per-vertex category (a code, an id, a pattern number) needs the same care.
- **Every `render()` redraws the shadow maps.** Post passes that draw the scene again (AO, depth of field, an id or
  normal buffer) each redraw every shadow-casting light's map unless `renderer.shadowMap.autoUpdate` is off; draw
  them once per frame with `renderer.shadowMap.needsUpdate = true` before the first pass.
- **Thousands of small meshes hang a render.** Every flower or rail as its own mesh is a draw call per pass;
  merge what never moves (`mergeStatic`), use an `InstancedMesh` for many copies of one piece.
- **A cache of on-demand meshes must never drop what's on screen or a set's own pieces**: count who shows each
  geometry (`assign`) and pin the load-time ones. And an older request that finishes meshing late must not replace
  the newer pose: the `Actor` remembers the last pose asked for and ignores the rest.
- **Two surfaces in the same plane flicker through each other** (z-fighting) in blocks that change as the camera
  moves, and an edge-finding pass outlines every block. Pieces built in the same place (a front and a copy of it)
  need one of them set a few millimetres proud.
- **Shadow acne** (moire stripes on lit faces) means the lamp's `normalBias` is too small for its shadow map's
  texel; raise it with `lamp({ normalBias })` rather than the depth bias, which detaches shadows from their feet.
- **Seed `GTAOPass`**: it makes its noise with `Math.random()`, so each load differed slightly; `engine.js` seeds it.

