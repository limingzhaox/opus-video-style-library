# 113 · 安检 X 光 / Security X-ray

来源类型：官方风格原文 + 本库中文执行模板  
原作者：Lemo-Opuscar by Lemomo (LemoLab)  
上游原文：https://github.com/lemomo-ai/lemo-opuscar/blob/8ca0dd805e214bcc1d30714cd5b9d21cc02a454b/styles/security-xray/STYLE.md  
固定版本：8ca0dd805e214bcc1d30714cd5b9d21cc02a454b  
抓取核对日期：2026-11-24  
本库改动：中文任务模板、中文摘要与编排；原文全文保留。

## 使用前先看

- 30fps，模型必须封闭且朝外，不能用负缩放镜像；开口网格会产生错误厚度与黑亮斑。
- 安检规定必须引用具体路线和日期的真实来源，判定前对象、规则和数值同屏停2.5秒；说明为模拟影像，不当作实际安检证据。
- Lemo-Opuscar by Lemomo (LemoLab), https://github.com/lemomo-ai/lemo-opuscar 。风格原文、公共规范及其改编文档按 CC BY-NC 4.0（https://creativecommons.org/licenses/by-nc/4.0/）署名非商业共享；本库新增中文模板与编排。上游另允许为自己的影片（含商业及客户影片）读取、复制、改编文档并随该片项目交付，超出该范围的商业产品、服务或文档再发行需另获授权。代码 MIT、示例画面 CC BY 4.0 仅覆盖可授权部分，第三方素材、六项示例旁白和 Clawd 等另有例外。详见 ATTRIBUTION.md 与 sources/upstream/lemo/LICENSE。
- 案例图许可：CC-BY-4.0；署名与第三方资产详见 sources/upstream/lemo/styles/security-xray/demo/CREDITS。六项示例配音的限制也适用于整段原影片，不能只凭画面许可转发音轨。

- 这是代码渲染工作流；聊天文本本身不会自动产生 MP4，需有可执行的项目环境。
- 先看预览再做长片；不要把示例素材的许可自动套到自己的歌曲、照片、字体和品牌上。
- 下方复制区包含全部风格与公共规范，不要求 AI 另外从本机隐藏路径读取文件。

## 完整复制区

【来源与许可】
Lemo-Opuscar by Lemomo (LemoLab), https://github.com/lemomo-ai/lemo-opuscar 。风格原文、公共规范及其改编文档按 CC BY-NC 4.0（https://creativecommons.org/licenses/by-nc/4.0/）署名非商业共享；本库新增中文模板与编排。上游另允许为自己的影片（含商业及客户影片）读取、复制、改编文档并随该片项目交付，超出该范围的商业产品、服务或文档再发行需另获授权。代码 MIT、示例画面 CC BY 4.0 仅覆盖可授权部分，第三方素材、六项示例旁白和 Clawd 等另有例外。详见 ATTRIBUTION.md 与 sources/upstream/lemo/LICENSE。

你是一位能写代码、检查画面并渲染成片的动画导演。请用“安检 X 光 / Security X-ray”制作一个属于我的视频。

【我的需求；把花括号内容换成实际值】
主题与一句话故事：{{填写主题和结尾变化}}
用途与观众：{{例如面向普通观众的科普短片}}
内容依据或已有脚本：{{填写；没有则说明需要你写}}
音频、歌词、图片、数据、品牌素材路径：{{填写；没有写“无”}}
素材使用权限与需显示的署名：{{填写来源与许可；不清楚请列待确认项}}
目标时长：30 秒起步；MV 以实测歌曲时长为准
画幅与清晰度：默认横屏 16:9、1920×1080；帧率按本风格原文与引擎规范，未规定时24fps；竖屏须重新构图，不直接裁横屏
语言：简体中文；配音需求：{{有/无、声线与语速}}
必须出现的内容：{{填写}}
禁止出现的内容：{{填写}}
预算与速度：先做低成本验证，再渲染完整片
个人工程名：my-video（可改为英文短名）
确认方式：先给 3 张由真实渲染代码产出的样帧和 5–10 秒预览；我确认风格后再做完整成片

【本风格的核心实现】
在行李安检台上按材料厚度计算双能X光透射，用橙有机、绿混合、蓝金属、黑不透射讲内部结构。
特别检查：
- 30fps，模型必须封闭且朝外，不能用负缩放镜像；开口网格会产生错误厚度与黑亮斑。
- 安检规定必须引用具体路线和日期的真实来源，判定前对象、规则和数值同屏停2.5秒；说明为模拟影像，不当作实际安检证据。

【工程与流程】
1. 在工作区单独克隆 https://github.com/lemomo-ai/lemo-opuscar ，检出 8ca0dd805e214bcc1d30714cd5b9d21cc02a454b，保留上游原目录供渲染工具和相对路径使用。图册只归档提示词文档，没有打包全部视频源代码。
在独立个人工程目录实现，参考 styles/security-xray/STYLE.md；不得把示例电影的故事、角色、文案、音轨当成我的需求。先读风格规范与 DIRECTOR.md、TECHNIQUE.md。Windows 的 sh 命令在 Git Bash 或 WSL 执行。window.TEXTS(t) 的 pass: true 只用于无需完整阅读的路过文字，不能用于观众必须读懂的信息；字幕另按 SRT 检查。
2. 先检查机器的 Python、Node/浏览器、FFmpeg、字体与 GPU 能力。Lemo 当前要求 FFmpeg 7+；先用 ffmpeg -version 核对。缺少工具或访问权限时明确报告缺什么，不能只描述完成、伪造文件或把截图称为已渲染视频。
3. 把我的需求写成 PLAN.md 或 TREATMENT.md：一句话故事、分镜、逐镜秒数、镜头运动、文字位置、音乐与声音 cue、所需素材、预计成本。涉及事实和数据时写 FACTS.md；没有来源的数字不填。
4. 按主题写旁白并实测音频时长；无需旁白时用画面和声音讲清楚。
5. 先完成 3 张代表开头、关键变化、结尾的样帧，逐张检查；再渲染 5–10 秒低清短段，检查字幕、运动、音画同步与控制台。复杂慢风格先计时，再估算整片。
6. 随机效果固定种子；有历史累积的媒介按顺序渲染。并行前先比较随机抽帧与连续渲染是否一致。
7. 正式导出使用项目文档中的工具与参数，不臆造命令。交付可播放 MP4、720p 预览、源代码、素材清单与许可、字幕（有台词时）、复现说明；保留最终片长、帧率、音频响度与实际渲染耗时。
8. 实际打开并检查成片开头、中间、转场、结尾及全片联系表，确认没有空帧、字体回退、遮挡、裁字、爆音或无意复制的作者片尾签名。交代尚未完成的检查。

下面是完整风格参考与公共制作规范。它们是上游参考资料，不代表我的主题或逐字台词；我的具体需求优先。风格中明确的声音、镜头和媒介限制优先于公共建议，例如无声电影不添加旁白或拟音。遇到 macOS/Linux 示例命令时按当前系统等价转换，不直接在 PowerShell 粘贴 bash 命令。相对资源路径以完整克隆的上游工程为准。


===== 完整风格原文：styles/security-xray/STYLE.md =====

# Security X-ray — Style Prompt

> The film is seen through a baggage-screening console: objects are never shown, only their dual-energy X-ray image, where every material has its colour (organic orange, mixed green, metal blue, impenetrable black) and every outline comes from thickness, not from a drawing. The operator exists only as actions on the screen: a box dragged around an object, a zoom, a measurement, a material filter, a verdict.
> References (grammar only): real checkpoint and cargo screening imagery (the colour convention, the scrolling line-scan, the operator's function keys); CT baggage scanners (rotatable 3D volumes in the same colours); medical radiography (thickness as light). Copy no manufacturer's interface, logo, layout or typeface, and never name one.

## 1. Essence, and what it is not

- **Transmission, not rendering.** Every pixel is the path length of the X-ray through matter, split by material class. Overlaps change the colour (a cable over clothes turns green), walls glow at their edges, solid metal goes dark.
- **The colour code is the language.** Orange = organic (Zeff < 10), green = mixed or light inorganic (Zeff 10–18), blue = metal (Zeff > 18), black = nothing got through. The legend sits on screen; the audience learns it within seconds.
- **A machine with a person behind it.** The console chrome (lane, belt speed, clock, bag counter, material legend, function keys, status) is always readable; decisions arrive as operator actions on the screen. If there is a voice, it is that operator in the first person: few words, flat, saying only what the screen cannot (a conclusion, a dry aside), never reading out the rule or the numbers already on screen.
- **Things are understood by their insides**: the coil in a hair dryer, the strings of a guitar, the gears in a toy car, the spine of a book.
- **Real rules.** When the image is judged, the rule on screen is a real, sourced regulation.

Not Sci-fi Hologram HUD (no invented glowing chrome: the console is plain, functional, dark), not Exploded Teardown (objects are never taken apart or lit as solids), not Under the Microscope, not a medical scan film (luggage, belts, trays, a checkpoint), not a keynote (no slides, no centred title pages).

## 2. Materials & rendering

- **Thickness pass** (three.js): every mesh double-sided, depth test off, additive blending into a float target. A fragment writes `±distance × density × class`, minus for front faces, plus for back faces, so each pixel holds the path length through organic (R), inorganic (G) and metal (B). Hollow objects are an outer solid plus the same shape shrunk with negative density, which gives walls their real thickness.
- **Every solid must be closed.** An open tube or a missing cap leaves a hole that reads as a dark or bright fleck; cap tube ends, keep winding outward, never mirror with a negative scale (it flips the sign).
- **Dual-energy colouriser** (one full-screen shader): high and low energy attenuation from the three channels; their ratio picks the hue (orange → green → blue), the total sets brightness. Brightness rises with thickness, peaks, then falls towards black, so thick steel is dark blue and a solid block is black. Gradient edge enhancement (the machines' EDGE function), a fine detector grain and scanlines.
- **Two displays.** The screening image is opaque on a navy belt background (so black can read as black); the CT volume is additive glow on the dark reconstruction field. Both use the same material classes.
- **The scan.** A fixed curtain line; the bag moves through it; columns that have passed are in colour, the rest a pale grey preview. Material filters (organic strip, metal strip, high penetration) are wipes across the image.
- **Textures in object space**: weave for fabric, lumps for food, paper and foam, anchored to the object and measured in millimetres so they stay put when the camera zooms.
- **Around the screen**: a dark booth lit by the monitor; through the glass the apron at night (runway, taxiway and floodlights as soft bokeh) for time of day; the machine's tunnel exit and rollers. Everything outside the screen is 2D, parallaxed and out of focus.
- **Post**: bloom from the screen image only, vignette, light grain in the mux.

## 3. Colour logic

- The four material colours are reserved for X-ray matter. UI and annotations never use pure organic orange or metal blue as decoration.
- Neutral ground: near-black navy for the console, a slightly lighter navy for the empty belt.
- Operator colours, one meaning each: amber = flagged / under review, red = refused, green = cleared, pale blue = machine state (scanning, curtain, CT). One verdict colour per screen.
- Text is near-white on dark plates; dim blue-grey for secondary machine text.
- Time of day lives outside the screen: the sky behind the glass (night navy → dawn amber), the runway lights; the screen keeps its colours all night.
- Example (our demo): belt #080F1A, organic rgb(255,133,26), mixed rgb(115,235,51), metal rgb(46,122,255), amber rgb(255,178,58), refuse rgb(255,74,64), clear rgb(96,232,140).

## 4. Type & subtitles

Two voices in type, never mixed:

- **Machine voice**: a monospace (e.g. IBM Plex Mono, OFL), 15–22 px for chrome, 56–64 px for the clock and counter, about 32 px for the status word. **English only**, upper case for states and keys, as a real console would print it: legend (ORGANIC / MIXED / METAL / OPAQUE), status (SCANNING, REVIEW, CLEAR, BAG CHECK, UNCLEAR, STANDBY), view labels, the CT header.
- **Operator voice** (labels, rules, verdicts): a CJK sans (e.g. Noto Sans SC, OFL, subset to the characters used) at **34–44 px** on screen, bold, with the English line under it in the monospace at 17–22 px. One line per language. A label that cannot hold 34 px Chinese is written in the machine voice instead (English only).
- Labels attach to the object with a leader line or sit in a panel beside the image; verdicts are stamps (tick or cross, word, English line) that land after the hold.
- Every image carries its stamp (bag number, time): it keeps the clock visible in tight shots.
- Nothing the viewer must read under 18 px at 1080p; legends and chrome may go to 15 px. Sizes are on screen: when the outside camera pulls back (scale < 1), anything the viewer must read waits for the push in, or is set larger.
- **Subtitles** (when there is a voice) are the operator's log: a dark plate fixed to the frame's bottom left (not to the console, so it never moves with the camera), a thin white bar on its left edge, Chinese 36 px over English 24 px in the monospace, one line each. Keep panels, verdict stamps and judged objects out of that corner: panels sit top right of the image, the CT verdict bottom right. Cues less than about 0.6 s apart share one plate (the text changes, the plate resizes), so it never blinks off and on between lines.
- Holds: a judged frame shows object, rule, number and leaves 2.5 s before the verdict; verdicts stay ≥ 1.5 s; labels ≥ characters ÷ 4.5 + 1.5 s.

## 5. Motion quality

- The belt moves at constant speed with short decelerations to a stop (a real belt has inertia), and a small settle.
- Operator actions are fast and precise: boxes are dragged open from a corner in 0.25–0.3 s, zoom eases in/out, measurement lines grow and tick.
- Counters and clocks jump on cuts to compress hours; within a shot they run in real time.
- Material filters and rescans are wipes; the CT appears through a short digital tear.
- CT orbits are slow and continuous, ease in and out, with a push and a near-stop where the detail is.
- Never moves: the console chrome, the legend, the view frames. Judged frames are locked.
- **Frame rate and grain**: 30 fps.

## 6. Camera grammar

Two cameras: one outside the screen (2D, over the booth and the monitor), one inside the X-ray (zoom on the image, or a CT orbit).

| Move | What it expresses | Can serve |
|---|---|---|
| Wide booth, window behind | place, time of day | an opening; the hour changing; an ending |
| Push from booth into the screen | attention narrowing | the next bag; a shift starting |
| Tight crop on part of the console | one object, one reading | a montage; a counter or clock |
| Operator zoom inside the image | suspicion | a flagged object |
| Locked frame with a panel | judging | a rule, a measurement, a verdict |
| CT orbit with push | seeing in 3D what the flat image hid | a reveal; a hidden mechanism; a living thing |
| Pull back to the window | consequence, time passing | dawn; the end of a run |

Subject at least a third of the view when it is judged; panels on the side away from the object; never cover the object with text.

Transitions come from the machine, never a hard jump in brightness:
- **Between bags: the scan sweep.** The next picture comes in behind a thin X-ray scan line moving the belt's way (right to left), the old picture held on the other side; short (about 0.2 s) on the beat in a montage, 0.3–0.6 s for a new judgment or a jump in time. No crossfades, no white flash frames.
- **Filters and rescans** are wipes of the same kind inside the image.
- **Into CT** a short digital tear, kept dim (the reconstruction settles out of noise; no frame much brighter than the CT that follows); out of CT a scan sweep back to the console.
- **Wide ↔ close** at the booth is a camera move, not a cut: push into the screen, pull back to the window. When the outside camera crosses the scale where the monitor fills the frame, keep drawing the window behind it so nothing pops.
- List rows and panels arrive behind a reveal line, not with a flash band.

## 7. Sound palette

- **One family of console tones** (sine with a little second harmonic, soft edges): scan chirp, two-tone alarm, single clear tone, low buzzing refusal, rising beeps for list rows. Keep the same family for the whole film.
- **Machine foley**: belt motor and rollers, X-ray tunnel buzz (120 Hz + filtered noise) while a bag passes, servo whine for zoom, relay clicks for keys, a CT gantry whir, a thump when the belt stops, a pitch-falling power-down.
- **Score**: plucked and short-bowed strings (pizzicato, spiccato) for the flow, tremolo strings and timpani for a held judgment, harp and sustained strings for release; tuned percussion (vibraphone, marimba, glockenspiel, xylophone) for small comic or tender moments. Divide the beat to push the flow instead of changing tempo.
- **Silence**: drop the groove under a judgment, leave the hum.
- **Mix**: tones and foley over the music; duck the music 4–5 dB under alarms, verdicts and list beeps; little energy below 50 Hz; −14 LUFS master, true peak ≤ −1 dBTP.
- **Voice** (optional): the operator, close and dry, no room. Compress it, set it by RMS about 10 dB over the music and 7 dB over music plus machine beds while it speaks, cut the music's 300 Hz–4 kHz band under it, and keep it off the alarm and verdict tones: a line sits in the hold before a verdict or right after it, never on it. Leave the moment a hidden thing is revealed without words.

## 8. Native moves

- **The scan curtain.** A bag crosses a line; behind it the grey preview turns into colour column by column. *Fits content like:* revealing the contents of anything sealed; a product's insides at launch; a parcel at a sorting hub.
- **Box, zoom, read.** The operator drags a box, the image zooms, a panel with the reading slides in, a verdict stamps. *Fits content like:* a compliance rule; a defect found on an assembly line; a counterfeit check.
- **Measure against a rule.** Rulers on the image give a size; a same-scale outline of the limit sits beside the object. *Fits content like:* cabin-bag sizes; a part tolerance; a dose or volume.
- **Material filter.** Organic strip or metal strip wipes away one class to show what remains. *Fits content like:* finding the battery in a toy; wiring inside a wall; the metal frame of a shoe.
- **Into CT.** The flat image cannot tell; a tear into a rotating 3D volume shows what it is, and something moves. *Fits content like:* an animal hidden in a box; the mechanism of a watch; a component stack in a phone.
- **Rescan.** The same bag again, without the removed item; a dashed outline marks where it was. *Fits content like:* before/after; a fix verified; a recall.
- **The shift.** Clock, counter and the sky behind the glass carry hours in seconds; a summary table closes it. *Fits content like:* a night at a sorting centre; a year of shipments; a launch day.

Our demo opens on the machine's self-test and *the scan curtain* from the wide booth, uses *into CT* as its climax and ends on *the shift*'s summary table, the belt stopping and the screen going to standby. A new film opens and ends another way: a *material filter* wiping an image already on screen, a wide booth at dawn running backwards to night, an ending on a *rescan* with its dashed outline, or a CT orbit that pulls back out to the whole bag.

## 9. Pitfalls of the medium

- **Wrong colours for the material.** Aluminium is green-blue, steel blue, lithium cells blue-green, glass and bone green, water and food orange. Check every prop's class; a black area must be a genuinely thick, dense object.
- **Clutter.** Too many overlapping objects turn into mud. Keep 4–8 readable objects per bag, iconic shapes (keyboard grid, coil spring, J-hook) and vary the classes.
- **Thin things vanish** (a strap seen flat, a 1 mm plate): raise density or thickness until it reads at the shot's scale.
- **Open meshes and mirrored meshes** produce flecks and negative thickness (see §2).
- **Text over the image.** Panels go beside the object; dim the image outside the operator's box rather than covering it.
- **Flat side view.** Low objects look like a strip in the side view; use it for tall or layered things, not for crops.
- **Facts.** Screening rules differ between domestic and international flights and between airlines; quote the exact rule for the route you show, keep FACTS.md with source URLs and wording.
- **Render state.** Set a render target's viewport and scissor before binding it; a stale viewport squashes the image and makes frames depend on render order.
- **Brands.** No manufacturer names, logos or real products in the console or on labels.
- **Chrome in two languages.** Bilingual chrome (a Chinese legend at 20 px) drops under the readable size and clutters the console; keep chrome English and give Chinese only to the operator's labels, at full size.

## 10. Engine

- `demo/xr.js`: `X(geometry, class, density, parent, opts)` (weave, lump), `boxShell`, `cylShell`, `tube` (capped), `lathe`, `flat`, `instanced`, `spring`; `makeEngine(W, H)` returns `renderView(view, deviceRect, items)` (renders only the visible part of a view, viewport-safe) and `drawView(view, {split, strip, front, hot, side, mode, gain, dim, clipFrom})`, the dual-energy colouriser.
- `demo/props.js`: the demo's bags and trays at real sizes (your film packs its own; suitcase, laptop, umbrella, sneakers, books, flask, tray of metal items, backpack with power bank, tote with bottle, lunch jar). `demo/crab.js`: the demo's live cargo, a procedural carapace, jointed legs with a pose function, hairy claws, twisted rope.
- `demo/film.js`: console layout, booth and window, verdict panels, CT shot, time warp, `window.EV` cues; `VO` (voice clip starts) and `SUBS` (bilingual cues) in film time, `subtitles()` for the operator's log plate. `demo/audio.py`: voice, score, console tones and foley from `events.json`.
- Minimal example of something new: a wrist watch, top view (`item`, `X`, `cylShell` from `xr.js`; `E`, `mainV`, `setTop` as set up in `film.js`).
  ```js
  const it = item('watch'); E.scene.add(it);
  cylShell(0.02, 0.01, 0.0015, MET, 1.2, it);                 // steel case
  X(new THREE.CylinderGeometry(0.004, 0.004, 0.004, 20), MET, 1.6, it);   // movement
  setTop(mainV, 0, 0, 3); E.renderView(mainV, rect, [it]); E.drawView(mainV, {});
  ```

## 11. Variation space

The agent decides the place (checkpoint, cargo hub, mail room, customs, a factory line), the bags and what is inside, the rules, how many judgments, the hours, whether there is CT, and the music.

- **Structures**: one bag, three filters, one discovery; a conveyor of 20 items cut on the beat ending on one stop; a before/after rescan story.
- **Openings**: the machine's self-test; a single object already on screen in grey, coloured by the first pass; a wide booth at dawn running backwards to night.
- **Endings**: a summary table; the belt stopping and the screen going to standby; a CT orbit that pulls back out to the whole bag.

---

How our demo was made (story, shots, score, end card, build): [DEMO.md](DEMO.md). Read it after your treatment exists.


===== 完整公共规范：DIRECTOR.md =====

# Directing a Lemo-Opuscar film

The directing method behind every film in this library. Pair it with one `styles/<slug>/STYLE.md` (the style) and [`TECHNIQUE.md`](TECHNIQUE.md) (how to build).

You are the director, not a tech demo. A film is judged in this order: **sound, rhythm, camera, directing** (performance, staging, emotional arc). Good-looking frames are only the starting point.

---

## 1. Take the brief

The user gives a style and a topic, sometimes more (length, language, voice, must-have shots, brand rules). Everything else is your decision. Ask once, in a single message (AGENTS.md, Workflow), then no more questions. Defaults:

- Length **30–60 s**; shorter and tight beats padded. Beyond two or three minutes multiplies time and token cost: tell the user.
- 1920×1080 at 24 fps by default; an output frame rate set in the style's `STYLE.md` (30 or 60 fps, for example) wins, and is what you pass to `--fps` and `mux.sh`; other sizes (vertical 1080×1920, for example) with `--size WxH` on the render tools.
- Voice and subtitles in the language the user writes in. Subtitles burned in and exported as `.srt`.
- **The language on screen is the film's, not the demo's.** Many `STYLE.md` files set a Chinese line above an English line (subtitles, titles, labels): those are the two languages of our demos. A film in one language sets that line alone, in the upper line's place and size. A film in two keeps the stack, its main language on top. For another script, choose an openly licensed face of the same kind (weight, serif or sans, written or printed). The rest of the style's type stays: sizes, placement, how the text arrives.
- Loudness −14 LUFS.

Say it in the questions when it matters: a good Chinese voice uses Microsoft's online service (edge-tts) and needs a connection; offline, Kokoro reads Chinese but sounds plain (TECHNIQUE.md §4).

Requests that only change the plan:

- **No voice, or no subtitles.** Drop those steps and say so in the treatment.
- **Their own voice recording.** Use it as it is; transcribe it with faster-whisper for word timings.
- **Their own material**: logos, photos, footage, and for a style built from real data or scans (its `STYLE.md` says so) their own data, scans, imagery or CAD. Ask whether they have any; what they give comes first, and the sources in the `STYLE.md` are the fallback. Before you download from those sources, tell the user what you will fetch, from where and under which licence. Rights: section 12.

## 2. Find a benchmark first

Before writing anything, pick one or two reference works (films, title sequences, games, ads) that set the bar for this style **and this topic**. They are your choice, made for the user's film; don't borrow the demo's. Write down:

- **What to learn**: composition, pacing, camera grammar, colour logic, score structure.
- **What not to take**: characters, designs, melodies, specific shots, logos, fonts.

The benchmark lifts quality more than any rule below.

## 3. Shape the story

- **One subject, one goal, one turn.** A character (or a single object, product or idea) wants something, something changes, it ends differently from how it began.
- **Hook in the first 3 seconds.** No slow logo reveal before anything happens.
- **An ending that echoes.** Bookend the opening, reveal the scale, or let the character do the thing right the second time.
- **One native move**: a moment only this medium can do (a fold that becomes a transition, ink that blooms into the next scene, a type grid that snaps into the logo). Put it at the emotional peak. `STYLE.md` lists the medium's native moves; pick or invent the one your story needs.
- **Cut the extras.** One gag the audience reads at thumbnail size beats three they can't. If a beat needs explaining, remove it.

## 4. Write the treatment

Write `TREATMENT.md` before drawing anything, and before you open the style's `DEMO.md` or demo code (an Edit & Documentary style gathers its material first: AGENTS.md, "Treatment first"):

1. **Three candidate structures**, a few lines each (for example: a single journey, a before/after, a countdown, a list that turns), then the one you chose and why. Choose the opening image, the ending and the shape of the score from the topic too; the first idea that comes to mind for a style is usually its cliché.
2. **Logline and arc**: one sentence, then setup → turn → ending.
3. **Benchmark**: learn / don't learn (section 2).
4. **Shot list**: for every shot, the framing (wide / full / medium / close / insert), angle, camera move (push, pull, pan, track, crane, zoom), duration, and **why** it is shot that way.
5. **Beat sheet**, second by second.
6. **Cue map**: tempo, bar grid, instrumentation per section, and on which beat every cut, key action and subtitle lands.
7. **Sound design table**: for each section, the ambience bed, the main foley and the music state.
8. **Subtitle and title design**: the type is part of the style.

## 5. Prove the look

- **With characters**: draw a model sheet (turnaround, 3–4 expressions, 2–3 key poses, palette) plus two style frames.
- **Without characters**: three style frames from the film, one of them the signature shot.

Render them with the real drawing code, not a mock-up, and check them yourself against the `STYLE.md` before going on.

### The storyboard (only if the user asked for one)

Render 6–9 key shots with the real drawing code, tiled into one sheet (`core/render/sheet.py`) with shot number, framing, duration and line under each. Send it with the logline and what you are least sure about, and **wait for approval**. If the user didn't ask for one, don't stop.

## 6. Sound is half the film

- **Every visible action has a sound**: landings, page turns, cuts, drips, clicks, cloth. Match the material (paper, wood, metal, ink and glass all sound different).
- **Three layers**: ambience (room, wind, rain, city), foley (tied to actions) and music. Duck the music under dialogue and key foley.
- **At least two real silences**, or near-silences, before the turn or the emotional peak. The first sound after the silence should be one of the most important sounds in the film.
- **Use sound as a transition** at least twice: bring the next scene's sound in early (J-cut) or let the last scene's sound run over the cut (L-cut).
- **Avoid generic "piano and strings".** Score in the instruments of the style's sound palette.

## 7. Rhythm: the music grid comes first

- Write the cue map before animating. The picture locks to the grid, and a script checks every cue (TECHNIQUE.md §3).
- **Vary the pace**: alternate fast and slow, include one clear acceleration or deceleration, and give the audience one breath (a long take or a held pause). A film at one even speed has failed.
- One action, one sound, one cut, but don't cut on every beat. Leave time to see.
- **Pace for the viewer, not the clock**:
  - Hold every subtitle at least 1.8 s, and never shorter than the spoken line + 0.6 s.
  - After text finishes animating in, hold it for roughly (letters ÷ 15 + 1.5) s in English, (characters ÷ 4.5 + 1.5) s in Chinese; `readcheck.mjs` checks this for you.
  - Hold a title card at least 4 s.
  - Give failures and gags enough time to be understood.
  - Fast is fine; make it fast with fewer words per screen, not by cutting before people finish reading.

## 8. Camera: every shot needs a reason

- Use at least **four different camera moves** and real changes of framing. 2D has a camera too: push, pull, parallax, focus pulls, frames within frames.
- **One signature shot** people remember: a oner, a scale reveal, a transition made from the medium itself.
- **Design transitions inside the medium** (a page turn, a carved line growing, ink spreading), as one consistent grammar. Avoid default fades and hard cuts.
- At key moments the subject fills at least a third of the frame height, with clear staging and a readable silhouette.

## 9. Performance

- **Anticipation, action, follow-through** on every meaningful move. Characters change emotion. They do not just slide across the screen.
- **Motion continuity**, especially for characters built from code rigs:
  - Blend every pose with keyframes and easing; never switch poses inside an `if`. The only exception is a deliberate one-frame comic pop.
  - Check shoulders and arms on a large action test sheet (reach, raise, run, kneel) before shooting (TECHNIQUE.md §10).
  - Held props sit **between the palms**, at a depth between the two arms. A hand-over interpolates from one palm to the other. A rolling object turns by distance ÷ radius.
  - Step through key actions at 0.2 s intervals, enlarged.
- Check every expression at final size, especially eyebrow direction: "worried" and "angry" are one flip apart.

## 10. The failures we saw most

- Subject too small, too far away, or pushed against the frame edge.
- Too dark to read, or a colour laid on the same colour (red on red).
- Subtitles covering the subject.
- A gag or failure too fast to understand.
- Blank frames in transitions.
- A timed effect (iris, zoom, follow cam) that doesn't track the subject after the camera moves (one world → screen function, TECHNIQUE.md §2).

## 11. Before you deliver

- Run the review loop (TECHNIQUE.md §8): contact sheets, 0.2 s strips of key actions, one full-speed viewing with sound.
- **One fix round.** Fix everything the review and the checks below find in one round, then check once more. Small fixes that second check turns up (a level, a frame) belong to the same round; anything bigger, tell the user in one line when you deliver. The user's notes after delivery are new rounds: change only what they ask.
- **Not the demo again.** After the treatment, read `DEMO.md` and compare: structure, opening, signature shot, camera path, score shape, ending. At least four of the six must differ; rethink the ones that match. Before delivery, put your contact sheet next to the demo poster (`styles/<slug>/poster.jpg`) as a last check.
- Voice: every line transcribes back correctly (speech-to-text check). For Chinese, one misheard character in a short line is normal: listen, and if it is right, let the check expect what the model heard (TECHNIQUE.md §4).
- Loudness about −14 LUFS; no black frames, no NaN frames; subtitles in sync and not covering key action.
- Every row of the sound design table is actually in the mix.
- Every map, globe or satellite view passes section 13, checked enlarged.
- No LemoLab sign-off: `grep -rniE "lemo ?lab|opus 5\.5" <project folder>` finds nothing outside `LICENSE`, `CREDITS` and the library's path in `LIB=` lines, and you have watched the last seconds of the film (text drawn into an image can't be grepped).

**Deliver**, in the project folder (the complete list):

- `<name>.mp4` (24 fps unless `STYLE.md` sets another rate, about −14 LUFS) and `poster.jpg`;
- `<name>.srt`, when the film has narration, dialogue or subtitles; when the subtitles are burned into the picture, `subtitles_<lang>.srt` instead (desktop players load a `.srt` named like the video on top of the picture, so every line would show twice);
- `TREATMENT.md`;
- `CREDITS`: every third-party asset in the film (sample libraries, music, fonts, images, the voice engine) with its source and licence (TECHNIQUE.md §11);
- the source, with a one-command `build.sh` (TECHNIQUE.md §2).

**Tell the user**, in their language: where the project folder and the film are; that `CREDITS` lists the third-party assets in the film and their licences; and that they are responsible for the materials they use in it.

## 12. Copyright red lines

- References teach grammar only. Don't copy characters, designs, melodies, shots, logos or type designs.
- No existing works, games, brands or events appear in the film unless the user owns them or has the right to use them. That includes the logos, photos and footage the user hands you: use them when they say they have the right, otherwise draw fictional stand-ins.
- Some of our demos are unofficial fan films of real events or characters. Keep the style, and never carry those names, marks or characters into a user's film.

## 13. Maps

These apply to every frame that shows a map, a globe or satellite imagery, in every style.

- **No borders unless the film is about them.** Draw coastlines, terrain, imagery or streets, without national or provincial borders. Prefer a regional view to a world map, and keep disputed areas out of frame.
- **When China is in frame, draw all of it.** Taiwan, Hainan, the South China Sea islands with the dashed line (in frame, or in an inset), and the Diaoyu Islands with Chiwei Yu. Taiwan and the mainland are one country, in the same colour and the same treatment. Zangnan and Aksai Chin are drawn as on China's standard map.
- **Default border data doesn't meet this.** The default boundaries of Natural Earth, world-atlas and OpenStreetMap can't be used to draw China. When the film needs borders, use China-view data (such as Natural Earth's `admin_0_countries_chn` layers, checked against the standard map) or China's standard map service (bzdt.ch.mnr.gov.cn).
- **Words follow the same map.** Taiwan, Hong Kong and Macao are never listed as countries: not in labels, legends, subtitles, the voice-over or data tables. A list that includes them is "countries and regions". Clean a dataset's country field before you chart it.
- **Other disputed areas**: the same; frame them out, or leave their borders undrawn.
- **Check and credit.** Before delivery, enlarge every map shot and check it against these rules. `CREDITS` names the map data, its source and its view (for example "Natural Earth 1:50m, China view").


===== 完整公共规范：TECHNIQUE.md =====

# Technique: how the films are built

Every film here is made from code: no video generation, no stock footage. This page explains the pipeline, to reproduce with our tools in `core/` or in your own stack. Pair it with [`DIRECTOR.md`](DIRECTOR.md) and one `styles/<slug>/STYLE.md`. Every command and flag is in [`core/README.md`](core/README.md).

```
timeline (single source of truth)
   ├─► picture:  web page with render(t) ──► headless Chrome, frame by frame ──► video.mp4
   ├─► voice:    TTS per line ──► speech-to-text check ──► word timings
   ├─► music:    score from the same timeline (samples + synthesis) ──► stems
   ├─► sound:    procedural foley at event times
   └─► subtitles: .srt + burned-in captions
mix (duck, compress, balance) ──► mux with ffmpeg, two-pass loudnorm −14 LUFS ──► film.mp4
```

## 1. Requirements and install

System tools, which the user installs: **Node 20+**, **ffmpeg 7+** (6.x under-reports audio length through `loudnorm`, and `mux.sh` then rejects the file as cut off), and **Python 3.11+** or [uv](https://docs.astral.sh/uv/). Developed on macOS (Apple silicon); Linux should work. On Windows, Git Bash (part of Git for Windows) works: run the same `sh` commands there; WSL also works. 3D and shader-heavy styles want a GPU.

Everything else installs in tiers, from the library root (`$LIB` in skill mode). Install a tier only when the film needs it:

| Command | Adds | Size |
|---|---|---|
| `sh plugin/skills/lemo-opuscar/scripts/setup.sh deps` | core: npm packages, headless browser, Python `.venv` (numpy, scipy, soundfile, soxr, pillow): render, synthesize sound, mux | ~350 MB |
| `… setup.sh deps voice` | Kokoro + model (English, offline), edge-tts (Chinese, online), faster-whisper (voice check) | ~0.55 GB + a Whisper model on first check (~145 MB for English, ~480 MB for Chinese) |
| `… setup.sh deps music` | numba, for plucked strings (`pluck.py`); the sampler itself needs only the core | ~140 MB |
| `sh tools/fetch.sh instruments <lib>` | a sample library: `freepats`, `karoryfer`, `salamander`, `vcsl`, `vsco2ce` or `all` | 70–400 MB each |
| `sh tools/fetch.sh hdri` | HDRIs for 3D styles | 12 MB |

Some styles need packages of their own (a LiDAR reader, a slide-scan decoder, a CAD importer); the style's `STYLE.md` lists them. They are packages, not system tools: install them yourself into a private venv or `node_modules` in the project folder, never into `$LIB/.venv`.

The styles marked ✦ also draw with an image generator, which the library doesn't include and you don't install: the user's own Codex CLI, signed in (`core/image/gen_image.py`), or another image tool they have. Their prompts go to that service (core/README.md, "Image generation").

A synthesized score needs no big download. A sampled one needs the libraries its instruments live in: `sampler.py` downloads the missing ones itself, all at once, when the score is rendered (`LEMO_FETCH=0` turns that off and prints the `fetch.sh` commands instead). Put `"$LIB/.venv/bin/python" core/audio/sampler.py --need <your mix.py>` at the top of a `build.sh`, so they arrive before the long picture render, not after it. A pack needs about twice its size free while it unpacks. Downloads come from npm, PyPI, GitHub Releases and Hugging Face (`HF_ENDPOINT` sets a mirror).

## 2. The picture is a function of time

Each film is a folder with an `index.html` (`<demo>` in the commands) that exposes:

```js
window.DUR = 54.2;                 // seconds
window.render = (t) => { ... };    // draw the frame at time t, deterministic
window.READY = true;               // set once fonts and images are loaded
window.EV = [{t, type, ...}];      // optional: sound / cue events for the mixer
window.TEXTS = (t) => [{id, text, x0, y0, x1, y1}];   // optional: every text visible at t, for readcheck (pass: true = not meant to be read in full: a sign passed by, fine-print credits)
```

**Paths:** pages reach library files with absolute URLs (`/core/lib.js`, `/node_modules/three/build/three.module.js`); scripts and `build.sh` use `$LIB`. Never `../..`.

A `build.sh` that works in both modes (in skill mode, put `LIB=<path setup.sh printed>` at the top):

```sh
#!/bin/sh
set -e
HERE=$(cd "$(dirname "$0")" && pwd)
LIB=${LIB:-$(cd "$HERE/../.." && pwd)}          # clone mode: <repo>/films/<name>/
export LIB
[ -f "$LIB/core/render/video.mjs" ] || { echo "set LIB to the library folder"; exit 1; }
cd "$LIB"
node core/render/events.mjs "$HERE"
node core/render/video.mjs "$HERE" --fps 24 --out "$HERE/out/video.mp4"
"$LIB/.venv/bin/python" "$HERE/mix.py"                               # score, foley, voice → out/mix.wav
sh core/render/mux.sh "$HERE/out/video.mp4" "$HERE/out/mix.wav" "$HERE/<name>.mp4" 24
```

Rules that keep it reliable:

- **Deterministic.** No `Date.now()`, no `Math.random()` without a seed (`core/lib.js` has `mulberry` and `hash`), no state carried from the previous frame. Any frame can be rendered alone, in any order, by any worker.
- **Canvas 2D** for most 2D styles; **three.js** for 3D (§9); **WebGL2** shaders for post passes (film damage, CRT, ink redraw).
- **Animate on twos where the style wants it** (12 fps stepping for stop-motion, pixel or cel looks), but keep the camera and light smooth every frame. A stepped camera reads as lag.
- **One world → screen function.** Any effect that follows a subject (iris, zoom, spotlight) goes through it. Never hand-type screen coordinates.
- **Draw for the frame you render.** The default is 1920×1080; for another size pass `--size WxH` (e.g. `1080x1920`) to every render tool and lay the page out from `innerWidth` × `innerHeight`.

Capture (`core/render/`):

```sh
node core/render/still.mjs <demo> 1.5 12 --range 0:50:2   # review stills; exits on page errors
node core/render/video.mjs <demo> --fps 24 --workers 3     # all frames → <demo>/out/video.mp4
node core/render/events.mjs <demo>                         # export DUR + EV → events.json
node core/render/readcheck.mjs <demo>                      # every on-screen text stays long enough to read
```

To render a second version with other content, pass it to the page and give it its own output: `--q 'content=content_alt.json' --out …/alt.mp4` (the same for `events.mjs`).

Capture is fast because of **JPEG screenshots**, **one browser per worker** and **grain added in ffmpeg**: grain drawn in the page makes every frame incompressible and slow.

## 3. One timeline drives everything

Keep sections, tempo, beats and hit points in one file (`timeline.js`). Export it to JSON and let the score, the mixer, the subtitles and the checks read the same numbers:

```js
export const SECS = [{ id: 'chase', t: 12.0, bpm: 144, beats: 12 }, ...];
export const HIT  = { pratfall: ['chase', 6], ... };   // section + beat
```

A small script (`cuecheck.py`, in `styles/<slug>/demo/tools/` of several demos) compares every visual hit with the music cue it should land on. Aim for 0 ms.

## 4. Voice

- **TTS is only the default.** If the user brings a recording or names a voice, use that. Otherwise:
  - **English**: [Kokoro](https://github.com/thewh1teagle/kokoro-onnx), local, many voices (an unknown `voice` name makes `tts.py` print the full list; `af_` / `am_` are American, `bf_` / `bm_` British; cast the narrator for this film, not the demo's). `core/tts/tts.py lines.json out/` writes one WAV per line and a durations file. Its Chinese voices (`"lang": "cmn"`) work offline but sound plain.
  - **Chinese**: `core/tts/tts_zh.py lines.json out/` uses [edge-tts](https://github.com/rany2/edge-tts) with Microsoft's neural voices (`zh-CN-XiaoxiaoNeural`, `zh-CN-YunxiNeural`…), with the same outputs as `tts.py`, a rate per line and the silence trimmed. **It needs a network connection.**
- Spell numbers out in the TTS text and write them as digits in the subtitles.
- **Check every line**: `core/tts/asr_check.py` transcribes each WAV with faster-whisper and compares it with the script (`--lang zh`: numbers by value, so 十九 matches 19, and the rest character by character); re-generate until it exits 0. A misheard character in a short Chinese line is normal: listen, and if it is right, put what the model heard in the line's `asr` field. It also writes word timestamps for placing lines and subtitles.
- **Before mixing**: TTS has a high peak-to-average ratio. Compress the voice first, then balance by RMS: voice about 10 dB above the music.

## 5. Music

Write an original score from the cue map, in the instruments of the style's sound palette; no generic piano and strings.

- **Samples**: `core/audio/sampler.py` plays real instruments from free libraries (VSCO 2 CE, VCSL, FreePats, Karoryfer, Salamander Grand Piano; list and licences in `core/audio/INSTRUMENTS.md`). Write the score as events `(time, instrument, pitch, duration, velocity, pan)`. Long notes are extended seamlessly, and round-robins avoid the machine-gun effect.
- **Plucked and folk strings** (guqin, pipa, shamisen, banjo…): `core/audio/pluck.py`, physical modelling (Karplus–Strong) with bends and vibrato.
- **Synthesis** with numpy for chip tunes, drones and effects; no download needed.
- **Balance the low end.** Synthetic scores get bass-heavy quickly. Measure energy per band after mixing; keep 20–120 Hz around −3 dB relative to the rest, skip pad notes below MIDI 48, and give the bass some 2nd and 3rd harmonics so it speaks on small speakers.

## 6. Sound effects and mix

- `core/audio/sfx.py` synthesises foley procedurally (click, whoosh, thump, ding, paper, noise beds…) with filters, envelopes and `add(buffer, sound, at, gain, pan)`. Drive it from `window.EV`, so every sound sits exactly on its frame.
- **Master**: `sh core/render/mux.sh video.mp4 mix.wav out.mp4 24 [grain]` muxes, runs a two-pass loudnorm to −14 LUFS with a true-peak limit, adds grain in ffmpeg and prints the measured loudness; it exits non-zero on any failure. On light backgrounds use less grain; for pixel and vector styles, none.
- Films with grain baked into the picture compress badly; re-encode with `-tune grain` and a higher CRF.

## 7. Subtitles

- Export `.srt` with `core/render/srt.py cues.json out.srt` (cues = `[{t0, t1, text}]`), and burn styled captions into the page itself: the caption design is part of the style.
- Timing rules are in DIRECTOR.md §7.

## 8. Review loop

1. Contact sheets: a frame every 1–2 s with `still.mjs --range`, tiled with `core/render/sheet.py`. At least two full passes.
2. Frame strips at 0.2 s for every key action: hand-overs, falls, hits.
3. On the final file: `ffmpeg -af ebur128` (loudness), `blackdetect` (blank frames), whisper again on the final mix if it has voice.
4. Watch it once, at full speed, with sound.

## 9. 3D notes

- three.js r170 rendered headless through WebGL2 on the GPU; physical depth of field and GTAO from `core/three/post.js`, rendered at 2× and downsampled.
- Lighting: soft area lights plus a Poly Haven HDRI at low intensity reads more "real" than bright ambient light.
- `core/three/post.js` is written for a perspective camera. For an orthographic camera swap `perspectiveDepthToViewZ` for `orthographicDepthToViewZ` in its depth pass, or the depth of field silently breaks.

## 10. Characters drawn in code

- A 2.5D rig (torso, head, limbs solved per frame) is enough for pantomime.
- Order the shoulder rotation as abduction, then flexion; the reverse order crosses raised arms into an X.
- Let the shoulder girdle rise and move forward as the arm lifts, and don't outline the part of the arm that overlaps the torso: that line is what makes a joint look like a puppet seam.

## 11. Assets, credits and fonts

Only CC0, CC BY or OFL material, each listed in the film's `CREDITS` with its source and licence; `core/audio/sampler.py credits(names)` writes the lines for the instruments you used. Public-domain works count as CC0; "no known restrictions" does not. Data or images under other open licences (ODbL, CC BY-SA, open-hardware licences) only after you have named the licence and its terms (attribution, share-alike) to the user and they agree. The user's own material is fine as it is. Images from an image generator (the ✦ styles) are listed too: which tool and model made them, that they are generated, and where the prompts are kept; drawings the user made are credited to them.

A film that states facts (a style built from real data or scans: its `STYLE.md` says so) keeps a `FACTS.md` in the project folder: each claim with its source URL and the quoted wording, or the measurement that produced it.

Fonts: Google Fonts (OFL), self-hosted in the project. The typefaces a `STYLE.md` names are not in the library; download them (`https://github.com/google/fonts/tree/main/ofl/<family>`) into the project's `fonts/`. `core/fonts/` holds a few Latin display fonts and a Chinese display font with only about 200 glyphs, not enough for running Chinese text. For Chinese, subset a CJK font to the characters you use: the Google Fonts CSS API with `&text=` returns just those glyphs (`https://fonts.googleapis.com/css2?family=Noto+Sans+SC:wght@700&text=<URL-encoded characters>`). Download the font file it points to into the project's `fonts/` and load it with `@font-face`; don't link Google Fonts at render time.

## 12. Where to look in our demos

| If you need… | Look at |
|---|---|
| 2D character animation and lip sync | `styles/scifi-toon/`, `styles/cel-anime-80s/` |
| a timeline-driven score with cue checking | `styles/microgame/`, `styles/silent-film/` |
| an image-to-ink redraw and film-damage post pass | `styles/silent-film/demo/engine/` |
| a brush or stroke engine | `styles/watercolor/`, `styles/ink-wash/`, `styles/impasto/` |
| 3D with depth of field and real materials | `styles/brick-toy/`, `styles/paper-popup/` |
| a CRT or VHS look | `core/post/crt.js`, `styles/ascii-crt/`, `styles/backrooms/` |

Each style's `DEMO.md` says how its demo was built. Open it and the code only after your treatment exists, to learn a technique, never to rebuild our film (an Edit & Documentary style's material tools in `demo/tools/` come first: AGENTS.md, "Treatment first"). In skill mode, get the source with `sh <skill folder>/scripts/setup.sh demo <slug>`. Copied demo code often reaches the library with `../..`: replace that with `$LIB` or absolute URLs.


## 原作者媒介陷阱与经验摘录

## 9. Pitfalls of the medium

- **Wrong colours for the material.** Aluminium is green-blue, steel blue, lithium cells blue-green, glass and bone green, water and food orange. Check every prop's class; a black area must be a genuinely thick, dense object.
- **Clutter.** Too many overlapping objects turn into mud. Keep 4–8 readable objects per bag, iconic shapes (keyboard grid, coil spring, J-hook) and vary the classes.
- **Thin things vanish** (a strap seen flat, a 1 mm plate): raise density or thickness until it reads at the shot's scale.
- **Open meshes and mirrored meshes** produce flecks and negative thickness (see §2).
- **Text over the image.** Panels go beside the object; dim the image outside the operator's box rather than covering it.
- **Flat side view.** Low objects look like a strip in the side view; use it for tall or layered things, not for crops.
- **Facts.** Screening rules differ between domestic and international flights and between airlines; quote the exact rule for the route you show, keep FACTS.md with source URLs and wording.
- **Render state.** Set a render target's viewport and scissor before binding it; a stale viewport squashes the image and makes frames depend on render order.
- **Brands.** No manufacturer names, logos or real products in the console or on labels.
- **Chrome in two languages.** Bilingual chrome (a Chinese legend at 20 px) drops under the readable size and clutters the console; keep chrome English and give Chinese only to the operator's labels, at full size.


