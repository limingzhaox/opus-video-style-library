# 70 · 彩绘珐琅 / Painted enamel

来源类型：根据作者引擎说明整理的使用模板；并非作者原始创作提示词  
原作者：Miranda Dixon-Luinenburg  
上游原文：https://github.com/cyborggirl963/opus-5.5-music-video-art-styles/tree/main/styles/painted-enamel  
固定版本：801b3548c54765ecf932ce8b7f3cf4b29fb7a8bf  
抓取核对日期：2026-11-03  
本库改动：中文任务模板、中文摘要与编排；原文全文保留。

## 使用前先看

- 暖罩色、黄清漆和重裂纹叠加会变泥，用细裂纹和明确高光笔解决。
- 发光层必须被前景不透明形体遮挡；不要给每个形状都加柔软倒角高光。

- 这是代码渲染工作流；聊天文本本身不会自动产生 MP4，需有可执行的项目环境。
- 先看预览再做长片；不要把示例素材的许可自动套到自己的歌曲、照片、字体和品牌上。
- 下方复制区包含全部风格与公共规范，不要求 AI 另外从本机隐藏路径读取文件。

## 完整复制区

你是一位能写代码、检查画面并渲染成片的动画导演。请用“彩绘珐琅 / Painted enamel”制作一个属于我的视频。

【我的需求；把花括号内容换成实际值】
主题与一句话故事：{{填写主题和结尾变化}}
用途与观众：{{例如面向普通观众的科普短片}}
内容依据或已有脚本：{{填写；没有则说明需要你写}}
音频、歌词、图片、数据、品牌素材路径：{{填写；没有写“无”}}
素材使用权限与需显示的署名：{{填写来源与许可；不清楚请列待确认项}}
目标时长：30 秒起步；MV 以实测歌曲时长为准
画幅与清晰度：默认横屏 16:9、1920×1080；帧率按本风格原文与引擎规范，未规定时24fps；竖屏须重新构图，不直接裁横屏
语言：简体中文；配音需求：{{有/无、声线与语速}}
必须出现的内容：{{填写}}
禁止出现的内容：{{填写}}
预算与速度：先做低成本验证，再渲染完整片
个人工程名：my-video（可改为英文短名）
确认方式：先给 3 张由真实渲染代码产出的样帧和 5–10 秒预览；我确认风格后再做完整成片

【本风格的核心实现】
以双加载色的刷毛、清楚单笔高光和光泽漆面表现马车珐琅彩绘。
特别检查：
- 暖罩色、黄清漆和重裂纹叠加会变泥，用细裂纹和明确高光笔解决。
- 发光层必须被前景不透明形体遮挡；不要给每个形状都加柔软倒角高光。

【工程与流程】
1. 在工作区单独克隆 https://github.com/cyborggirl963/opus-5.5-music-video-art-styles ，检出 801b3548c54765ecf932ce8b7f3cf4b29fb7a8bf。将 styles/painted-enamel/ 复制到 projects/my-video/，保留引擎，按该风格 README 指定的文件替换示例场景。不要直接修改 styles/ 中的母版。
建立 Python 虚拟环境，阅读 requirements.txt 后安装渲染依赖；需分析音频时再安装 requirements-audio.txt。使用 Chrome 或项目支持的 Chromium。使用 python tools/serve.py 提供本地 HTTP，不用 file:// 打开渲染页面。
2. 先检查机器的 Python、Node/浏览器、FFmpeg、字体与 GPU 能力。Lemo 当前要求 FFmpeg 7+；先用 ffmpeg -version 核对。缺少工具或访问权限时明确报告缺什么，不能只描述完成、伪造文件或把截图称为已渲染视频。
3. 把我的需求写成 PLAN.md 或 TREATMENT.md：一句话故事、分镜、逐镜秒数、镜头运动、文字位置、音乐与声音 cue、所需素材、预计成本。涉及事实和数据时写 FACTS.md；没有来源的数字不填。
4. 如果是 MV，先取得音频与实际演唱歌词，测量段落、停顿、节拍与词时间；不得沿用 37.5 秒示例诗的时间轴。未提供音乐时不要假装已经完成歌词对齐，可先制作无歌词短预览。
5. 先完成 3 张代表开头、关键变化、结尾的样帧，逐张检查；再渲染 5–10 秒低清短段，检查字幕、运动、音画同步与控制台。复杂慢风格先计时，再估算整片。
6. 随机效果固定种子；有历史累积的媒介按顺序渲染。并行前先比较随机抽帧与连续渲染是否一致。
7. 正式导出使用项目文档中的工具与参数，不臆造命令。交付可播放 MP4、720p 预览、源代码、素材清单与许可、字幕（有台词时）、复现说明；保留最终片长、帧率、音频响度与实际渲染耗时。
8. 实际打开并检查成片开头、中间、转场、结尾及全片联系表，确认没有空帧、字体回退、遮挡、裁字、爆音或无意复制的作者片尾签名。交代尚未完成的检查。

下面是完整风格参考与公共制作规范。它们是上游参考资料，不代表我的主题或逐字台词；我的具体需求优先。风格中明确的声音、镜头和媒介限制优先于公共建议，例如无声电影不添加旁白或拟音。遇到 macOS/Linux 示例命令时按当前系统等价转换，不直接在 PowerShell 粘贴 bash 命令。相对资源路径以完整克隆的上游工程为准。


===== 完整风格原文：styles/painted-enamel/README.md =====

# Painted enamel

The picture is a panel painted in glossy enamel on the side of a wagon. Every stroke is a bundle of bristles loaded with two
colours side by side, so base coats keep their brush marks and a single stroke shades itself. Highlights are crisp one-stroke
flicks set in from the edge that faces the nearest light; the far edge gets a darker band; cloth folds are a dark stroke with
a light flick beside it; every shape is lined in a thin dark outline; anything precious is gold leaf, laid in squares and
burnished, catching the light as it turns. The panel sits in a gilded bead moulding on the wagon's green boards, under a
slightly amber varnish with a fine craze, with a cartouche of little lamps on top and two ribbons along the bottom.
Night isn't painted darker: it is a **light map** (an ambient colour plus a pool of light for every fire, lamp and lit window)
multiplied onto the paint, with flames, lit glass and windows on a separate self-lit layer the night doesn't touch, and glows
screened on top. Figures are small skeletons with two-bone IK arms, so a hand can meet a lantern or a gate exactly; trees are
painted once and bent every frame by the wind. Plain HTML canvas, no libraries.

![Two cloaked travellers walking into the wind at dusk, a red banner streaming, one holding a lit lantern, painted in enamel in a gilt frame on a green wagon](img/hero.jpg)

The demo sets Christina Rossetti's "Who Has Seen the Wind?" (37.5 s): travellers walk a windy road at dusk, a bough of gold
leaves trembles, a gust runs through the long grass, and as night falls a village lights its windows and street lamps, a
windmill turns, the poplars bow, and at an inn the travellers light the porch lamp and go in before the wind slams the gate.

| | |
|---|---|
| ![A bough of gold and red leaves hanging over a valley at dusk; far below a tiny caravan with lit lanterns](img/bough.jpg) | ![The caravan on the road at dusk, a wagon and pack beast, poplars bent by a gust, long grass streaming](img/road-gust.jpg) |
| ![At an inn's gate at night, one traveller lifts a lantern to light the porch lamp while the other holds the gate open onto a lit courtyard](img/inn.jpg) | ![A village on a hill at night, windows and street lamps lit, poplars bowing in the wind, a gilded weathervane](img/village.jpg) |

## Looks in this family

- **Enamel** (the demo's look): the painter in `paint.js`, the light map, and the wagon frame. ![The village at night in enamel](img/look-enamel.jpg)
- **Chalkboard**: the same scene calls drawn in coloured chalk on a slate board kept for years, with notes chalked into grooves round the edges. ![The village at night in coloured chalk on a slate board](img/look-chalkboard.jpg)

## Run the demo

From the repository root:

```bash
python tools/serve.py
```

then open <http://localhost:8000/styles/painted-enamel/index.html>. Space plays and pauses; drag the bar to scrub. Add
`#t12.5` to the address for a still at 12.5 s (the page furniture hides and the canvas fills the window; change the number
and the frame redraws). The page spends about 5 seconds building (it paints the still layers of the five sets, the tree
sprites and the varnish) and then plays live. On an Apple-silicon Mac a frame takes about 20-60 ms to draw, so it plays at
roughly full speed, dropping frames in the busiest shots; the MP4 is always smooth.

Stills (with a contact sheet) and the MP4:

```bash
python tools/still.py styles/painted-enamel/index.html 2 6 12.5 0:37.5:2.5 --sheet
python tools/render_mp4.py styles/painted-enamel/index.html --fast        # 720p preview
python tools/render_mp4.py styles/painted-enamel/index.html               # 1080p and 720p
```

A `--fast` render of the whole 37.5 s (900 frames) takes 35-70 seconds here (about 40-75 ms a frame including the readback
and the encoder, depending on what else the machine is doing), plus a few seconds to build; the full-quality render spends
longer in the encoder.

## How it works

### Files, in load order

| file | job |
|---|---|
| `../../examples/poem/lyrics_data.js` | the song: `window.SONG` with the title, credit, audio, duration, beats, sections and each line's word times |
| `core.js` | the frame size (1920x1080 canvas; the picture is 1920x960, the lyric band below), maths, a seeded random (`mulberry32`), value noise (`vn2`, `fbm2`), colours as `[r,g,b]`, shapes, splines, fonts, a plain lyric band |
| `paint.js` | the enamel painter: the brush (`bristles`, `comma`), gold leaf (`leafFill`), the palette `PAINT`, light colours `LIGHTCOL`, `makePainter` (the style object `S`), `lightScene` (the night), sprites |
| `props.js` | pictograms (`GL`, `glyphLines`, `tally`), street lamps, cottages and their windows, tapered branches, conifers |
| `rig.js` | the posable figures: `traveller`, `packBeast`, `wagonSide`, `cookPot`, two-bone IK (`ik2`), `hangSwing` |
| `wind.js` | the wind (`windAt`, `windStr`, `windInt`) and what it moves: bending trees, grass, leaves in flight, a banner, washing, chimney smoke, clouds, a weathervane, a windmill, a swinging sign, stars, the moon; and weather: storms and rain |
| `frame.js` | the wagon: boards, moulding and flourishes, varnish and craze, the cartouche of lamps, the ribbons, the gap seen during a slide |
| `shots.js` | the demo's timeline: `LINES`, timing helpers, the breeze and gusts, nightfall, the frame's cues, `SHOTS` |
| `sets_dusk.js`, `sets_night.js` | the demo's five sets: `road`, `walkers`, `branch`, `village`, `inn` |
| `engine.js` | baking sets, the lit scene, the camera, wipes and slides, the frame composite, the lyric band, `renderAt(t)` |
| `player.js` | the page: play, pause, scrub, `#t` stills, the silent clock when the song won't load, `window.__video` |

All plain scripts sharing globals, as in the rest of this repository.

### Shapes, colours and the style object `S`

A shape is `shp(rings)`: one or more closed rings of `[x,y]` points, with its bounding box `bb` and a lazily built `path`.
Build rings with `rect`, `ell`, `blob`, `archPts`, `scallop` (a scalloped round, how folk painters draw a tree's crown),
`smoothRing(points)` (a closed Catmull-Rom curve) and `spline(points, closed, step)`.

Colours are keys into `PAINT` (`'cloakB'`, `'leafGold'`...) or plain `[r,g,b]`. Add your own with
`Object.assign(PAINT,{river:[120,160,190]})`; the sets and `wind.js` each add theirs that way.

Everything is painted through `S`, which `makePainter(T, lights)` returns. The chalkboard look implements the same calls, so
a set, a figure or a prop never needs to know which look is drawing it.

| call | paints |
|---|---|
| `S.fill(shape, key, o)` | a shape. `o.role` picks the treatment: `cloth`, `wood`, `wall` (with `o.blocks`), `roof`, `thatch`, `foliage`, `fur`, `hair`, `skin`, `leather`, `metal`, `ceramic`, `stone`, `rock`, `land`, `floor` (flags toward `o.vanish`), `paper`, `snow`, `sky`, `dark`, `leaf` (gold leaf: `o.sheen` 0..1 for the catch, `o.dim`), `window` and `glass` (self-lit; `o.k` how lit), `embers` (self-lit). Also `o.folds` (polylines), `o.dir` (brush direction), `o.line:false` (no lining), `o.depth` |
| `S.line(pts, key, w, o)` | a stroke. Roles: default round stroke with a lit side (`pole`, `strap`, `rope`, `limb` look the same), `grain`, `crack`, `leafline` (a gold line), `road`, `water`, `thread` (self-lit), `blade` (grass: `o.k` shows the pale side), `streak` (a long cloud: `key` on top, `o.key2` underneath) |
| `S.lamp(x, y, size, lit, o)` | a box lantern. Lit, it adds a pool to the light map (via `S.extra`) and paints its glass self-lit with a gold-leaf flame; `o.k` 0..1 brings it up gradually |
| `S.flame(x, y, w, h, o)` | tongues of two-colour strokes and sparks, self-lit, with glows; `o.t` animates, `o.lean` bends it with the wind |
| `S.glow(x, y, r, key, k, o)` | a soft glow on the screened layer (`o.flat` squashes it) |
| `S.smoke(pts, w, o)`, `S.steam(x, y, w, h, t, o)` | smoke along a path; steam rising |
| `S.sky(o)` | a gradient laid on with long strokes (`o.top`, `o.mid`, `o.low`, `o.h`), stars, optional aurora curtains. `o.motes` puts motes in place of the stars: points of light in the aurora's colours, some strung in short curving lines, no glints |
| `S.star(x, y, s, k)`, `S.glyph(name, x, y, s, key)` | a star; a pictogram from `GL` |
| `S.faceProfile(shape, o)` | a face deep in a hood, the chin and nose caught by light (`o.lit`) |
| `S.clip(shape, fn)`, `S.tf(setup, draw)` | clip, or transform (`setup(ctx)` is applied to each layer), whatever `fn`/`draw` paints |
| `S.layer(d)` | depth 0..1 for what follows: below .36 things fade toward the haze colour and get finer lining |
| `S.seed(n)` | set the brush seed (see Determinism) |
| `S.backlit(on)` | shapes painted while on become dark silhouettes on the self-lit layer: a figure walking into a bright doorway |
| `S.sprite(key, {w,h,ox,oy,at}, paint)`, `S.bent(sprite, x, y, bend)` | paint something once into its own layers, then draw it bent (below) |

### The night: three layers and a light map

A scene is painted into three 1920x960 canvases: `g` reflective paint, `e` self-lit paint (flames, lit glass and windows,
stars, the moon) and `gl` glows. A reflective shape knocks out whatever self-lit paint and glow lies behind it, so a figure
in front of a lamp hides it and a cloud passing over the moon covers it. Then `lightScene(layers, lights, ambient)` builds the
light map (a vertical gradient between the two ambient colours, plus a radial pool `{x,y,r,k,c}` for each light, added),
multiplies it onto `g`, draws `e` on top and screens `gl` over that. Dusk and night are nothing but the ambient colours and
the lights: `ambientFor(t)` in `shots.js` slides from a warm dusk to a blue night as `NIGHT(t)` goes from 0 to 1.

The same lights tell the painter which side of each shape catches the light, so the highlight flicks face the nearest fire.

### Sets

A set is an object in `SETS`:

```js
SETS.walkers={
  lightsAt(t){const n=NIGHT(t);return[{x:-160,y:640,r:1800,col:'dusk',k:.9*(1-n*.7)}];},   // or lights:[...]
  ambientAt:t=>ambientFor(t),                                                            // or ambient:[top,bottom]
  back(S){...},             // painted once: sky, hills, the wall, the road
  prep(S){...},             // painted once: the tree sprites
  front(S){...},            // painted once, over the moving things (optional)
  dyn(S,t,shot){...},       // every frame, between back and front: trees bending, the two travellers, the banner
  dynFront(S,t,shot){...},  // every frame, over everything: grass, flying leaves
};
```

`col` is a key into `LIGHTCOL` (`fire`, `lamp`, `window`, `dusk`, `moon`, `ember`). A set can also have `post(g,t,shot)`, run
on the finished scene (rain streaks, say). `back` and `front` are baked once, so anything that differs between two shots of
the same set belongs in `dyn`; `shot.act` tells a set which way it's being used.

### Shots, the camera and transitions

`SHOTS` in `shots.js` lists each shot in order. A real one from the demo:

```js
{id:'walkers', t0:LT(1), set:'walkers', inT:WP(), cam:[[LT(1),900,500,1.06],[LT(2),1040,505,1.1]]},
```

`t0` is when it starts (here: the start of line 2). `cam` is a list of keys `[time, x, y, zoom]` in the set's 1920x960
picture; the camera eases between them and adds a slow drift so nothing sits dead still. Zoom 1 shows the whole set; the
crop can't leave the picture, so near an edge a high zoom is pushed back inward. `inT` is how the shot comes in: `WP()` a
painted wipe (new paint brushed across the old in broad strokes, `WP(.8)` for a slower one), `{type:'slide',dur:1.2}` (the
whole wagon slides away and the next one comes on, a lantern swinging in the gap: the demo uses it at the second verse),
`{type:'fade',dur}` up from black, or nothing for a cut. A shot can also carry `pics`: a lit still of another set, rising over
the picture as gold light and fading (the demo's last bars use one).

### Timing to the song

`shots.js` turns `SONG` into helpers: `LT(i)` is when line `i` starts, `WT(i,j)` when word `j` of line `i` is sung,
`BEAT(n)` is beat `n`, `SEC.verse2` is a section's `[name, start, end]`. Motion is written as functions of `t`:
`ramp(t,t0,t1,a,b)` eases from `a` to `b`, `bump(t,t0)` swells and falls around `t0`. For example, B's lantern catches on
"you:" and flares:

```js
const lanternK=t=>sstep(WT(1,3),WT(1,3)+.3,t);                                   // in sets_dusk.js
if(lk>0&&hB.lamp)S.glow(hB.lamp[0],hB.lamp[1],70,'lampLit',1.2*bump(t,WT(1,3)+.08,.08,.45));
```

The village's windows light one per beat of the second verse's first line (`BEAT(31)` to `BEAT(36)`), and the frame's
cues are all word times: the ribbons tie on "passing through" (`KNOT=[WT(3,3),WT(3,4)+.7]`).

### The wind

`BREEZE(t)` (a strength of about 0.1-0.6) and `GUSTS` (`{t, v, w, k}`: a bump of wind whose middle crosses x=960 at time `t`,
moving right to left at `v` px/s, `w` px wide, `k` strong) are set in `shots.js`. From them `wind.js` gives:

- `windStr(x,t)`: the strength at `x`, with some turbulence; `windAt(x,t)` the same as a signed push (negative: to the left);
- `windInt(t)`: how much wind has blown so far, tabulated once. Leaves, clouds and windmill sails move by it, so they hurry
  in a gust and never jump;
- `treeBend(x,t,k)`: how far a tree bows, following the wind a moment late.

Every prop takes `t` and asks the wind itself: `treeSprite` + `windTree` (round trees, poplars and pines, painted once and
bent in strips along a curve of constant length, so a tree that bows also dips), `grassBand`, `flyingLeaves` (gold leaf
that flashes as it turns over), `banner` (a swallowtail with a gold roundel), `washing`, `smokeStream`, `cloudBank`,
`weathervane`, `windmillBody` + `windmillSails`, `swingSign`, `starField`, `moonDisc` (`o.shadow` puts part of it in
shadow: .2 is a gibbous moon). Figures take `o.wind` and stream their cloaks, hoods and scarves; hanging lanterns lean and
swing with `hangSwing(t, wind)`.

For skies that aren't ours, `wind.js` also has weather the demo doesn't use (call it from a set's `dyn`, or `post`):

- `stormSky(S, t, {cx, cy, R, squash, arms, spin, seed, k, clip, bolts})`: a slow vortex of cloud with a glowing green
  eye. Lightning crawls along its arms three times a second, and bolts go up into the eye from each `[x, y]` of `bolts`,
  each on its own period; the flashes go into the light map, so the land under them flickers. `clip` keeps it in the sky.
- `retreatingStorm(S, t, edge, k, {dir, lit, seed})`: a storm going off over the edge of the sky, dark banks beyond
  `edge` with their trailing edge lit by the light coming back behind them, lightning still flickering in them. Move
  `edge` with time and it leaves; `dir` -1 sends it off to the left.
- `rainStreaks(g, t, {n, len, w, alpha, col, seed, toward})`: rain over the finished scene (from `post(g, t)`), slanted
  by the wind. With `toward: {edge, r, side}`, rain near land turned on its side bends to fall toward that land's own
  ground (`edge` is its ground line; `side` says which side of it is open air) instead of down.

These paint straight onto the enamel painter's layers (`S.T`), so the lab's chalk look leaves them out.

### Figures (`rig.js`)

`traveller(S, x, y, h, o)` poses a cloaked figure standing on `(x,y)`, `h` tall, facing `o.face` (1 right, -1 left).
`o.pose` holds `mode` (`stand`, `walk`, `sit`), `phase` (of the stride: use distance walked / (h/2) and the feet don't slide),
`lean`, `head` (looks up), `crouch`, and the arms `armF` (near) and `armB` (far). An arm is `{to:[u,v]}` in the figure's own
units or `{at:[x,y]}` in set pixels, so a hand lands exactly on a door, a pole or a lamp; `hold` puts something in the hand
(`lantern` with `lit`, `k` and `swing`; `pole` with `pole:[foot,top]`; `staff`, `stick`, `bowl`, `bread`). `o.gear` hangs a
`frame` pack or a `sack` on the back. `o.wind` streams the cloak; `o.tail` adds a scarf end; `o.lit` lights the face.
`packBeast` and `wagonSide` (springs that sag, wheels that roll with distance, `tilt` to rock, `flutter` for the canvas top, a
swinging lamp) work the same way.

### The frame

`drawCartouche(O, lamps, cold, {group})` draws the row of lamps; `lampsFor(t)` lights lamp `i` at `LAMP_T[i]` (one per line
in the demo, in two groups of four). `drawRibbons(O, state, t, wind)` draws the two ribbons from a state
`{tie, braid, part, loop, back, close}`, each 0..1: tie a knot, plait with a third strand, come undone and blow away, tie
one half, come back, tie again. `ribbonState(t)` in `engine.js` builds it from the cue times in `shots.js`. When two very
different ribbon shapes follow each other they dissolve through two small band canvases.

### Lyrics

`drawLyrics(O, t)` in `engine.js` writes the current line in the band under the picture, each word lighting as it is sung.
A line shows from a little before its first word until a little after it ends, never leaves before its last word has lit, and
waits for the line before it. Before `TITLE[1]` the band shows `SONG.title · SONG.credit` instead. `LINES` is `SONG.lines`
reshaped as `[section, text, start, end, [word times]]`.

### Determinism and caching

- There is no `Math.random`: everything random is `mulberry32` with fixed seeds, or noise of position and time.
- Brush strokes are seeded per shape (`S.seed(n)` plus a counter that goes up with every shape), so a shape painted again the
  next frame gets the same strokes. The counter means that adding or dropping a shape shifts the strokes of everything after
  it; the sets call `S.seed()` before each figure, `cottageWindows` before each window and `flyingLeaves` before each leaf,
  so a lamp lighting up, an arm appearing or a leaf leaving the picture doesn't make its neighbours' paint boil.
- A scene is repainted "on twos", 12 times a second, like hand-painted animation; the camera, the frame and the lyrics move
  at 24. `renderScene` keeps the last painted scene per slot and reuses it until the twelfth of a second changes.
- `back`, `front` and sprites are painted once (`bakeSet`, kept for up to nine sets); `prepareAll()` builds everything at load
  so the first frame of a set doesn't stall.
- `step(t)` and `renderAt(t)` are the same function and any frame can be drawn from scratch, in any order.

## Make your own video in this style

1. Copy the folder: `cp -r styles/painted-enamel projects/my-song` (or anywhere under the repository).
2. Make your song's `lyrics_data.js` with the audio tools (`tools/audio/to_js.py`, the last step of
   [docs/timing.md](../../docs/timing.md)) and point the first script tag of `index.html` at it. `SONG.audio` is the song's
   path relative to the page.
3. **Keep** `core.js`, `paint.js`, `props.js`, `rig.js`, `wind.js`, `frame.js`, `engine.js` and `player.js`.
   **Replace** `shots.js` (your timeline) and the `sets_*.js` files (your scenes); update the script tags if you rename them.
4. In `shots.js` set `TITLE` (when the title card shows), `LAMP_T` and `LAMP_GROUP` (a dozen lamps at most: one per section
   works for a long song), the ribbon cues (`KNOT`, `BRAID`, `UNBRAID`, `PART`, `LOOP`, `BACK`, `CLOSE`: set any you don't
   want beyond the end of the song), `BREEZE` and `GUSTS` (or `BREEZE=t=>0` and `GUSTS=[]` for a still night), `NIGHT` and
   the two ambient colours.
5. Add a set: copy one from `sets_dusk.js` and change it. Paint what never moves in `back` (use `S.layer(d)` to push far
   things into the haze), sprites in `prep`, what moves in `dyn`, and whatever stands in front of the action in `front`
   (a wall a figure walks behind). Give it `lightsAt(t)` and `ambientAt(t)`.
6. Add shots to `SHOTS`, one per line or per phrase: `{id, t0, set, inT, cam}`. Put changes on line starts (`t0:LT(i)`) and
   frame the camera with `#t` stills.
7. Time a move to a word: `const k=ramp(t,WT(5,1),WT(5,1)+.8)` goes from 0 to 1 over the 0.8 s after word 2 of line 6. On a
   beat: `bump(t,BEAT(40))`. Everything is a function of `t`, so there is no state to reset when you scrub.
8. Check it: `python tools/still.py projects/my-song/index.html 0:END:2.5 --sheet`, read the console errors it prints (a
   single `NaN` in a gradient blanks a frame), then render.

Useful knobs:

- the look of the paint: `bristles` options (`alpha`, `ragged`, `var`), the flick width in `flicks` (`fw`), `lining`'s
  weight, `leafFill`'s gradient and catch;
- the night: `AMB_DUSK`, `AMB_NIGHT` and `NIGHT(t)` in `shots.js`, each light's `r` and `k`, `LIGHTCOL`;
- the frame: `X0, Y0, PWd, PHd` (the panel), the board and lining colours in `buildFrameStatic`, the varnish's craze
  strength in `buildVarnish` (0.2);
- the wind: `BREEZE`, `GUSTS`, `treeBend`'s factor (0.16), each prop's `lean`/`speed` option;
- pace: the wipe length in `WP(d)`, the slide's `dur`, the camera keys.

## Lab

Open <http://localhost:8000/styles/painted-enamel/lab/index.html> and use the buttons, or
`lab/index.html?scene=village&style=chalkboard`. Render every scene in every look:

```bash
python tools/lab_stills.py styles/painted-enamel/lab/index.html --all --sheet
```

The lab draws two moments of the demo (the road at dusk at 5.6 s, the village at 27.9 s) through each look, calling the
demo's own sets. `lab/lab.js` lists them in `LAB_SCENES` (a set, a time, a camera and the lyric line to show).

- **Enamel** is the video's own path: `renderInto` paints the set with the enamel painter and the light map, and
  `composePicture` puts it in the wagon frame.
- **Chalkboard** (`lab/style_chalk.js`) sends the same calls to a chalk style. Masses are laid with the side of the chalk and
  then outlined; hatching sits on the side toward the light; fires, lamps and windows are rubbed into glows; a later shape
  rubs out what's behind it. The board's tooth decides where chalk takes, so light pressure breaks into specks. There is no
  light map: the board is lit by one lamp above it. The whole set is drawn smaller in the middle of a slate board with years
  of rubbed-out marks, notes chalked into grooves along the top (wind, leaves, lamps, windows, the moon) and a column down the
  right that keeps count (gusts so far, leaves down, a lamp ringed for the current line). Sprites are chalked into their own
  canvases with a solid mask for rubbing out.

## Performance

- **Build:** about 5 s at load (the five sets' still layers, sixteen tree sprites, the varnish's craze, the outro's gold
  picture). Longer when other heavy work is running.
- **Per frame:** about 20-60 ms to draw on an Apple-silicon Mac, most of it the moving paint: figures (a few dozen shapes
  each, every one a bundle of strokes), grass blades, leaves, and the light map. The same scene is reused for alternate frames
  (on twos). A painted wipe or a slide draws two scenes, so its frames cost about double.
- **MP4:** about 40-75 ms a frame for a `--fast` render including readback and encoding, so the whole demo takes about a
  minute. (With several other heavy renders running on the same machine it took three times as long.)
- **Memory:** about 350 MB of canvases, most of it baked layers (three 1920x960 canvases per set, six with a front layer).
  JavaScript itself uses little.
- **What makes it slow:** big `foliage` shapes painted every frame (hundreds of leaf strokes each: paint trees once as sprites
  and bend them), many blades of grass, and canvas filters (blur, brightness) used per frame. Everything that can be made once
  is made once.
- **A slice:** `python tools/render_mp4.py styles/painted-enamel/index.html --fast --start 15 --end 21`. Every frame depends
  only on its time, so a slice matches the full render and can be spliced in with `tools/splice.py`.

## Lessons and gotchas

- **Washed out and sepia:** a warm overlay, a heavy amber varnish and a strong craze turned a first painted pass into mud
  tiles. The light map (multiply, then self-lit paint on top), crisp flicks instead of soft bevels, and a fine craze fixed it.
- **Soft highlight bands round every shape read as an airbrushed bevel.** Separate one-stroke flicks set in from the lit
  edge read as paint. Four parallel fold strokes read as claw marks: use one dark stroke with one light flick beside it.
- **Glows wash over whatever is in front of them** until every reflective shape knocks out the self-lit paint and glow
  behind it. A figure walking into a bright doorway looked translucent until drawn as a dark silhouette (`S.backlit`), since
  the light map can't tell which side of a figure faces the light.
- **A hood opening painted flat black reads as a void.** Light the chin and the tip of the nose from the fire.
- **Things at the wrong height read as other things:** a bedroll carried at head height looked like a hat brim.
- **Long ribbons of paper arcing between two figures read as pale tubes across their faces.** Keep small things in hands.
- **A still layer is baked once per set,** so anything that differs between two shots of the same set (who stands where,
  what's lit) must be painted in `dyn`.
- **Lyric timing:** lines stay 0.8 s after they're sung but never leave before their last word has lit, and the next line
  doesn't show across a cut.
- **Smoke drawn as round-capped segments stacks its opacity into a solid tube.** Draw it as a few long strokes at low opacity,
  layered.
- **Trees built from many small clumps looked like stacked cabbages.** A few big scalloped lobes, the back ones darker, read
  as painted trees; poplars as one tall flame with a lighter one inside it.
- **Random light and dark leaf strokes read as camouflage.** Use a light tone and a mid tone.
- **Gold leaf multiplied by a dim light map looks like beige paint.** Give it a small glint (a glow) when it turns to face the
  light, and keep the burnished catch small and yellow rather than white.
- **Three stacked strokes for a cloud read as a flying saucer.** One or two long tapered streaks with a lit underside read
  as cloud.
- **A gust is only visible against calm.** Drop the breeze just before it (a lull), and the travelling band of bent, pale grass
  and bowing trees stands out.
- **A tree rotated about its foot looks like it is falling over.** Bend it in strips along a curve of constant length, so the
  crown dips as it bows.
- **A gesture behind another figure is lost.** When a hand has to meet something (a lamp), make sure nobody stands between it
  and the camera; painting order decides who covers whom.
- **Sky painted per frame lands on the baked buildings.** Clip clouds and stars to the sky.
- **A dark sky with white stars reads as an ordinary night on Earth.** To make a night plainly somewhere else, change
  its lights (motes in the aurora's colours, some strung in short lines, with no cross-shaped glints) or its weather.
- **A plain dark storm is just a dark sky.** Give it a shape you can read at a glance (a slow spiral with a lit eye,
  lightning crawling along its arms, bolts going up into it rather than down) and put the flashes in the light map, so
  the land under it flickers with them. A darkness that is weather rather than night reads best on its way out: a storm
  going off over the edge of the sky, its trailing edge lit by the light coming back.
- **Rain obeys the ground it falls on.** Near land turned on its side, rain that still falls straight down reads as a
  mistake; bend it toward that land's own ground, more the closer it gets.
- **Build what the first frame needs at load.** A tree sprite first needed mid-shot stalls that frame, and a sprite requested
  with different options than it was made with comes back as the cached one: give each sprite one function that makes it.
- **A fade from pure black gives a blank first frame.** Start from a dim picture instead.
- **The camera can't leave the set.** A zoomed camera centred near an edge is pushed back inward, so frame with stills.
- **Check the console.** One bad value in a canvas gradient kills the whole frame; the still tool prints errors.
- **The browser caches scripts.** Serve with `tools/serve.py`, which doesn't, or an edit can keep running its old version.



===== 完整公共规范：CLAUDE.md =====

# Instructions for Claude

This repository makes music videos in code: each style in `styles/` is an engine that draws every frame on an HTML
canvas (or WebGL / three.js) in a hand-made-looking medium, timed to a song, and `tools/` renders them to MP4. Read
`README.md` for the map, then the doc for whatever you're doing.

## When someone wants a video for their song

Follow [docs/workflow.md](docs/workflow.md). It's a conversation, not a build order to rush through:

1. **Get the inputs:** the song (mp3), the lyric sheet as sung, and ask whether they have stems and MIDI (Suno and
   stem splitters provide them) and any reference images.
2. **Ask the concept questions before building anything:** who is singing, who "you" is, whose voice the chorus is,
   what the key images (especially the ending) mean, how much the video may show, what stays out. Don't guess at
   these; an open question is better than a confident wrong answer. If the song belongs to a larger world, read
   whatever they give you about it, and keep a list of every detail the video invents, flagged as unconfirmed.
3. **Measure the song** ([docs/timing.md](docs/timing.md)): tempo, sections, stops and hits, and every word's time.
   Time to the audio, not to the lyric sheet's markings.
4. **Pitch three looks and recommend one:** the medium and why it suits this song, the organizing object, a small
   visual grammar and an arc, a section-by-section plan keyed to timestamps, and the open questions. The styles in
   `styles/` are the starting points (each README says what it's good at); a new medium is fine too
   ([docs/engine-patterns.md](docs/engine-patterns.md)).
5. **Style lab:** the same three or four moments drawn in each candidate look. Show the stills.
6. **Checkpoint:** build one section (20-90 s), render it (`--fast`), send it, get notes.
7. **Build the rest** section by section, then render the final MP4s. The MP4 is what gets shared.

Build a project in `projects/<song-slug>/`, copied from a style folder ([docs/your-own-video.md](docs/your-own-video.md)).
Don't change `styles/` for one person's video. Keep notes in `projects/<song-slug>/PLAN.md` as you go: their answers
and rulings, the measured sections and sync points, the shot list, the invented details, and their feedback on each
round. A later session should be able to pick up from that file alone.

## Working practices

- **Look at what you render.** Make stills and contact sheets (`tools/still.py ... --sheet`) and open the images.
  Check every frame on the sheet: edges, blank frames, the camera inside things, covered text, long freezes.
- **Read the console output** the tools print. A single bad canvas gradient value blanks a frame.
- **Preview slices with `--fast`**; render the full 1080p only at the end. Styles that carry state between frames
  must be rendered in order (the tools do this).
- **Keep it deterministic:** seeded randomness keyed to the frame, never `Math.random()` per frame.
- **Follow the page contract** in [docs/rendering.md](docs/rendering.md) (`window.__video`, `window.SONG`,
  `<canvas id="film">`, `#t<seconds>` stills) so the tools work.
- Apply the lessons in [docs/workflow.md](docs/workflow.md#what-the-notes-taught-true-for-every-style): busy
  enough, no long freezes, obvious changes, varied choruses, whole figures rather than close-up hands.
- The person's audio is git-ignored. If their lyrics or story are private, keep the project out of any public
  remote (add it to `.git/info/exclude`, or keep it outside the repo and pass `--root` to the tools).

## Setup

```bash
python3 -m venv .venv && .venv/bin/pip install -r requirements.txt -r requirements-audio.txt
```

Google Chrome must be installed (or `.venv/bin/python -m playwright install chromium`). To preview in the desktop
app's browser pane, create `.claude/launch.json` running `python3 tools/serve.py 8000` on port 8000 (git-ignored).
Use the server, never `file://`: module pages don't load from files and a plain server caches stale scripts.



===== 完整公共规范：docs/workflow.md =====

# How a video gets made

These videos were made in conversation: a person with a song and a clear sense of what it's about, and Claude
writing and rendering the code. The process below is what worked over a dozen songs. It suits working with Claude
Code (see [CLAUDE.md](../CLAUDE.md), which tells Claude to follow it), and it works just as well by hand.

The short version: **decide what the song is about, measure it, pitch three looks, test the look on a few scenes,
build one section, get notes, then build the rest.** Each step is cheap next to the one after it, so mistakes get
caught while they're still cheap.

## 1. Gather the inputs

- **The song** as an mp3 (or anything ffmpeg reads).
- **The lyric sheet** as plain text, one sung line per line, with `#section` markers (see
  [examples/poem/lyrics.txt](../examples/poem/lyrics.txt)). Write it the way it's sung: if the singer repeats a line
  that isn't on the sheet, add it.
- **Stems, if you have them.** An isolated vocal stem makes transcription far cleaner. Suno exports stems as audio
  and as MIDI per instrument; the MIDI's tempo map gives an exact beat grid, and the vocal MIDI gives note onsets to
  snap words to (see [timing.md](timing.md)).
- **Reference images, if any.** Mood boards and concept art are useful for content (what's in the world, what
  people wear, what the place looks like) even when the style will be different.

## 2. Decide what the song is about

Before any pictures, answer the questions that decide the concept. A video can't be good if these are guesses.

- **Who is singing,** and to whom? Who is "you"? It's often not who it seems, and it can change between verses.
- **Whose voice is the chorus?** The singer's, an imagined audience's, a crowd's, a custom's?
- **What do the key images mean?** Especially the closing one.
- **How much may the video show?** If the song belongs to a larger story, what would be a spoiler?
- **What stays out?** Eras, events, people, kinds of imagery.

If the song is part of a larger world (a novel, a game, a band's mythology), read up on it first, and **keep a list
of every detail the video invents**: a place's layout, what a prop says, who stands where. Show that list to
whoever owns the world, and treat nothing on it as settled until they say so.

## 3. Measure the song

Time the video to what the audio does, not to what the lyric sheet says. (AI song generators in particular ignore
markings like "quiet" or "almost unaccompanied".) With the tools in [timing.md](timing.md):

- tempo, and whether it changes;
- the sections and their loudness: which chorus is the big one, where it drops to almost nothing;
- **the stops and hits.** Musical stops, dropouts and the hit that ends a bridge make the best sync points: the
  place to freeze, cut, switch a light off, or change the whole picture;
- every word's time.

## 4. Pitch three looks

Offer three directions and recommend one. For each:

- **the medium** (paper cut, embroidery, marbled paper...) and why it suits this song. The strongest choices mean
  something: marbled paint for a song about water, where nothing stays put; a lantern lecture for a song sung by
  someone lecturing; a desk of files and stamps for a song about a record that doesn't add up;
- **the organizing object:** the one thing the whole video is, such as a desk under a lamp, a hanging read along
  its length, a printed sheet, a painted wagon's panels, a board of pasted-up photographs;
- **a small visual grammar:** a few rules that give the images meaning (stamps are the audience's verdicts, frost
  is the stillness, the camera's date flickers between years), and an **arc** over the song (clean to decayed,
  night to morning, empty to crowded);
- a **section-by-section plan** keyed to timestamps, giving each section one main image;
- the questions still open.

The [styles/](../styles) folder has eighteen engines to start from, and each one's README says what it's good at.
A new song can also want a new medium: the engines share their patterns ([engine-patterns.md](engine-patterns.md)),
so a new one is less work than it sounds.

## 5. Style lab

Draw the same three or four key moments in each candidate look, side by side, as stills (and a few seconds of motion
if the look depends on how it moves). Comparing like with like makes the choice easy, and it shows the problems
early: people who look like mannequins, faces that look ill, a palette that turns cute. Every family here with more
than one look has a lab page (`styles/<family>/lab/`) built this way.

Expect the first choice to be refined: "this look, but with the other one's colours", or "this, for the scenes in the
other world only". Mixing is fine.

## 6. Checkpoint

Build a real section before the whole song: 20-30 seconds of the section that carries the concept, or the first
90 seconds. Render it as an MP4 and get notes on the look, the pace, the figures, the text. This is where most of
the useful notes arrive, and they're cheap to act on now.

## 7. Build the whole song

Section by section. After each, render stills across it (`tools/still.py ... a:b:2 --sheet`) and look at every one:
frame edges, blank frames, things the camera cuts through, text that's unreadable or covered. Fix, then move on.
When it's all there, render the MP4, then scan it at one frame every two seconds.

## 8. Notes, and fixing a stretch

Notes on a full video are usually local: one stretch feels empty, one chorus repeats the last, a transition jerks.
Re-render only that slice and splice it in ([rendering.md](rendering.md#fixing-one-stretch)).

## 9. Deliver an MP4

Share the MP4, not the web page. A browser player's pause and scrub can feel unreliable, and people give up on it.
`tools/render_mp4.py` writes a 1080p file and a smaller 720p one for sending.

## 10. Revising a finished video

A second or third pass (new conventions, a list of fixes, a stretch that needs more going on) works best as: a short
written plan of every change; then before/after sheets, stills from the old render and the new build at the same song
times side by side; then the full render. The sheets let the notes land on exactly what changed. When picking stills
for review, catch short effects at their peak: a flash or a bolt that lasts half a second is easy to miss.

## What the notes taught (true for every style)

- **Busy enough.** Something new on nearly every beat, or at least every line. A stretch with nothing happening
  reads as a mistake, not a rest. When a stretch feels empty, fill it with callbacks (translucent overlays of earlier
  scenes) and background life (children, animals, people passing) rather than restaging it.
- **No long freezes.** A four-second still reads as the player stalling. Keep holds to a beat or two, or keep
  something drifting: a slow camera move, breathing light, smoke.
- **Make small changes obvious.** A face swapping for another face, a detail changing on a paper: if it matters,
  make it big and push the camera in on it. Subtle changes go unseen.
- **Too clean reads as dead.** A video that stays tidy all the way through can feel flat; give it an arc.
- **Vary the repeats.** The second chorus shouldn't replay the first. New scenes, with brief flashes back to the
  first chorus's pictures on key words, keep the echo without the repetition. A motif that does something different
  each chorus (ribbons that knot, then plait, then slip) works well.
- **Whole figures beat close-up hands.** Big silhouettes of hands and arms read as clubs, poles or chess pieces. A
  whole figure, even small and mostly still, carries a beat better.
- **Faces:** realistic halftone or heavy shading can make people look ill. Stylized faces (dot eyes, lowered lids
  when looking down) for close figures and blank faces for crowds read better.
- **What makes a look cute** (sometimes wanted, often not): flat candy fills, rounded sack-shaped figures with blob
  heads, even lighting, bobbing walks. For solemn songs, use weight, texture, uneven light and stillness instead.
- **Real texts make good props.** A period document, a real letter or hymn, an actual map give a scene weight even if nobody
  can read them.
- **Impossible places need ordinary things in them.** Floating or folded land only reads as land when it carries
  trees, lit windows, snow on its ground side, smoke going the "wrong" way.
- **Decide about text in the picture.** A lyric band under the picture is one choice; no readable text at all
  (squiggles for writing) is another; either way, be consistent. Captions that only repeat the lyric are redundant.
- **Fake text is worse than no text.** A card of invented glyphs that flickers reads as a screen of foreign writing.
  Use pictograms, squiggles, or nothing. Likewise on-screen read-outs (temperatures, timecodes) in a "technical"
  medium: keep them only if they mean something.
- **Show the medium working.** When a look risks feeling static (a photograph, a print, a drawing), let the viewer
  watch it being made: a plate exposing, inks printing in on the beats, stitches sewn in, a slide pushed into the
  lantern. It answers "static and unclear" without changing the look.
- **Vary what leads a scene.** In a medium with a life of its own (liquid light, marbling, sand), let some scenes be
  led by the pictures and some by the medium, rather than the same mix throughout.
- **Props must sit in hands.** A rope, a ring, a cloth or a cup that floats near a hand reads as broken. Anchor held
  things to the rig's hand points and check every one in stills.
- **Arms that move naturally:** pose them by where the hand and elbow should be, blend joint angles rather than
  positions, let the forearm trail the upper arm, and add breathing and small weight shifts. Arms that slide
  straight between poses look like a puppet's.
- **Bodies carry identity.** In silhouette, heat or other outline-first looks the outline is all a viewer gets: if
  someone is heavily built, or small and round, the shape must show it. Keep sizes consistent (an animal is as big in
  every shot).
- **Shapes read as other shapes.** A figure lying flat reads as a collapsed body (have them sit or doze upright unless
  a death is meant); a pyramid of sacks in a lit doorway reads as a hooded head; a fan of hair strands reads as a
  feathered headdress. Look at every silhouette as a stranger would.



===== 完整公共规范：docs/timing.md =====

# Timing a song

Everything in a video hangs off the song's clock: the lyric band lights each word as it's sung, pieces land on
beats, scenes change on line starts, the lamp goes out in a dropout. This page is how to get those times. The tools
are in [tools/audio/](../tools/audio); each prints its own help with `--help`.

Setup (once): `pip install -r requirements-audio.txt` (librosa, scipy, faster-whisper, mido). The Whisper model
downloads the first time it's used.

## The pipeline

```bash
# 1. the shape of the song: tempo, loudness, sections
python tools/audio/analyze.py song.mp3

# 2. words with timestamps, from the vocal stem if you have one
python tools/audio/transcribe.py vocals.mp3 --lyrics lyrics.txt --out whisper.json

# 3. your lyric sheet matched to Whisper's words
python tools/audio/align.py lyrics.txt whisper.json --out lines.json

# 4. snap each word to where the voice starts it (vocal MIDI and/or vocal audio)
python tools/audio/snap.py lines.json --midi vocals.mid --audio vocals.mp3 --out snapped.json

# 5. the page's data file
python tools/audio/to_js.py snapped.json --out projects/my-song/lyrics_data.js --title "My Song" \
    --audio song.mp3 --audio-file projects/my-song/song.mp3 --bpm 96 --beats-per-bar 4
```

Then open the video with the lyrics showing and listen through. Fix what's off by editing `lyrics_data.js`
directly: it's plain data.

## Step by step

### 1. The shape of the song

`analyze.py` prints the global tempo and the local tempo every 20 s, a table of loudness, brightness and rhythmic
busyness every few seconds, and guesses at section boundaries. Read it next to the lyric sheet. You're looking for:

- which sections are loud and which drop out: the video's big and quiet moments should follow them;
- tempo changes (a slow intro, a half-time bridge);
- **stops and hits.** `onsets.py song.mp3 --from 140 --to 155` zooms in on a stretch: the strongest onsets, the
  beats, and the loudness every quarter second, so a dropout shows as a run of low numbers. These are the best
  sync points a song offers: the place for everything to freeze, for a cut, for a light to go off.

`sections.py song.mp3 --lines lines.json` compares the sections' loudness, drums and tonal energy once you know
where they are.

### 2. Transcribe

`transcribe.py` runs faster-whisper with word timestamps. Give it the **vocal stem** if there is one; sung vocals
over a full mix transcribe much worse. The `small` model is usually enough and takes about a minute. `--lyrics`
passes the start of your lyric sheet as a prompt, so names and odd words come out spelled your way. `medium` can
rescue mumbled lines, but over a long song it can drift further than `small`.

Expect Whisper's times to run **early**, typically a few tenths of a second and sometimes by more than a second,
and to hear some words wrong, especially names and unusual words. Step 3 doesn't care about wrong words; steps 4 and
the listen-through fix the times.

### 3. Align

`align.py` lines your sheet up against Whisper's words (a sequence match, so misheard or missing words don't break
it; unmatched words get times interpolated from their neighbours). It prints each line with a match count like
`m7/9`. Low counts are where to listen first. Watch for:

- **numbers:** Whisper writes "1974" as one token for three sung words. The script spells out years and small
  numbers before matching, but check them;
- **hyphenated words** and contractions;
- **a misheard last line** ("Let it go" for "Letting go"): the end of a song, over a fade, is where Whisper guesses;
- **repeats and ad-libs** the singer added: put them on the sheet as sung, or they'll be squeezed between
  neighbours.

### 4. Snap to the voice

`snap.py` moves each word to the nearest sung-note onset within 0.32 s: note onsets from the **vocal MIDI** first
(if you have it), then onsets detected in the **vocal audio**. It first reports the median offset between the words
and the onsets; if Whisper ran early across the whole song, pass that back as `--shift` so everything moves before
snapping.

After snapping, some things still need a human ear:

- **line starts that land in silence** or on the tail of the previous word: move them to where the voice comes in;
- **choruses and held notes:** a melisma or a long held word confuses onsets;
- **MIDI quantization:** Suno's MIDI is quantized to sixteenth notes and can sit about 0.3 s off the voice.

For those, `onsets.py vocals.mp3 --from 25 --to 27 --pitch` prints the sung pitch and loudness every 50 ms: the
word starts where the pitch appears and the loudness jumps.

### 5. Write the page data

`to_js.py` writes `lyrics_data.js`, which sets `window.SONG`:

```js
window.SONG = {
  title: "My Song", credit: "", audio: "song.mp3", duration: 212.4,
  bpm: 96, beatsPerBar: 4, firstBeat: 0.35,
  sections: [["verse1", 12.3, 41.0], ...],
  beats: [0.35, 0.975, ...],            // only with --beats: exact beat times
  lines: [{section: "verse1", text: "Who has seen the wind?", t0: 12.3, t1: 14.9,
           words: [["Who", 12.3], ["has", 12.9], ...]}, ...],
};
SONG.beat(n)  // the time of beat n
```

Every style in this repo reads that shape (see [examples/poem/lyrics_data.js](../examples/poem/lyrics_data.js)).

## Beats

For a steady song, `--bpm` and `--first-beat` (the time of the first downbeat) are enough: `SONG.beat(n)` is
`firstBeat + n * 60 / bpm`. Find the first beat with `onsets.py` on the song's opening seconds.

If the tempo drifts or changes, use exact beat times instead:

- **from MIDI stems:** Suno writes a tempo event on every beat, so the tempo map is an exact beat grid.
  `midi.py drums.mid --beats-out beats.json` (any of the song's MIDI files will do);
- **from the audio:** `analyze.py song.mp3 --beats-out beats.json` (librosa's estimate; check it).

Pass the file to `to_js.py --beats beats.json`; `SONG.beat(n)` then reads from the list.

## Hits and loudness

Some styles pulse, flash or move with the music itself rather than the words: a lamp that breathes with the mix, a
ring on every drum hit, mouths that open with the voice. `pulses.py` measures those:

```bash
python tools/audio/pulses.py song.mp3 --percussion perc.mp3 --drums drums.mp3 --vocals vocals.mp3 --out projects/my-song/audio_data.js
```

It writes `window.AUDIO = {fps, ticks, kicks, env, venv, vdb}`: small hits (`ticks`) and big ones (`kicks`) as
`[time, strength]`, the mix's and the voice's loudness 24 times a second (`env`, `venv`, 0..1), and the voice's
loudness in decibels mapped to 0..1 (`vdb`, better for mouths). Stems give much cleaner hits than the mix; without
them everything comes from the mix. The liquid light show reads this file as it is; any style can read the arrays.

## Suno specifics

- The stem download gives an audio file and a MIDI file per instrument. The lead vocal stem transcribes cleanly.
- The MIDI files carry a key-signature event that the `mido` library can't decode (it raises
  `KeySignatureError`). `tools/audio/midi.py` patches mido to read it as C; import `load()` from it in your own
  scripts to get the fix.
- The MIDI tempo map has one event per beat: an exact beat grid, including tempo changes after an intro.
- Vocal MIDI notes are quantized and can sit up to ~0.3 s off the voice: good anchors for snapping, not ground truth.
- Suno ignores dynamics on the lyric sheet ("quiet", "spoken", "almost unaccompanied"). Measure.

## Checking by eye and ear

Open the page, play it with the sound on, and watch the lyric band. Words that light up early are the common
fault. For a close look, `#t25.3` on the page's URL shows the frame at 25.3 s with the band as it is then.



===== 完整公共规范：docs/rendering.md =====

# Previewing and rendering

Every video here is a web page that draws its frames on a canvas. You watch it in a browser while you work, and
when it's done a script steps through it frame by frame in headless Chrome and pipes the frames to ffmpeg. This
page covers the page contract the tools rely on, previewing, stills, MP4s, and fixing a stretch.

Setup (once): `pip install -r requirements.txt` (Playwright, imageio-ffmpeg, Pillow, numpy). The tools drive your
installed Google Chrome; if you don't have it, `python -m playwright install chromium` gets Playwright's own.
imageio-ffmpeg bundles an ffmpeg with x264 and AAC, so there's nothing else to install.

## The page contract

A video page (a style's `index.html`, or a copy of one for your song):

- draws into `<canvas id="film" width="1920" height="1080">`;
- loads its song data as `window.SONG` (see [timing.md](timing.md#5-write-the-page-data)) and plays `SONG.audio`
  in an `<audio>` element, falling back to a silent clock if the audio can't load;
- sets `window.__video`:
  - `ready`: true once everything is built;
  - `duration`: the song's length in seconds;
  - `step(t)`: draw song time `t` the way playback does. The MP4 renderer calls it at 24 fps, strictly in order;
  - `renderAt(t)`: draw a still of time `t` from a fresh state (catching up whatever the frames before it built);
  - either may return a Promise (a page that builds scenes asynchronously); the tools wait for it;
  - `error`: set this to the error text if building fails, and the tools stop and print it;
  - optionally `shots` and `probe(t)` for 3D pages (see `tools/probe.py`);
- shows a still when the URL ends in `#t<seconds>` (e.g. `index.html#t12.5`), with the page chrome hidden;
- draws only while playing: a paused player shouldn't keep redrawing its frame on every animation frame (the tools
  draw and read back each frame in one call, but a page that redraws on its own fights anything else that draws);
- is **deterministic**: all randomness comes from seeded generators keyed to the frame number, never
  `Math.random()` per frame, so a given moment always draws the same picture. An MP4 depends on it.

A style-lab page sets `window.__lab = { ready, scenes, styles, render(scene, style) }`, where `render` draws one
scene in one look and returns the canvas.

## Previewing

```bash
python tools/serve.py            # serves the repository at http://localhost:8000/ and lists the demo pages
```

Open a page from the list. Use this server rather than `python -m http.server` or opening the file directly:

- pages that use ES modules or load files **don't work from `file://`**;
- a plain server lets the browser **cache scripts**, so after an edit you can be looking at the old code. This
  server sends no-cache headers;
- audio and video only seek when the server answers **Range requests**; this one does.

**Stills in the browser:** add `#t<seconds>` to the URL. Changing only the `#` part doesn't reload the page, so
after editing code, reload with a new query (`index.html?r=2#t30`).

**Always check the console** after a load. One bad value in a canvas gradient (a NaN colour stop) throws, and the
whole frame goes blank.

**In Claude Code's desktop app**, the preview pane can run the server for you: create `.claude/launch.json` with
```json
{ "version": "0.0.1", "configurations": [
  { "name": "videos", "runtimeExecutable": "python3", "runtimeArgs": ["tools/serve.py", "8000"], "port": 8000 } ] }
```
(it's git-ignored).

## Stills and contact sheets

```bash
python tools/still.py styles/paper-cut/index.html 5 12.5 30          # three stills
python tools/still.py styles/paper-cut/index.html 0:37.5:2.5 --sheet # a frame every 2.5 s, tiled into one image
python tools/lab_stills.py styles/embroidery/lab/index.html --all --sheet
```

Output goes to `renders/` (git-ignored). The contact sheet is the fastest way to review a whole video: look at every
frame on it, not just the ones you changed. Things to look for: frame edges showing the end of the world, blank or
black frames, the camera inside an object, text covered or cut off, two scenes' seams, something frozen too long.

## MP4s

```bash
python tools/render_mp4.py styles/marbling/index.html                    # renders/marbling.mp4 and -720p.mp4
python tools/render_mp4.py projects/my-song/index.html --out "renders/My Song.mp4"
python tools/render_mp4.py projects/my-song/index.html --start 60 --end 90 --fast   # quick preview of a slice
```

- Two files: 1080p (x264 `slow`, CRF 23, AAC 192k: roughly 5 Mbps for a busy picture) and `-720p` (CRF 25: about
  1 Mbps, small enough to send).
- `--fast` writes only the 720p with the `veryfast` preset. Busy, grainy frames can take many times longer to
  encode with the slow preset than to draw, so use `--fast` for previews and the normal mode for the final.
- The audio comes from `SONG.audio` unless you pass `--audio`. A slice gets short audio fades.
- **Fonts:** the styles load their type from Google Fonts. If a font request fails (a flaky network), canvas text
  silently falls back to a default font, so `render_mp4.py` and `render_frames.py` check the page's fonts after it
  builds and stop if any failed. Run again, or pass `--allow-font-fallback` if you really mean it. The still tools
  print a warning instead.
- 24 fps. Frames are rendered **in order**: many styles draw each frame over the one before (frost that grows,
  ghosting, marbled paint that keeps its history), so a frame can't be drawn on its own.
- Speed depends on the style and on how much the machine is doing: from about 40 ms a frame (paper cut, painted
  enamel, archive desk) to 250 ms or more (sand, the pinscreen, screenprint's printing), including reading the frame
  back and encoding. Each style's README gives its numbers. A four-minute song is 5,760 frames: a few minutes for the
  fast styles, half an hour or more for the slow ones (see the next section for splitting a render across browsers).

## Long renders: frames on disk, resumable, in parallel

For a long song in a slow style, render the frames to a folder instead of straight into ffmpeg:

```bash
python tools/render_frames.py projects/my-song/index.html --dir renders/frames/my-song --jobs 3
python tools/encode.py renders/frames/my-song --out "renders/My Song.mp4"
```

- Frame `i` is `<dir>/<i:05d>.jpg` and shows song time `(i + 0.5) / 24`. Frames already on disk are skipped, so an
  interrupted render continues where it stopped when you run the same command again, and deleting a stretch's
  frames and re-running redoes just that stretch.
- `--jobs N` renders N runs of frames in N browsers at once. Each run starts with `renderAt()` at its first frame,
  which catches up styles whose frames depend on earlier ones, then steps in order. (Tested: a resumed run's frames
  match a straight-through render pixel for pixel.) GPU-heavy styles gain less, since the browsers share one GPU.
- `encode.py` takes the audio from the folder's `meta.json` (the page's `SONG.audio`), cuts it to the frames on
  disk, and writes the same 1080p and 720p files as `render_mp4.py`.
- **A render that sits before its first frame** is usually the machine, not the page: with other renders or heavy
  WebGL pages running, Chrome can take minutes to start or to build a page. `render_mp4.py` prints the page's URL when
  it's loaded and a progress line every 240 frames.
- **Heavy 3D pages:** building every set of a long WebGL video at once can hang the GPU. Render such a video in
  segments (`--start`/`--end` runs into the same frame folder, each run building only what its stretch needs), and
  on a machine that other renders are sharing, run one segment at a time.

## Fixing one stretch

A full render can take a while. To fix one stretch, render only that slice at full quality and splice it into the
finished file at whole frames:

```bash
python tools/render_mp4.py projects/my-song/index.html --start 120 --end 135 --out renders/fix.mp4
python tools/splice.py "renders/My Song.mp4" renders/fix.mp4 --at 120 --out "renders/My Song v2.mp4"
```

A slice opens with `renderAt(t)`, which catches up styles whose frames build on earlier ones, so its frames match the
full render's and the splice is seamless.

## Checking a 3D video's framing

`python tools/probe.py styles/diorama/index.html` asks the page, for the start, middle and end of every shot,
whether anything stands between the camera and its subject, or whether the camera is inside something. In a crowded
set it finds blocked views much faster than contact sheets.

## Sharing

Share the MP4. If you also want a review page (the video with notes around it), keep in mind that some hosts cap
file sizes: split a long 720p video into parts at scene changes and play them in sequence against the song, and
serve it from something that answers Range requests.



===== 完整公共规范：docs/your-own-video.md =====

# Making a video for your own song

The hands-on steps, from an mp3 to an MP4. For the creative side (what to decide before building, how to pick a
look) see [workflow.md](workflow.md). If you're working with Claude Code, you can just ask it to make a video for
your song: [CLAUDE.md](../CLAUDE.md) walks it through all of this.

## 1. Set up

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt            # rendering
pip install -r requirements-audio.txt      # timing a song (Whisper, librosa, MIDI)
```

You need Google Chrome installed (or run `python -m playwright install chromium`).

## 2. Start a project folder from a style

Pick a style from the [gallery](../README.md#the-styles) and copy its folder:

```bash
cp -r styles/paper-cut projects/my-song
cp ~/Music/my-song.mp3 projects/my-song/song.mp3
```

Audio files are git-ignored, so your song stays out of the repository.

In `projects/my-song/index.html`, change the lyrics script from the demo's
```html
<script src="../../examples/poem/lyrics_data.js"></script>
```
to your own
```html
<script src="lyrics_data.js"></script>
```
(Relative paths from `projects/my-song/` resolve just as they did from `styles/<style>/`, so anything else the
page loads from the repo keeps working.)

## 3. Time the lyrics

Write the lyric sheet (`projects/my-song/lyrics.txt`, one sung line per line, `#section` markers), then run the
pipeline in [timing.md](timing.md). It ends with `projects/my-song/lyrics_data.js`.

## 4. Look at it

```bash
python tools/serve.py
```

Open `http://localhost:8000/projects/my-song/index.html`. The demo's scenes now play under your lyrics for as long as
the demo lasts. That's the moment to decide the plan: which scene goes where, which line lands on which image.

## 5. Replace the demo's scenes with yours

Every style's README has a "Make your own video in this style" section that says which files are the demo (its
scenes, sets, shots or timeline) and which are the engine. Keep the engine; rewrite the demo files. Work a section
at a time:

```bash
python tools/still.py projects/my-song/index.html 30:60:2 --sheet   # stills every 2 s across 0:30-1:00
```

Look at every still on the sheet. Check the console output printed at the end.

## 6. Render

```bash
python tools/render_mp4.py projects/my-song/index.html --start 30 --end 60 --fast   # a quick 720p preview
python tools/render_mp4.py projects/my-song/index.html --out "renders/My Song.mp4"  # the final, 1080p + 720p
```

To fix one stretch later without re-rendering everything, see
[rendering.md](rendering.md#fixing-one-stretch).



===== 完整公共规范：docs/engine-patterns.md =====

# How the engines are built

The eighteen engines in [styles/](../styles) share no code at run time: each folder is self-contained, written for one
song in one medium (a few began as copies of another's files, such as the 3D pipeline or the ray-marched figure). But they
share a shape, and knowing it makes any of them easy to read and a new one quicker to write. This page is that
shape, plus the browser gotchas that cost the most time.

## Simulate the process, not the look

Each engine models how its medium is physically made, and the imperfections come out right on their own:

| medium | what the code does |
| --- | --- |
| screenprint | each ink is a stencil mask plus a halftone; inks are pulled one at a time and multiplied onto paper, each a little out of register, with squeegee streaks and pinholes |
| linocut | a block is a list of gouge cuts and inked areas; the key block prints black over watercolour washes |
| wool embroidery | wool is laid and couched from tiles, outlines are stem-stitched, light is couched gold thread |
| marbled paper | paint floats as closed outlines on a bath; drops, combs and swirls are exact maps applied to every point |
| magic lantern | slides are baked as tinted glass; a frame stacks glass by multiplying and throws it through a lens |
| painted enamel | two-colour bristle strokes with a highlight flick toward the light, then gold leaf |
| paper cut | cut shapes with a lit rim and a soft shadow, layered in depth and lit from behind |
| mosaic | tesserae are laid in rows along the outlines, then grouted |
| sand on a lightbox | sand thickness is a density field; the lamp shows through as `exp(-k * thickness)`; fingers clear lines |
| carved diorama | each piece is a signed-distance sculpture meshed in the browser; tool marks are a bump in the piece's own space |
| photomontage | photographs are painted in greys, then given a print's grain, halation and tone curve, and cut out with drifting scissors |
| pinscreen | a field of pins at different heights, lit from a low angle, each pin's shadow falling on the next |
| archive desk | every paper is pre-rendered with its shadow, grain, foxing and torn fibres; stamps are inked, then eroded |
| night poster | a shape's shadow is the band a shifted copy of it fails to cover; night mixes colours toward navy while lamps keep their brightness |
| batik | a real 3D set lit by two coloured lamps is rendered into buffers; wax resists where both lamps reach, each dye takes where only one does, and the wax cracks |
| long-exposure glass plate | each frame integrates many light drawings over the exposure, so whatever moved is a smear and whatever stood still is sharp; then halation, dust and the emulsion's edge |
| silverpoint | even hatching whose weight follows the tone; lines can't be erased, and tarnish from grey to brown with age |
| carved relief | the scene becomes a height field, shaded by a raking light with its own cast shadows |
| liquid light show | oil, water and dye in a dish on a projector: warped-noise dye bands, metaball oil drops with a meniscus, and drawn transparencies whose black ink really blocks the lamp |
| thermal camera | a scene rendered as temperatures and mapped through a camera palette, with a thin visible-light edge overlay, warm breath and fading heat prints |
| showboat stage | painted flats given brushwork by a sampled-stroke pass, lit by a light map in which the actors are lit through their own silhouettes |

A filter that makes a clean digital picture look like linocut never convinces for long. A few rules about how the
real thing is made go much further.

## One frame

Almost every engine's frame function looks like this:

```
renderFrame(t):
  shot = the shot covering t
  set  = shot.set, baked on first use           (the still layers: land, buildings, background)
  cam  = shot.cam(t)                            (keyframed, eased)
  draw the set's layers through the camera       (parallax: nearer layers move more)
  draw what moves at t                           (figures, props, light, weather)
  post: light (a multiplied lamp or light map), grain, vignette, the medium's texture
  if t is inside a transition: draw the next shot too and mix (dissolve, wipe, push)
  the lyric band / margin / caption for t
  fade in and out at the ends
```

The canvas is 1920x1080. Several styles keep the picture above a band for the lyrics (e.g. 1920x960 + 120).

## Sets, shots, cameras

- **Sets** (or scenes, worlds, plates) are places. Their still parts are drawn once into offscreen canvases the first
  time they're needed ("baked"), then only composited. Keep a memory budget: the whole song's sets rarely fit at
  once, so drop the least recently used. Bake at load what the first seconds need, so playback doesn't hitch.
- **Shots** are stretches of song time: `{t0, t1, set, cam, ...}` plus a function that poses what moves.
- **Camera keys** are `[time, x, y, zoom, ...]` with easing between them. Two useful rules:
  - push in with **lens zoom**, not by travelling into the layers: depth travel blows the nearest layer up (snow
    becomes moons);
  - **never let the camera see past the edge** of what's drawn. Check the frame corners on every new camera.
- **Transitions:** dissolves, drop wipes (a new picture spreading inside a drop), push and pull (from a room to the
  picture on its screen), panels (pull back to a page of panels, push into another), re-laying one medium as another
  past a moving line.

## Time: on twos, and in step with the song

- Hand-made animation moves **on twos**: pose changes at 12 fps inside 24 fps video. Several engines step motion at
  12 fps (`tm12 = Math.floor(t * 12) / 12`) while the camera moves at the full 24, which keeps the hand-made feel
  without a juddering camera. Texture "boil" (grain, ink noise) often changes at 8 fps.
- **Ease into fast moves**, or drive them with real time: a move that starts at full speed jumps at 12 fps.
- **Hits on beats, changes on lines.** `SONG.beat(n)` and each line's `t0` and word times are the anchors. A word
  lighting in the lyric band typically fades up over `[t - 0.04, t + 0.16]`.
- **Keep something moving.** A hold longer than a beat or two reads as the player freezing. A slow drift, a breathing
  light or drifting smoke keeps a still picture alive.

## Determinism and frame-to-frame state

- All randomness comes from seeded generators (`mulberry32(seed)`) and noise keyed to the frame number. Never call
  `Math.random()` while drawing a frame. The same `t` must give the same picture, or an MP4 won't match what you
  checked.
- Some styles **carry state from frame to frame**: frost that grows, ghosting of the previous frame, a charcoal
  drawing that's erased and redrawn, marbled paint whose outlines remember every comb. Those must be stepped in
  order. `renderAt(t)` then means "rebuild the state from the start of this scene up to t", and each engine's README
  says how it does that.
- When a view steps backwards in time (a camera effect that holds frames, a scrub), keep what's already baked rather
  than rebuilding it from scratch each step, or rendering crawls.

## Figures

- **Whole figures**, posed. Every engine has a rig: jointed silhouettes, contour-drawn people, ray-marched signed
  distance bodies, carved 3D pieces. Most use **two-bone IK** for arms (and often legs), so a hand can be put exactly
  on a rope, a cup or another hand. Each rig spells it its own way: `reachArm()` in paper cut, an arm given as
  `{t: [x, y]}` in embroidery or `{at: [x, y]}` in painted enamel; the style READMEs show how.
- Build **every figure of a kind from one model**, so its anatomy is the same in every shot; vary only pose,
  clothing and age.
- Things that make figures read wrong, all hit at least once: round heads read as teddy bears (give them a muzzle
  or a jaw); coats that hang along the body turn a crouching figure into a plank (hang them toward world-down);
  digitigrade legs with a long stride look like sitting on a stool; two figures leaving the same way merge into one
  blob; close-up arm silhouettes read as clubs or poles.

## Light

- A **lamp** is a radial gradient drawn with `multiply` (or a light map multiplied onto the whole picture). Its
  warmth and brightness carry most of a scene's mood.
- **Self-lit things** (flames, lit windows, glowing marks) go in their own layer drawn after the light map, plus a
  glow. A reflective shape in front should erase the self-lit layer behind it.
- On pale paper, `screen` adds almost nothing; `soft-light` plus a weaker `screen` shows coloured light.
- Glass only darkens: a moving piece has to pass over light glass, or it vanishes.

## Text in the picture

- Load fonts before drawing and wait for them (`document.fonts.load(...)` for each face and script you use), or text
  falls back to a default font. `document.fonts.load` resolves even when the font never arrived, so check the
  result (or `document.fonts.check(...)`) before building. Put `<meta charset="utf-8">` at the top of the page for
  any non-ASCII text.
- **Start building only when every script has loaded** (`DOMContentLoaded`, or put the start call at the end of the
  last script). A build started from a font promise plus a short timer can win the race against later scripts when
  the fonts come from cache, and the page fails to build only sometimes.
- Keep the lyrics readable: if the camera zooms, keep the text out of the zoom (a band or margin drawn in screen
  space).

## Browser gotchas that cost hours

- **One bad gradient value kills the frame.** `addColorStop` with a NaN or an out-of-range offset throws, and nothing
  after it draws. Check the console after every change.
- **`destination-out` uses the current fill's alpha.** A fill left translucent from the last wash only half-erases.
  Set `fillStyle = '#000'` before erasing.
- **`[hidden]` loses to `display: grid`.** Add `.gate[hidden] { display: none }` for overlay elements.
- **Globals collide.** Plain scripts share one global scope; a helper named like an existing function (`hand`,
  `line`) silently replaces it.
- **Tiling seams:** a texture tiled from a sampled corner shows seams on big pieces; downsample the whole texture.
- **WebGL:** GLSL has reserved words you'd never guess (`patch`); creating a texture while another is bound can
  overwrite a texture unit (create textures on a scratch unit such as TEXTURE15); a three.js `InstancedMesh` keeps the
  bounds of its first draw unless `frustumCulled = false`.
- **Headless loads:** wait for the page with `wait_until='commit'` and your own ready flag; a page that builds a lot
  at load can time out waiting for the load event.
- **Grain that changes every frame bloats the MP4.** Change it on twos.

## Starting a new engine

1. Copy the style closest to what you want. Keep its player (`index.html`, the playback and `window.__video` parts
   of its engine) and its lyric code.
2. Write the medium: the few functions that turn a shape into your medium's marks. Test them on stills first, on a
   page that just draws one scene (a lab page).
3. Draw the same key scenes in your medium and in one or two alternatives. Choose.
4. Then sets, shots and the song.



## 原作者媒介陷阱与经验摘录

## Lessons and gotchas

- **Washed out and sepia:** a warm overlay, a heavy amber varnish and a strong craze turned a first painted pass into mud
  tiles. The light map (multiply, then self-lit paint on top), crisp flicks instead of soft bevels, and a fine craze fixed it.
- **Soft highlight bands round every shape read as an airbrushed bevel.** Separate one-stroke flicks set in from the lit
  edge read as paint. Four parallel fold strokes read as claw marks: use one dark stroke with one light flick beside it.
- **Glows wash over whatever is in front of them** until every reflective shape knocks out the self-lit paint and glow
  behind it. A figure walking into a bright doorway looked translucent until drawn as a dark silhouette (`S.backlit`), since
  the light map can't tell which side of a figure faces the light.
- **A hood opening painted flat black reads as a void.** Light the chin and the tip of the nose from the fire.
- **Things at the wrong height read as other things:** a bedroll carried at head height looked like a hat brim.
- **Long ribbons of paper arcing between two figures read as pale tubes across their faces.** Keep small things in hands.
- **A still layer is baked once per set,** so anything that differs between two shots of the same set (who stands where,
  what's lit) must be painted in `dyn`.
- **Lyric timing:** lines stay 0.8 s after they're sung but never leave before their last word has lit, and the next line
  doesn't show across a cut.
- **Smoke drawn as round-capped segments stacks its opacity into a solid tube.** Draw it as a few long strokes at low opacity,
  layered.
- **Trees built from many small clumps looked like stacked cabbages.** A few big scalloped lobes, the back ones darker, read
  as painted trees; poplars as one tall flame with a lighter one inside it.
- **Random light and dark leaf strokes read as camouflage.** Use a light tone and a mid tone.
- **Gold leaf multiplied by a dim light map looks like beige paint.** Give it a small glint (a glow) when it turns to face the
  light, and keep the burnished catch small and yellow rather than white.
- **Three stacked strokes for a cloud read as a flying saucer.** One or two long tapered streaks with a lit underside read
  as cloud.
- **A gust is only visible against calm.** Drop the breeze just before it (a lull), and the travelling band of bent, pale grass
  and bowing trees stands out.
- **A tree rotated about its foot looks like it is falling over.** Bend it in strips along a curve of constant length, so the
  crown dips as it bows.
- **A gesture behind another figure is lost.** When a hand has to meet something (a lamp), make sure nobody stands between it
  and the camera; painting order decides who covers whom.
- **Sky painted per frame lands on the baked buildings.** Clip clouds and stars to the sky.
- **A dark sky with white stars reads as an ordinary night on Earth.** To make a night plainly somewhere else, change
  its lights (motes in the aurora's colours, some strung in short lines, with no cross-shaped glints) or its weather.
- **A plain dark storm is just a dark sky.** Give it a shape you can read at a glance (a slow spiral with a lit eye,
  lightning crawling along its arms, bolts going up into it rather than down) and put the flashes in the light map, so
  the land under it flickers with them. A darkness that is weather rather than night reads best on its way out: a storm
  going off over the edge of the sky, its trailing edge lit by the light coming back.
- **Rain obeys the ground it falls on.** Near land turned on its side, rain that still falls straight down reads as a
  mistake; bend it toward that land's own ground, more the closer it gets.
- **Build what the first frame needs at load.** A tree sprite first needed mid-shot stalls that frame, and a sprite requested
  with different options than it was made with comes back as the cached one: give each sprite one function that makes it.
- **A fade from pure black gives a blank first frame.** Start from a dim picture instead.
- **The camera can't leave the set.** A zoomed camera centred near an edge is pushed back inward, so frame with stills.
- **Check the console.** One bad value in a canvas gradient kills the whole frame; the still tool prints errors.
- **The browser caches scripts.** Serve with `tools/serve.py`, which doesn't, or an edit can keep running its old version.


