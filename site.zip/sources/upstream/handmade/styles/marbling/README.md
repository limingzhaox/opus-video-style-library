# Marbled paper

Paint floated on a bath of thickened water, moved with drops, a stylus, combs and a stir, the way a marbler works
before laying the paper down. Nothing here is a filter over a picture. Each colour is a closed outline of floating
paint, and every move (a drop landing, a comb pulled through, a swirl) is an exact mathematical map applied to every
point of every outline, so edges stay crisp at any zoom and paint never overlaps or leaves a gap. Newer paint always
sits where older paint was pushed away from, so drawing the outlines oldest-first shows every colour where it really
is. On top of that come what makes it look like paint rather than vector art: pigment grains that ride along with
their colour, a soft darker band and a fine dark vein where two colours meet, marbled insides (stone, woodgrain,
combed cloth) for objects, and a faint size texture, sheen and vignette over the whole tray. Almost every move can
run backwards exactly, so a picture can be combed apart and then rewound to almost where it was.

![A gust as a comb through the tray: feathered sky, bowing trees, a hat blowing away](img/hero.jpg)

This family has one look, so there's no style lab.

| | | |
| --- | --- | --- |
| ![Drops filling the tray under the title card](img/drops.jpg) | ![Leaves made of drops pulled with a stylus](img/leaves.jpg) | ![The wind as a comb passing through the leaves](img/comb.jpg) |
| drops fill the tray (0:02) | leaves: a drop, a drop inside it, a stylus pull (0:13) | the wind is a comb passing across the tray (0:16) |

![The drop wipe: the hill opening inside a drop that pushes the branch picture outward](img/wipe.jpg)

## Run the demo

```bash
python tools/serve.py        # then open http://localhost:8000/styles/marbling/index.html
```

`index.html#t12.5` shows the still at 12.5 s with the page furniture hidden. Space plays and pauses; the bar scrubs.

The page does play live, with the song, but it works every frame out as it goes (moves the paint, then draws it), and
a frame costs 20-150 ms here, so in a browser it runs slowly and stutters, and scrubbing backwards has to replay the
scene from its start. The MP4 is the way to watch it:

```bash
python tools/still.py styles/marbling/index.html 2.4 13 16.4 28.9            # stills into renders/stills/
python tools/still.py styles/marbling/index.html 0:37.5:2.5 --sheet --step  # a contact sheet of the whole demo
python tools/render_mp4.py styles/marbling/index.html --fast                # renders/marbling-720p.mp4
python tools/render_mp4.py styles/marbling/index.html                       # 1080p and 720p, slow encoder
```

The whole 37.5 s demo renders to 720p (`--fast`) in about a minute on an otherwise idle Apple M4 laptop (~70 ms a
frame including reading the canvas back and encoding); with other heavy work running it took four. Each still replays its scene from the scene's start, so a long list of stills
is faster with `--step`, which carries the paint on from one still to the next (the times must be in order).

## How it works

Plain canvas 2D, no libraries; fonts from Google Fonts (IM Fell English for the lyric band). The files load as plain
scripts sharing one global scope, in this order:

| file | job |
| --- | --- |
| `../../examples/poem/lyrics_data.js` | `window.SONG`: title, credit, audio, duration, beats, and every line's word times |
| `core.js` | frame size (`W,H` 1920x1080, picture `PW,PH` 1920x960 above a 120 px lyric band), math, seeded random (`mulberry32`), value noise (`fbm2`), colour helpers, outline helpers (`spline`, `resample`, `rect`, `ell`, `blob`), fonts |
| `marble.js` | the engine: `Bath`, `Film`, the marbling maps, timed moves, `Script`, rewinds, marbled insides, the sway, and all the drawing |
| `figures.js` | figures: traced from simple parts (`maskOutline`), or smooth tapered strokes along a spine (`strokeOutline`): `coatFigure`, `swimmer`, `swimmerTop`, `elder`, `walker` |
| `props.js` | builders shared by scenes: `sprinkle`, `Float`, `Breathe`, landscape pieces (`crownTree`, `treeOutline`, `spruce`, `islandPts`, `fishPts`), `houseFront`, moving figures (`walkerMoves`, `figureMoves`, `swimMoves`, `elderMoves`), running water (`flowRibbon`, `channelField`), `carried` |
| `scene_branch.js`, `scene_hill.js` | the demo's two scenes (replace these) |
| `timeline.js` | `SCENES` and `SEGS`: which scene plays when, and how each takes over from the last (replace this) |
| `video.js` | steps scenes frame by frame, draws drop wipes, fades and the lyric band, keeps cards, sets `window.__video`, runs the player |

### The paint

```js
new Bath(name, {bounds, dens, maxLen, minLen})   // one tray: films oldest first, plus pigment grains
new Film(points, colour, {tag, vein, va, vw, grain, alpha, glow, gold, lite, keep})   // one closed outline of paint
bath.add(film, rnd)       // float it (and sprinkle grains in it with the seeded generator rnd)
bath.map(fn, sel)         // apply a point map to every film passing sel (and their grains)
bath.tidy()               // resample outlines: split edges longer than maxLen, merge points closer than minLen
```

A film's options: `vein` is the edge colour (`null` for none; default a darker shade of the fill), `va`/`vw` its
alpha and width, `grain` how many pigment specks (0 for none; the bath's `dens` sets specks per pixel), `glow` a
soft light around it, `gold` a moving bronze-powder fill, `lite` a lift toward cream, `alpha`, `hidden`, and `keep`
(never resampled; for outlines you rebuild yourself every frame). Films can also be: frozen (`bath.freeze(f)`: no move
touches it again) and frosted (`f.ice` 0..1); a window onto another bath (`f.window = otherBath`: that bath's paint
shows inside this outline); left out of sways and pushes (`f.nosway`). `f.kids` is a film's marbled inside, made by
`marbleInside(film, kind, palette, seed, o)` with kind `'drops'` (stone), `'cloth'` (drops then a fine comb),
`'grain'` (wood: strips waved along `o.dir`, with knots) or `'bands'` (strips combed with alternating teeth).

### The moves

Each move is a closed-form map of the plane (after Jaffer and Lu's mathematical marbling) applied in small steps, so
it can be watched. Every one takes a song time `t0` and a duration, plus `{sel, ease}`: `sel(film)` limits it to some
films (the demo's `nb=f=>f.tag!=='base'` keeps the tray's ground out of pushes), `ease` is one of `E.lin`, `E.out`,
`E.io`, `E.sine`, `E.drop`.

```js
Drop(bath, cx, cy, r, colour, t0, dur, o)        // paint lands and spreads; everything moves outward
ShapeDrop(bath, pts, colour, t0, dur, o)         // paint spreading into an outline
Float(bath, pts, colour, t0, dur, {from, inside, ring, ringK})   // an object spreading out of its anchor `from`
                                                 //   (inside: a marbleInside spec; ring: baths below that bend round it)
Tine(bath, t0, dur, point, dir, z, lam, {teeth:{sp, alt}, front:[f0, f1, width]})   // a stylus, or a comb of teeth
Swirl(bath, t0, dur, centre, angle, sigma)       // a stylus stirred round
Wave(bath, t0, dur, dir, amp, k, phase)          // a comb wiggled as it is pulled
Bend(bath, t0, dur, root, angle, h, {p})         // a turn about a root, growing with distance: a stalk or tree bowing
Move(bath, t0, dur, (e0, e1) => pointMap)        // any map you write; e0..e1 is the eased progress of this step
Morph(bath, [[finder, fromPts, toPts]], t0, dur) // ease a film between two poses
StretchX / StretchY(bath, sel, anchor, s0, s1, t0, dur)
At(t, fn)                  // once, at t
During(t0, t1, (t, dt) => ...)   // every frame between t0 and t1
Rewind(moves, t0, dur)     // play these moves backwards, last first
TapeRewind(moves, tA, tB, t0, dur)   // over [t0, t0+dur], run the listed moves' clock from tB back to tA
```

`Tine` with `teeth` is a comb; `alt: true` flips every other tooth. With `front`, the comb crosses the tray from `f0`
to `f1` (measured along `dir`): a point moves only while the comb goes by it, so the feathering sweeps across the
picture and stays behind it. That's the wind in the demo. `Drop`, `ShapeDrop`, `Tine`, `Swirl`, `Wave`, `Bend` and
`Move` all run backwards exactly when stepped from a later progress to an earlier one, which is what the rewinds do.
`At` and `During` don't run backwards, which is how a rewind comes back "less something".

`Breathe(baths, amps, t0, t1, seed, period, {view, pauses})` keeps the paint alive: a smooth current that sways back
and forth (it reverses every `period` seconds, so outlines don't grow without limit), one amplitude per bath.

### A scene

A scene is a function that builds its baths and a list of timed moves, and returns:

```js
{name, baths /* bottom to top */, script: new Script(moves), ground /* colour behind all */, cam, segments,
 surface /* 0..1 texture, sheen, vignette */, post(inst), draw(g, t), over(g, t, view, zoom)}   // last three optional
```

`segments` are the stretches of song time the scene is stepped through (it can skip a gap and come back, e.g. for a
reprise). `cam` keys are `[t, cx, cy, zoom]` in the scene's own world coordinates, eased between (a fifth entry
`'lin'` makes a straight move). Here is the gust from `scene_hill.js`, line 7, and its rewind in line 8:

```js
const GT=26.3,GD=2.8,FR=[-400,2400,260];          // the comb crosses from x=-400 to 2400 in 2.8 s
const gust=[Tine(sky,GT,GD,[0,0],[1,0],120,10,{teeth:{sp:40},front:FR,ease:E.io,sel:nb}), /* far hills, land, crowns */];
TR.forEach((T,i)=>gust.push(Bend(trees,frontAt(T.x-160),1.0,[T.x,T.y],.26+.03*i,T.h,{sel:T.sel,p:1.4,ease:E.io})));
mv.push(...gust);
mv.push(TapeRewind(gust,26.2,30.0,30.0,2.5,{ease:E.io}));   // "The wind is passing by": the gust runs backwards
```

and a leaf from `scene_branch.js`, made the way a marbler makes one:

```js
mv.push(Drop(leaves,cx,cy,r,C(c1),t,.3,{tag,sel,vein:shade(C(c1),.5)}));      // a drop of green
mv.push(Drop(leaves,cx,cy,r*.52,C(c2),t+.1,.25,{tag,sel}));                   // a paler drop inside it
mv.push(Tine(leaves,t+.28,.4,[cx,cy],[dx,dy],r*1.25,r*.34,{sel,ease:E.io}));  // a stylus pulled through: a leaf
```

### The timeline

```js
const SCENES={branch:sceneBranch,hill:sceneHill};
const SEGS=[{scene:'branch',s0:0},
  {scene:'hill',s0:18.75,prev:'branch',wipe:{t:18.75,dur:1.8,c:[960,470],R:1250}}];
```

A segment opens with a drop wipe (`wipe`: a drop lands at `c` in the old scene's world and the new picture shows
inside it while it pushes the old paint outward; `push:false` leaves the old picture unpushed), an `unwipe` (the old
picture closes back in round the new one, `rad(t)` giving the circle's radius), or a `fade` of so many seconds.

**Cards** keep a picture for later. Define `const CARD_REQ=[{key, scene, t, reg:[x0,y0,x1,y1]}]` (in `timeline.js`):
when that scene passes `t`, its films and grains near `reg` are copied. Later, `cardBaths(req)` gives you live baths
rebuilt from the copy (or, if the song wasn't played through, runs the scene up to `t` first), to show again and comb
into the next picture. The demo doesn't use them.

### Figures

`walker(x, y, phase, k, o)` is a person side on, in a long coat and a hat, with a cloak streaming from the shoulders:
every part is a tapered stroke, so it's rebuilt every frame without tracing. `walkerMoves(bath, id, pos, t0, t1, o)`
moves one along `pos(t) -> [x, y]` with the stride tied to the distance walked, the coat's cloth carried with the
hips, the cloak's combed stripes laid along the cloak so they ripple with it, and options for the wind (`wind`,
`gustOf(t)`, `leanOf(t)`) and the hat (`hatUntil`). `coatFigure` is a stout figure traced from parts with poses
(`figureMoves` floats it in and eases between poses). `swimmer` is a swimmer side on, `swimmerTop` a swimmer seen from
above, and `elder` an old person resting in the water, easing from holding themselves up to lying back
(`swimMoves`, `elderMoves`). They have an ordinary skin tone by default (`skin`, or `skinPal` / `pal` for your own
colours); swimmers take `hairLen`, and `fins: true` puts swim fins on their feet.

### The lyric band

`video.js` turns `SONG.lines` into lyric groups: a line appears 0.45 s before its first word and leaves 0.45 s before
the next line starts; each word brightens from dim to lit over `[t - 0.04, t + 0.16]` of its sung time; a long line
shrinks to fit. `TITLE` shows `SONG.title` and `SONG.credit` in the band from 0.35 to 3.6 s. `LOOK` holds the band's
colours.

### Determinism and state

The paint's state is the history of every move, so a frame can't be drawn on its own: scenes are stepped forward in
order. Steps always land on the frame times `(k + 0.5) / 24` that the MP4 renderer uses, so `step(t)` (which carries
the live scenes on) and `renderAt(t)` (which rebuilds them and catches up from their start) produce identical
frames, and a slice rendered with `--start` splices into a full render exactly. Every random choice comes from a
seeded `mulberry32`; each drop seeds its own grain generator from its position; the sway is a function of time. A
scene is built the first time it's needed and dropped a second after its last segment. The grain colour table, the
size texture and the frost pattern are built on first use; the lyric band at load.

## Make your own video in this style

1. **Copy the folder and add your song:** `cp -r styles/marbling projects/my-song` and put your mp3 in it as
   `song.mp3` (see [docs/your-own-video.md](../../docs/your-own-video.md)).
2. **Time the lyrics** with the pipeline in [docs/timing.md](../../docs/timing.md), ending with
   `tools/audio/to_js.py`, which writes `projects/my-song/lyrics_data.js`. In `index.html`, change
   `<script src="../../examples/poem/lyrics_data.js">` to `<script src="lyrics_data.js">`. The next line already
   points the audio at `SONG.audio`.
3. **Keep** `core.js`, `marble.js`, `figures.js`, `props.js` and `video.js`. **Replace** `scene_branch.js` and
   `scene_hill.js` with your own scene files (and their `<script>` tags in `index.html`), and rewrite `timeline.js`.
   In `video.js`, `TITLE` (when the title card shows), `POSTER` (the frame the page shows before Play) and `LOOK`
   (the band's colours) are yours to change.
4. **Write a scene.** Start from this and grow it:

   ```js
   function sceneMine(){
     const sky=new Bath('sky',{dens:.0045,maxLen:5,minLen:2}),land=new Bath('land'),mv=[],nb=f=>f.tag!=='base',beat=SONG.beat;
     mv.push(At(0,()=>sky.add(new Film(rect(-300,-300,2520,1560),C('#c3d0d8'),{vein:null,tag:'base'}),mulberry32(3))));   // the tray
     mv.push(...sprinkle(sky,[-80,-80,2000,1040],120,['#b3c6d3','#dce4e4','#9fb7c9','#e9e5d9'],28,72,.1,2.8,11,{sel:nb})); // drops
     mv.push(Tine(sky,2.9,1.0,[0,0],[1,0],58,12,{teeth:{sp:44,alt:true},ease:E.io,sel:nb}));                             // combed
     mv.push(Float(land,myOutline /* your points */,'#8a9a62',beat(8),1.0,{from:[960,1000],ring:[sky],
       inside:{kind:'cloth',pal:['#8a9a62','#97a66c','#7b8b56'],size:28,dir:[1,.1],z:9,sp:20,seed:5}}));                // an object
     mv.push(Breathe([sky],[8],0,20));
     return{name:'mine',baths:[sky,land],script:new Script(mv),ground:'#c3d0d8',cam:[[0,960,480,1]],segments:[[0,20]]};}
   ```

   Add it to `SCENES` and `SEGS` in `timeline.js`. Build the tray's first picture in the scene's first frames, and
   if the scene opens inside a drop wipe, start its segment a little before the wipe (the demo's hill starts at
   18.55 for a wipe at 18.75) and build its world with near-instant moves (durations of .03-.05 s).
5. **Time moves to the song.** `SONG.beat(n)` is beat `n`; `SONG.lines[i].t0` is where line `i` starts;
   `SONG.lines[i].words[j][1]` is when word `j` is sung. Put drops and hits on beats and changes on line starts, e.g.
   `Drop(sky,x,y,120,C('#e9e5d9'),SONG.beat(4),.9,{sel:nb})`. Keep something moving: a hold longer than a beat or two
   reads as the player freezing.
6. **Look at it** with `python tools/still.py projects/my-song/index.html 0:30:1 --sheet --step`, fix, and preview
   slices with `render_mp4.py --start --end --fast`.

**Useful knobs.**

| where | knob | what it does |
| --- | --- | --- |
| `Bath` | `dens` | pigment specks per square pixel (.004-.01 reads as paint; 0 for none) |
| `Bath` | `maxLen`, `minLen` | outline spacing: 3/.8 for close-ups, 5/2 for wide or heavily combed layers (fewer points to draw) |
| `Film` | `vein`, `va`, `vw` | the edge line between colours: `null` for none |
| `Drop` / `sprinkle` | `sel` | what a drop pushes: `nb` to leave the tray's ground alone; a tag test so splashes only push each other |
| `Float` | `from`, `ease`, `ring`, `ringK` | where an object spreads from, how, and how much the paint below bends round it |
| `Float` | `inside.size` | the grain of a marbled inside: one film per drop over the object's bounding box, so bigger is cheaper |
| `Tine` | `z`, `lam`, `teeth.sp`, `alt` | how far paint moves, how fast that falls off, tooth spacing, alternating teeth |
| `Tine` | `front: [f0, f1, w]` | a comb passing across the tray; keep `z` below about two thirds of `w` |
| `Breathe` | amplitudes, `pauses`, `view` | sway per bath; no sway while a stretch will be rewound; sway only near the camera |
| scene | `surface` | 0..1: the size texture, sheen and vignette (lighter scenes look better around .75) |

## Performance

On an Apple M4 laptop, stepping and drawing a frame takes 20-60 ms for most of the demo, 90-150 ms while a drop wipe
draws both scenes, and about 0.6 s for the one frame where the second scene is built. A full `--fast` render of the
37.5 s demo takes about a minute on an idle machine. The page uses about 35 MB of JavaScript heap.

What costs time:

- **Strokes.** Each film is filled once and stroked twice (the soft band and the vein), and the two strokes cost
  several times the fill. The cost climbs steeply as outlines get long and folded, and combs do exactly that: the
  demo's sky draws in 10 ms at rest (54,000 points) and in 90-100 ms once the gust has combed it (130,000-210,000
  points). Coarser spacing on wide or heavily combed layers (`maxLen` 5, `minLen` 2 rather than 3 and .8) keeps the
  count down, and so does combing only the baths that need it.
- **Marbled insides.** An inside is one film per drop over the object's bounding box. A hill 2,400 px wide with
  `size: 30` is 1,500 films, and swaying it moves and resamples all of them every frame. Size insides to what the
  camera sees and use a larger `size` for big areas.
- **Sway on big baths.** Land barely shows a pixel of sway; leave it out and sway the sky, trees and grass.
- **Building a scene** (all its outlines, insides and first drops) happens on the first frame it's needed. Keep the
  first frames' drops few, or spread them over the opening seconds.

To render one stretch, use `render_mp4.py --start S --end E`: the page catches the scene up from its start (a few
seconds at most here) and the frames match the full render exactly, so `tools/splice.py` can drop the slice in.

## Lessons and gotchas

- **Outlines grow without limit under a steady current.** Anything that stirs the paint the same way every frame
  stretches outlines until they hold hundreds of thousands of points. The sway reverses every period instead.
- **Figures traced from overlapping parts look lumpy.** Tapered strokes along a spine (`strokeOutline`) give smooth,
  graceful figures. Seen from above, a swimmer needs its own outline (`swimmerTop`) or it reads as a stick.
- **Objects look pasted on** when they appear as clean geometric blocks. Bow their outlines slightly (`organic`),
  float each part in from its own anchor, let the paint underneath bend round them as they land (`ring`), and let
  everything sway a little.
- **Undoing a push can scar the paint.** While paint is pushed far out, resampling adds points along chords inside
  the opened disc, and when the push is undone they collapse to the centre as a star. Don't push a picture you mean
  to rewind or bring back later: use `wipe: {push: false}`.
- **Rewinds leave chevrons** where the paint also swayed during the comb they undo. Pause the sway (`Breathe`'s
  `pauses`) for any stretch you'll rewind.
- **Rewind only what should come back.** `TapeRewind` takes a list: pass just the comb and the bends, and anything
  else (leaves carried off by a `During`, a hat blown away) stays gone.
- **Concentric drops read as an eye or a target.** Use them only where that's wanted, or pull them into another shape
  straight away (the demo's leaves are concentric drops for a third of a second).
- **Drops push everything in their bath.** A stream of splashes inflates whatever it lands on unless the drops push
  only each other (`sel`) and fade.
- **A window squashed flat and stretched open later magnifies** any sway or push it took while flat, fifty or a
  hundred times. Mark such films `nosway`.
- **A full-frame ground film in a lower bath hides the baths above it** if anything pushes it. Size ground films to
  their region, tag them `'base'` and leave them out of pushes (`nb`).
- **A drop over paint in a lower bath that wasn't pushed** shows that paint through as a flat disc. Put such a drop in
  its own top bath, or push every bath it covers.
- **An object floated in with a slow-starting ease** (`E.io`) starts as a copy about 1% of its size; resampling it at
  that size merged its points, and it grew back as a crude polygon (twigs became thorns, a branch became a wedge).
  `ShapeDrop` now leaves an outline out of resampling while it grows or shrinks.
- **A path offset by more than its curve's radius** folds over itself: a stream whose bend is tighter than its
  half-width makes a cusp in the inner bank.
- **Water that is a round mouth of even width looks like a pipe.** Start a stream as a trickle and widen it as it
  falls.
- **A comb passing across the tray (`front`) folds the paint** if its shift `z` is more than about two thirds of the front's
  width: points outrun the front.
- **A figure rebuilt every frame jitters** if a comb or push passes through its bath: the move's per-frame increment
  shows before the next rebuild. Keep such figures in a bath the combs leave alone (the walker's films are also frozen).
- **Wide worlds are slow** unless the wide layers use coarser outlines, only paint near the camera sways
  (`Breathe`'s `view`), and moving specks are only added where they'll be seen.
- **A scene opening inside a drop wipe must already be built** at the wipe's first frame: start its segment a little
  before, and build its world with near-instant moves.
- **Build scenes before they're needed if playback hitches.** The first frame of a scene pays for building it.
- **One bad value in a canvas gradient blanks the whole frame.** Read the console output after every change.
- **Changing only the `#t` part of the address doesn't reload the page;** after editing code, reload with a new
  query (`index.html?r=2#t30`).
- **`display: grid` beats the `hidden` attribute,** so the play overlay never hid: `.gate[hidden]{display:none}`.

