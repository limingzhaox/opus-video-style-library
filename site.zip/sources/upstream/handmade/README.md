# Opus 5.5 music video art styles

Music videos drawn entirely in code, in hand-made-looking media: backlit paper cut, wool embroidery, marbled paper,
tinted linocut, magic-lantern slides, long-exposure glass plates, batik, screenprint, carved wooden dioramas, a
showboat stage, a liquid light show, a thermal camera, mosaic, sand, painted enamel, photomontage and more. Every
frame is drawn on an HTML canvas (or in WebGL / three.js) from code, with no image assets, timed word by word to a
song, and rendered to MP4 by headless Chrome.

**Made by Claude Opus 5.5.** Nearly everything here (every engine, demo, tool and page of documentation) was written
by Claude Opus 5.5, Anthropic's model, working in Claude Code, directed by Miranda Dixon-Luinenburg. See
[Who made this](#who-made-this).

![Every style, drawing the same poem](gallery/styles.jpg)

Each style is a complete engine with a demo: the same 37.5 seconds, Christina Rossetti's "Who Has Seen the Wind?"
over a small synthesised tune, so you can compare them like with like. The repository also has the tools and the
process for making a video for your own song: measuring the song and timing the lyrics (Whisper, alignment, MIDI
stems), previewing, rendering stills and MP4s, and a written-down way of working that you can hand to Claude Code.

## The styles

Eighteen engines, plus the extra looks their style labs draw. Each links to its folder, whose README explains how
it works and how to use it for your own song. "Plays live" means the demo plays smoothly in the browser; every style
renders to MP4 the same way.

| | |
|---|---|
| <a href="styles/paper-cut"><img src="styles/paper-cut/img/hero.jpg" width="400" alt="Backlit paper cut"></a> | **[Backlit paper cut](styles/paper-cut)**<br>Shadow theatre in layers: tinted paper lit from behind, sliding past itself as the camera moves, with lit rims, mist between the layers, an aurora sky (WebGL) and jointed silhouette puppets on IK. The land can float, curl overhead or stand on its edge, and a place can grow era by era, new buildings set down on the beats.<br><br>*Good for:* landscapes, weather and night skies, journeys, places that can't exist.<br>Plays live. |
| <a href="styles/embroidery"><img src="styles/embroidery/img/hero.jpg" width="400" alt="Wool embroidery"></a> | **[Wool embroidery](styles/embroidery)**<br>A long hanging, wool laid and couched on linen, outlined in stem stitch, with French-knot leaves, couched gold thread for light and wind, and stitched skies and hanging land. Pieces are sewn in on screen, and the camera travels along the cloth. Its lab adds: paper theatre, fresco.<br><br>*Good for:* folk tales, households and seasons, anything that reads like a tapestry.<br>Plays live. |
| <a href="styles/marbling"><img src="styles/marbling/img/hero.jpg" width="400" alt="Marbled paper"></a> | **[Marbled paper](styles/marbling)**<br>Paint floating on a bath and moved with drops, combs and swirls, each an exact map that also runs backwards, so a picture can be combed away and rewound. Crisp edges at any zoom, pigment grains, veins where colours meet.<br><br>*Good for:* water, wind and flow; memory; things that won't stay put.<br>Plays live but stutters: render it for a smooth copy. |
| <a href="styles/linocut"><img src="styles/linocut/img/hero.jpg" width="400" alt="Tinted linocut"></a> | **[Tinted linocut](styles/linocut)**<br>A black key block of gouge cuts printed over watercolour washes, moving on twos, with carved beams of light, haloed silhouettes, flash-backs to earlier prints, and the lyrics pencilled into the margin. Its lab adds: pen and wash, charcoal.<br><br>*Good for:* solemn songs, journeys, landscapes with moving light.<br>Plays live. |
| <a href="styles/screenprint"><img src="styles/screenprint/img/hero.jpg" width="400" alt="Screenprint"></a> | **[Screenprint](styles/screenprint)**<br>Posters pulled one ink at a time: halftone dots at each screen's angle, ragged stencils, squeegee streaks and screens slipping out of register, with something printing in on nearly every beat. Ray-marched figures with posed hands; the lyrics on a purple ditto songsheet. Its lab adds: slab glass, pressed flowers.<br><br>*Good for:* bold, fast songs with poster energy.<br>Plays live once its scenes are printed. |
| <a href="styles/magic-lantern"><img src="styles/magic-lantern/img/hero.jpg" width="400" alt="Magic lantern"></a> | **[Magic lantern](styles/magic-lantern)**<br>Hand-tinted engraved glass slides thrown by a flickering oil lantern: slipping slides, a spinning chromatrope, dissolves, pull-backs to the lecture room and its audience, pictures thrown on fog, and the lyrics as a printed Reading. Its lab adds: wood engraving, crayon lithograph.<br><br>*Good for:* narrated songs, history, travelogues, a singer showing you pictures.<br>Plays live. |
| <a href="styles/glass-plate"><img src="styles/glass-plate/img/hero.jpg" width="400" alt="Long-exposure glass plate"></a> | **[Long-exposure glass plate](styles/glass-plate)**<br>Dry glass plates exposed for minutes to a year: whatever moved is a blur and whatever stood still is sharp, passers-by leave ghost trails, the sun draws its arcs, with halation, dust, scratches and a sleeve that counts the exposure. Its lab adds: silverpoint, carved frieze.<br><br>*Good for:* stillness against movement, time passing, weather, memory.<br>Slow to draw: render it to watch (about 2 minutes). |
| <a href="styles/batik"><img src="styles/batik/img/hero.jpg" width="400" alt="Batik"></a> | **[Batik](styles/batik)**<br>A waxed and dyed cloth worked out from a real 3D set lit by a gold lamp and a blue lamp: one dye where only the gold reaches, another where only the blue does, cream wax where both do; crackle, batik patterns, colourways swept in by a dye front, two dyes for the high points, a caption band. Its lab adds: two-lamp model box, gold line on indigo, shop-window glass.<br><br>*Good for:* warm, textile-rich songs; two voices or two sides; journeys through open country.<br>Plays live at 9-16 fps. |
| <a href="styles/diorama"><img src="styles/diorama/img/hero.jpg" width="400" alt="Carved diorama"></a> | **[Carved diorama](styles/diorama)**<br>Real 3D (three.js): carved and painted wooden pieces, meshed in the browser from signed-distance models, on a relief-map table under one lamp, with tool marks, a miniature depth of field and pieces that move on twos.<br><br>*Good for:* a whole world seen from above, small figures, a camera that flies.<br>Plays live at 13-20 fps; builds in 15-50 s. |
| <a href="styles/night-poster"><img src="styles/night-poster/img/hero.jpg" width="400" alt="Night poster"></a> | **[Night poster](styles/night-poster)**<br>Flat-colour poster illustration by night and by day: hard-edged shadow shapes, indigo nights with amber lamplight, contour-drawn people, pages of curved-seam panels showing one moment at different times, and a finale where the panels become a house's lit windows. Its lab adds: soft shapes, ink line.<br><br>*Good for:* everyday life, towns and streets, many moments in one frame.<br>Plays live. |
| <a href="styles/painted-enamel"><img src="styles/painted-enamel/img/hero.jpg" width="400" alt="Painted enamel"></a> | **[Painted enamel](styles/painted-enamel)**<br>A picture painted in glossy enamel on a wagon's side panel: two-colour bristle strokes, highlight flicks, gold leaf, varnish craze; night as a light map with lamps that light on the beats; ribbons along the frame that knot and plait. Its lab adds: chalkboard.<br><br>*Good for:* road songs, travellers, villages and fairs at night.<br>Plays live. |
| <a href="styles/showboat"><img src="styles/showboat/img/hero.jpg" width="400" alt="Showboat stage"></a> | **[Showboat stage](styles/showboat)**<br>A painted theatre seen from the stalls: flats and cloths given brushwork, hinged trees and leaves on wires worked by stagehands and a wind machine, actors lit through their own silhouettes, footlights and house lights, a lyric card on an easel, and zooms from the back row to the stage.<br><br>*Good for:* songs that are a performance: comic, theatrical, sung to an audience.<br>Plays live. |
| <a href="styles/liquid-light"><img src="styles/liquid-light/img/hero.jpg" width="400" alt="Liquid light show"></a> | **[Liquid light show](styles/liquid-light)**<br>A 1960s overhead-projector light show: oil, water and dye swirling in a dish (WebGL), with drawn transparencies laid on top whose black ink really blocks the lamp; bubbles, a ring on every hit, and a lamp that can fail and come back.<br><br>*Good for:* psychedelic, dreamy or fluid songs; interludes; music with a strong pulse.<br>Plays live. |
| <a href="styles/thermal"><img src="styles/thermal/img/hero.jpg" width="400" alt="Thermal camera"></a> | **[Thermal camera](styles/thermal)**<br>What a heat camera sees on a windy night: bodies, breath, paw and boot prints and handprints glowing and fading, chimney smoke laid flat, false-colour palettes that sweep across with the wind, and a thin white outline laid over the heat (three.js, figures meshed from signed distances). Its lab adds: eight more palettes and edge treatments.<br><br>*Good for:* night and cold, bodies and touch, watching from a distance.<br>Plays live at about 10 fps with people on screen; render it for a smooth copy. |
| <a href="styles/mosaic-and-sand"><img src="styles/mosaic-and-sand/img/hero.jpg" width="400" alt="Stone mosaic and sand"></a> | **[Stone mosaic and sand](styles/mosaic-and-sand)**<br>Tesserae laid along every outline in a mortar bed that can glow, laid in on the beats; sand on lit glass, pushed, cleared and blown by the wind; and any picture, still or moving, re-laid as mosaic behind a moving line.<br><br>*Good for:* monumental and fleeting things, a change of medium mid-song.<br>Mosaic plays live; sand at 4-10 fps. |
| <a href="styles/photomontage"><img src="styles/photomontage/img/hero.jpg" width="400" alt="Photomontage"></a> | **[Photomontage](styles/photomontage)**<br>A constructivist paste-up board: photographs made in code (every face different), cut or torn, landing on the words beside black and red planes, bold type, maps and pen drawings, with a WebGL pinscreen for remembered places. Its lab adds: pinscreen, drafting sheet, drawing.<br><br>*Good for:* argument and research, crowds, maps and evidence.<br>Plays live; the pinscreen at about 16 fps. |
| <a href="styles/archive-desk"><img src="styles/archive-desk/img/hero.jpg" width="400" alt="Archive desk"></a> | **[Archive desk](styles/archive-desk)**<br>A desk under one lamp, from above: papers on keyframed tracks, rubber stamps landing on words, a typed transcript, photographs, newsprint and pencil drawings made in code, frost, smoke, and a decay system of VHS tearing and a surveillance camera.<br><br>*Good for:* records and testimony, memory, a story told in documents, decay.<br>Plays live. |
| <a href="styles/flat-poster"><img src="styles/flat-poster/img/hero.jpg" width="400" alt="Flat vector poster"></a> | **[Flat vector poster](styles/flat-poster)**<br>Bright flat line art with pastel fills: the simplest engine here, and a lesson in what makes a look cute (flat candy fills, round figures, even light, bobbing walks).<br><br>*Good for:* light-hearted songs, or as a starting point.<br>Plays live. |

## Quick start

You need Python 3.9 or newer and Google Chrome.

```bash
git clone https://github.com/cyborggirl963/opus-5.5-music-video-art-styles.git && cd opus-5.5-music-video-art-styles
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

python tools/serve.py                                  # then open a demo from the list it prints
python tools/still.py styles/paper-cut/index.html 12   # a still frame, into renders/stills/
python tools/render_mp4.py styles/paper-cut/index.html # the demo as renders/paper-cut.mp4 (+ a 720p copy)
```

In the browser, `#t12.5` at the end of a demo's URL shows the frame at 12.5 s; Space plays and pauses.

## Make a video for your own song

**With Claude Code:** open this folder in Claude Code and tell it about your song, for example "I'd like a music
video for `~/Music/my-song.mp3`; here are the lyrics". [CLAUDE.md](CLAUDE.md) walks it through the process that made
these styles: it asks what the song is about before drawing anything, measures the song, pitches three looks, shows
you a style lab of the same scenes in each, builds one section for your notes, then the rest, and hands you an MP4.

**By hand:** [docs/your-own-video.md](docs/your-own-video.md) has the steps: copy a style folder into `projects/`,
time your lyrics, replace the demo's scenes, render.

## Documentation

- [docs/workflow.md](docs/workflow.md): how a video gets made, from the questions to ask about a song to the final
  MP4, and what the rounds of notes taught (true for every style).
- [docs/timing.md](docs/timing.md): measuring a song and timing every word (Whisper, alignment, Suno stems and
  MIDI, snapping, beats).
- [docs/rendering.md](docs/rendering.md): the page contract the tools rely on, previewing, stills, contact sheets,
  MP4s, and re-rendering one stretch.
- [docs/engine-patterns.md](docs/engine-patterns.md): how the engines are built (sets, shots, cameras, motion on
  twos, figures, light, determinism) and the browser gotchas that cost the most time.
- Each style's own README: what it simulates, how its engine works file by file, how to make your own video in it,
  and the problems hit while building it.

## What's where

```
styles/<style>/     an engine, its demo (index.html), its style lab (lab/), its README
tools/              serve, still, render_mp4, render_frames + encode, lab_stills, splice, reel, probe, gallery
tools/audio/        analyze, transcribe, align, snap, midi, onsets, sections, clip, to_js, pulses
tools/maps/         real coastlines (Natural Earth) projected for a map on screen
examples/poem/      the demo song: the poem, its timing, the tune and the script that makes it
projects/           your own videos (audio and renders are git-ignored)
docs/               the documentation above
```

## Who made this

Claude Opus 5.5 (Anthropic's model, working in Claude Code) did most of the work: it wrote every engine, demo, style
lab, tool and page of documentation in this repository, and rendered and checked the frames. The engines were first
built over a few days in September 2026 for a series of music videos for Miranda Dixon-Luinenburg's songs, each one
pitched, tested in a style lab, built a section at a time and revised from notes; Claude then rebuilt them as this
story-free collection, with a new demo for every style.

Miranda Dixon-Luinenburg wrote the songs the engines were made for and directed the videos: chose each look from
the style labs, answered the questions about what each song meant, and gave the rounds of notes that shaped the
engines (many of them became the lessons in [docs/workflow.md](docs/workflow.md)). The way of working in
[CLAUDE.md](CLAUDE.md) is that collaboration, written down so you can have the same one.

## Credits

- The demo poem is Christina Rossetti's "Who Has Seen the Wind?" (1872), in the public domain. The tune is
  synthesised by [examples/poem/make_tune.py](examples/poem/make_tune.py).
- Coastlines are [Natural Earth](https://www.naturalearthdata.com/) data (public domain), via the
  [world-atlas](https://github.com/topojson/world-atlas) package.
- The 3D styles use [three.js](https://threejs.org/) (MIT), loaded from jsDelivr. Fonts come from Google Fonts.

## License

MIT; see [LICENSE](LICENSE).

