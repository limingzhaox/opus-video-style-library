# 76 · 档案桌面 / Archive desk

来源类型：根据作者引擎说明整理的使用模板；并非作者原始创作提示词  
原作者：Miranda Dixon-Luinenburg  
上游原文：https://github.com/cyborggirl963/opus-5.5-music-video-art-styles/tree/main/styles/archive-desk  
固定版本：801b3548c54765ecf932ce8b7f3cf4b29fb7a8bf  
抓取核对日期：2026-11-03  
本库改动：中文任务模板、中文摘要与编排；原文全文保留。

## 使用前先看

- 从干净到受干扰要有明确递进曲线，随机监控叠层不要抢先毁掉开场。
- 微小变化需在画面上可见；纸页移动与逐字歌词共用音频时间轴，别直接沿用示例诗的时长。

- 这是代码渲染工作流；聊天文本本身不会自动产生 MP4，需有可执行的项目环境。
- 先看预览再做长片；不要把示例素材的许可自动套到自己的歌曲、照片、字体和品牌上。
- 下方复制区包含全部风格与公共规范，不要求 AI 另外从本机隐藏路径读取文件。

## 完整复制区

你是一位能写代码、检查画面并渲染成片的动画导演。请用“档案桌面 / Archive desk”制作一个属于我的视频。

【我的需求；把花括号内容换成实际值】
主题与一句话故事：{{填写主题和结尾变化}}
用途与观众：{{例如面向普通观众的科普短片}}
内容依据或已有脚本：{{填写；没有则说明需要你写}}
音频、歌词、图片、数据、品牌素材路径：{{填写；没有写“无”}}
素材使用权限与需显示的署名：{{填写来源与许可；不清楚请列待确认项}}
目标时长：30 秒起步；MV 以实测歌曲时长为准
画幅与清晰度：默认横屏 16:9、1920×1080；帧率按本风格原文与引擎规范，未规定时24fps；竖屏须重新构图，不直接裁横屏
语言：简体中文；配音需求：{{有/无、声线与语速}}
必须出现的内容：{{填写}}
禁止出现的内容：{{填写}}
预算与速度：先做低成本验证，再渲染完整片
个人工程名：my-video（可改为英文短名）
确认方式：先给 3 张由真实渲染代码产出的样帧和 5–10 秒预览；我确认风格后再做完整成片

【本风格的核心实现】
在单盏吊灯下俯看档案桌，纸页按关键帧滑动堆叠，歌词逐字打进陈述页。
特别检查：
- 从干净到受干扰要有明确递进曲线，随机监控叠层不要抢先毁掉开场。
- 微小变化需在画面上可见；纸页移动与逐字歌词共用音频时间轴，别直接沿用示例诗的时长。

【工程与流程】
1. 在工作区单独克隆 https://github.com/cyborggirl963/opus-5.5-music-video-art-styles ，检出 801b3548c54765ecf932ce8b7f3cf4b29fb7a8bf。将 styles/archive-desk/ 复制到 projects/my-video/，保留引擎，按该风格 README 指定的文件替换示例场景。不要直接修改 styles/ 中的母版。
建立 Python 虚拟环境，阅读 requirements.txt 后安装渲染依赖；需分析音频时再安装 requirements-audio.txt。使用 Chrome 或项目支持的 Chromium。使用 python tools/serve.py 提供本地 HTTP，不用 file:// 打开渲染页面。
2. 先检查机器的 Python、Node/浏览器、FFmpeg、字体与 GPU 能力。Lemo 当前要求 FFmpeg 7+；先用 ffmpeg -version 核对。缺少工具或访问权限时明确报告缺什么，不能只描述完成、伪造文件或把截图称为已渲染视频。
3. 把我的需求写成 PLAN.md 或 TREATMENT.md：一句话故事、分镜、逐镜秒数、镜头运动、文字位置、音乐与声音 cue、所需素材、预计成本。涉及事实和数据时写 FACTS.md；没有来源的数字不填。
4. 如果是 MV，先取得音频与实际演唱歌词，测量段落、停顿、节拍与词时间；不得沿用 37.5 秒示例诗的时间轴。未提供音乐时不要假装已经完成歌词对齐，可先制作无歌词短预览。
5. 先完成 3 张代表开头、关键变化、结尾的样帧，逐张检查；再渲染 5–10 秒低清短段，检查字幕、运动、音画同步与控制台。复杂慢风格先计时，再估算整片。
6. 随机效果固定种子；有历史累积的媒介按顺序渲染。并行前先比较随机抽帧与连续渲染是否一致。
7. 正式导出使用项目文档中的工具与参数，不臆造命令。交付可播放 MP4、720p 预览、源代码、素材清单与许可、字幕（有台词时）、复现说明；保留最终片长、帧率、音频响度与实际渲染耗时。
8. 实际打开并检查成片开头、中间、转场、结尾及全片联系表，确认没有空帧、字体回退、遮挡、裁字、爆音或无意复制的作者片尾签名。交代尚未完成的检查。

下面是完整风格参考与公共制作规范。它们是上游参考资料，不代表我的主题或逐字台词；我的具体需求优先。风格中明确的声音、镜头和媒介限制优先于公共建议，例如无声电影不添加旁白或拟音。遇到 macOS/Linux 示例命令时按当前系统等价转换，不直接在 PowerShell 粘贴 bash 命令。相对资源路径以完整克隆的上游工程为准。


===== 完整风格原文：styles/archive-desk/README.md =====

# Archive desk

A desk under one hanging lamp, seen from straight above. Papers arrive, slide, stack and leave on keyframed tracks,
while the lyrics are typed onto a statement page one word at a time. Everything is drawn with plain 2D canvas: no
libraries and no image files. It looks like real paper and film because each object is pre-rendered with the
things real ones have:
- **Paper:** a baked soft shadow, a grain texture overlaid on the base colour, darkened edges, foxing spots, and
  torn edges with pale fibres.
- **Rubber stamps:** the ink is eroded with noise and has dropouts, and each stamp lands with a small squash.
- **Typewriting:** every letter sits a little off its line, a little rotated and unevenly inked, with a faint
  double strike.
- **Black-and-white photographs:** painted in greys at low resolution, then printed. The print pass adds surface
  mottling, halation, an S-curve with lifted blacks, grain, toning, a vignette, scratches and a white border.
- **Newsprint:** a photograph can be reprinted as newspaper halftone, a staggered grid of ink dots on grey torn
  newsprint under a masthead and a headline, the columns too small to read.
- **Pencil:** strokes take their colour from a noise tile, so they pick up the paper's tooth, and rubbing out
  leaves grey ghosts.

On top of the objects:
- **Light:** the lamp's pool is multiplied over the desk, and a cool window light carries the shadows of a tree
  outside.
- **Frost and smoke:** frost grows in from the frame's edges, and smoke rises from a cigarette in curl-noise strands.
- **Decay:** a system borrowed from worn VHS tape (tearing, colour split, rolling, held frames, static), plus a
  green surveillance-camera overlay.

The demo is a weather office's case file on the wind, over Christina Rossetti's "Who Has Seen the Wind?".
- **What you see:**
  - The title is typed onto the file's label as the lamp flickers on.
  - Photographs show what the wind moves: a weathervane, a field, a harbour, poplars, washing, a kite.
  - Two witnesses are stamped NO WITNESS on "I" and "you".
  - A contact sheet of aspen leaves is circled in china marker while the leaves tremble.
  - An anemometer strip records the song's own gusts.
  - On "passing by", the local paper's report of the gale lands, its photograph of the poplars in halftone.
  - A forecaster's surface chart unfolds and gets its isobars, fronts and wind arrows.
  - A pencil tree is drawn upright, rubbed out on "bow" and drawn again bowing.
- **The ending:** a gust clears the desk and blows the typed words off the page. The smoke settles to rise straight
  up.

![The desk near the end of the demo: the surface chart, a pencil tree bowing, the wind scale, a newspaper clipping of the gale, the anemometer strip stamped PASSED BY, and the typed poem](img/hero.jpg)

| | |
|---|---|
| ![The contact sheet under a working magnifier, the wind scale circled at force 3](img/leaves.jpg) | ![The surveillance camera zoomed in on the chart, with the line as a caption](img/cctv.jpg) |
| ![The surface chart with isobars, fronts and wind arrows, frost starting at the edges](img/chart.jpg) | ![The last gust: papers gone, the typed letters blowing off the page](img/gust.jpg) |

## Run the demo

From the repository root:

```
python tools/serve.py
```

Then open http://localhost:8000/styles/archive-desk/index.html. It plays live in the browser, in step with the
song: a frame takes about 10 ms to draw. Space plays and pauses, and the bar scrubs. If the song can't load, the
video plays on a silent clock.

- **A still:** add `#t12.5` to the address (any time in seconds) for a full-width still of that moment. Changing
  only the `#` part doesn't reload the page; after editing code, reload.
- **Stills to PNG, with a contact sheet:**
  `python tools/still.py styles/archive-desk/index.html 2 6 12.5 0:37.5:2.5 --sheet`
- **MP4:** `python tools/render_mp4.py styles/archive-desk/index.html --fast` writes `renders/archive-desk-720p.mp4`.
  - On an otherwise idle Apple M4, the whole 37.5 s demo (900 frames) took 36 s in `--fast` mode: about 40 ms a
    frame, including reading the canvas back and encoding.
  - With several other renders running it took about 4 minutes.
  - Without `--fast` it writes 1080p and 720p with the slow x264 preset. That is several times slower, because
    busy frames are expensive to encode.

## How it works

### Files and load order

Plain scripts that share global names, loaded in this order by `index.html`:

| File | Job |
|---|---|
| `../../examples/poem/lyrics_data.js` | `window.SONG`: the song's timing (shared by every style) |
| `data.js` | `LINES`, built from `SONG`; `MAPDATA`, the projected coastline for the chart; `mapXY(lon, lat)` |
| `core.js` | Math, seeded random, value noise, fbm and curl noise; fonts; wood, paper, grain and static textures; `makeObj` (paper objects); stamps and seals; `photoTreat`; `makeFace` portraits; `makeGroup` |
| `objects.js` | The timeline: `addObj`, pose tracks (`P`, `K2`, `life`, `sweep`), `stampOn`, song-time helpers (`LT`, `WT`, `BEAT`), and draw-on helpers (`drawOn`, `revealText`, `marker`, `foldView`, `scribble`) |
| `sketch.js` | Pencil: the `Sheet` class (timed strokes, text, dots, erasures), stroke helpers, and the `SK` shape library (tree, spruce, house, figure, grass, gust lines) |
| `photos.js` | `photoPrint` and its painting helpers; the scenes in `PH` (street, shopfront, field, harbour, forest, vane, poplars, washing, kite, leaves); newsprint (`halftone`, `newsClipping`); `portraitPrint`, `contactSheet`, `blowUp` |
| `scene.js` | The demo: every object on the desk, built and timed. Replace this for your video |
| `engine.js` | The draught (wind), the typed transcript, frost, smoke, the lamp and window light, camera, decay and the surveillance camera, playback, and `window.__video`. Each section starts with the demo's keyframe lists |

The page follows the repository's contract: it draws into `<canvas id="film" width="1920" height="1080">` and sets
`window.__video = {ready, duration, step(t), renderAt(t)}` (`error` if the build fails). `#t<seconds>` shows a
still.

### Objects and tracks

Desk coordinates are pixels of a 1920x1080 desk (the camera at scale 1 shows exactly that). An object is a
pre-rendered canvas plus a pose function.

```js
makeObj(w, h, opts, draw)   // -> {c, w, h, pad, S}: a canvas of the object with its soft shadow baked in
```

`draw(g, r)` paints in the object's own coordinates (0..w, 0..h) with a seeded random `r`. Useful `opts`:
- `base`, `texA`, `age`: paper colour, grain strength and edge darkening.
- `grid` and `fox`: squared paper and foxing spots.
- `round` (corner radius) or `path` (any Path2D outline; `tornPoly` gives torn ones).
- `fill(g, path, r)`: paint a non-paper object (ashtray, magnifier) yourself.
- Shadow: `shA`, `shB`, `shX`, `shY`, or `shadow: false`.
- `S`: pixel density.
- `after(g, r)`: draw outside the clip, such as torn-edge fibres.

```js
addObj(id, canvas, z, track, {dyn, draw, loose, flut, jit})
```

- `track` is a list of keys `[t, x, y, degrees, alpha, scale, ease]`. The ease shapes the move into that key.
  Before the first key the object isn't there; after the last it stays put.
- `P(t, [x, y, deg, scale], alpha, ease)` makes one key.
- `K2([t, [x, y, deg, scale], alpha, ease], ...)` makes a track whose moves ease in and out unless you say
  otherwise.
- `dyn(g, t)` draws animated things on top in the object's coordinates: typing, pencil, marker, a chart trace.
- `draw(g, t, o)` replaces the canvas altogether. The folding chart and the magnifier use it.
- `z` is fixed for the whole video.
- `loose` and `flut` say how the draught treats the object (see below).

A real example from the demo: the weathervane photograph arrives as "seen" is sung, and gets shoved aside when
the chart comes in.

```js
ph('VANE', PH.vane(41, 260, 300, {turn: .14}), 260, 300, 41, 20,
   [[WT(0,2)-.55, [650,-260,16]], [WT(0,2), [560,262,-5], 1, easeOut], [18.45, [560,262,-5]], [19.1, [420,150,-12]]]);
```

`ph` is a local shorthand in `scene.js` for `addObj(id, photoObj(canvas, w, h, seed), z, K2(...keys), {loose: 1, flut: .8})`.

### Timing to the song

- `LINES[i] = [section, text, start, end, [word start times]]`, built in `data.js` from `SONG.lines`.
- `LT(i)` is line i's start. `WT(i, j)` is when word j of line i is sung; j = -1 is the last word.
- `BEAT(n)` is beat n (`SONG.beat`).
- Everything in `scene.js` is written against these, so a stamp lands on its word:

```js
stampOn('W1', WT(1,1), 'NO WITNESS', 85, 168, -9, 22, 2, 5.1, VIOLET, .16);  // lands on "I"
stampOn('FOLDER', BEAT(5), {...sealCanvas('WEATHER OFFICE * OBSERVATIONS * ', 'No. 4', VIOLET, 3.3), w: 124, h: 124}, 392, 258, -14, 0, 0, 0, VIOLET, .15);
```

The full signature is `stampOn(id, t, text, x, y, deg, size, borders, seed, color, burst)`:
- `x`, `y` are in the object's coordinates.
- `text` may be a ready canvas `{c, w, h}`, such as a seal.
- `burst` flashes static as the stamp lands.

### How the lyrics are shown

The typed transcript (`engine.js`, "the transcript") is the lyric display:
- Each section of the song gets its own page, headed "RECORD OF STATEMENT".
- The page slides in just before the section's first line and leaves just before the next section's.
- Each word starts typing when it is sung, plus a small lag (`LAG`). Its letters are spread over the time until the
  next word, 22-70 ms apart.
- Long lines wrap. About 16 rows fit on a page at the default `TSIZE` 24 and `TLH` 40.
- `BRACKETS` draws a pencil bracket beside chosen lines.
- `BLOW_T` makes the last page's letters lift off and blow away at the end.
- A finished page is drawn from a cache.

While the surveillance camera is on, the picture is too coarse to read, so the line in `CCTV_CAP` is also
captioned word by word in the camera's font.

Keep the transcript readable: when the camera zooms, keep the page in frame. Zooms up to about 1.06 centred at
x 960 or more do.

### The draught

`WIND(t)` is one curve: 0 is still, .4 a breeze, 1 a gust, 2 a gale. It is `.42 * swell(t) + kf(GUST_K, t)`, all
times `kf(CALM_K, t)`:
- **`swell`** follows the demo tune's own wind noise, which rises and falls every 7.5 s.
- **`GUST_K`** adds gusts on chosen words.
- **`CALM_K`** lets the end go still.

Everything the wind touches reads the same curve:
- **Papers** with `flut` shiver with smooth noise, scaled by the wind.
- **Papers** with `loose` get shoved by each entry in `PUSH` (`[start, seconds, dx, dy, degrees]`), each by a
  slightly different amount. The last entry is the gust that clears the desk.
- **Smoke** is pushed along `WDIR` as it ages.
- **Dust** drifts by the wind summed over time.
- **The hanging lamp** sways.
- **The branches** outside the window bow, more at the tips, plus `BOW_K`.
- **The anemometer strip** in `scene.js` plots it.

### Light

`lightPass` builds a half-size light map, then multiplies it over the desk:
- **The lamp:** a radial gradient whose warmth (`LW_K`), brightness (`LB_K`) and position (`LX_K`, `LY_K`) are
  keyframed. It flickers on at the start and browns out on the last beat (`LAMP_OFF`).
- **The window:** a parallelogram of cool light (`WIN`, `WIN_K`, `WINC`) with the window frame and a swaying tree
  cut out of it. It is drawn in a quarter-size buffer, blurred and added. It is faded near the lamp, where it
  would only burn out pale paper.

The lights are added together before they multiply the desk. That is what lets the window light the desk when the
lamp is off.

### Photographs, portraits, pencil

- **`photoPrint(w, h, seed, paint, opts)`** paints in greys with `gv(v)` through the helpers:
  - `phSky`, `phStreaks` (wind-dragged cloud), `phRidge`, `phForest`, `phConifer`.
  - `phBroadleaf` and `phPoplar`, both with a `bend`.
  - `phGrass`, `phWaves`, `phPerson` (with `lean` and `flap` for wind), `phCar`, `phPole`, `phWire`.

  Then it prints the result. `opts.q` sets how coarse the negative is (5.5 for a blow-up); `contrast`, `grain`,
  `tone`, `border` and `fade` do what they say.
- **`PH.*`** are ready scenes. Each takes `(seed, w, h, opts)`.
- **`makeFace(p)`** builds a parametric portrait:
  - `hair`: short, parted, swept, bald, curly, cap, shaved, long or bun.
  - `beard`: full, moustache or stubble.
  - `glasses`, `clothes`, face shape, lighting side and toning.

  `FACES` has presets. `portraitPrint(p, w, h, seed)` prints one with the same finish as the other photographs.
  `blowUp(p, seed, w, h)` makes a grainy enlargement.
- **`halftone(g, src, x, y, w, h, {cell, ink, paper, gain, lift})`** reprints a photograph (any canvas, such as a
  `PH.*` print made with `border: 0`) as newspaper halftone: one round dot per cell of a staggered grid, its radius
  growing with the square root of the darkness, so a mid-grey keeps its weight.
- **`newsClipping(seed, w, h, {paper, date, head, photo, photoH})`** makes a clipping as a paper object: torn
  newsprint, the masthead and date over a double rule, a headline, the photograph in halftone, a caption and columns
  of body text drawn as grey bars. The demo's:

  ```js
  const news = newsClipping(56, 340, 300, {paper: 'The Coast Weekly', date: 'Saturday', head: 'Gale in the night',
    photo: PH.poplars(57, 320, 170, {bend: .95, border: 0}), photoH: 128});
  addObj('NEWS', news, 53, K2([WT(7,3)-.5, [1500,-300,20]], [WT(7,3)+.05, [1086,592,-5,.82], 1, easeOut]), {loose: 1, flut: .7});
  ```
- **`contactSheet(seed, frame, {cols, rows, fw, fh})`** lays film strips of frames. `frame(k, w, h)` paints frame k,
  and `at(k)` gives a frame's corner, for circling in china marker with `marker`.
- **`new Sheet(w, h)`** is a pencil layer in a paper's coordinates. Add timed operations, call `finish()`, then
  `sheet.draw(g, t)` from the paper's `dyn`:
  - `line(points, t0, t1, {w, a, col, erase, ghost})`; `lines` spreads several strokes over one span.
  - `text`, `dot`, `rubOut`, `smudge`.

  A stroke with `erase: t` is rubbed out to a grey ghost at t. Finished operations are baked into the sheet's own
  canvas, so a sheet costs almost nothing once it's drawn.
- **`SK.tree(x, y, h, bend, seed)`** returns the tree's parts separately (`trunkLow`, `trunkHigh`, `limbs`, `crown`,
  `shade`). The same seed with a different `bend` gives the same tree bowed. That is how the demo rubs out the
  upright crown and redraws it bent.

### Camera, frost, smoke, decay

- **`CAMK`**: `[t, x, y, scale]` keys, eased in and out; `x`, `y` are the desk point at the frame's centre.
  `SHAKE_K` adds noise shake. For a cut, put two keys a hundredth of a second apart (`[224.0, ...], [224.01, ...]`).
- **Frost** grows in from the frame's edges from `F_EDGE.t0`, at `F_EDGE.sp` pixels a second. Each tuft is a short
  stem with 60-degree side needles. It lives in screen space (frost on the glass), is grown incrementally into its
  own canvas, and is drawn as a thin shadow, a blue-grey body and a white core.
- **Smoke:** `makeEmitter({t0, t1, src, dir, spd, n, rate, wind, seed})` makes curl-noise strands simulated at
  120 steps a second. They are drawn in long, low-opacity chunks at quarter, half and full resolution, plus a
  shadow pass cast away from the lamp.
- **Decay:** one curve, `CKF` (0 clean to 1 ruined), drives tearing, rolling, colour split, displaced blocks,
  ghosting, desaturation, scanlines, flicker, held frames and random intrusions. Each effect only starts above its
  own threshold, so a low curve stays clean.
  - `CCTV_WIN` lists surveillance windows and the chance the camera is on in each 5-frame block.
  - `CCTV_ZOOM` zooms that camera onto part of an object. While it is on, the scene runs at 8 frames a second.
  - `STATIC` adds bursts; stamps add their own.
- **Focus pulls and spotlights:** `FOCUS` blurs everything except some objects (the title card uses it), and
  `SPOT` darkens everything except some objects.

### Determinism and caching

- There is no `Math.random()` per frame. Textures and objects come from seeded `mulberry32`, and per-frame
  randomness is `hashi(frame, salt)` with frame = floor(t × 24). A given time always looks the same.
- Everything is built at load in `buildAll()`: textures, every object canvas, page caches, frost needles and the
  window tree. Building on first use caused visible hitches.
- `step(t)` draws the way playback does. It skips a frame already drawn and keeps the deliberate held frames.
- Frost growth, smoke, pencil sheets and ghosting carry state from the frame before, so an MP4 must be rendered
  in order, as `render_mp4.py` does.
- `renderAt(t)` makes a clean still from any state. The frost regrows, the smoke re-simulates the 6 s that are
  visible, and the sheets rebuild.
- Small steps back in time, from the surveillance camera's 8 fps clock, keep what has been built.

## Make your own video in this style

1. **Copy the folder:** `cp -r styles/archive-desk projects/my-song`, and put your mp3 in it as `song.mp3`
   (see [docs/your-own-video.md](../../docs/your-own-video.md)).
2. **Make your song's timing file** with `tools/audio/to_js.py`, which writes a `lyrics_data.js` of the same shape
   ([docs/timing.md](../../docs/timing.md)). Point the first script tag in `index.html` at it:
   `<script src="lyrics_data.js"></script>`. `SONG.audio` must be the song's path relative to `index.html`.
3. **Change the title** and subtitle in `index.html`. The title card types `SONG.title` and `SONG.credit` onto the
   case file's label, so those come from your timing file.
4. **Keep** `core.js`, `objects.js`, `sketch.js`, `photos.js` and most of `engine.js`. Rewrite `scene.js`, and redo
   the keyframe lists at the top of each `engine.js` section:
   - `GUST_K`, `CALM_K`, `PUSH`, `swell`.
   - `BRACKETS`, `BLOW_T`.
   - `F_EDGE`.
   - `CAMK`, `SHAKE_K`.
   - `LW_K`, `LB_K`, `LX_K`, `LY_K`, `LAMP_OFF`.
   - `WIN`, `BOW_K`.
   - `FOCUS`, `SPOT`.
   - `CKF`, `CCTV_WIN`, `CCTV_CAP`, `CCTV_ZOOM`, `STATIC`.

   `swell` follows the demo tune's wind; set it to a constant, or to your song's loudness.
5. **Replace `data.js`'s map** if you want a chart of somewhere else. `MAPDATA` is `{w, h, lon0, lat1, k, c, land}`,
   with land rings as flat `[x, y, ...]` lists in map pixels. The demo's is Natural Earth 1:50m land (public domain,
   from the world-atlas package), clipped to the British Isles, projected with x = (lon - lon0)·k·c and
   y = (lat1 - lat)·k, and simplified. See `tools/maps/` for making one. Remember the simplification gotcha below.
6. **Add an object:** build its canvas with `makeObj` (or `photoObj(PH.field(seed), w, h, seed)`), then `addObj` it
   with a track keyed to your words:

   ```js
   const note = makeObj(300, 200, {seed: 7, base: '#ece6d4'}, (g, r) => typeText(g, 'Filed.', 30, 60, 22, r));
   addObj('NOTE', note, 45, K2([LT(3)-.5, [900,1400,10]], [LT(3), [900,700,-4], 1, easeOut]), {loose: .7, flut: .4});
   stampOn('NOTE', WT(3,-1), 'RECEIVED', 150, 130, -6, 30, 2, 9, RED, .3);
   ```

   - **To have it arrive on a word,** end its arrival key at `WT(i, j)`.
   - **To make it leave,** add `sweep(at, to, t0)` keys or a key with alpha 0.
   - **For pencil,** make a `Sheet`, add strokes timed to words, and draw it from the object's `dyn`.
   - **To land a move on a beat,** use `BEAT(n)`. Change things on line starts (`LT`).
7. **Check stills across the whole song** with `tools/still.py ... 0:<duration>:2 --sheet`. Look at the frame
   edges, the transcript, and every stamp. Then render with `--fast`.

Useful knobs:
- **Typing:** `TSIZE`, `TLH` and `TMAXW` set the type's size, row height and line length.
- **Pages:** `TRP` is where the page lies.
- **Paper:** an object's `flut` and `loose`.
- **Decay:** `CKF`'s height. Stay under about .3 for a clean look, around .5 for visible damage.
- **Frost:** `F_EDGE.sp`.
- **Window:** `WINC` and `WIN_K` for its strength.
- **Photos:** `photoPrint`'s `contrast` and `grain`.

## Performance

Measured in headless Chrome with the GPU on, on an Apple M4 with nothing else running:
- **`step(t)` in order:** 10 ms a frame on average (median 8 ms, 95th percentile 16 ms), so it plays live
  comfortably. With the machine busy with other renders it was about 18 ms.
- **`renderAt(t)`, a cold still:** 70-135 ms, mostly re-simulating six seconds of smoke.
- **Building at load:** about 1.5 s including fonts.
- **Memory:** the JavaScript heap is small (about 11 MB). The canvases are most of it, roughly 150 MB: a dozen
  full-frame and half-size buffers plus every pre-rendered paper.

What makes a frame slow:
- the smoke simulation (strands × points × two curl lookups, 5 steps a frame);
- the surface chart and the anemometer trace, which are redrawn every frame;
- full-frame composites in the decay pass (colour split, ghosting);
- the magnifier, which copies what's under its lens.

To render a slice, pass `--start` and `--end` to `render_mp4.py`.
- **Its first frame rebuilds the state** that carries over: frost grows to that moment, smoke re-simulates the
  visible 6 s, and pencil sheets bake.
- **The slice matches a full render** except for small differences in the smoke. Splice it in with
  `tools/splice.py`.

## Lessons and gotchas

- **A perfectly clean desk looks too tidy.** A decay arc fixes it: clean at the start and increasingly corrupted,
  with static, dropped frames and surveillance overlays flickering in and out. Gate the random intrusions behind a
  threshold on the curve, or they spoil the clean opening.
- **Small changes need to be obvious.** A swap between two similar faces went unnoticed. Make faces clearly
  different people, and move the camera in when a change matters.
- **Smoke looked like a solid white tube.** Overlapping round-capped segments stack their opacity. Draw longer
  chunks at low opacity, in several layers.
- **Frost:** long branching lines look like twigs, and random short needles look like static. Short tufts growing
  inward from the edges look like frost. On pale paper, white needles vanish, so give them a blue-grey body, a
  thin shadow and a white core.
- **Edge effects belong in screen space.** Frost grown in desk coordinates showed as a hard inset rectangle once
  the camera pulled back.
- **Photos:** plain silhouettes read as default avatar icons. A photo reads as a photo once it has shading,
  features, grain and toning. Run portraits through the same print as everything else, or they look pale beside
  the other photos.
- **A single bad value in a canvas gradient** (NaN or Infinity in a colour stop or a radius) kills the whole
  frame. Read the console after every load; the tools print it.
- **Build caches at load, not on first use:** building on first use caused a 120 ms hitch mid-song.
- **Character encoding:** put `<meta charset="utf-8">` first, or text in other scripts comes out garbled.
- **The play overlay never hid:** `display: grid` beat the `hidden` attribute. Add `.gate[hidden]{display:none}`.
- **Serve over HTTP:** some previewers open `file://` pages as static snapshots with no scripts.
- **Stale scripts after an edit:** a plain Python server lets the browser cache them. `tools/serve.py` sends
  no-cache headers.
- **Map outlines:** simplifying a closed outline can collapse it to two points, so split it at the point farthest
  from its start first. Outlines that cross the date line draw lines straight across the map; shift their
  longitudes per outline.
- **Global names collide.** These are plain scripts in one namespace. `core.js` has a global `hand()` for
  handwriting, and a line helper of the same name broke every text on the desk; hence `hl()`.
- **The surveillance camera's clock:** at 8 fps its scene time steps backwards between blocks. Every pencil sheet
  rebuilt itself from scratch on each step, and the render crawled. The same steps back also restarted the smoke
  and regrew all the frost, giving 60 ms spikes. Sheets, frost and smoke now all keep their state through steps
  back of up to 0.3 s.
- **Overlays on paper** (tracing paper, the window light) have to be modest. Tracing paper needs to be milky
  (alpha about .6) with lines darker than the drawing under it. Light added near the lamp burns pale paper out, so
  the window light fades near the lamp.
- **Encoding is the slow part.** Busy frames are hard to encode: with x264's slow preset at two sizes, a test ran
  at about 0.4 s a frame although drawing took 3-10 ms. Use `--fast` for previews.
- **Render in order.** Frost, smoke and ghosting depend on the frame before.
- **Layering:** z is fixed per object. Raising one paper to cover another can put it above something else later,
  so plan z per scene, or raise several together.
- **Holds:** a hold of several seconds reads as the player freezing. Keep holds to a beat or two, and keep
  something drifting: the lamp breathing, dust, smoke, branch shadows.
- **Time to the measured audio,** not to the lyric sheet's labels. Song generators ignore dynamics markings.
  Speech-to-text word times can run early by a second or more, so check them against the vocal before timing
  stamps to words.
- **Cutting a hole** with `destination-out` removes only as much as the fill's alpha. A leftover translucent
  `fillStyle` left the magnifier's lens 88% black.
- **The surveillance camera's zoom reads the clean picture.** It used to crop the frame after the decay pass, so
  whenever that frame was torn or rolled the zoom magnified displaced strips and landed on the wrong part of the
  desk. It now crops the scene before decay (`SCN`) and adds its own degradation after.
- **See-through objects need their own shadow.** `makeObj` bakes a solid shadow under the whole outline, which shows
  through glass or anything translucent. Give such an object `shadow: false` and draw a soft blurred shadow yourself
  at the start of its `fill`.
- **Halftone dots grow with the square root of the darkness**, because a dot's ink is its area; a radius straight
  from the darkness makes the mid-tones too pale. Batch a row of dots into one path: a clipping has thousands.



===== 完整公共规范：CLAUDE.md =====

# Instructions for Claude

This repository makes music videos in code: each style in `styles/` is an engine that draws every frame on an HTML
canvas (or WebGL / three.js) in a hand-made-looking medium, timed to a song, and `tools/` renders them to MP4. Read
`README.md` for the map, then the doc for whatever you're doing.

## When someone wants a video for their song

Follow [docs/workflow.md](docs/workflow.md). It's a conversation, not a build order to rush through:

1. **Get the inputs:** the song (mp3), the lyric sheet as sung, and ask whether they have stems and MIDI (Suno and
   stem splitters provide them) and any reference images.
2. **Ask the concept questions before building anything:** who is singing, who "you" is, whose voice the chorus is,
   what the key images (especially the ending) mean, how much the video may show, what stays out. Don't guess at
   these; an open question is better than a confident wrong answer. If the song belongs to a larger world, read
   whatever they give you about it, and keep a list of every detail the video invents, flagged as unconfirmed.
3. **Measure the song** ([docs/timing.md](docs/timing.md)): tempo, sections, stops and hits, and every word's time.
   Time to the audio, not to the lyric sheet's markings.
4. **Pitch three looks and recommend one:** the medium and why it suits this song, the organizing object, a small
   visual grammar and an arc, a section-by-section plan keyed to timestamps, and the open questions. The styles in
   `styles/` are the starting points (each README says what it's good at); a new medium is fine too
   ([docs/engine-patterns.md](docs/engine-patterns.md)).
5. **Style lab:** the same three or four moments drawn in each candidate look. Show the stills.
6. **Checkpoint:** build one section (20-90 s), render it (`--fast`), send it, get notes.
7. **Build the rest** section by section, then render the final MP4s. The MP4 is what gets shared.

Build a project in `projects/<song-slug>/`, copied from a style folder ([docs/your-own-video.md](docs/your-own-video.md)).
Don't change `styles/` for one person's video. Keep notes in `projects/<song-slug>/PLAN.md` as you go: their answers
and rulings, the measured sections and sync points, the shot list, the invented details, and their feedback on each
round. A later session should be able to pick up from that file alone.

## Working practices

- **Look at what you render.** Make stills and contact sheets (`tools/still.py ... --sheet`) and open the images.
  Check every frame on the sheet: edges, blank frames, the camera inside things, covered text, long freezes.
- **Read the console output** the tools print. A single bad canvas gradient value blanks a frame.
- **Preview slices with `--fast`**; render the full 1080p only at the end. Styles that carry state between frames
  must be rendered in order (the tools do this).
- **Keep it deterministic:** seeded randomness keyed to the frame, never `Math.random()` per frame.
- **Follow the page contract** in [docs/rendering.md](docs/rendering.md) (`window.__video`, `window.SONG`,
  `<canvas id="film">`, `#t<seconds>` stills) so the tools work.
- Apply the lessons in [docs/workflow.md](docs/workflow.md#what-the-notes-taught-true-for-every-style): busy
  enough, no long freezes, obvious changes, varied choruses, whole figures rather than close-up hands.
- The person's audio is git-ignored. If their lyrics or story are private, keep the project out of any public
  remote (add it to `.git/info/exclude`, or keep it outside the repo and pass `--root` to the tools).

## Setup

```bash
python3 -m venv .venv && .venv/bin/pip install -r requirements.txt -r requirements-audio.txt
```

Google Chrome must be installed (or `.venv/bin/python -m playwright install chromium`). To preview in the desktop
app's browser pane, create `.claude/launch.json` running `python3 tools/serve.py 8000` on port 8000 (git-ignored).
Use the server, never `file://`: module pages don't load from files and a plain server caches stale scripts.



===== 完整公共规范：docs/workflow.md =====

# How a video gets made

These videos were made in conversation: a person with a song and a clear sense of what it's about, and Claude
writing and rendering the code. The process below is what worked over a dozen songs. It suits working with Claude
Code (see [CLAUDE.md](../CLAUDE.md), which tells Claude to follow it), and it works just as well by hand.

The short version: **decide what the song is about, measure it, pitch three looks, test the look on a few scenes,
build one section, get notes, then build the rest.** Each step is cheap next to the one after it, so mistakes get
caught while they're still cheap.

## 1. Gather the inputs

- **The song** as an mp3 (or anything ffmpeg reads).
- **The lyric sheet** as plain text, one sung line per line, with `#section` markers (see
  [examples/poem/lyrics.txt](../examples/poem/lyrics.txt)). Write it the way it's sung: if the singer repeats a line
  that isn't on the sheet, add it.
- **Stems, if you have them.** An isolated vocal stem makes transcription far cleaner. Suno exports stems as audio
  and as MIDI per instrument; the MIDI's tempo map gives an exact beat grid, and the vocal MIDI gives note onsets to
  snap words to (see [timing.md](timing.md)).
- **Reference images, if any.** Mood boards and concept art are useful for content (what's in the world, what
  people wear, what the place looks like) even when the style will be different.

## 2. Decide what the song is about

Before any pictures, answer the questions that decide the concept. A video can't be good if these are guesses.

- **Who is singing,** and to whom? Who is "you"? It's often not who it seems, and it can change between verses.
- **Whose voice is the chorus?** The singer's, an imagined audience's, a crowd's, a custom's?
- **What do the key images mean?** Especially the closing one.
- **How much may the video show?** If the song belongs to a larger story, what would be a spoiler?
- **What stays out?** Eras, events, people, kinds of imagery.

If the song is part of a larger world (a novel, a game, a band's mythology), read up on it first, and **keep a list
of every detail the video invents**: a place's layout, what a prop says, who stands where. Show that list to
whoever owns the world, and treat nothing on it as settled until they say so.

## 3. Measure the song

Time the video to what the audio does, not to what the lyric sheet says. (AI song generators in particular ignore
markings like "quiet" or "almost unaccompanied".) With the tools in [timing.md](timing.md):

- tempo, and whether it changes;
- the sections and their loudness: which chorus is the big one, where it drops to almost nothing;
- **the stops and hits.** Musical stops, dropouts and the hit that ends a bridge make the best sync points: the
  place to freeze, cut, switch a light off, or change the whole picture;
- every word's time.

## 4. Pitch three looks

Offer three directions and recommend one. For each:

- **the medium** (paper cut, embroidery, marbled paper...) and why it suits this song. The strongest choices mean
  something: marbled paint for a song about water, where nothing stays put; a lantern lecture for a song sung by
  someone lecturing; a desk of files and stamps for a song about a record that doesn't add up;
- **the organizing object:** the one thing the whole video is, such as a desk under a lamp, a hanging read along
  its length, a printed sheet, a painted wagon's panels, a board of pasted-up photographs;
- **a small visual grammar:** a few rules that give the images meaning (stamps are the audience's verdicts, frost
  is the stillness, the camera's date flickers between years), and an **arc** over the song (clean to decayed,
  night to morning, empty to crowded);
- a **section-by-section plan** keyed to timestamps, giving each section one main image;
- the questions still open.

The [styles/](../styles) folder has eighteen engines to start from, and each one's README says what it's good at.
A new song can also want a new medium: the engines share their patterns ([engine-patterns.md](engine-patterns.md)),
so a new one is less work than it sounds.

## 5. Style lab

Draw the same three or four key moments in each candidate look, side by side, as stills (and a few seconds of motion
if the look depends on how it moves). Comparing like with like makes the choice easy, and it shows the problems
early: people who look like mannequins, faces that look ill, a palette that turns cute. Every family here with more
than one look has a lab page (`styles/<family>/lab/`) built this way.

Expect the first choice to be refined: "this look, but with the other one's colours", or "this, for the scenes in the
other world only". Mixing is fine.

## 6. Checkpoint

Build a real section before the whole song: 20-30 seconds of the section that carries the concept, or the first
90 seconds. Render it as an MP4 and get notes on the look, the pace, the figures, the text. This is where most of
the useful notes arrive, and they're cheap to act on now.

## 7. Build the whole song

Section by section. After each, render stills across it (`tools/still.py ... a:b:2 --sheet`) and look at every one:
frame edges, blank frames, things the camera cuts through, text that's unreadable or covered. Fix, then move on.
When it's all there, render the MP4, then scan it at one frame every two seconds.

## 8. Notes, and fixing a stretch

Notes on a full video are usually local: one stretch feels empty, one chorus repeats the last, a transition jerks.
Re-render only that slice and splice it in ([rendering.md](rendering.md#fixing-one-stretch)).

## 9. Deliver an MP4

Share the MP4, not the web page. A browser player's pause and scrub can feel unreliable, and people give up on it.
`tools/render_mp4.py` writes a 1080p file and a smaller 720p one for sending.

## 10. Revising a finished video

A second or third pass (new conventions, a list of fixes, a stretch that needs more going on) works best as: a short
written plan of every change; then before/after sheets, stills from the old render and the new build at the same song
times side by side; then the full render. The sheets let the notes land on exactly what changed. When picking stills
for review, catch short effects at their peak: a flash or a bolt that lasts half a second is easy to miss.

## What the notes taught (true for every style)

- **Busy enough.** Something new on nearly every beat, or at least every line. A stretch with nothing happening
  reads as a mistake, not a rest. When a stretch feels empty, fill it with callbacks (translucent overlays of earlier
  scenes) and background life (children, animals, people passing) rather than restaging it.
- **No long freezes.** A four-second still reads as the player stalling. Keep holds to a beat or two, or keep
  something drifting: a slow camera move, breathing light, smoke.
- **Make small changes obvious.** A face swapping for another face, a detail changing on a paper: if it matters,
  make it big and push the camera in on it. Subtle changes go unseen.
- **Too clean reads as dead.** A video that stays tidy all the way through can feel flat; give it an arc.
- **Vary the repeats.** The second chorus shouldn't replay the first. New scenes, with brief flashes back to the
  first chorus's pictures on key words, keep the echo without the repetition. A motif that does something different
  each chorus (ribbons that knot, then plait, then slip) works well.
- **Whole figures beat close-up hands.** Big silhouettes of hands and arms read as clubs, poles or chess pieces. A
  whole figure, even small and mostly still, carries a beat better.
- **Faces:** realistic halftone or heavy shading can make people look ill. Stylized faces (dot eyes, lowered lids
  when looking down) for close figures and blank faces for crowds read better.
- **What makes a look cute** (sometimes wanted, often not): flat candy fills, rounded sack-shaped figures with blob
  heads, even lighting, bobbing walks. For solemn songs, use weight, texture, uneven light and stillness instead.
- **Real texts make good props.** A period document, a real letter or hymn, an actual map give a scene weight even if nobody
  can read them.
- **Impossible places need ordinary things in them.** Floating or folded land only reads as land when it carries
  trees, lit windows, snow on its ground side, smoke going the "wrong" way.
- **Decide about text in the picture.** A lyric band under the picture is one choice; no readable text at all
  (squiggles for writing) is another; either way, be consistent. Captions that only repeat the lyric are redundant.
- **Fake text is worse than no text.** A card of invented glyphs that flickers reads as a screen of foreign writing.
  Use pictograms, squiggles, or nothing. Likewise on-screen read-outs (temperatures, timecodes) in a "technical"
  medium: keep them only if they mean something.
- **Show the medium working.** When a look risks feeling static (a photograph, a print, a drawing), let the viewer
  watch it being made: a plate exposing, inks printing in on the beats, stitches sewn in, a slide pushed into the
  lantern. It answers "static and unclear" without changing the look.
- **Vary what leads a scene.** In a medium with a life of its own (liquid light, marbling, sand), let some scenes be
  led by the pictures and some by the medium, rather than the same mix throughout.
- **Props must sit in hands.** A rope, a ring, a cloth or a cup that floats near a hand reads as broken. Anchor held
  things to the rig's hand points and check every one in stills.
- **Arms that move naturally:** pose them by where the hand and elbow should be, blend joint angles rather than
  positions, let the forearm trail the upper arm, and add breathing and small weight shifts. Arms that slide
  straight between poses look like a puppet's.
- **Bodies carry identity.** In silhouette, heat or other outline-first looks the outline is all a viewer gets: if
  someone is heavily built, or small and round, the shape must show it. Keep sizes consistent (an animal is as big in
  every shot).
- **Shapes read as other shapes.** A figure lying flat reads as a collapsed body (have them sit or doze upright unless
  a death is meant); a pyramid of sacks in a lit doorway reads as a hooded head; a fan of hair strands reads as a
  feathered headdress. Look at every silhouette as a stranger would.



===== 完整公共规范：docs/timing.md =====

# Timing a song

Everything in a video hangs off the song's clock: the lyric band lights each word as it's sung, pieces land on
beats, scenes change on line starts, the lamp goes out in a dropout. This page is how to get those times. The tools
are in [tools/audio/](../tools/audio); each prints its own help with `--help`.

Setup (once): `pip install -r requirements-audio.txt` (librosa, scipy, faster-whisper, mido). The Whisper model
downloads the first time it's used.

## The pipeline

```bash
# 1. the shape of the song: tempo, loudness, sections
python tools/audio/analyze.py song.mp3

# 2. words with timestamps, from the vocal stem if you have one
python tools/audio/transcribe.py vocals.mp3 --lyrics lyrics.txt --out whisper.json

# 3. your lyric sheet matched to Whisper's words
python tools/audio/align.py lyrics.txt whisper.json --out lines.json

# 4. snap each word to where the voice starts it (vocal MIDI and/or vocal audio)
python tools/audio/snap.py lines.json --midi vocals.mid --audio vocals.mp3 --out snapped.json

# 5. the page's data file
python tools/audio/to_js.py snapped.json --out projects/my-song/lyrics_data.js --title "My Song" \
    --audio song.mp3 --audio-file projects/my-song/song.mp3 --bpm 96 --beats-per-bar 4
```

Then open the video with the lyrics showing and listen through. Fix what's off by editing `lyrics_data.js`
directly: it's plain data.

## Step by step

### 1. The shape of the song

`analyze.py` prints the global tempo and the local tempo every 20 s, a table of loudness, brightness and rhythmic
busyness every few seconds, and guesses at section boundaries. Read it next to the lyric sheet. You're looking for:

- which sections are loud and which drop out: the video's big and quiet moments should follow them;
- tempo changes (a slow intro, a half-time bridge);
- **stops and hits.** `onsets.py song.mp3 --from 140 --to 155` zooms in on a stretch: the strongest onsets, the
  beats, and the loudness every quarter second, so a dropout shows as a run of low numbers. These are the best
  sync points a song offers: the place for everything to freeze, for a cut, for a light to go off.

`sections.py song.mp3 --lines lines.json` compares the sections' loudness, drums and tonal energy once you know
where they are.

### 2. Transcribe

`transcribe.py` runs faster-whisper with word timestamps. Give it the **vocal stem** if there is one; sung vocals
over a full mix transcribe much worse. The `small` model is usually enough and takes about a minute. `--lyrics`
passes the start of your lyric sheet as a prompt, so names and odd words come out spelled your way. `medium` can
rescue mumbled lines, but over a long song it can drift further than `small`.

Expect Whisper's times to run **early**, typically a few tenths of a second and sometimes by more than a second,
and to hear some words wrong, especially names and unusual words. Step 3 doesn't care about wrong words; steps 4 and
the listen-through fix the times.

### 3. Align

`align.py` lines your sheet up against Whisper's words (a sequence match, so misheard or missing words don't break
it; unmatched words get times interpolated from their neighbours). It prints each line with a match count like
`m7/9`. Low counts are where to listen first. Watch for:

- **numbers:** Whisper writes "1974" as one token for three sung words. The script spells out years and small
  numbers before matching, but check them;
- **hyphenated words** and contractions;
- **a misheard last line** ("Let it go" for "Letting go"): the end of a song, over a fade, is where Whisper guesses;
- **repeats and ad-libs** the singer added: put them on the sheet as sung, or they'll be squeezed between
  neighbours.

### 4. Snap to the voice

`snap.py` moves each word to the nearest sung-note onset within 0.32 s: note onsets from the **vocal MIDI** first
(if you have it), then onsets detected in the **vocal audio**. It first reports the median offset between the words
and the onsets; if Whisper ran early across the whole song, pass that back as `--shift` so everything moves before
snapping.

After snapping, some things still need a human ear:

- **line starts that land in silence** or on the tail of the previous word: move them to where the voice comes in;
- **choruses and held notes:** a melisma or a long held word confuses onsets;
- **MIDI quantization:** Suno's MIDI is quantized to sixteenth notes and can sit about 0.3 s off the voice.

For those, `onsets.py vocals.mp3 --from 25 --to 27 --pitch` prints the sung pitch and loudness every 50 ms: the
word starts where the pitch appears and the loudness jumps.

### 5. Write the page data

`to_js.py` writes `lyrics_data.js`, which sets `window.SONG`:

```js
window.SONG = {
  title: "My Song", credit: "", audio: "song.mp3", duration: 212.4,
  bpm: 96, beatsPerBar: 4, firstBeat: 0.35,
  sections: [["verse1", 12.3, 41.0], ...],
  beats: [0.35, 0.975, ...],            // only with --beats: exact beat times
  lines: [{section: "verse1", text: "Who has seen the wind?", t0: 12.3, t1: 14.9,
           words: [["Who", 12.3], ["has", 12.9], ...]}, ...],
};
SONG.beat(n)  // the time of beat n
```

Every style in this repo reads that shape (see [examples/poem/lyrics_data.js](../examples/poem/lyrics_data.js)).

## Beats

For a steady song, `--bpm` and `--first-beat` (the time of the first downbeat) are enough: `SONG.beat(n)` is
`firstBeat + n * 60 / bpm`. Find the first beat with `onsets.py` on the song's opening seconds.

If the tempo drifts or changes, use exact beat times instead:

- **from MIDI stems:** Suno writes a tempo event on every beat, so the tempo map is an exact beat grid.
  `midi.py drums.mid --beats-out beats.json` (any of the song's MIDI files will do);
- **from the audio:** `analyze.py song.mp3 --beats-out beats.json` (librosa's estimate; check it).

Pass the file to `to_js.py --beats beats.json`; `SONG.beat(n)` then reads from the list.

## Hits and loudness

Some styles pulse, flash or move with the music itself rather than the words: a lamp that breathes with the mix, a
ring on every drum hit, mouths that open with the voice. `pulses.py` measures those:

```bash
python tools/audio/pulses.py song.mp3 --percussion perc.mp3 --drums drums.mp3 --vocals vocals.mp3 --out projects/my-song/audio_data.js
```

It writes `window.AUDIO = {fps, ticks, kicks, env, venv, vdb}`: small hits (`ticks`) and big ones (`kicks`) as
`[time, strength]`, the mix's and the voice's loudness 24 times a second (`env`, `venv`, 0..1), and the voice's
loudness in decibels mapped to 0..1 (`vdb`, better for mouths). Stems give much cleaner hits than the mix; without
them everything comes from the mix. The liquid light show reads this file as it is; any style can read the arrays.

## Suno specifics

- The stem download gives an audio file and a MIDI file per instrument. The lead vocal stem transcribes cleanly.
- The MIDI files carry a key-signature event that the `mido` library can't decode (it raises
  `KeySignatureError`). `tools/audio/midi.py` patches mido to read it as C; import `load()` from it in your own
  scripts to get the fix.
- The MIDI tempo map has one event per beat: an exact beat grid, including tempo changes after an intro.
- Vocal MIDI notes are quantized and can sit up to ~0.3 s off the voice: good anchors for snapping, not ground truth.
- Suno ignores dynamics on the lyric sheet ("quiet", "spoken", "almost unaccompanied"). Measure.

## Checking by eye and ear

Open the page, play it with the sound on, and watch the lyric band. Words that light up early are the common
fault. For a close look, `#t25.3` on the page's URL shows the frame at 25.3 s with the band as it is then.



===== 完整公共规范：docs/rendering.md =====

# Previewing and rendering

Every video here is a web page that draws its frames on a canvas. You watch it in a browser while you work, and
when it's done a script steps through it frame by frame in headless Chrome and pipes the frames to ffmpeg. This
page covers the page contract the tools rely on, previewing, stills, MP4s, and fixing a stretch.

Setup (once): `pip install -r requirements.txt` (Playwright, imageio-ffmpeg, Pillow, numpy). The tools drive your
installed Google Chrome; if you don't have it, `python -m playwright install chromium` gets Playwright's own.
imageio-ffmpeg bundles an ffmpeg with x264 and AAC, so there's nothing else to install.

## The page contract

A video page (a style's `index.html`, or a copy of one for your song):

- draws into `<canvas id="film" width="1920" height="1080">`;
- loads its song data as `window.SONG` (see [timing.md](timing.md#5-write-the-page-data)) and plays `SONG.audio`
  in an `<audio>` element, falling back to a silent clock if the audio can't load;
- sets `window.__video`:
  - `ready`: true once everything is built;
  - `duration`: the song's length in seconds;
  - `step(t)`: draw song time `t` the way playback does. The MP4 renderer calls it at 24 fps, strictly in order;
  - `renderAt(t)`: draw a still of time `t` from a fresh state (catching up whatever the frames before it built);
  - either may return a Promise (a page that builds scenes asynchronously); the tools wait for it;
  - `error`: set this to the error text if building fails, and the tools stop and print it;
  - optionally `shots` and `probe(t)` for 3D pages (see `tools/probe.py`);
- shows a still when the URL ends in `#t<seconds>` (e.g. `index.html#t12.5`), with the page chrome hidden;
- draws only while playing: a paused player shouldn't keep redrawing its frame on every animation frame (the tools
  draw and read back each frame in one call, but a page that redraws on its own fights anything else that draws);
- is **deterministic**: all randomness comes from seeded generators keyed to the frame number, never
  `Math.random()` per frame, so a given moment always draws the same picture. An MP4 depends on it.

A style-lab page sets `window.__lab = { ready, scenes, styles, render(scene, style) }`, where `render` draws one
scene in one look and returns the canvas.

## Previewing

```bash
python tools/serve.py            # serves the repository at http://localhost:8000/ and lists the demo pages
```

Open a page from the list. Use this server rather than `python -m http.server` or opening the file directly:

- pages that use ES modules or load files **don't work from `file://`**;
- a plain server lets the browser **cache scripts**, so after an edit you can be looking at the old code. This
  server sends no-cache headers;
- audio and video only seek when the server answers **Range requests**; this one does.

**Stills in the browser:** add `#t<seconds>` to the URL. Changing only the `#` part doesn't reload the page, so
after editing code, reload with a new query (`index.html?r=2#t30`).

**Always check the console** after a load. One bad value in a canvas gradient (a NaN colour stop) throws, and the
whole frame goes blank.

**In Claude Code's desktop app**, the preview pane can run the server for you: create `.claude/launch.json` with
```json
{ "version": "0.0.1", "configurations": [
  { "name": "videos", "runtimeExecutable": "python3", "runtimeArgs": ["tools/serve.py", "8000"], "port": 8000 } ] }
```
(it's git-ignored).

## Stills and contact sheets

```bash
python tools/still.py styles/paper-cut/index.html 5 12.5 30          # three stills
python tools/still.py styles/paper-cut/index.html 0:37.5:2.5 --sheet # a frame every 2.5 s, tiled into one image
python tools/lab_stills.py styles/embroidery/lab/index.html --all --sheet
```

Output goes to `renders/` (git-ignored). The contact sheet is the fastest way to review a whole video: look at every
frame on it, not just the ones you changed. Things to look for: frame edges showing the end of the world, blank or
black frames, the camera inside an object, text covered or cut off, two scenes' seams, something frozen too long.

## MP4s

```bash
python tools/render_mp4.py styles/marbling/index.html                    # renders/marbling.mp4 and -720p.mp4
python tools/render_mp4.py projects/my-song/index.html --out "renders/My Song.mp4"
python tools/render_mp4.py projects/my-song/index.html --start 60 --end 90 --fast   # quick preview of a slice
```

- Two files: 1080p (x264 `slow`, CRF 23, AAC 192k: roughly 5 Mbps for a busy picture) and `-720p` (CRF 25: about
  1 Mbps, small enough to send).
- `--fast` writes only the 720p with the `veryfast` preset. Busy, grainy frames can take many times longer to
  encode with the slow preset than to draw, so use `--fast` for previews and the normal mode for the final.
- The audio comes from `SONG.audio` unless you pass `--audio`. A slice gets short audio fades.
- **Fonts:** the styles load their type from Google Fonts. If a font request fails (a flaky network), canvas text
  silently falls back to a default font, so `render_mp4.py` and `render_frames.py` check the page's fonts after it
  builds and stop if any failed. Run again, or pass `--allow-font-fallback` if you really mean it. The still tools
  print a warning instead.
- 24 fps. Frames are rendered **in order**: many styles draw each frame over the one before (frost that grows,
  ghosting, marbled paint that keeps its history), so a frame can't be drawn on its own.
- Speed depends on the style and on how much the machine is doing: from about 40 ms a frame (paper cut, painted
  enamel, archive desk) to 250 ms or more (sand, the pinscreen, screenprint's printing), including reading the frame
  back and encoding. Each style's README gives its numbers. A four-minute song is 5,760 frames: a few minutes for the
  fast styles, half an hour or more for the slow ones (see the next section for splitting a render across browsers).

## Long renders: frames on disk, resumable, in parallel

For a long song in a slow style, render the frames to a folder instead of straight into ffmpeg:

```bash
python tools/render_frames.py projects/my-song/index.html --dir renders/frames/my-song --jobs 3
python tools/encode.py renders/frames/my-song --out "renders/My Song.mp4"
```

- Frame `i` is `<dir>/<i:05d>.jpg` and shows song time `(i + 0.5) / 24`. Frames already on disk are skipped, so an
  interrupted render continues where it stopped when you run the same command again, and deleting a stretch's
  frames and re-running redoes just that stretch.
- `--jobs N` renders N runs of frames in N browsers at once. Each run starts with `renderAt()` at its first frame,
  which catches up styles whose frames depend on earlier ones, then steps in order. (Tested: a resumed run's frames
  match a straight-through render pixel for pixel.) GPU-heavy styles gain less, since the browsers share one GPU.
- `encode.py` takes the audio from the folder's `meta.json` (the page's `SONG.audio`), cuts it to the frames on
  disk, and writes the same 1080p and 720p files as `render_mp4.py`.
- **A render that sits before its first frame** is usually the machine, not the page: with other renders or heavy
  WebGL pages running, Chrome can take minutes to start or to build a page. `render_mp4.py` prints the page's URL when
  it's loaded and a progress line every 240 frames.
- **Heavy 3D pages:** building every set of a long WebGL video at once can hang the GPU. Render such a video in
  segments (`--start`/`--end` runs into the same frame folder, each run building only what its stretch needs), and
  on a machine that other renders are sharing, run one segment at a time.

## Fixing one stretch

A full render can take a while. To fix one stretch, render only that slice at full quality and splice it into the
finished file at whole frames:

```bash
python tools/render_mp4.py projects/my-song/index.html --start 120 --end 135 --out renders/fix.mp4
python tools/splice.py "renders/My Song.mp4" renders/fix.mp4 --at 120 --out "renders/My Song v2.mp4"
```

A slice opens with `renderAt(t)`, which catches up styles whose frames build on earlier ones, so its frames match the
full render's and the splice is seamless.

## Checking a 3D video's framing

`python tools/probe.py styles/diorama/index.html` asks the page, for the start, middle and end of every shot,
whether anything stands between the camera and its subject, or whether the camera is inside something. In a crowded
set it finds blocked views much faster than contact sheets.

## Sharing

Share the MP4. If you also want a review page (the video with notes around it), keep in mind that some hosts cap
file sizes: split a long 720p video into parts at scene changes and play them in sequence against the song, and
serve it from something that answers Range requests.



===== 完整公共规范：docs/your-own-video.md =====

# Making a video for your own song

The hands-on steps, from an mp3 to an MP4. For the creative side (what to decide before building, how to pick a
look) see [workflow.md](workflow.md). If you're working with Claude Code, you can just ask it to make a video for
your song: [CLAUDE.md](../CLAUDE.md) walks it through all of this.

## 1. Set up

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt            # rendering
pip install -r requirements-audio.txt      # timing a song (Whisper, librosa, MIDI)
```

You need Google Chrome installed (or run `python -m playwright install chromium`).

## 2. Start a project folder from a style

Pick a style from the [gallery](../README.md#the-styles) and copy its folder:

```bash
cp -r styles/paper-cut projects/my-song
cp ~/Music/my-song.mp3 projects/my-song/song.mp3
```

Audio files are git-ignored, so your song stays out of the repository.

In `projects/my-song/index.html`, change the lyrics script from the demo's
```html
<script src="../../examples/poem/lyrics_data.js"></script>
```
to your own
```html
<script src="lyrics_data.js"></script>
```
(Relative paths from `projects/my-song/` resolve just as they did from `styles/<style>/`, so anything else the
page loads from the repo keeps working.)

## 3. Time the lyrics

Write the lyric sheet (`projects/my-song/lyrics.txt`, one sung line per line, `#section` markers), then run the
pipeline in [timing.md](timing.md). It ends with `projects/my-song/lyrics_data.js`.

## 4. Look at it

```bash
python tools/serve.py
```

Open `http://localhost:8000/projects/my-song/index.html`. The demo's scenes now play under your lyrics for as long as
the demo lasts. That's the moment to decide the plan: which scene goes where, which line lands on which image.

## 5. Replace the demo's scenes with yours

Every style's README has a "Make your own video in this style" section that says which files are the demo (its
scenes, sets, shots or timeline) and which are the engine. Keep the engine; rewrite the demo files. Work a section
at a time:

```bash
python tools/still.py projects/my-song/index.html 30:60:2 --sheet   # stills every 2 s across 0:30-1:00
```

Look at every still on the sheet. Check the console output printed at the end.

## 6. Render

```bash
python tools/render_mp4.py projects/my-song/index.html --start 30 --end 60 --fast   # a quick 720p preview
python tools/render_mp4.py projects/my-song/index.html --out "renders/My Song.mp4"  # the final, 1080p + 720p
```

To fix one stretch later without re-rendering everything, see
[rendering.md](rendering.md#fixing-one-stretch).



===== 完整公共规范：docs/engine-patterns.md =====

# How the engines are built

The eighteen engines in [styles/](../styles) share no code at run time: each folder is self-contained, written for one
song in one medium (a few began as copies of another's files, such as the 3D pipeline or the ray-marched figure). But they
share a shape, and knowing it makes any of them easy to read and a new one quicker to write. This page is that
shape, plus the browser gotchas that cost the most time.

## Simulate the process, not the look

Each engine models how its medium is physically made, and the imperfections come out right on their own:

| medium | what the code does |
| --- | --- |
| screenprint | each ink is a stencil mask plus a halftone; inks are pulled one at a time and multiplied onto paper, each a little out of register, with squeegee streaks and pinholes |
| linocut | a block is a list of gouge cuts and inked areas; the key block prints black over watercolour washes |
| wool embroidery | wool is laid and couched from tiles, outlines are stem-stitched, light is couched gold thread |
| marbled paper | paint floats as closed outlines on a bath; drops, combs and swirls are exact maps applied to every point |
| magic lantern | slides are baked as tinted glass; a frame stacks glass by multiplying and throws it through a lens |
| painted enamel | two-colour bristle strokes with a highlight flick toward the light, then gold leaf |
| paper cut | cut shapes with a lit rim and a soft shadow, layered in depth and lit from behind |
| mosaic | tesserae are laid in rows along the outlines, then grouted |
| sand on a lightbox | sand thickness is a density field; the lamp shows through as `exp(-k * thickness)`; fingers clear lines |
| carved diorama | each piece is a signed-distance sculpture meshed in the browser; tool marks are a bump in the piece's own space |
| photomontage | photographs are painted in greys, then given a print's grain, halation and tone curve, and cut out with drifting scissors |
| pinscreen | a field of pins at different heights, lit from a low angle, each pin's shadow falling on the next |
| archive desk | every paper is pre-rendered with its shadow, grain, foxing and torn fibres; stamps are inked, then eroded |
| night poster | a shape's shadow is the band a shifted copy of it fails to cover; night mixes colours toward navy while lamps keep their brightness |
| batik | a real 3D set lit by two coloured lamps is rendered into buffers; wax resists where both lamps reach, each dye takes where only one does, and the wax cracks |
| long-exposure glass plate | each frame integrates many light drawings over the exposure, so whatever moved is a smear and whatever stood still is sharp; then halation, dust and the emulsion's edge |
| silverpoint | even hatching whose weight follows the tone; lines can't be erased, and tarnish from grey to brown with age |
| carved relief | the scene becomes a height field, shaded by a raking light with its own cast shadows |
| liquid light show | oil, water and dye in a dish on a projector: warped-noise dye bands, metaball oil drops with a meniscus, and drawn transparencies whose black ink really blocks the lamp |
| thermal camera | a scene rendered as temperatures and mapped through a camera palette, with a thin visible-light edge overlay, warm breath and fading heat prints |
| showboat stage | painted flats given brushwork by a sampled-stroke pass, lit by a light map in which the actors are lit through their own silhouettes |

A filter that makes a clean digital picture look like linocut never convinces for long. A few rules about how the
real thing is made go much further.

## One frame

Almost every engine's frame function looks like this:

```
renderFrame(t):
  shot = the shot covering t
  set  = shot.set, baked on first use           (the still layers: land, buildings, background)
  cam  = shot.cam(t)                            (keyframed, eased)
  draw the set's layers through the camera       (parallax: nearer layers move more)
  draw what moves at t                           (figures, props, light, weather)
  post: light (a multiplied lamp or light map), grain, vignette, the medium's texture
  if t is inside a transition: draw the next shot too and mix (dissolve, wipe, push)
  the lyric band / margin / caption for t
  fade in and out at the ends
```

The canvas is 1920x1080. Several styles keep the picture above a band for the lyrics (e.g. 1920x960 + 120).

## Sets, shots, cameras

- **Sets** (or scenes, worlds, plates) are places. Their still parts are drawn once into offscreen canvases the first
  time they're needed ("baked"), then only composited. Keep a memory budget: the whole song's sets rarely fit at
  once, so drop the least recently used. Bake at load what the first seconds need, so playback doesn't hitch.
- **Shots** are stretches of song time: `{t0, t1, set, cam, ...}` plus a function that poses what moves.
- **Camera keys** are `[time, x, y, zoom, ...]` with easing between them. Two useful rules:
  - push in with **lens zoom**, not by travelling into the layers: depth travel blows the nearest layer up (snow
    becomes moons);
  - **never let the camera see past the edge** of what's drawn. Check the frame corners on every new camera.
- **Transitions:** dissolves, drop wipes (a new picture spreading inside a drop), push and pull (from a room to the
  picture on its screen), panels (pull back to a page of panels, push into another), re-laying one medium as another
  past a moving line.

## Time: on twos, and in step with the song

- Hand-made animation moves **on twos**: pose changes at 12 fps inside 24 fps video. Several engines step motion at
  12 fps (`tm12 = Math.floor(t * 12) / 12`) while the camera moves at the full 24, which keeps the hand-made feel
  without a juddering camera. Texture "boil" (grain, ink noise) often changes at 8 fps.
- **Ease into fast moves**, or drive them with real time: a move that starts at full speed jumps at 12 fps.
- **Hits on beats, changes on lines.** `SONG.beat(n)` and each line's `t0` and word times are the anchors. A word
  lighting in the lyric band typically fades up over `[t - 0.04, t + 0.16]`.
- **Keep something moving.** A hold longer than a beat or two reads as the player freezing. A slow drift, a breathing
  light or drifting smoke keeps a still picture alive.

## Determinism and frame-to-frame state

- All randomness comes from seeded generators (`mulberry32(seed)`) and noise keyed to the frame number. Never call
  `Math.random()` while drawing a frame. The same `t` must give the same picture, or an MP4 won't match what you
  checked.
- Some styles **carry state from frame to frame**: frost that grows, ghosting of the previous frame, a charcoal
  drawing that's erased and redrawn, marbled paint whose outlines remember every comb. Those must be stepped in
  order. `renderAt(t)` then means "rebuild the state from the start of this scene up to t", and each engine's README
  says how it does that.
- When a view steps backwards in time (a camera effect that holds frames, a scrub), keep what's already baked rather
  than rebuilding it from scratch each step, or rendering crawls.

## Figures

- **Whole figures**, posed. Every engine has a rig: jointed silhouettes, contour-drawn people, ray-marched signed
  distance bodies, carved 3D pieces. Most use **two-bone IK** for arms (and often legs), so a hand can be put exactly
  on a rope, a cup or another hand. Each rig spells it its own way: `reachArm()` in paper cut, an arm given as
  `{t: [x, y]}` in embroidery or `{at: [x, y]}` in painted enamel; the style READMEs show how.
- Build **every figure of a kind from one model**, so its anatomy is the same in every shot; vary only pose,
  clothing and age.
- Things that make figures read wrong, all hit at least once: round heads read as teddy bears (give them a muzzle
  or a jaw); coats that hang along the body turn a crouching figure into a plank (hang them toward world-down);
  digitigrade legs with a long stride look like sitting on a stool; two figures leaving the same way merge into one
  blob; close-up arm silhouettes read as clubs or poles.

## Light

- A **lamp** is a radial gradient drawn with `multiply` (or a light map multiplied onto the whole picture). Its
  warmth and brightness carry most of a scene's mood.
- **Self-lit things** (flames, lit windows, glowing marks) go in their own layer drawn after the light map, plus a
  glow. A reflective shape in front should erase the self-lit layer behind it.
- On pale paper, `screen` adds almost nothing; `soft-light` plus a weaker `screen` shows coloured light.
- Glass only darkens: a moving piece has to pass over light glass, or it vanishes.

## Text in the picture

- Load fonts before drawing and wait for them (`document.fonts.load(...)` for each face and script you use), or text
  falls back to a default font. `document.fonts.load` resolves even when the font never arrived, so check the
  result (or `document.fonts.check(...)`) before building. Put `<meta charset="utf-8">` at the top of the page for
  any non-ASCII text.
- **Start building only when every script has loaded** (`DOMContentLoaded`, or put the start call at the end of the
  last script). A build started from a font promise plus a short timer can win the race against later scripts when
  the fonts come from cache, and the page fails to build only sometimes.
- Keep the lyrics readable: if the camera zooms, keep the text out of the zoom (a band or margin drawn in screen
  space).

## Browser gotchas that cost hours

- **One bad gradient value kills the frame.** `addColorStop` with a NaN or an out-of-range offset throws, and nothing
  after it draws. Check the console after every change.
- **`destination-out` uses the current fill's alpha.** A fill left translucent from the last wash only half-erases.
  Set `fillStyle = '#000'` before erasing.
- **`[hidden]` loses to `display: grid`.** Add `.gate[hidden] { display: none }` for overlay elements.
- **Globals collide.** Plain scripts share one global scope; a helper named like an existing function (`hand`,
  `line`) silently replaces it.
- **Tiling seams:** a texture tiled from a sampled corner shows seams on big pieces; downsample the whole texture.
- **WebGL:** GLSL has reserved words you'd never guess (`patch`); creating a texture while another is bound can
  overwrite a texture unit (create textures on a scratch unit such as TEXTURE15); a three.js `InstancedMesh` keeps the
  bounds of its first draw unless `frustumCulled = false`.
- **Headless loads:** wait for the page with `wait_until='commit'` and your own ready flag; a page that builds a lot
  at load can time out waiting for the load event.
- **Grain that changes every frame bloats the MP4.** Change it on twos.

## Starting a new engine

1. Copy the style closest to what you want. Keep its player (`index.html`, the playback and `window.__video` parts
   of its engine) and its lyric code.
2. Write the medium: the few functions that turn a shape into your medium's marks. Test them on stills first, on a
   page that just draws one scene (a lab page).
3. Draw the same key scenes in your medium and in one or two alternatives. Choose.
4. Then sets, shots and the song.



## 原作者媒介陷阱与经验摘录

## Lessons and gotchas

- **A perfectly clean desk looks too tidy.** A decay arc fixes it: clean at the start and increasingly corrupted,
  with static, dropped frames and surveillance overlays flickering in and out. Gate the random intrusions behind a
  threshold on the curve, or they spoil the clean opening.
- **Small changes need to be obvious.** A swap between two similar faces went unnoticed. Make faces clearly
  different people, and move the camera in when a change matters.
- **Smoke looked like a solid white tube.** Overlapping round-capped segments stack their opacity. Draw longer
  chunks at low opacity, in several layers.
- **Frost:** long branching lines look like twigs, and random short needles look like static. Short tufts growing
  inward from the edges look like frost. On pale paper, white needles vanish, so give them a blue-grey body, a
  thin shadow and a white core.
- **Edge effects belong in screen space.** Frost grown in desk coordinates showed as a hard inset rectangle once
  the camera pulled back.
- **Photos:** plain silhouettes read as default avatar icons. A photo reads as a photo once it has shading,
  features, grain and toning. Run portraits through the same print as everything else, or they look pale beside
  the other photos.
- **A single bad value in a canvas gradient** (NaN or Infinity in a colour stop or a radius) kills the whole
  frame. Read the console after every load; the tools print it.
- **Build caches at load, not on first use:** building on first use caused a 120 ms hitch mid-song.
- **Character encoding:** put `<meta charset="utf-8">` first, or text in other scripts comes out garbled.
- **The play overlay never hid:** `display: grid` beat the `hidden` attribute. Add `.gate[hidden]{display:none}`.
- **Serve over HTTP:** some previewers open `file://` pages as static snapshots with no scripts.
- **Stale scripts after an edit:** a plain Python server lets the browser cache them. `tools/serve.py` sends
  no-cache headers.
- **Map outlines:** simplifying a closed outline can collapse it to two points, so split it at the point farthest
  from its start first. Outlines that cross the date line draw lines straight across the map; shift their
  longitudes per outline.
- **Global names collide.** These are plain scripts in one namespace. `core.js` has a global `hand()` for
  handwriting, and a line helper of the same name broke every text on the desk; hence `hl()`.
- **The surveillance camera's clock:** at 8 fps its scene time steps backwards between blocks. Every pencil sheet
  rebuilt itself from scratch on each step, and the render crawled. The same steps back also restarted the smoke
  and regrew all the frost, giving 60 ms spikes. Sheets, frost and smoke now all keep their state through steps
  back of up to 0.3 s.
- **Overlays on paper** (tracing paper, the window light) have to be modest. Tracing paper needs to be milky
  (alpha about .6) with lines darker than the drawing under it. Light added near the lamp burns pale paper out, so
  the window light fades near the lamp.
- **Encoding is the slow part.** Busy frames are hard to encode: with x264's slow preset at two sizes, a test ran
  at about 0.4 s a frame although drawing took 3-10 ms. Use `--fast` for previews.
- **Render in order.** Frost, smoke and ghosting depend on the frame before.
- **Layering:** z is fixed per object. Raising one paper to cover another can put it above something else later,
  so plan z per scene, or raise several together.
- **Holds:** a hold of several seconds reads as the player freezing. Keep holds to a beat or two, and keep
  something drifting: the lamp breathing, dust, smoke, branch shadows.
- **Time to the measured audio,** not to the lyric sheet's labels. Song generators ignore dynamics markings.
  Speech-to-text word times can run early by a second or more, so check them against the vocal before timing
  stamps to words.
- **Cutting a hole** with `destination-out` removes only as much as the fill's alpha. A leftover translucent
  `fillStyle` left the magnifier's lens 88% black.
- **The surveillance camera's zoom reads the clean picture.** It used to crop the frame after the decay pass, so
  whenever that frame was torn or rolled the zoom magnified displaced strips and landed on the wrong part of the
  desk. It now crops the scene before decay (`SCN`) and adds its own degradation after.
- **See-through objects need their own shadow.** `makeObj` bakes a solid shadow under the whole outline, which shows
  through glass or anything translucent. Give such an object `shadow: false` and draw a soft blurred shadow yourself
  at the start of its `fill`.
- **Halftone dots grow with the square root of the darkness**, because a dot's ink is its area; a radius straight
  from the darkness makes the mid-tones too pale. Batch a row of dots into one path: a clipping has thousands.


