# 73 · 热成像 / Thermal camera

来源类型：根据作者引擎说明整理的使用模板；并非作者原始创作提示词  
原作者：Miranda Dixon-Luinenburg  
上游原文：https://github.com/cyborggirl963/opus-5.5-music-video-art-styles/tree/main/styles/thermal  
固定版本：801b3548c54765ecf932ce8b7f3cf4b29fb7a8bf  
抓取核对日期：2026-11-03  
本库改动：中文任务模板、中文摘要与编排；原文全文保留。

## 使用前先看

- 普通玻璃在长波热成像中通常不透明，不能借可见光规则画透窗人物。
- 同温环境和接触的人会合并成色块，保留细边缘辅助；这是艺术模拟，不输出医学诊断或真实测温结论。

- 这是代码渲染工作流；聊天文本本身不会自动产生 MP4，需有可执行的项目环境。
- 先看预览再做长片；不要把示例素材的许可自动套到自己的歌曲、照片、字体和品牌上。
- 下方复制区包含全部风格与公共规范，不要求 AI 另外从本机隐藏路径读取文件。

## 完整复制区

你是一位能写代码、检查画面并渲染成片的动画导演。请用“热成像 / Thermal camera”制作一个属于我的视频。

【我的需求；把花括号内容换成实际值】
主题与一句话故事：{{填写主题和结尾变化}}
用途与观众：{{例如面向普通观众的科普短片}}
内容依据或已有脚本：{{填写；没有则说明需要你写}}
音频、歌词、图片、数据、品牌素材路径：{{填写；没有写“无”}}
素材使用权限与需显示的署名：{{填写来源与许可；不清楚请列待确认项}}
目标时长：30 秒起步；MV 以实测歌曲时长为准
画幅与清晰度：默认横屏 16:9、1920×1080；帧率按本风格原文与引擎规范，未规定时24fps；竖屏须重新构图，不直接裁横屏
语言：简体中文；配音需求：{{有/无、声线与语速}}
必须出现的内容：{{填写}}
禁止出现的内容：{{填写}}
预算与速度：先做低成本验证，再渲染完整片
个人工程名：my-video（可改为英文短名）
确认方式：先给 3 张由真实渲染代码产出的样帧和 5–10 秒预览；我确认风格后再做完整成片

【本风格的核心实现】
按表面温度而非可见光反射着色，用呼吸、脚印、余温和热轨迹叙事。
特别检查：
- 普通玻璃在长波热成像中通常不透明，不能借可见光规则画透窗人物。
- 同温环境和接触的人会合并成色块，保留细边缘辅助；这是艺术模拟，不输出医学诊断或真实测温结论。

【工程与流程】
1. 在工作区单独克隆 https://github.com/cyborggirl963/opus-5.5-music-video-art-styles ，检出 801b3548c54765ecf932ce8b7f3cf4b29fb7a8bf。将 styles/thermal/ 复制到 projects/my-video/，保留引擎，按该风格 README 指定的文件替换示例场景。不要直接修改 styles/ 中的母版。
建立 Python 虚拟环境，阅读 requirements.txt 后安装渲染依赖；需分析音频时再安装 requirements-audio.txt。使用 Chrome 或项目支持的 Chromium。使用 python tools/serve.py 提供本地 HTTP，不用 file:// 打开渲染页面。
2. 先检查机器的 Python、Node/浏览器、FFmpeg、字体与 GPU 能力。Lemo 当前要求 FFmpeg 7+；先用 ffmpeg -version 核对。缺少工具或访问权限时明确报告缺什么，不能只描述完成、伪造文件或把截图称为已渲染视频。
3. 把我的需求写成 PLAN.md 或 TREATMENT.md：一句话故事、分镜、逐镜秒数、镜头运动、文字位置、音乐与声音 cue、所需素材、预计成本。涉及事实和数据时写 FACTS.md；没有来源的数字不填。
4. 如果是 MV，先取得音频与实际演唱歌词，测量段落、停顿、节拍与词时间；不得沿用 37.5 秒示例诗的时间轴。未提供音乐时不要假装已经完成歌词对齐，可先制作无歌词短预览。
5. 先完成 3 张代表开头、关键变化、结尾的样帧，逐张检查；再渲染 5–10 秒低清短段，检查字幕、运动、音画同步与控制台。复杂慢风格先计时，再估算整片。
6. 随机效果固定种子；有历史累积的媒介按顺序渲染。并行前先比较随机抽帧与连续渲染是否一致。
7. 正式导出使用项目文档中的工具与参数，不臆造命令。交付可播放 MP4、720p 预览、源代码、素材清单与许可、字幕（有台词时）、复现说明；保留最终片长、帧率、音频响度与实际渲染耗时。
8. 实际打开并检查成片开头、中间、转场、结尾及全片联系表，确认没有空帧、字体回退、遮挡、裁字、爆音或无意复制的作者片尾签名。交代尚未完成的检查。

下面是完整风格参考与公共制作规范。它们是上游参考资料，不代表我的主题或逐字台词；我的具体需求优先。风格中明确的声音、镜头和媒介限制优先于公共建议，例如无声电影不添加旁白或拟音。遇到 macOS/Linux 示例命令时按当前系统等价转换，不直接在 PowerShell 粘贴 bash 命令。相对资源路径以完整克隆的上游工程为准。


===== 完整风格原文：styles/thermal/README.md =====

# Thermal camera

The picture a heat camera makes: every surface drawn by the warmth it gives off rather than the light it
reflects, mapped through a false-colour palette. It's real 3D (three.js), built from signed-distance models meshed
in the browser, but every vertex carries a temperature, an emissivity and a visible brightness instead of a colour.
A heat pass renders apparent temperature at a sensor's low resolution: emissivity falls at grazing angles, so bodies
cool toward their outlines; glass and bare metal reflect the cold sky; hollows such as the corners of the eyes read
warmer. A visible pass supplies only thin white outlines, laid over the heat the way real cameras blend in their
visible image. The final pass is the camera itself: detail enhancement with its dark halos, a noisy sensor with a
fixed column pattern, vignetting, a little bloom on hot sources, and the palette. Breath, smoke and exhaust are warm
gas; footprints and handprints are heat marks that fade; everything moves twelve times a second. The demo is a
farmyard on a windy autumn night. The camera can't see the wind either, only what it does to warm things.

*Good for:* songs set at night or in the cold; bodies, breath and touch; distance, watching and being watched;
anything where warmth means something.

![A woman reaches over a field gate to lift the latch, her breath blown sideways; a child and a dog wait beside her, a warm truck behind](img/hero.jpg)

| | |
|---|---|
| ![The farmhouse at night: lit windows, the chimney's smoke streaming flat, trees and clouds](img/yard.jpg) | ![From above: warm paw prints and boot prints fading on the gravel, breath trailing downwind](img/prints.jpg) |
| ![A lit window with the leaves of a branch hanging dark against it](img/window.jpg) | ![The second stanza in the arctic palette: washing streaming from the line like flags](img/washing.jpg) |

## Looks in this family

The [style lab](lab/index.html) draws three moments of the demo through each of the camera's settings. The
temperatures never change; only the way the camera turns them into a picture does.

| | | |
|---|---|---|
| ![Ironbow](img/look-ironbow.jpg)<br>**Ironbow** (the demo's first stanza): black through violet, red and orange to white. | ![White-hot](img/look-white-hot.jpg)<br>**White-hot**: plain grey, hotter is whiter. | ![Black-hot](img/look-black-hot.jpg)<br>**Black-hot**: inverted grey, the way surveillance cameras often show it. |
| ![Rainbow](img/look-rainbow.jpg)<br>**Rainbow**: every few degrees a new colour; loud, but small differences jump out. | ![Amber](img/look-amber.jpg)<br>**Amber**: one warm hue, black to cream; reads as older footage. | ![Arctic](img/look-arctic.jpg)<br>**Arctic** (the second stanza): a blue world where only warm things turn gold. |
| ![Embossed edges](img/look-emboss.jpg)<br>**Embossed edges**: the visible image's edges lighten the dark parts and darken the bright. | ![No edges](img/look-no-edges.jpg)<br>**No edge overlay**: heat alone; things at the air's temperature disappear. | ![Read-outs](img/look-readouts.jpg)<br>**Camera read-outs**: the scale bar with its span, and a spot meter reading the heat buffer. |

## Run the demo

```bash
python tools/serve.py
```

Then open http://localhost:8000/styles/thermal/index.html and press Play (or Space); drag the bar to scrub. The page
has to be served: ES modules and module workers don't run from `file://`, and `tools/serve.py` stops the browser
caching old scripts. Add `#t12.5` to the address for a still of 12.5 s with the page around it hidden (after
editing code, reload with a new query, `index.html?r=2#t12.5`, since changing only the `#` part doesn't reload).

```bash
python tools/still.py styles/thermal/index.html 2 6 12.5 0:37.5:2.5 --sheet   # stills and a contact sheet
python tools/render_mp4.py styles/thermal/index.html --fast                    # renders/thermal-720p.mp4
python tools/render_mp4.py styles/thermal/index.html                           # 1080p and 720p
```

It plays live, unevenly. Drawing a frame takes a few milliseconds; what's slow is the figures, whose poses are
meshed afresh twelve times a second (0.1-0.4 s of worker time each). So the player shows about 10 frames a second
while people are on screen, dropping frames to keep time with the audio, and the full 24 in the shots without them.
The MP4 is the smooth version, since the renderer waits for every pose: a `--fast` render draws the demo's 900 frames
in under a minute here. The page loads in about 6 s while eight workers mesh the set.

## How it works

`index.html` loads Archivo Narrow from Google Fonts, an import map for three.js 0.170 from jsDelivr, the song timing
(`../../examples/poem/lyrics_data.js`, which sets `window.SONG`) and then `film.js` as a module; everything else is
imported from there. Nothing is loaded at run time but the font and three.js: every model is meshed from code.

| File | Job |
|---|---|
| `film.js` | Builds the sets, draws the frame for song time t (figures, props, breath, wind, camera, gas, decals, render), the lyric band, the camera's read-outs, the player, and `window.__video`. |
| `thermal.js` | The renderer: palettes, the heat and visible materials (with the wind's bending in their vertex shader), gas, heat decals, the wind uniforms, and `ThermalRenderer` with its passes. |
| `kit.js` | Building a set: `Stage` (pieces, flat shapes, sky, emitters), `Actor` (a figure meshed per pose), `Walkers` (a crowd), `beamSet`, pose blending (`blend`, `keyed`), `setOff`. |
| `pieces.js` | `needOne()`: sends mesh requests to a pool of module workers and caches the geometries; `peekOne()`, `assign()`. |
| `tmesher.js` | The module worker: builds one model and meshes it. |
| `tmodels.js` | Every model as a signed-distance function with thermal "colours": the person, the dog, trees, grass, the house's neighbours, props. No three.js here, so the workers can import it. |
| `sdf.js` | Signed-distance modelling and the mesher (block-sparse surface nets), shared with the carved diorama style. |
| `common.js` | The demo's shared vocabulary: the air temperature, looks, people, the wind, time and pose helpers, cameras, handprints and footprints. |
| `sets.js` | The demo's one set, the farmyard (`setYard`). |
| `shots.js` | The demo's shot list and its choreography. |

`sdf.js` is the diorama style's modeller with one change for heat: the cavity factor (how closed in a surface is)
comes out separately instead of darkening the colour, because a heat camera sees hollows warmer, not darker. See
[the diorama's README](../diorama/README.md#modelling-and-meshing) for the primitives and operations. The per-pose
figure meshing (`Actor`, the pose cache in `pieces.js`) is the same idea the diorama uses for its moving pieces.

### Heat instead of colour

Every model op carries `th(T, e, alb)` instead of an RGB colour: `T` the temperature in C, `e` the emissivity, and
`alb` the brightness a visible camera would see, which is used for the edge overlay and nothing else. A 4th channel is
a material code that picks the fine texture the heat shader adds:

| code | material | | code | material |
|---|---|---|---|---|
| 0 | skin | | 5 | wood, paper |
| 1 | metal | | 6 | leather, rubber |
| 2 | hot source (no texture, and gusts don't cool it) | | 7 | stone, glass, ice, snow |
| 3 | cloth | | 8 | leaves and grass (the only parts of a meshed piece that flutter) |
| 4 | hair, fur | | | |

```js
const M = new Model();
M.add(P.cyl([0, 0.2, 0], 0.15, 0.2, 0.02), { col: th(55, 0.95, 0.8), mat: 5 });   // a mug of hot tea: 55 C, matt
M.sub(P.cyl([0, 0.36, 0], 0.12, 0.06, 0.01), { k: 0.01, col: th(68, 0.97, 0.1) }); // the tea, hotter still
return { model: M, bounds: autoBounds(M, 0.08) };
```

The heat shader writes an apparent temperature, not a colour: `ea * T + (1 - ea) * Tr`, where `ea` is the emissivity
reduced at grazing angles and `Tr` is what the surface reflects (`look.trefl`, the sky's cold outdoors, the room's
warmth indoors). So polished metal and glass show their surroundings, not themselves, and a body's outline is cooler
than its middle. The palette only happens at the end, in the final pass, which is why the lab can re-map any frame.

Some temperatures that read right for a cold night (air at 4 C; the demo's values):

| | C | | C |
|---|---|---|---|
| clear sky, horizon to overhead | -22 to -40 | a person's face (nose to cheek) | 29-34 |
| clouds | up to 22 above the clear sky | a parka, a knit hat | 13-15 |
| a roof losing heat to the sky | 1-2 | trousers, boots | 12-19 |
| grass, trees, a fence (at the air) | 3-4 | a dog's coat, its eyes and mouth | 16, 37 |
| house walls, lit windows | 7-8, 13-18 | breath as it leaves the mouth | 31 |
| a truck's hood, tyres, exhaust pipe | 34, 11, 70 | chimney top, smoke, sparks | 44, 58, 260 |

`humanTemps(p)` and `dogTemps(p)` work these out from a core temperature and the air: skin a little under the core,
clothes and hair a fraction of the way from the air up to the skin, cold hands and noses when `cold` is set. Set a
person's `room: true` and the whole figure reads as the air (a statue).

### The renderer

`new ThermalRenderer(canvas, 1920, 1080, [1280, 640], 120)` draws into the page's canvas: the picture fills 1920x960
and the bottom 120 px are the lyric band. `R.render(scene, camera, look, frameNumber)` runs:

1. **Heat**: every mesh with its heat material, plus the gas, into a half-float target at the sensor's size (1280x640
   by default; `look.sensor: [960, 480]` gives a softer, older-looking camera). Heat decals and the gust cooling are
   applied per pixel here.
2. **Blur**: the heat image at a quarter size, blurred, for detail enhancement.
3. **Visible**: brightness, normals and depth at full size, only for the edges.
4. **Final**: a slight optical softening; detail enhancement (`T + dde * (T - blurred)`, capped at `ddeMax`
   degrees); span to 0..1; sensor noise that changes every frame and a column pattern that doesn't; vignette; the
   palette; the edge overlay; bloom on anything hotter than the span; a flash and a fade; the overlay canvas.

`look` is a plain object; the demo keeps a few in `common.js` (`OUT`, `COLD`, `NEAR`) and each shot can adjust one:

| key | what it does |
|---|---|
| `palette`, `span: [cold, hot]` | the lookup (`ironbow`, `rainbow`, `amber`, `arctic`, `white` for white-hot, `black` for black-hot; add your own to `STOPS`) and the temperatures at its two ends |
| `trefl` | the temperature low-emissivity surfaces reflect (the sky, outdoors) |
| `msx`, `edge`, `line`, `edgeW` | edge overlay strength (0 turns it off), `'line'` (thin white lines, the default) or `'emboss'`, how white the lines are, their width in pixels |
| `dde`, `ddeMax` | detail enhancement and its cap in degrees |
| `noise`, `fpn`, `vig`, `gamma`, `texAmp` | sensor noise, column pattern, vignette, contrast curve, the materials' fine texture |
| `flash`, `fade` | a white flash (0..1) and a fade to black (1 = full picture) |
| `palette2`, `span2`, `wipe: [front, softness, slant, wobble]` | a change of palette sweeping across the picture: behind the front (0..1 across) the new palette and span |
| `osd`, `spot: [x, y, z]` | (film.js) the camera's read-outs: a scale bar with the span and a spot meter at a point in the scene, reading the temperature the sensor actually saw there |

Palettes are `STOPS[name]`, lists of `[position, '#rrggbb']`, turned into 256-entry lookups by `makeLUT`.

**Gas** (`Gas` in `thermal.js`) is deterministic: each particle is born at `i / rate` and its position, temperature
and opacity are worked out from its age, so any frame can be drawn on its own. An emitter is a plain object:
`{p` or `path(t), dir, rate, life, T, amb, size: [at birth, at death], spread, speed, rise, drift: [x, y, z] (ft/s),
alpha, cool, puff (breaths a second), flutter: [amp, rate], hard (hard-edged flecks: blown leaves, sparks), t0, t1,
seed, off}`. Particles fade to the air's temperature (`amb`) as they age, which is what makes breath and smoke look
right. `path(t)` returns where the emitter was when a particle was born, so a plume from a walking person trails
behind them rather than following their head.

**Heat decals** (`setDecals(list)`, at most 48 a frame): `{p: [x, y, z], r, T, k}` sets any surface within `r` of
`p` toward `T` by `k`. They're spheres in world space, so a mark on something that moves must be moved with it (the
demo works out the gate's and the door's handprints from their hinges every frame). `handprint(centre, up, right, T)`
and `prints(t, pos, t0, t1, step, dT, fade, options)` in `common.js` build a hand and a trail of footprints.

### The wind

The whole set shares one wind field: a steady breeze along `WIND_DIR` plus up to four gust fronts that travel
downwind at 36 ft/s, each rising sharply at its front and dying away behind it. `setWind(state)` (called every frame
with the shot's `wind(t)`) hands it to the shaders, and `windAt(x, z, t)` in `common.js` is the same field in
JavaScript. Everything reads it:

- **Bending**, in the vertex shader. A piece placed with `sway: {k, len, pivot, mode}` bends downwind by `k` feet per
  unit of wind at the far end of its `len`, growing with the square of the distance from the pivot: `mode` 0 bends
  upward (trees, grass), `'hang'` hangs down from the pivot (washing), `'x'` reaches out along +x (a branch).
  `flutter: [amount, fineness]` adds a shake of its own (fineness is 1 / the size of the parts that move together).
  On a meshed piece only material 8 (leaves, grass) flutters fully.
- **Cooling**, in the heat shader: a band just behind each gust front strips warmth from anything warmer than the
  air (`cool`, `coolMax` in the wind state), so lit windows dim one after another as a gust crosses a house.
- **Gas**: shots set emitters' `drift` from `driftAt(x, z, t)`, so smoke lies down in a gust and breath streams off.
- **People and animals**: the shots turn the wind into a scarf's and a ponytail's direction (`windLocal`), a lean,
  a dog's ears.
- **The sky**: clouds (warmer than the clear sky between them) drift by the wind's `scroll`.

`GUSTS` in `common.js` is the demo's list: `{tc, w, str}` puts a front across s = 0 at time `tc`; `tcAt(t, x, z)`
works out the `tc` that brings a gust to a place at a given time, which is how the gusts land on words.

### Figures

`humanModel` (in `tmodels.js`, meshed as type `'human'`) is one parametric person: build (`H` height in feet, `bw`
breadth, `mus`, `gut`, `fem`, `child`), clothing (`top`: `'tshirt'`, `'shirt'`, `'jacket'`, `'parka'`, `'coat'` or
`'bare'`; `drape`, `legsWear`, `feetWear`, `hair`, `beard`, `hat: 'knit'`, `scarf`), the wind (`hairTail`,
`scarfTail`, `scarfWave`, `hem`) and pose: `legs` as `'stand'` with a `stride`, one of several seated and crouching
set-ups, or `'free'` with `pelvisY` and `footL`/`footR` targets so any two poses blend; `lean`, `twist`, `side`, the
head's `headYaw`, `headPitch`, `headRoll`; arms as angles `{fwd, out, bend}` or IK targets `{t: [x, y, z], pole}`;
things held (`holdL`/`holdR` of `'plate'`, `'jug'`, `'paper'`, `'bucket'`, `'bag'`; `cup`; `bundle`). It faces +z
with its feet at y = 0; `mouthAt(p)` says where its mouth is, for breath.

`dogModel` (`'dog'`) is a dog or a wolf: `pose` `'stand'`, `'pant'`, `'run'` (with `phase` 0-3), `'walk'` (with a
continuous `phase`), `'crouch'`, `'lie'`, `'sniff'`; `size`, `headYaw`, `headPitch`, `ears` (0 up, 1 flat), `tail`.

An `Actor` (`kit.js`) is a figure on stage. Each frame `film.js` calls `actor.set(params, h)` with that frame's pose:
if the pose has been meshed before it shows at once, otherwise it's meshed in a worker first (and `set` returns a
Promise, which `step()` hands back to the render tool to wait for). `h` is the mesh's cell size in feet, the main cost
knob: 0.022-0.028 for a close shot, 0.032-0.05 for a wide one. While a frame shows, `film.js` asks the workers for the
next half-second of poses (`prefetch`). The cache (`MAX` in `pieces.js`) keeps 72 meshes nobody is showing and drops
the oldest. Poses blend with `keyed(t, [[t0, pose0], [t1, pose1], ...])` and `blend(a, b, u)`; `walkP(t, rate, amp)`
in `common.js` is a walk.

### Sets

A set is a function that builds a `Stage` and returns it. From the demo's yard, in brief:

```js
export function setYard() {
  const s = new Stage(), amb = AMB; s.amb = amb; s.em = {};
  s.sky(amb - 26, 18, { amp: 22, lo: -0.12, hi: 0.42, scale: 1.4 });                  // horizon, zenith drop, clouds
  s.box([7000, 0.4, 7000], { p: [0, -0.2, 0] }, { T: amb - 1.2, alb: 0.3, mat: 8, noise: 0.9, noiseScale: 0.22 });
  s.box([3, 11, 3], { p: [11, 23.5, -23] }, { T: amb + 9, alb: 0.4, mat: 7, grad: [2.4, 18, 0.6] }, 'chimney');
  s.em.smoke = s.emit({ p: [11, 29.6, -23], dir: [0, 1, 0], rate: 26, life: 5.5, T: 58, amb, size: [1.3, 10], alpha: 0.13, cool: 1.6, seed: 11 });
  for (const [x, z, h, seed] of TREES)                                                  // a tree that bows and shakes
    s.piece('tree', { T: amb, h, seed }, 0.09, { p: [x, 0, z], sway: { k: 0.085 * h, len: h }, flutter: [0.2, 0.7] });
  new Actor(s, 'human', 0.024, {}, 'woman');                                            // posed by the shots
  return s;
}
```

- `s.piece(type, params, h, tf, name)` meshes a model from `tmodels.js` in a worker; `tf` places it (`p`, `r` or
  `ry`, `s`) and gives it a `sway` and `flutter`.
- `s.box`, `s.plane`, `s.cyl`, `s.sphere` and `s.flat(geometry, ...)` are plain three.js shapes with a flat thermal
  material: `{T, e, alb, mat, noise, noiseScale, grad: [C per ft of height, from height, lumpiness], stripe: [axis,
  spacing, dT]}` (the stripes are boards and siding). `s.plane(w, h, tf, o, name, [xSegs, ySegs])` subdivides a sheet
  so it can bend. The demo's house is built this way: crisp edges and cheap.
- `s.sign(w, h, canvas, ...)` is a board whose painted words show in the visible pass only: paint and bare board
  are the same temperature, so a heat camera can read a sign only through its edges.
- `s.sky(T, zenith, clouds)`, `s.void(T)` (the dark beyond an indoor set) and `s.emit(emitter)`.
- Named things (`s.named`) are what shots move: the demo's truck, gate and door, and props called `prop_*`, which
  start hidden and show only where a shot's `props(t)` puts them.

`film.js` builds every set a shot names, from the functions called `set<Name>` that `sets.js` exports
(`setYard` is the set `'yard'`). `?sets=yard` builds only those.

### Shots and the camera

A shot is a plain object covering a stretch of song time. From the demo (the prints seen from above):

```js
shot({ t0: 7.5, t1: 11.25, look: () => ({ ...OUT, span: [-10, 30] }),
  cam: (t) => ({ pos: [lerp(-8.4, -10, sm(7.5, 11.25, t)), 17, lerp(20.2, 19.4, sm(7.5, 11.25, t))],
                 look: [lerp(-4.6, -6.2, sm(7.5, 11.25, t)), 0, 10.4], fov: 42 }),
  cast: (t) => detail(0.032, { woman: W(t), child: C(t), dog: D(t) }),
  breath: (t) => breathOf({ w: W(t), c: C(t), d: D(t) }, t), fx, decals: marks,
});
```

- `look`: an object or a function of t.
- `cam(t)`: `{pos, look, fov, roll}` in feet and degrees. `aim(target, dir, dist, fov)` in `common.js` places a
  camera at a distance and direction from what it looks at.
- `cast(t)`: `{actorName: {p, ry, params, h, flare} | null}`. Everything else about a figure is in `params`. `flare`
  raises the whole figure's temperature (a heat flare); `setOff(mesh, degrees)` does the same for any piece.
- `props(t)`: `{prop_name: {p, rx, ry, rz}}` for the props this shot shows.
- `fx(t, stage)`: anything else, after the cast: the demo moves the truck, the gate and the door here, and steers
  the emitters (smoke drift, exhaust on and off, leaves torn off in a gust, chimney flares on the beats).
- `breath(t)`: a list of breaths `{p, dir, drift, T, puff, alpha}`, one per breathing figure (keep each figure's
  place in the list with a null when it isn't there). Past puffs ask `breath(t)` again for when they were breathed.
- `decals(t)`: the heat marks for this frame. `wind(t)`: the wind state (the demo gives every shot `windState`).

`film.js` picks the shot whose `t0` is the last at or before t (so shots must cover the song), steps t down to a
twelfth of a second, and cuts. Everything, the camera included, moves on twos; only the sensor noise changes every
frame. There are no dissolves: a heat camera cuts. The demo's stanza change is a palette wipe instead (`wipe` above),
with a short flash, and the door opening pumps the camera's automatic gain (the span jumps up as the hot hall comes
into view, then settles).

### The lyric band

The bottom 120 px. During the intro it shows `SONG.title` in italics over `SONG.credit` in spaced capitals; then each
line of `SONG.lines` fades in 0.2 s before its start and out as the next begins, in Archivo Narrow, drawn on a canvas
(`R.bandCanvas`) that the renderer lays under the picture. Change `drawBand` in `film.js` for another layout; a
`caption` in the look replaces the line (the lab labels its looks that way).

### Determinism and caching

Every frame is a function of its time: poses, the wind, the camera and the gas are all computed from t, the noise is
keyed to the frame number, and nothing calls `Math.random()`. So `step(t)` and `renderAt(t)` are the same function,
any slice renders exactly, and a still at 12.5 s matches frame 300 of the MP4. The only state is the mesh cache, which
changes how long a frame takes, never what it shows. `step(t)` returns a Promise while a pose is being meshed (the
tools wait for it) and nothing once everything is cached. `window.__video` also has `frame(t, lookOverrides)` (used by
the lab), `shots`, `stages` and `R`, the renderer.

## Make your own video in this style

1. **Copy the folder**: `cp -r styles/thermal projects/my-song`, and put your mp3 in it as `song.mp3` (see
   [docs/your-own-video.md](../../docs/your-own-video.md) for the whole process). Paths work the same from
   `projects/my-song/`, and the tools serve it at http://localhost:8000/projects/my-song/index.html.
2. **Your song**: make its `lyrics_data.js` with the timing pipeline in [docs/timing.md](../../docs/timing.md) (it
   ends with `tools/audio/to_js.py`, which writes the same `window.SONG` shape), then point the page at it: in
   `index.html`, change `../../examples/poem/lyrics_data.js` to `lyrics_data.js`. `SONG.audio` is the mp3's path
   relative to the page. Change the page's title and heading. The lab page loads the timing from
   `../../../examples/poem/lyrics_data.js`; point it at `../lyrics_data.js` too if you use it.
3. **Keep** `film.js`, `thermal.js`, `kit.js`, `pieces.js`, `tmesher.js`, `tmodels.js` and `sdf.js`. **Replace**
   `sets.js` with your places, `shots.js` with your shot list, and in `common.js` the air temperature, looks, people
   and `GUSTS` (keep its helpers). The demo's gust times fall back to fixed times if your song has fewer lines, so the
   demo keeps playing under your lyrics while you work.
4. **Decide the temperatures first.** Pick the air, then everything relative to it (the table above), and a span for
   each kind of shot: the span, not the palette, decides what reads. Things within a degree or two of their
   background vanish unless the edge overlay outlines them.
5. **Add a set**: export `function setMine()` from `sets.js` returning a `Stage`, and name `'mine'` in your shots.
   `?sets=mine` builds only that set while you work. Name the things your shots move.
6. **Add a model**: a function in `tmodels.js` returning `{model, bounds}` with thermal colours, added to `MODELS`.
   Try it in a set with `s.piece('mine', {...}, 0.04, {p: [...]})` and look at a still; halve `h` only if you
   must (mesh time grows with 1/h²).
7. **Add a shot**: an object like the one above. Cut on line starts (`SONG.lines[i].t0`), put hits on beats. Give
   the figures an `h` that suits their size in frame. Make sure something moves: breath, smoke, a sway.
8. **Time a move to a word or beat**: `word(i, k, fallback)` in `common.js` is when word k of line i is sung (both
   counted from 0) and `beat(n)` is beat n. The demo opens its door on "you": `const YOU = word(5, 1, 23.125)` and
   `doorA = (t) => 1.35 * sm(YOU - 0.18, YOU + 0.32, t)`. To send a gust to a place on a word, add
   `{ tc: tcAt(word(i, k, fallback), x, z), w: 34, str: 1 }` to `GUSTS`.
9. **Useful knobs**: the looks' `span` and `palette`; `trefl`; `dde`; the edge overlay's `msx` and `line`; `GUSTS`
   and `baseAt` (the wind); each piece's `sway` and `flutter`; `cool` in `windState`; a figure's `h`; `sensor`.

## Lab

Open http://localhost:8000/styles/thermal/lab/index.html (with `tools/serve.py` running) and pick a scene and a look;
`?scene=gate&style=amber` opens on a pair. The lab loads the demo's own `film.js`, meshes the figures for its three
moments (the yard at 2.6 s, the window at 13.4 s, the gate at 17.3 s) once, and then draws any moment in any look
immediately with `window.__video.frame(t, lookOverrides)`.

```bash
python tools/lab_stills.py styles/thermal/lab/index.html --all --sheet    # every scene in every look
python tools/lab_stills.py styles/thermal/lab/index.html gate:readouts    # one
```

What each look changes (see `LOOKS` in `lab/lab.js`):

- **Ironbow**, **white-hot**, **black-hot**, **rainbow**, **amber**: only `palette`; the span is the shot's own.
- **Arctic**: `palette: 'arctic'` with a lower span, so that walls and trees sit in the blues and only lit windows,
  engines and people reach the gold end.
- **Embossed edges**: `edge: 'emboss'`, the heavier overlay many cameras use: edges from the visible image's
  brightness, depth and normals, lightening dark areas and darkening bright ones, 1.25 px wide.
- **No edge overlay**: `msx: 0`, heat alone. Compare it with ironbow to see how much of the picture's legibility is
  the overlay: the fence, the gate and the grass are at the air's temperature and nearly vanish.
- **Camera read-outs**: `osd: true` and a `spot` point. `film.js` renders once, reads the heat buffer back at the
  spot (`R.readT(u, v)`), draws a scale bar and a crosshair with the reading on the overlay canvas, and renders again.

## Performance

On an Apple M4 shared with other sessions' renders (the tools run headless Chrome with the GPU on):

- **Load**: about 6 s: 18 set meshes in eight workers, most of the time the five broadleaf trees (`h` 0.09). The set
  is 99 distinct geometries and about 1.7 million vertices; the sixteen spruces share three meshes.
- **Frames**: drawing takes 1-16 ms when every pose is cached. Meshing takes, in worker time on an idle machine, 0.37 s
  for a person at `h` 0.024 (41,000 vertices), 0.2 s at 0.034 (20,000) and 0.13 s at 0.045 (12,000), and 0.18 s for
  the dog at 0.024; about twice that when other renders share the machine. Stepped in order, stretches with people
  cost 70-140 ms a frame and the rest about 6 ms. A full `--fast` render drew its 900 frames in 51 s (57 ms a frame,
  including reading the canvas back); the whole command, with loading and encoding, took from one to six minutes here,
  depending on what else the machine was doing.
- **Memory**: the JS heap is about 210 MB, most of it cached pose meshes; lower `MAX` in `pieces.js` (72) if memory
  is tight.
- **What makes it slow**: small `h` on figures (vertices grow with 1/h²), several figures at once, and poses that
  never repeat. Wide shots don't need fine figures: the demo meshes people at `h` 0.045 in its widest shot. A figure
  that holds still costs nothing after its first frame.
- **A slice**: `python tools/render_mp4.py styles/thermal/index.html --start 15 --end 19 --fast`. Every frame depends
  only on its time, so a slice matches the full render and can be spliced into it with `tools/splice.py`.

## Lessons and gotchas

- **Traces are the style's best tool.** Breath, smoke, exhaust, footprints, handprints, the warm patch where someone
  sat: a heat camera shows what just happened, and that's what tells a story in it. Seen from above, breath trailing
  downwind was the clearest picture of the wind in the demo.
- **Anything at the air's temperature disappears.** A fence, a gate, grass, a sign: without the edge overlay they're
  gone. Keep the overlay on, as thin white lines at half strength (0.8 px); the heavier embossed overlay muddies warm
  bodies.
- **Faces read in profile and at a distance, not straight on.** Close up and face-on a warm face is a smooth
  mannequin; keep faces to profiles and medium shots, and let hats, hair and breath carry them.
- **Glass is opaque to a heat camera.** A lit window shows its own warmth, never the room behind it, and a glazed door
  hides the face behind it; a barred opening doesn't.
- **Two warm bodies touching merge into one blob**, and so do figures of the same temperature overlapping in depth.
  Keep a layer of cooler clothing, or a gap, between them.
- **Text is invisible in heat.** Paint is the same temperature as the board; `s.sign()` puts it in the visible pass,
  where only the overlay can show it.
- **The span decides what reads, more than the palette.** A palette wipe needs each palette's own span (`span2`): a
  shared span flashed the incoming palette to its hot end. Cool palettes such as arctic need a lower span so warm
  things reach their warm end.
- **Detail enhancement lies about thin cool things against a very cold sky**: branches and blown leaves came out with
  hot rims. The enhancement is capped (`ddeMax`, 6 degrees).
- **Edges from depth must ignore slopes.** First differences of depth fire on distant ground seen at a grazing angle
  and drew a grey band along the horizon; the second difference of inverse depth is flat on any plane and jumps only
  at outlines.
- **Material codes must not blend across a seam.** Blended, skin beside cloth passed through 2 (a hot source) and
  leaves beside bark missed 8. The modeller takes the winning op's code, and the shaders read it as a flat varying.
- **Keep the sky cold below the horizon, and the ground big.** A sky sphere whose temperature follows height warms
  below the horizon, and it shows through past the edge of a small ground plane.
- **Flutter only small things, at their own scale.** A noise shake fine enough for leaves melted whole trees; give each
  piece a fineness, and let only leaves and grass shake fully on a meshed piece.
- **Washing on a line running downwind** streams out like flags, face-on to a camera beside it; on a line across the
  wind it billows toward or away from the camera and reads as a shapeless blanket.
- **A gust's cooling is limited by physics**: it can only take away a surface's warmth above the air, so it barely
  shows on walls a few degrees above it. It shows on lit windows and on people; let the windows dim one by one.
- **Hot things dominate the frame.** A truck's hood right after a drive is the brightest thing in any shot it's in;
  park it out of the shots that are about something else, or keep it small.
- **Handprints are small**: a palm is a few pixels beyond 15 ft. Bring the mark toward the camera (the demo's gate
  swings toward it) or go close.
- **Past breath must leave from where the mouth was.** Using the current mouth made a walking person's plume follow
  their head like a rigid tail; `breath(t)` is asked again for each puff's own time.
- **Figures cost their mesh, not their drawing.** Give every shot a figure detail to suit its framing, and don't
  animate a far-off figure every frame when nobody can see it (the demo's dog in the truck turns its head every
  two beats).
- **A heat camera cuts; it doesn't dissolve.** For a change of section, change the palette (the demo sweeps it across
  with the wind), pump the gain or flash briefly; the last two are what a real camera does.
- **Move on twos.** Twelve drawings a second reads as a real, slightly cheap camera rather than a render, and the
  sensor noise, which still changes every frame, keeps a held shot alive.
- **Don't start or end on pure black.** The demo fades up from 20% and fades down to about 30%.
- **`step()` may return a Promise**, and the render tools wait for it; a page that meshes on demand must still never
  draw a frame before its poses are ready.



===== 完整公共规范：CLAUDE.md =====

# Instructions for Claude

This repository makes music videos in code: each style in `styles/` is an engine that draws every frame on an HTML
canvas (or WebGL / three.js) in a hand-made-looking medium, timed to a song, and `tools/` renders them to MP4. Read
`README.md` for the map, then the doc for whatever you're doing.

## When someone wants a video for their song

Follow [docs/workflow.md](docs/workflow.md). It's a conversation, not a build order to rush through:

1. **Get the inputs:** the song (mp3), the lyric sheet as sung, and ask whether they have stems and MIDI (Suno and
   stem splitters provide them) and any reference images.
2. **Ask the concept questions before building anything:** who is singing, who "you" is, whose voice the chorus is,
   what the key images (especially the ending) mean, how much the video may show, what stays out. Don't guess at
   these; an open question is better than a confident wrong answer. If the song belongs to a larger world, read
   whatever they give you about it, and keep a list of every detail the video invents, flagged as unconfirmed.
3. **Measure the song** ([docs/timing.md](docs/timing.md)): tempo, sections, stops and hits, and every word's time.
   Time to the audio, not to the lyric sheet's markings.
4. **Pitch three looks and recommend one:** the medium and why it suits this song, the organizing object, a small
   visual grammar and an arc, a section-by-section plan keyed to timestamps, and the open questions. The styles in
   `styles/` are the starting points (each README says what it's good at); a new medium is fine too
   ([docs/engine-patterns.md](docs/engine-patterns.md)).
5. **Style lab:** the same three or four moments drawn in each candidate look. Show the stills.
6. **Checkpoint:** build one section (20-90 s), render it (`--fast`), send it, get notes.
7. **Build the rest** section by section, then render the final MP4s. The MP4 is what gets shared.

Build a project in `projects/<song-slug>/`, copied from a style folder ([docs/your-own-video.md](docs/your-own-video.md)).
Don't change `styles/` for one person's video. Keep notes in `projects/<song-slug>/PLAN.md` as you go: their answers
and rulings, the measured sections and sync points, the shot list, the invented details, and their feedback on each
round. A later session should be able to pick up from that file alone.

## Working practices

- **Look at what you render.** Make stills and contact sheets (`tools/still.py ... --sheet`) and open the images.
  Check every frame on the sheet: edges, blank frames, the camera inside things, covered text, long freezes.
- **Read the console output** the tools print. A single bad canvas gradient value blanks a frame.
- **Preview slices with `--fast`**; render the full 1080p only at the end. Styles that carry state between frames
  must be rendered in order (the tools do this).
- **Keep it deterministic:** seeded randomness keyed to the frame, never `Math.random()` per frame.
- **Follow the page contract** in [docs/rendering.md](docs/rendering.md) (`window.__video`, `window.SONG`,
  `<canvas id="film">`, `#t<seconds>` stills) so the tools work.
- Apply the lessons in [docs/workflow.md](docs/workflow.md#what-the-notes-taught-true-for-every-style): busy
  enough, no long freezes, obvious changes, varied choruses, whole figures rather than close-up hands.
- The person's audio is git-ignored. If their lyrics or story are private, keep the project out of any public
  remote (add it to `.git/info/exclude`, or keep it outside the repo and pass `--root` to the tools).

## Setup

```bash
python3 -m venv .venv && .venv/bin/pip install -r requirements.txt -r requirements-audio.txt
```

Google Chrome must be installed (or `.venv/bin/python -m playwright install chromium`). To preview in the desktop
app's browser pane, create `.claude/launch.json` running `python3 tools/serve.py 8000` on port 8000 (git-ignored).
Use the server, never `file://`: module pages don't load from files and a plain server caches stale scripts.



===== 完整公共规范：docs/workflow.md =====

# How a video gets made

These videos were made in conversation: a person with a song and a clear sense of what it's about, and Claude
writing and rendering the code. The process below is what worked over a dozen songs. It suits working with Claude
Code (see [CLAUDE.md](../CLAUDE.md), which tells Claude to follow it), and it works just as well by hand.

The short version: **decide what the song is about, measure it, pitch three looks, test the look on a few scenes,
build one section, get notes, then build the rest.** Each step is cheap next to the one after it, so mistakes get
caught while they're still cheap.

## 1. Gather the inputs

- **The song** as an mp3 (or anything ffmpeg reads).
- **The lyric sheet** as plain text, one sung line per line, with `#section` markers (see
  [examples/poem/lyrics.txt](../examples/poem/lyrics.txt)). Write it the way it's sung: if the singer repeats a line
  that isn't on the sheet, add it.
- **Stems, if you have them.** An isolated vocal stem makes transcription far cleaner. Suno exports stems as audio
  and as MIDI per instrument; the MIDI's tempo map gives an exact beat grid, and the vocal MIDI gives note onsets to
  snap words to (see [timing.md](timing.md)).
- **Reference images, if any.** Mood boards and concept art are useful for content (what's in the world, what
  people wear, what the place looks like) even when the style will be different.

## 2. Decide what the song is about

Before any pictures, answer the questions that decide the concept. A video can't be good if these are guesses.

- **Who is singing,** and to whom? Who is "you"? It's often not who it seems, and it can change between verses.
- **Whose voice is the chorus?** The singer's, an imagined audience's, a crowd's, a custom's?
- **What do the key images mean?** Especially the closing one.
- **How much may the video show?** If the song belongs to a larger story, what would be a spoiler?
- **What stays out?** Eras, events, people, kinds of imagery.

If the song is part of a larger world (a novel, a game, a band's mythology), read up on it first, and **keep a list
of every detail the video invents**: a place's layout, what a prop says, who stands where. Show that list to
whoever owns the world, and treat nothing on it as settled until they say so.

## 3. Measure the song

Time the video to what the audio does, not to what the lyric sheet says. (AI song generators in particular ignore
markings like "quiet" or "almost unaccompanied".) With the tools in [timing.md](timing.md):

- tempo, and whether it changes;
- the sections and their loudness: which chorus is the big one, where it drops to almost nothing;
- **the stops and hits.** Musical stops, dropouts and the hit that ends a bridge make the best sync points: the
  place to freeze, cut, switch a light off, or change the whole picture;
- every word's time.

## 4. Pitch three looks

Offer three directions and recommend one. For each:

- **the medium** (paper cut, embroidery, marbled paper...) and why it suits this song. The strongest choices mean
  something: marbled paint for a song about water, where nothing stays put; a lantern lecture for a song sung by
  someone lecturing; a desk of files and stamps for a song about a record that doesn't add up;
- **the organizing object:** the one thing the whole video is, such as a desk under a lamp, a hanging read along
  its length, a printed sheet, a painted wagon's panels, a board of pasted-up photographs;
- **a small visual grammar:** a few rules that give the images meaning (stamps are the audience's verdicts, frost
  is the stillness, the camera's date flickers between years), and an **arc** over the song (clean to decayed,
  night to morning, empty to crowded);
- a **section-by-section plan** keyed to timestamps, giving each section one main image;
- the questions still open.

The [styles/](../styles) folder has eighteen engines to start from, and each one's README says what it's good at.
A new song can also want a new medium: the engines share their patterns ([engine-patterns.md](engine-patterns.md)),
so a new one is less work than it sounds.

## 5. Style lab

Draw the same three or four key moments in each candidate look, side by side, as stills (and a few seconds of motion
if the look depends on how it moves). Comparing like with like makes the choice easy, and it shows the problems
early: people who look like mannequins, faces that look ill, a palette that turns cute. Every family here with more
than one look has a lab page (`styles/<family>/lab/`) built this way.

Expect the first choice to be refined: "this look, but with the other one's colours", or "this, for the scenes in the
other world only". Mixing is fine.

## 6. Checkpoint

Build a real section before the whole song: 20-30 seconds of the section that carries the concept, or the first
90 seconds. Render it as an MP4 and get notes on the look, the pace, the figures, the text. This is where most of
the useful notes arrive, and they're cheap to act on now.

## 7. Build the whole song

Section by section. After each, render stills across it (`tools/still.py ... a:b:2 --sheet`) and look at every one:
frame edges, blank frames, things the camera cuts through, text that's unreadable or covered. Fix, then move on.
When it's all there, render the MP4, then scan it at one frame every two seconds.

## 8. Notes, and fixing a stretch

Notes on a full video are usually local: one stretch feels empty, one chorus repeats the last, a transition jerks.
Re-render only that slice and splice it in ([rendering.md](rendering.md#fixing-one-stretch)).

## 9. Deliver an MP4

Share the MP4, not the web page. A browser player's pause and scrub can feel unreliable, and people give up on it.
`tools/render_mp4.py` writes a 1080p file and a smaller 720p one for sending.

## 10. Revising a finished video

A second or third pass (new conventions, a list of fixes, a stretch that needs more going on) works best as: a short
written plan of every change; then before/after sheets, stills from the old render and the new build at the same song
times side by side; then the full render. The sheets let the notes land on exactly what changed. When picking stills
for review, catch short effects at their peak: a flash or a bolt that lasts half a second is easy to miss.

## What the notes taught (true for every style)

- **Busy enough.** Something new on nearly every beat, or at least every line. A stretch with nothing happening
  reads as a mistake, not a rest. When a stretch feels empty, fill it with callbacks (translucent overlays of earlier
  scenes) and background life (children, animals, people passing) rather than restaging it.
- **No long freezes.** A four-second still reads as the player stalling. Keep holds to a beat or two, or keep
  something drifting: a slow camera move, breathing light, smoke.
- **Make small changes obvious.** A face swapping for another face, a detail changing on a paper: if it matters,
  make it big and push the camera in on it. Subtle changes go unseen.
- **Too clean reads as dead.** A video that stays tidy all the way through can feel flat; give it an arc.
- **Vary the repeats.** The second chorus shouldn't replay the first. New scenes, with brief flashes back to the
  first chorus's pictures on key words, keep the echo without the repetition. A motif that does something different
  each chorus (ribbons that knot, then plait, then slip) works well.
- **Whole figures beat close-up hands.** Big silhouettes of hands and arms read as clubs, poles or chess pieces. A
  whole figure, even small and mostly still, carries a beat better.
- **Faces:** realistic halftone or heavy shading can make people look ill. Stylized faces (dot eyes, lowered lids
  when looking down) for close figures and blank faces for crowds read better.
- **What makes a look cute** (sometimes wanted, often not): flat candy fills, rounded sack-shaped figures with blob
  heads, even lighting, bobbing walks. For solemn songs, use weight, texture, uneven light and stillness instead.
- **Real texts make good props.** A period document, a real letter or hymn, an actual map give a scene weight even if nobody
  can read them.
- **Impossible places need ordinary things in them.** Floating or folded land only reads as land when it carries
  trees, lit windows, snow on its ground side, smoke going the "wrong" way.
- **Decide about text in the picture.** A lyric band under the picture is one choice; no readable text at all
  (squiggles for writing) is another; either way, be consistent. Captions that only repeat the lyric are redundant.
- **Fake text is worse than no text.** A card of invented glyphs that flickers reads as a screen of foreign writing.
  Use pictograms, squiggles, or nothing. Likewise on-screen read-outs (temperatures, timecodes) in a "technical"
  medium: keep them only if they mean something.
- **Show the medium working.** When a look risks feeling static (a photograph, a print, a drawing), let the viewer
  watch it being made: a plate exposing, inks printing in on the beats, stitches sewn in, a slide pushed into the
  lantern. It answers "static and unclear" without changing the look.
- **Vary what leads a scene.** In a medium with a life of its own (liquid light, marbling, sand), let some scenes be
  led by the pictures and some by the medium, rather than the same mix throughout.
- **Props must sit in hands.** A rope, a ring, a cloth or a cup that floats near a hand reads as broken. Anchor held
  things to the rig's hand points and check every one in stills.
- **Arms that move naturally:** pose them by where the hand and elbow should be, blend joint angles rather than
  positions, let the forearm trail the upper arm, and add breathing and small weight shifts. Arms that slide
  straight between poses look like a puppet's.
- **Bodies carry identity.** In silhouette, heat or other outline-first looks the outline is all a viewer gets: if
  someone is heavily built, or small and round, the shape must show it. Keep sizes consistent (an animal is as big in
  every shot).
- **Shapes read as other shapes.** A figure lying flat reads as a collapsed body (have them sit or doze upright unless
  a death is meant); a pyramid of sacks in a lit doorway reads as a hooded head; a fan of hair strands reads as a
  feathered headdress. Look at every silhouette as a stranger would.



===== 完整公共规范：docs/timing.md =====

# Timing a song

Everything in a video hangs off the song's clock: the lyric band lights each word as it's sung, pieces land on
beats, scenes change on line starts, the lamp goes out in a dropout. This page is how to get those times. The tools
are in [tools/audio/](../tools/audio); each prints its own help with `--help`.

Setup (once): `pip install -r requirements-audio.txt` (librosa, scipy, faster-whisper, mido). The Whisper model
downloads the first time it's used.

## The pipeline

```bash
# 1. the shape of the song: tempo, loudness, sections
python tools/audio/analyze.py song.mp3

# 2. words with timestamps, from the vocal stem if you have one
python tools/audio/transcribe.py vocals.mp3 --lyrics lyrics.txt --out whisper.json

# 3. your lyric sheet matched to Whisper's words
python tools/audio/align.py lyrics.txt whisper.json --out lines.json

# 4. snap each word to where the voice starts it (vocal MIDI and/or vocal audio)
python tools/audio/snap.py lines.json --midi vocals.mid --audio vocals.mp3 --out snapped.json

# 5. the page's data file
python tools/audio/to_js.py snapped.json --out projects/my-song/lyrics_data.js --title "My Song" \
    --audio song.mp3 --audio-file projects/my-song/song.mp3 --bpm 96 --beats-per-bar 4
```

Then open the video with the lyrics showing and listen through. Fix what's off by editing `lyrics_data.js`
directly: it's plain data.

## Step by step

### 1. The shape of the song

`analyze.py` prints the global tempo and the local tempo every 20 s, a table of loudness, brightness and rhythmic
busyness every few seconds, and guesses at section boundaries. Read it next to the lyric sheet. You're looking for:

- which sections are loud and which drop out: the video's big and quiet moments should follow them;
- tempo changes (a slow intro, a half-time bridge);
- **stops and hits.** `onsets.py song.mp3 --from 140 --to 155` zooms in on a stretch: the strongest onsets, the
  beats, and the loudness every quarter second, so a dropout shows as a run of low numbers. These are the best
  sync points a song offers: the place for everything to freeze, for a cut, for a light to go off.

`sections.py song.mp3 --lines lines.json` compares the sections' loudness, drums and tonal energy once you know
where they are.

### 2. Transcribe

`transcribe.py` runs faster-whisper with word timestamps. Give it the **vocal stem** if there is one; sung vocals
over a full mix transcribe much worse. The `small` model is usually enough and takes about a minute. `--lyrics`
passes the start of your lyric sheet as a prompt, so names and odd words come out spelled your way. `medium` can
rescue mumbled lines, but over a long song it can drift further than `small`.

Expect Whisper's times to run **early**, typically a few tenths of a second and sometimes by more than a second,
and to hear some words wrong, especially names and unusual words. Step 3 doesn't care about wrong words; steps 4 and
the listen-through fix the times.

### 3. Align

`align.py` lines your sheet up against Whisper's words (a sequence match, so misheard or missing words don't break
it; unmatched words get times interpolated from their neighbours). It prints each line with a match count like
`m7/9`. Low counts are where to listen first. Watch for:

- **numbers:** Whisper writes "1974" as one token for three sung words. The script spells out years and small
  numbers before matching, but check them;
- **hyphenated words** and contractions;
- **a misheard last line** ("Let it go" for "Letting go"): the end of a song, over a fade, is where Whisper guesses;
- **repeats and ad-libs** the singer added: put them on the sheet as sung, or they'll be squeezed between
  neighbours.

### 4. Snap to the voice

`snap.py` moves each word to the nearest sung-note onset within 0.32 s: note onsets from the **vocal MIDI** first
(if you have it), then onsets detected in the **vocal audio**. It first reports the median offset between the words
and the onsets; if Whisper ran early across the whole song, pass that back as `--shift` so everything moves before
snapping.

After snapping, some things still need a human ear:

- **line starts that land in silence** or on the tail of the previous word: move them to where the voice comes in;
- **choruses and held notes:** a melisma or a long held word confuses onsets;
- **MIDI quantization:** Suno's MIDI is quantized to sixteenth notes and can sit about 0.3 s off the voice.

For those, `onsets.py vocals.mp3 --from 25 --to 27 --pitch` prints the sung pitch and loudness every 50 ms: the
word starts where the pitch appears and the loudness jumps.

### 5. Write the page data

`to_js.py` writes `lyrics_data.js`, which sets `window.SONG`:

```js
window.SONG = {
  title: "My Song", credit: "", audio: "song.mp3", duration: 212.4,
  bpm: 96, beatsPerBar: 4, firstBeat: 0.35,
  sections: [["verse1", 12.3, 41.0], ...],
  beats: [0.35, 0.975, ...],            // only with --beats: exact beat times
  lines: [{section: "verse1", text: "Who has seen the wind?", t0: 12.3, t1: 14.9,
           words: [["Who", 12.3], ["has", 12.9], ...]}, ...],
};
SONG.beat(n)  // the time of beat n
```

Every style in this repo reads that shape (see [examples/poem/lyrics_data.js](../examples/poem/lyrics_data.js)).

## Beats

For a steady song, `--bpm` and `--first-beat` (the time of the first downbeat) are enough: `SONG.beat(n)` is
`firstBeat + n * 60 / bpm`. Find the first beat with `onsets.py` on the song's opening seconds.

If the tempo drifts or changes, use exact beat times instead:

- **from MIDI stems:** Suno writes a tempo event on every beat, so the tempo map is an exact beat grid.
  `midi.py drums.mid --beats-out beats.json` (any of the song's MIDI files will do);
- **from the audio:** `analyze.py song.mp3 --beats-out beats.json` (librosa's estimate; check it).

Pass the file to `to_js.py --beats beats.json`; `SONG.beat(n)` then reads from the list.

## Hits and loudness

Some styles pulse, flash or move with the music itself rather than the words: a lamp that breathes with the mix, a
ring on every drum hit, mouths that open with the voice. `pulses.py` measures those:

```bash
python tools/audio/pulses.py song.mp3 --percussion perc.mp3 --drums drums.mp3 --vocals vocals.mp3 --out projects/my-song/audio_data.js
```

It writes `window.AUDIO = {fps, ticks, kicks, env, venv, vdb}`: small hits (`ticks`) and big ones (`kicks`) as
`[time, strength]`, the mix's and the voice's loudness 24 times a second (`env`, `venv`, 0..1), and the voice's
loudness in decibels mapped to 0..1 (`vdb`, better for mouths). Stems give much cleaner hits than the mix; without
them everything comes from the mix. The liquid light show reads this file as it is; any style can read the arrays.

## Suno specifics

- The stem download gives an audio file and a MIDI file per instrument. The lead vocal stem transcribes cleanly.
- The MIDI files carry a key-signature event that the `mido` library can't decode (it raises
  `KeySignatureError`). `tools/audio/midi.py` patches mido to read it as C; import `load()` from it in your own
  scripts to get the fix.
- The MIDI tempo map has one event per beat: an exact beat grid, including tempo changes after an intro.
- Vocal MIDI notes are quantized and can sit up to ~0.3 s off the voice: good anchors for snapping, not ground truth.
- Suno ignores dynamics on the lyric sheet ("quiet", "spoken", "almost unaccompanied"). Measure.

## Checking by eye and ear

Open the page, play it with the sound on, and watch the lyric band. Words that light up early are the common
fault. For a close look, `#t25.3` on the page's URL shows the frame at 25.3 s with the band as it is then.



===== 完整公共规范：docs/rendering.md =====

# Previewing and rendering

Every video here is a web page that draws its frames on a canvas. You watch it in a browser while you work, and
when it's done a script steps through it frame by frame in headless Chrome and pipes the frames to ffmpeg. This
page covers the page contract the tools rely on, previewing, stills, MP4s, and fixing a stretch.

Setup (once): `pip install -r requirements.txt` (Playwright, imageio-ffmpeg, Pillow, numpy). The tools drive your
installed Google Chrome; if you don't have it, `python -m playwright install chromium` gets Playwright's own.
imageio-ffmpeg bundles an ffmpeg with x264 and AAC, so there's nothing else to install.

## The page contract

A video page (a style's `index.html`, or a copy of one for your song):

- draws into `<canvas id="film" width="1920" height="1080">`;
- loads its song data as `window.SONG` (see [timing.md](timing.md#5-write-the-page-data)) and plays `SONG.audio`
  in an `<audio>` element, falling back to a silent clock if the audio can't load;
- sets `window.__video`:
  - `ready`: true once everything is built;
  - `duration`: the song's length in seconds;
  - `step(t)`: draw song time `t` the way playback does. The MP4 renderer calls it at 24 fps, strictly in order;
  - `renderAt(t)`: draw a still of time `t` from a fresh state (catching up whatever the frames before it built);
  - either may return a Promise (a page that builds scenes asynchronously); the tools wait for it;
  - `error`: set this to the error text if building fails, and the tools stop and print it;
  - optionally `shots` and `probe(t)` for 3D pages (see `tools/probe.py`);
- shows a still when the URL ends in `#t<seconds>` (e.g. `index.html#t12.5`), with the page chrome hidden;
- draws only while playing: a paused player shouldn't keep redrawing its frame on every animation frame (the tools
  draw and read back each frame in one call, but a page that redraws on its own fights anything else that draws);
- is **deterministic**: all randomness comes from seeded generators keyed to the frame number, never
  `Math.random()` per frame, so a given moment always draws the same picture. An MP4 depends on it.

A style-lab page sets `window.__lab = { ready, scenes, styles, render(scene, style) }`, where `render` draws one
scene in one look and returns the canvas.

## Previewing

```bash
python tools/serve.py            # serves the repository at http://localhost:8000/ and lists the demo pages
```

Open a page from the list. Use this server rather than `python -m http.server` or opening the file directly:

- pages that use ES modules or load files **don't work from `file://`**;
- a plain server lets the browser **cache scripts**, so after an edit you can be looking at the old code. This
  server sends no-cache headers;
- audio and video only seek when the server answers **Range requests**; this one does.

**Stills in the browser:** add `#t<seconds>` to the URL. Changing only the `#` part doesn't reload the page, so
after editing code, reload with a new query (`index.html?r=2#t30`).

**Always check the console** after a load. One bad value in a canvas gradient (a NaN colour stop) throws, and the
whole frame goes blank.

**In Claude Code's desktop app**, the preview pane can run the server for you: create `.claude/launch.json` with
```json
{ "version": "0.0.1", "configurations": [
  { "name": "videos", "runtimeExecutable": "python3", "runtimeArgs": ["tools/serve.py", "8000"], "port": 8000 } ] }
```
(it's git-ignored).

## Stills and contact sheets

```bash
python tools/still.py styles/paper-cut/index.html 5 12.5 30          # three stills
python tools/still.py styles/paper-cut/index.html 0:37.5:2.5 --sheet # a frame every 2.5 s, tiled into one image
python tools/lab_stills.py styles/embroidery/lab/index.html --all --sheet
```

Output goes to `renders/` (git-ignored). The contact sheet is the fastest way to review a whole video: look at every
frame on it, not just the ones you changed. Things to look for: frame edges showing the end of the world, blank or
black frames, the camera inside an object, text covered or cut off, two scenes' seams, something frozen too long.

## MP4s

```bash
python tools/render_mp4.py styles/marbling/index.html                    # renders/marbling.mp4 and -720p.mp4
python tools/render_mp4.py projects/my-song/index.html --out "renders/My Song.mp4"
python tools/render_mp4.py projects/my-song/index.html --start 60 --end 90 --fast   # quick preview of a slice
```

- Two files: 1080p (x264 `slow`, CRF 23, AAC 192k: roughly 5 Mbps for a busy picture) and `-720p` (CRF 25: about
  1 Mbps, small enough to send).
- `--fast` writes only the 720p with the `veryfast` preset. Busy, grainy frames can take many times longer to
  encode with the slow preset than to draw, so use `--fast` for previews and the normal mode for the final.
- The audio comes from `SONG.audio` unless you pass `--audio`. A slice gets short audio fades.
- **Fonts:** the styles load their type from Google Fonts. If a font request fails (a flaky network), canvas text
  silently falls back to a default font, so `render_mp4.py` and `render_frames.py` check the page's fonts after it
  builds and stop if any failed. Run again, or pass `--allow-font-fallback` if you really mean it. The still tools
  print a warning instead.
- 24 fps. Frames are rendered **in order**: many styles draw each frame over the one before (frost that grows,
  ghosting, marbled paint that keeps its history), so a frame can't be drawn on its own.
- Speed depends on the style and on how much the machine is doing: from about 40 ms a frame (paper cut, painted
  enamel, archive desk) to 250 ms or more (sand, the pinscreen, screenprint's printing), including reading the frame
  back and encoding. Each style's README gives its numbers. A four-minute song is 5,760 frames: a few minutes for the
  fast styles, half an hour or more for the slow ones (see the next section for splitting a render across browsers).

## Long renders: frames on disk, resumable, in parallel

For a long song in a slow style, render the frames to a folder instead of straight into ffmpeg:

```bash
python tools/render_frames.py projects/my-song/index.html --dir renders/frames/my-song --jobs 3
python tools/encode.py renders/frames/my-song --out "renders/My Song.mp4"
```

- Frame `i` is `<dir>/<i:05d>.jpg` and shows song time `(i + 0.5) / 24`. Frames already on disk are skipped, so an
  interrupted render continues where it stopped when you run the same command again, and deleting a stretch's
  frames and re-running redoes just that stretch.
- `--jobs N` renders N runs of frames in N browsers at once. Each run starts with `renderAt()` at its first frame,
  which catches up styles whose frames depend on earlier ones, then steps in order. (Tested: a resumed run's frames
  match a straight-through render pixel for pixel.) GPU-heavy styles gain less, since the browsers share one GPU.
- `encode.py` takes the audio from the folder's `meta.json` (the page's `SONG.audio`), cuts it to the frames on
  disk, and writes the same 1080p and 720p files as `render_mp4.py`.
- **A render that sits before its first frame** is usually the machine, not the page: with other renders or heavy
  WebGL pages running, Chrome can take minutes to start or to build a page. `render_mp4.py` prints the page's URL when
  it's loaded and a progress line every 240 frames.
- **Heavy 3D pages:** building every set of a long WebGL video at once can hang the GPU. Render such a video in
  segments (`--start`/`--end` runs into the same frame folder, each run building only what its stretch needs), and
  on a machine that other renders are sharing, run one segment at a time.

## Fixing one stretch

A full render can take a while. To fix one stretch, render only that slice at full quality and splice it into the
finished file at whole frames:

```bash
python tools/render_mp4.py projects/my-song/index.html --start 120 --end 135 --out renders/fix.mp4
python tools/splice.py "renders/My Song.mp4" renders/fix.mp4 --at 120 --out "renders/My Song v2.mp4"
```

A slice opens with `renderAt(t)`, which catches up styles whose frames build on earlier ones, so its frames match the
full render's and the splice is seamless.

## Checking a 3D video's framing

`python tools/probe.py styles/diorama/index.html` asks the page, for the start, middle and end of every shot,
whether anything stands between the camera and its subject, or whether the camera is inside something. In a crowded
set it finds blocked views much faster than contact sheets.

## Sharing

Share the MP4. If you also want a review page (the video with notes around it), keep in mind that some hosts cap
file sizes: split a long 720p video into parts at scene changes and play them in sequence against the song, and
serve it from something that answers Range requests.



===== 完整公共规范：docs/your-own-video.md =====

# Making a video for your own song

The hands-on steps, from an mp3 to an MP4. For the creative side (what to decide before building, how to pick a
look) see [workflow.md](workflow.md). If you're working with Claude Code, you can just ask it to make a video for
your song: [CLAUDE.md](../CLAUDE.md) walks it through all of this.

## 1. Set up

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt            # rendering
pip install -r requirements-audio.txt      # timing a song (Whisper, librosa, MIDI)
```

You need Google Chrome installed (or run `python -m playwright install chromium`).

## 2. Start a project folder from a style

Pick a style from the [gallery](../README.md#the-styles) and copy its folder:

```bash
cp -r styles/paper-cut projects/my-song
cp ~/Music/my-song.mp3 projects/my-song/song.mp3
```

Audio files are git-ignored, so your song stays out of the repository.

In `projects/my-song/index.html`, change the lyrics script from the demo's
```html
<script src="../../examples/poem/lyrics_data.js"></script>
```
to your own
```html
<script src="lyrics_data.js"></script>
```
(Relative paths from `projects/my-song/` resolve just as they did from `styles/<style>/`, so anything else the
page loads from the repo keeps working.)

## 3. Time the lyrics

Write the lyric sheet (`projects/my-song/lyrics.txt`, one sung line per line, `#section` markers), then run the
pipeline in [timing.md](timing.md). It ends with `projects/my-song/lyrics_data.js`.

## 4. Look at it

```bash
python tools/serve.py
```

Open `http://localhost:8000/projects/my-song/index.html`. The demo's scenes now play under your lyrics for as long as
the demo lasts. That's the moment to decide the plan: which scene goes where, which line lands on which image.

## 5. Replace the demo's scenes with yours

Every style's README has a "Make your own video in this style" section that says which files are the demo (its
scenes, sets, shots or timeline) and which are the engine. Keep the engine; rewrite the demo files. Work a section
at a time:

```bash
python tools/still.py projects/my-song/index.html 30:60:2 --sheet   # stills every 2 s across 0:30-1:00
```

Look at every still on the sheet. Check the console output printed at the end.

## 6. Render

```bash
python tools/render_mp4.py projects/my-song/index.html --start 30 --end 60 --fast   # a quick 720p preview
python tools/render_mp4.py projects/my-song/index.html --out "renders/My Song.mp4"  # the final, 1080p + 720p
```

To fix one stretch later without re-rendering everything, see
[rendering.md](rendering.md#fixing-one-stretch).



===== 完整公共规范：docs/engine-patterns.md =====

# How the engines are built

The eighteen engines in [styles/](../styles) share no code at run time: each folder is self-contained, written for one
song in one medium (a few began as copies of another's files, such as the 3D pipeline or the ray-marched figure). But they
share a shape, and knowing it makes any of them easy to read and a new one quicker to write. This page is that
shape, plus the browser gotchas that cost the most time.

## Simulate the process, not the look

Each engine models how its medium is physically made, and the imperfections come out right on their own:

| medium | what the code does |
| --- | --- |
| screenprint | each ink is a stencil mask plus a halftone; inks are pulled one at a time and multiplied onto paper, each a little out of register, with squeegee streaks and pinholes |
| linocut | a block is a list of gouge cuts and inked areas; the key block prints black over watercolour washes |
| wool embroidery | wool is laid and couched from tiles, outlines are stem-stitched, light is couched gold thread |
| marbled paper | paint floats as closed outlines on a bath; drops, combs and swirls are exact maps applied to every point |
| magic lantern | slides are baked as tinted glass; a frame stacks glass by multiplying and throws it through a lens |
| painted enamel | two-colour bristle strokes with a highlight flick toward the light, then gold leaf |
| paper cut | cut shapes with a lit rim and a soft shadow, layered in depth and lit from behind |
| mosaic | tesserae are laid in rows along the outlines, then grouted |
| sand on a lightbox | sand thickness is a density field; the lamp shows through as `exp(-k * thickness)`; fingers clear lines |
| carved diorama | each piece is a signed-distance sculpture meshed in the browser; tool marks are a bump in the piece's own space |
| photomontage | photographs are painted in greys, then given a print's grain, halation and tone curve, and cut out with drifting scissors |
| pinscreen | a field of pins at different heights, lit from a low angle, each pin's shadow falling on the next |
| archive desk | every paper is pre-rendered with its shadow, grain, foxing and torn fibres; stamps are inked, then eroded |
| night poster | a shape's shadow is the band a shifted copy of it fails to cover; night mixes colours toward navy while lamps keep their brightness |
| batik | a real 3D set lit by two coloured lamps is rendered into buffers; wax resists where both lamps reach, each dye takes where only one does, and the wax cracks |
| long-exposure glass plate | each frame integrates many light drawings over the exposure, so whatever moved is a smear and whatever stood still is sharp; then halation, dust and the emulsion's edge |
| silverpoint | even hatching whose weight follows the tone; lines can't be erased, and tarnish from grey to brown with age |
| carved relief | the scene becomes a height field, shaded by a raking light with its own cast shadows |
| liquid light show | oil, water and dye in a dish on a projector: warped-noise dye bands, metaball oil drops with a meniscus, and drawn transparencies whose black ink really blocks the lamp |
| thermal camera | a scene rendered as temperatures and mapped through a camera palette, with a thin visible-light edge overlay, warm breath and fading heat prints |
| showboat stage | painted flats given brushwork by a sampled-stroke pass, lit by a light map in which the actors are lit through their own silhouettes |

A filter that makes a clean digital picture look like linocut never convinces for long. A few rules about how the
real thing is made go much further.

## One frame

Almost every engine's frame function looks like this:

```
renderFrame(t):
  shot = the shot covering t
  set  = shot.set, baked on first use           (the still layers: land, buildings, background)
  cam  = shot.cam(t)                            (keyframed, eased)
  draw the set's layers through the camera       (parallax: nearer layers move more)
  draw what moves at t                           (figures, props, light, weather)
  post: light (a multiplied lamp or light map), grain, vignette, the medium's texture
  if t is inside a transition: draw the next shot too and mix (dissolve, wipe, push)
  the lyric band / margin / caption for t
  fade in and out at the ends
```

The canvas is 1920x1080. Several styles keep the picture above a band for the lyrics (e.g. 1920x960 + 120).

## Sets, shots, cameras

- **Sets** (or scenes, worlds, plates) are places. Their still parts are drawn once into offscreen canvases the first
  time they're needed ("baked"), then only composited. Keep a memory budget: the whole song's sets rarely fit at
  once, so drop the least recently used. Bake at load what the first seconds need, so playback doesn't hitch.
- **Shots** are stretches of song time: `{t0, t1, set, cam, ...}` plus a function that poses what moves.
- **Camera keys** are `[time, x, y, zoom, ...]` with easing between them. Two useful rules:
  - push in with **lens zoom**, not by travelling into the layers: depth travel blows the nearest layer up (snow
    becomes moons);
  - **never let the camera see past the edge** of what's drawn. Check the frame corners on every new camera.
- **Transitions:** dissolves, drop wipes (a new picture spreading inside a drop), push and pull (from a room to the
  picture on its screen), panels (pull back to a page of panels, push into another), re-laying one medium as another
  past a moving line.

## Time: on twos, and in step with the song

- Hand-made animation moves **on twos**: pose changes at 12 fps inside 24 fps video. Several engines step motion at
  12 fps (`tm12 = Math.floor(t * 12) / 12`) while the camera moves at the full 24, which keeps the hand-made feel
  without a juddering camera. Texture "boil" (grain, ink noise) often changes at 8 fps.
- **Ease into fast moves**, or drive them with real time: a move that starts at full speed jumps at 12 fps.
- **Hits on beats, changes on lines.** `SONG.beat(n)` and each line's `t0` and word times are the anchors. A word
  lighting in the lyric band typically fades up over `[t - 0.04, t + 0.16]`.
- **Keep something moving.** A hold longer than a beat or two reads as the player freezing. A slow drift, a breathing
  light or drifting smoke keeps a still picture alive.

## Determinism and frame-to-frame state

- All randomness comes from seeded generators (`mulberry32(seed)`) and noise keyed to the frame number. Never call
  `Math.random()` while drawing a frame. The same `t` must give the same picture, or an MP4 won't match what you
  checked.
- Some styles **carry state from frame to frame**: frost that grows, ghosting of the previous frame, a charcoal
  drawing that's erased and redrawn, marbled paint whose outlines remember every comb. Those must be stepped in
  order. `renderAt(t)` then means "rebuild the state from the start of this scene up to t", and each engine's README
  says how it does that.
- When a view steps backwards in time (a camera effect that holds frames, a scrub), keep what's already baked rather
  than rebuilding it from scratch each step, or rendering crawls.

## Figures

- **Whole figures**, posed. Every engine has a rig: jointed silhouettes, contour-drawn people, ray-marched signed
  distance bodies, carved 3D pieces. Most use **two-bone IK** for arms (and often legs), so a hand can be put exactly
  on a rope, a cup or another hand. Each rig spells it its own way: `reachArm()` in paper cut, an arm given as
  `{t: [x, y]}` in embroidery or `{at: [x, y]}` in painted enamel; the style READMEs show how.
- Build **every figure of a kind from one model**, so its anatomy is the same in every shot; vary only pose,
  clothing and age.
- Things that make figures read wrong, all hit at least once: round heads read as teddy bears (give them a muzzle
  or a jaw); coats that hang along the body turn a crouching figure into a plank (hang them toward world-down);
  digitigrade legs with a long stride look like sitting on a stool; two figures leaving the same way merge into one
  blob; close-up arm silhouettes read as clubs or poles.

## Light

- A **lamp** is a radial gradient drawn with `multiply` (or a light map multiplied onto the whole picture). Its
  warmth and brightness carry most of a scene's mood.
- **Self-lit things** (flames, lit windows, glowing marks) go in their own layer drawn after the light map, plus a
  glow. A reflective shape in front should erase the self-lit layer behind it.
- On pale paper, `screen` adds almost nothing; `soft-light` plus a weaker `screen` shows coloured light.
- Glass only darkens: a moving piece has to pass over light glass, or it vanishes.

## Text in the picture

- Load fonts before drawing and wait for them (`document.fonts.load(...)` for each face and script you use), or text
  falls back to a default font. `document.fonts.load` resolves even when the font never arrived, so check the
  result (or `document.fonts.check(...)`) before building. Put `<meta charset="utf-8">` at the top of the page for
  any non-ASCII text.
- **Start building only when every script has loaded** (`DOMContentLoaded`, or put the start call at the end of the
  last script). A build started from a font promise plus a short timer can win the race against later scripts when
  the fonts come from cache, and the page fails to build only sometimes.
- Keep the lyrics readable: if the camera zooms, keep the text out of the zoom (a band or margin drawn in screen
  space).

## Browser gotchas that cost hours

- **One bad gradient value kills the frame.** `addColorStop` with a NaN or an out-of-range offset throws, and nothing
  after it draws. Check the console after every change.
- **`destination-out` uses the current fill's alpha.** A fill left translucent from the last wash only half-erases.
  Set `fillStyle = '#000'` before erasing.
- **`[hidden]` loses to `display: grid`.** Add `.gate[hidden] { display: none }` for overlay elements.
- **Globals collide.** Plain scripts share one global scope; a helper named like an existing function (`hand`,
  `line`) silently replaces it.
- **Tiling seams:** a texture tiled from a sampled corner shows seams on big pieces; downsample the whole texture.
- **WebGL:** GLSL has reserved words you'd never guess (`patch`); creating a texture while another is bound can
  overwrite a texture unit (create textures on a scratch unit such as TEXTURE15); a three.js `InstancedMesh` keeps the
  bounds of its first draw unless `frustumCulled = false`.
- **Headless loads:** wait for the page with `wait_until='commit'` and your own ready flag; a page that builds a lot
  at load can time out waiting for the load event.
- **Grain that changes every frame bloats the MP4.** Change it on twos.

## Starting a new engine

1. Copy the style closest to what you want. Keep its player (`index.html`, the playback and `window.__video` parts
   of its engine) and its lyric code.
2. Write the medium: the few functions that turn a shape into your medium's marks. Test them on stills first, on a
   page that just draws one scene (a lab page).
3. Draw the same key scenes in your medium and in one or two alternatives. Choose.
4. Then sets, shots and the song.



## 原作者媒介陷阱与经验摘录

## Lessons and gotchas

- **Traces are the style's best tool.** Breath, smoke, exhaust, footprints, handprints, the warm patch where someone
  sat: a heat camera shows what just happened, and that's what tells a story in it. Seen from above, breath trailing
  downwind was the clearest picture of the wind in the demo.
- **Anything at the air's temperature disappears.** A fence, a gate, grass, a sign: without the edge overlay they're
  gone. Keep the overlay on, as thin white lines at half strength (0.8 px); the heavier embossed overlay muddies warm
  bodies.
- **Faces read in profile and at a distance, not straight on.** Close up and face-on a warm face is a smooth
  mannequin; keep faces to profiles and medium shots, and let hats, hair and breath carry them.
- **Glass is opaque to a heat camera.** A lit window shows its own warmth, never the room behind it, and a glazed door
  hides the face behind it; a barred opening doesn't.
- **Two warm bodies touching merge into one blob**, and so do figures of the same temperature overlapping in depth.
  Keep a layer of cooler clothing, or a gap, between them.
- **Text is invisible in heat.** Paint is the same temperature as the board; `s.sign()` puts it in the visible pass,
  where only the overlay can show it.
- **The span decides what reads, more than the palette.** A palette wipe needs each palette's own span (`span2`): a
  shared span flashed the incoming palette to its hot end. Cool palettes such as arctic need a lower span so warm
  things reach their warm end.
- **Detail enhancement lies about thin cool things against a very cold sky**: branches and blown leaves came out with
  hot rims. The enhancement is capped (`ddeMax`, 6 degrees).
- **Edges from depth must ignore slopes.** First differences of depth fire on distant ground seen at a grazing angle
  and drew a grey band along the horizon; the second difference of inverse depth is flat on any plane and jumps only
  at outlines.
- **Material codes must not blend across a seam.** Blended, skin beside cloth passed through 2 (a hot source) and
  leaves beside bark missed 8. The modeller takes the winning op's code, and the shaders read it as a flat varying.
- **Keep the sky cold below the horizon, and the ground big.** A sky sphere whose temperature follows height warms
  below the horizon, and it shows through past the edge of a small ground plane.
- **Flutter only small things, at their own scale.** A noise shake fine enough for leaves melted whole trees; give each
  piece a fineness, and let only leaves and grass shake fully on a meshed piece.
- **Washing on a line running downwind** streams out like flags, face-on to a camera beside it; on a line across the
  wind it billows toward or away from the camera and reads as a shapeless blanket.
- **A gust's cooling is limited by physics**: it can only take away a surface's warmth above the air, so it barely
  shows on walls a few degrees above it. It shows on lit windows and on people; let the windows dim one by one.
- **Hot things dominate the frame.** A truck's hood right after a drive is the brightest thing in any shot it's in;
  park it out of the shots that are about something else, or keep it small.
- **Handprints are small**: a palm is a few pixels beyond 15 ft. Bring the mark toward the camera (the demo's gate
  swings toward it) or go close.
- **Past breath must leave from where the mouth was.** Using the current mouth made a walking person's plume follow
  their head like a rigid tail; `breath(t)` is asked again for each puff's own time.
- **Figures cost their mesh, not their drawing.** Give every shot a figure detail to suit its framing, and don't
  animate a far-off figure every frame when nobody can see it (the demo's dog in the truck turns its head every
  two beats).
- **A heat camera cuts; it doesn't dissolve.** For a change of section, change the palette (the demo sweeps it across
  with the wind), pump the gain or flash briefly; the last two are what a real camera does.
- **Move on twos.** Twelve drawings a second reads as a real, slightly cheap camera rather than a render, and the
  sensor noise, which still changes every frame, keeps a held shot alive.
- **Don't start or end on pure black.** The demo fades up from 20% and fades down to about 30%.
- **`step()` may return a Promise**, and the render tools wait for it; a page that meshes on demand must still never
  draw a frame before its poses are ready.


