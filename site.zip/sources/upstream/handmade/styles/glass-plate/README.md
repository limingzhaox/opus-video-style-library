# Long-exposure glass plate

Photographs on dry glass plates, exposed so long that whatever moved is a blur and only what stood still came out
sharp, the way the first street photographs lost every passer-by and kept only a man having his boots blacked. Every
picture is a plate being exposed while you watch: it comes up out of the dark, bright parts first; trees, washing and
clouds are recorded as the average of every pose they held, so they smear downwind while the church, the wall and the
standing stone stay crisp; people who pass leave a faint band along their way with a clearer ghost where they are now,
and people who keep still are as sharp as the stone. The print is what an old plate gives: orthochromatic greys (pale
skies, dark foliage and skin), a warm-black tone, the lens soft toward the corners, halation spreading from anything
bright, grain, dust and hairs, fine scratches, a chipped corner, silvering in the dense edges, the ragged edge of the
emulsion, and sometimes a crack that knocks one side of the picture a hair out of line. Under the picture is the
plate's paper sleeve: the plate number and a running count of the exposure, the lyric being sung, the stop and the wind.
Exposures run from minutes to a year: long enough that days and nights flatten to grey and the sun draws its track
across the sky, one arc a day.

![A hillside in a gale on a long exposure: three trees on the skyline bowed and smeared into fans, a church and a dry-stone wall sharp, a woman and a girl standing still and sharp beside a standing stone, a passer-by's ghost on the path](img/hero.jpg)

*Good for:* stillness against movement, waiting, time passing (minutes, days, a year), weather, places that outlast
the people in them, memory and absence.

The demo sets Christina Rossetti's "Who Has Seen the Wind?" as six plates, the exposures climbing through the song:
four minutes on a hill with a church while the picture comes up out of the dark under the title; twenty minutes on a
lane where passers-by are ghosts and a girl's kite is a smear across the sky, then close on a beech's leaves trembling;
an hour on a drying green where the washing blows out into bands; six hours on the church tower, its weathervane turned
to a disc and the sun drawing its track behind it; a day beside the standing stone with the two who keep still; and the
hill again, where the trees bow in a gale on "bow", "down" and "heads", and then the exposure runs on for a year: the
sun's arcs fill the sky, the grey flattens, and the two who stood still are gone, because a day is nothing to a year.

| | |
|---|---|
| ![The lane: a woman and a girl stand sharp while passers-by are ghosts on the road and the girl's kite flies above a beech's bough](img/lane.jpg) | ![The drying green: sheets and shirts on a line smeared out into pale bands against a dark orchard](img/washing.jpg) |
| ![The church tower close: the weathervane turned to a disc, the sun's track behind, a crack across the glass](img/tower.jpg) | ![The hill after a year: the sun's arcs over a flattened grey, the trees gone soft, the church and the stone sharp](img/year.jpg) |

## Looks in this family

The [style lab](lab/index.html) draws the demo's three places (the hill, the lane, the drying green) in each look.
The scene painter is the same for all three; each look turns its buffers into a different medium and records
movement its own way.

- **Long-exposure glass plate** (the demo): what moved is the average of its poses, a blur; what stood still is sharp.
  ![The lane as a glass plate](img/look-plate.jpg)
- **Silverpoint**: even hatching in silver on a tinted, prepared ground. Silver can't be erased, and it tarnishes, so
  fresh lines are grey and old ones brown (the church and the stone brown, the people grey), and whatever moved is
  drawn in its last pose over faint lines of its earlier ones (pentimenti).
  ![The lane in silverpoint](img/look-silverpoint.jpg)
- **Carved frieze**: limestone relief under a low raking light, three panels between pilasters, the same scene at three
  moments, so whatever moved is repeated panel by panel; the lyric is cut as an inscription under it.
  ![The lane as a carved frieze](img/look-frieze.jpg)

## Run the demo

```bash
python tools/serve.py
```

Then open `http://localhost:8000/styles/glass-plate/index.html`. Play, or press Space; drag the bar to scrub. If the
song can't load, it plays on a silent clock. Add `#t12.5` to the address for a still of 12.5 s with the page around it
hidden (after editing code, reload with a new query, `index.html?r=2#t12.5`: changing only the `#` part doesn't
reload).

```bash
python tools/still.py styles/glass-plate/index.html 2 6 12.5 0:37.5:2.5 --sheet   # stills and a contact sheet
python tools/render_mp4.py styles/glass-plate/index.html --fast                    # renders/glass-plate-720p.mp4
python tools/render_mp4.py styles/glass-plate/index.html                           # 1080p and 720p
```

It doesn't play smoothly live: a frame takes about 40-250 ms to draw, and the first frame of each plate up to two
seconds (it paints the plate's still layer and renders its figures), so in the browser it plays at a few frames a
second. Render it for the smooth version: a `--fast` render of the 37.5 s took about two minutes on an Apple-silicon
Mac that was busy with other renders.

## How it works

Plain scripts that share global names, loaded in this order by `index.html`:

| File | Job |
|---|---|
| `../../examples/poem/lyrics_data.js` | `window.SONG`: the lines, word times and beat grid |
| `core.js` | sizes (`W`, `H`; the picture `PW` x `PH` = 1920 x 930 over a 150 px `BAND`; the design size `DW` x `DH` = 1600 x 775), maths, seeded random `RNG(seed)`, value noise, point-list geometry (`ellipsePts`, `chaikin`, `wobble`, `taperPts`, `archPts`...), named scratch canvases, the fonts and a check that they really loaded |
| `figure.js` | the ray-marched figure (head, hands, coat, legs), read back as shade, material and key light, plus the surface normal and depth for the relief |
| `gl.js` | WebGL2 helpers: `glPass(name, shader, w, h, textures, uniforms)` runs a full-frame shader over some canvases |
| `paint.js` | the scene painter `PT`: the buffers, shapes, lines, glows, clipping, the time-average `avg`, figures and their layers |
| `cast.js` | people: `womanSpec`/`womanParts` (a dark skirt, a pale shawl, hair up), `girlSpec`/`girlParts` (a pinafore, a plait, legs drawn as parts), `walkerSpec` (passers-by in a cap, a hood, a jacket or a long coat), hair, a cap, a pack |
| `land.js` | the pieces: sky, clouds, the sun's daily arcs, ridges, fields, conifers, the ground, a path, a standing stone, a dry-stone wall, a hedge, a gate, a church, a weathervane, a cottage, smoke; and the wind's things: a broad tree that bends, grass, cloth on a line, a kite, leaves on a twig, a loose leaf's streak |
| `actors.js` | exposure of what moves: `exposeRoute` (a person along a route, by song time), `lightRoute` (a light that draws its own line), `passer` and `sway` (one still, in any look), `poseHist`, `walkerAt`, `curveAt`, `hAt` |
| `plate.js` | the print (`renderPlate`: the plate shader, dust and hairs, the rebate, cracks) and the sleeve (`drawSleeve`) |
| `sets.js` | the demo's three places, `HILL`, `LANE` and `YARD`: a still part and functions that draw their moving things at one moment |
| `shots.js` | this video: the wind, the six plates, their cameras, exposures and moving things |
| `engine.js` | the timeline: cached still layers per plate, the camera, second exposures, dissolves, the lyric and title card, `window.__video` |
| `index.html` | the page and the player |

`core.js`, `figure.js` and `gl.js` started from the magic-lantern style's cleaned copies. `figure.js` adds three things
to that one: a shoulder drop for coats whose shoulders slope (`cloak.drop`), a third read-back (`spec.withN`) of the
surface normal and depth that the relief carves figures from, and caches bounded by count and by memory.

**The scene painter.** A scene draws once into a set of same-size buffers, and each look turns them into its medium:

```
T   tone: the scene as an orthochromatic plate records it, grey 0 (black) .. 1 (white)
L   light: glow from light sources, additive (the plate turns it into halation)
H   height: the relief (the frieze only)
O   contour lines, AG how long ago each part was drawn and when it appears, WT white heightening, RT when each contour
    appears (the silverpoint only)
```

```js
const P = new PT(w, h, k, ox, oy, { st: 'A' });   // st: 'A' the plate, 'B' silverpoint, 'C' the relief
P.shape(points or [points, ...] or Path2D, { tone, tex: { amt, kind, sc }, blur, glow, h: { v, dome, r, mode }, out, white, old, a, rule })
P.line(points, width, { tone, glow, gw, blur, out, h })
P.glow(x, y, r, v); P.shade(x, y, r, v0, v1, { sy })       // a light; a soft darkening
P.with(weight, () => ...)                                  // draw at a weight (a trail is a figure drawn at .02 many times)
P.clip(shape, () => ..., 'evenodd')                        // draw inside a shape in every buffer
P.avg([[pose, share], ...], pose => draw(pose), { box })   // the time-average: see below
P.fig(spec, x, y, heightInDesignUnits, { parts, ghost, shadow, hu, sole })   // a figure standing with its soles at (x, y)
```

Everything is in design units (1600 x 775) and `k`, `ox`, `oy` map them to buffer pixels, so the same scene paints at
any size and framing. A shape carries all its looks' information at once (its tone for the plate, its contour for the
silverpoint, its height for the relief), and the painter fills only the buffers its look needs.

**The time-average.** `P.avg(list, draw, { box })` is how the plate records movement. `list` is the exposure so far as
`[pose, share]` pairs. Each pose is drawn alone into a clear scratch buffer and added into an accumulator at its share
(`lighter`), then the accumulator goes onto the tone. So every point gets exactly the share of the exposure that
something covered it: a branch that swung is a blur, a trunk that barely moved is solid, and parts of one pose that
overlap (a tree's leaf clumps) don't count twice. Shares add up to 1 for something that was there the whole time, to
less for something that was there part of it. `box` (design units) bounds the work.

Where do the shares come from? `poseHist(f, t0, t1, lo, hi, bins)` samples a pose function `f(t)` (a tree's bend, a
sheet's lift, a vane's angle, a cloud's drift) over the exposure and gathers the samples into bins. The bins are fixed
for the whole plate (`held()` in `shots.js` caches each thing's range), so a pose drawn one frame is the same pose the
next and only the shares change: nothing jitters, and the blur grows as the exposure goes on. A gust leaves its mark
for the rest of the plate, the way a real long exposure remembers it.

**People.** Passers-by are drawn a cheaper way: `exposeRoute(P, t, keys, path, draw, { trail, lead })` draws a
walker at every point of their route so far at a small weight (`trail` is film density per second of being there), so
a walk leaves a faint band and a pause a clearer ghost, then draws where they are now at `lead` weight so you can see
who is moving and which way. A route is `[[time, u], ...]` along a `curveAt(points)` path. The two who keep still are
simply drawn once at full weight. A figure that is still except for one part (the girl's arm that flies the kite, a
shawl's fringe) is drawn through `P.avg` with only that part changing between poses.

**Plates and the timeline.** `shots.js` lists the plates:

```js
shot({ t0: LINE(3), t1: LINE(4), no: '3', key: 'yard', ramp: .45, dis: .4, dust: 47,
  exp: expText(expLinear(LINE(3), LINE(4), 3600)), stop: 'f/32', wind: 'Wind SW, fresh',   // counts up to 1 hr
  cam: [[LINE(3), 1.1, 800, 420], [LINE(4), 1.24, 900, 405]],                            // [time, zoom, centre x, y]
  bg(P) { yardStill(P); },                                    // the still layer, painted once
  act(P, t, S) {                                              // what moves, every frame
    const lift = τ => clamp(.1 + .7 * WIND(τ) + .13 * Math.sin(τ * 9.3), 0, 1);
    const hist = held('p3:lift', lift, LINE(3), LINE(4), t, 32).map(([l, w]) => [[l, 0], w]);
    P.avg(hist, ([l, ph]) => yardLine(P, l, ph), { box: YARD_LINE_BOX });
    yardPairFilm(P);
  } });
```

(simplified from the real one). A plate's `bg` is painted once into a cached canvas at the resolution its closest
camera framing needs (plates sharing a `key` share it); each frame copies the camera's view of it into a working
painter, `act` paints the moving things over it, and `renderPlate` prints it. Other fields: `ramp` (seconds the image
takes to come up out of the dark, from `exp0`), `dis` (seconds of double exposure from the plate before: every cut here
is a short one), `flat` (0..1, days and nights averaged to grey), `crack` (`[[x0, y0], [x1, y1], seed]` in 0..1 of the
frame), `dust` (the plate's own dust seed), `over` (a second exposure of another place on the same plate). Camera keys
ease in and out; zoom is interpolated in log space.

Moving things are drawn over the still layer, so anything that should pass *behind* something still (clouds behind
the church, the sun's track behind the hills) is drawn inside `P.clip(HILL.skyClip, ...)`: the sky above the hills,
less the church's silhouette.

**The print** (`plate.js`, `renderPlate(P, { seed, flat, exp, flash, grainSeed, crack, shift })`) is one shader: lens
softness toward the corners, flattening, halation from the blurred light buffer and the brightest tones, the exposure
ramp, a print curve with lifted blacks, the vignette, two sizes of grain (reseeded 8 times a second), dust and hairs
(white on the print), dark specks, silvering in dense edges, the rebate, and a crack if the plate has one (the tone
beyond it read a hair out of line). `plateDust(w, h, seed)` and `crackMask(w, h, crack)` make each plate's damage once.

**The lyric and the sleeve.** `drawSleeve` shows the plate number and the running exposure (`expWords(seconds)`:
"40 s", "4 min", "1 hr 20 min", "3 days", "5 weeks", "7 months", "1 year") at the left, the stop and the wind at the
right, and in the middle the words of the current line as they're sung, laid out from where the whole line would start
so they don't shift (`lyricAt(t)`, from `SONG.lines[i].words`). The line holds until the next begins or 2.6 s after
its last word. From 0.25 s until just before the first word, the middle shows `SONG.title` and `SONG.credit` instead.

**Determinism and caching.** A frame is a pure function of `t`: every random choice comes from `RNG(seed)` or hashed
noise with fixed seeds, the pose histograms are computed from `t`, and people's trails are resampled from the start of
their route each frame. So `step(t)` and `renderAt(t)` are the same call and frames can be drawn in any order. The
caches (still layers, five at a time; figures, 600 or about 256 MB; figure layers, 500 or about 60 million pixels;
dust; the last frame of the previous plate, for dissolves) are bounded, and evicted canvases are emptied so the browser
can reclaim them at once.

## Make your own video in this style

1. Copy the folder and your song: `cp -r styles/glass-plate projects/my-song`, `cp ~/Music/my-song.mp3
   projects/my-song/song.mp3` (see [docs/your-own-video.md](../../docs/your-own-video.md)).
2. Time your lyrics ([docs/timing.md](../../docs/timing.md)) so you end up with `projects/my-song/lyrics_data.js`
   (written by `tools/audio/to_js.py`), and in `index.html` change `../../examples/poem/lyrics_data.js` to
   `lyrics_data.js`. The demo's plates now play under your song (for as long as they last).
3. Keep `core.js`, `figure.js`, `gl.js`, `paint.js`, `actors.js`, `plate.js`, `engine.js` and the player. Borrow from
   `cast.js` and `land.js`, and rewrite `sets.js` and `shots.js`.
4. **A place:** a function that paints the still part in design units (1600 x 775, horizon near y 360), like
   `yardStill(P)`, and a function per moving thing that draws one moment of it, like `yardLine(P, lift, ripple)` or
   `hillTree(P, i, bend)`. Give each still thing an `old` (years since it was drawn) so the silverpoint can tarnish
   it, and a relief height `h` (the ground's `groundH(y)` plus a little) so the frieze can carve it. Try it in the lab
   first (add a scene to `lab/scenes.js`).
5. **A plate:** `shot({ t0, t1, no, key, bg, act, cam, exp, stop, wind })`. In `act`, average each moving thing with
   `P.avg(held(key, poseFunction, t0, t1, t, bins), pose => draw(pose), { box })`, walk people with `exposeRoute`, and
   draw whoever keeps still once. Choose `bins` so a bin moves the thing about 3 px (`hillTrees` works it out from the
   zoom). Give each plate a new exposure: the counter climbing is half the story.
6. **Timing:** `SONG.beat(n)` (here `B(n)`) is beat n, `LINE(i)` line i's start, `WORD(i, k)` word k of line i. Put gusts
   on words (`GUSTS`: `[time, strength, width]`), cuts on line starts, and a push-in across a line. The average widens
   as a gust comes on and keeps what it recorded, so a gust centred on a word shows from a beat before it and stays.
7. **Knobs:** `BREEZE` and `GUSTS` (the wind); `treeBend` (how far a tree leans and sways for a wind); the plate's
   `ramp`, `exp0`, `flat`, `crack`, `dust`, `dis`; `renderPlate`'s `grain` and `silver`; `exposeRoute`'s `trail` and
   `lead`; the print's colours (`dk`, `md`, `lt` in `FS_PLATE`); the sleeve's type in `drawSleeve`.

## Lab

Open `http://localhost:8000/styles/glass-plate/lab/index.html`, pick a scene and a look (`?s=lane&st=silverpoint`
opens on a pair). **Play** animates the look over six seconds: the plate exposing (its moving things gathering), the
silverpoint being drawn in, stage by stage, and tarnishing, the camera walking along the frieze while the low sun
swings. To render every pair:

```bash
python tools/lab_stills.py styles/glass-plate/lab/index.html --all --sheet
```

A lab scene (`lab/scenes.js`) describes what moved as functions of τ, the exposure's own time from 0 to 1, and each
look draws it its own way (`look()` and `sway()`):

- **Plate** (`renderPlate`): averages every moving thing over τ in [0, u] with `P.avg`, and draws passers-by as trails
  with `passer`. The band is the sleeve.
- **Silverpoint** (`renderSilver` in `lab/looks.js`): a shader turns the tone into even parallel hatching in two
  directions (the second only in the darks), stroke weight following the darkness, broken into strokes of a hand's
  length, taken up unevenly by the ground's tooth; contours from the `O` buffer; white heightening on the lights; a
  finish map (`focus`) that keeps the subjects finished and leaves the rest sketched and the sheet's edges bare. The
  line colour goes from fresh grey to tarnished brown with each part's age (`AG`, plus `ageBy`), and `nowT` reveals
  the drawing part by part (`P.rt`). Moving things are drawn where they were at τ = u, over faint `linesOnly` lines of
  where they had been. The band is the sheet's margin, written.
- **Carved frieze** (`renderRelief`): `friezeStrip` paints the scene three times, at τ = the scene's `moments`, into
  panels of relief between pilasters (drawn after the panels, so no panel's edge covers them), and the view is cropped
  from the strip. The shader lights the height field from a low sun, marches toward the light for the carving's own
  shadows, darkens the hollows, and adds limestone mottling, water streaks, pits and claw-chisel marks. The band is
  the lyric cut in capitals with the number in Roman numerals in a sunk panel.

## Performance

- A frame draws in about 40-250 ms in Chrome on an Apple-silicon Mac. The cost is the moving things: every pose of a
  tree in a histogram is a full drawing (up to 64 poses of a crown when the camera is close), the washing is 90-100
  poses of seven pieces of cloth, and a passer-by's trail is re-drawn from the start of their route each frame (36
  figure images a second of walking). The first frame of each plate also paints its still layer and renders its
  figures (up to two seconds).
- A whole `--fast` render: 1 minute 40 seconds to 2 minutes for the 900 frames (110-140 ms a frame, reading back and
  encoding included), on a machine running other renders at the same time (load average 8-12). Before blur filters were taken
  out of the per-pose drawing and clouds were drawn from sprites, the same render took six minutes: a CSS `blur` on
  a shape that is drawn dozens of times a frame is the costliest thing you can do here.
- Memory: a still layer per plate is two canvases at the plate's closest framing (up to 5200 px on a side; five kept),
  plus the bounded figure caches.
- A camera push-in used to cost seconds a frame, because every zoom step asked for new figure renders. Figures are now
  rendered at sizes a tenth of an octave apart (a quarter for ghosts) and scaled, and a figure wholly off the frame is
  skipped.
- Render a slice while you work on a stretch: `python tools/render_mp4.py styles/glass-plate/index.html --start 15
  --end 19 --fast`. Frames don't depend on earlier frames, so a slice matches the full render exactly.

## Lessons and gotchas

- **A blur needs enough copies.** Too few and a smear looks like a picket fence or a strobe: about one pose per 2.5-3 px
  of travel. For a walker, draw where they are now a little heavier than the trail, so it reads as a person going
  somewhere.
- **Average properly.** Drawing each pose over the last at a small alpha under-counts where poses overlap and
  double-counts where parts of one pose overlap each other (a tree's clumps), so a tree's middle never quite goes
  solid unless you overweight it. `P.avg` draws each pose alone and adds them by their share of the exposure.
- **Fixed bins, or the blur boils.** Poses sampled afresh each frame would shift a little every frame and the average
  would flicker. Bin them between a range fixed for the whole plate, and let only the shares change.
- **Dark on dark vanishes.** A walker's ghost disappeared against a dark wood; a girl's raised arm vanished against a
  dark hedge until she stood against the pale distance. Keep moving and important things against pale ground: sheets
  against a dark orchard, dark trees against a pale sky. Ghosts in pale coats show against dark woods, dark ones
  against pale fields.
- **Lights drawn only into the glow buffer vanish,** because the print blurs that buffer 16 px: burn a thin line into
  the tone too (`lightRoute` does). And a light walked at night doesn't register on a plate that also holds a day,
  which is true to the medium: lights read on night plates and short ones.
- **At night, dark coats vanish and pale skin doesn't:** a figure at night on a long exposure showed only its hands.
  Glove them and shade the face.
- **Moving things are drawn over the still layer,** so clouds covered the church's finial and the vane floated free.
  Clip anything that passes behind something still, and make the clip follow thin parts exactly, or a pale halo shows
  round them.
- **Flatten before the halation.** A year's exposure flattens to grey; apply that to the tone before adding the light,
  or the sun's arcs go grey too.
- **A year's sun arcs merge into one white arch** if every arc glows: draw them thin, with a small glow each, broken
  where a cloudy day hid the sun.
- **A spinning vane averages to a very faint disc,** because the arrow covers little of the circle. Give it a broad
  tail and keep it turning through most of the exposure.
- **Random jitter strobes.** Leaves shaken by a random amount per pose showed as a few distinct copies. Swing each leaf
  through a sine at its own rate and phase, and spread the poses evenly through the cycle: a smooth fan.
- **A loose leaf drawn at every step is a dotted chain.** Draw its way as a soft band with a few tumbling shapes.
- **A branch must grow out of its tree.** A bough across the sky with its tree off the frame read as a floating stick.
- **No blur filters in anything drawn per pose.** A canvas `blur` on a tree's shading, a cloth's folds or each cloud,
  drawn dozens of times a frame inside an average, made renders four times slower. Draw those sharp (the average
  blurs them anyway), or draw them once into a sprite and move the sprite (`cloud` does).
- **Figures at every zoom step are slow.** A push-in asked for new ray-marched figures every frame (seconds a frame).
  Render at log-spaced sizes and scale, skip figures off the frame, and keep per-pixel noise out of big figures (use a
  lookup table).
- **Bound every cache and empty what you evict.** Canvases piled up (a layer set for every pose and size, a new WebGL
  output canvas every frame) until, after a minute, the picture went black.
- **Plates sharing a still layer must paint it the same way.** A still taken of a plate that didn't carry the painter
  came out blank until `bgFor` looked up the plate that does.
- **Two figures standing in one place print as one.** Stand them a step apart.
- **Bareheaded figures read as bald** without hair drawn as parts over the model's cap; close up, the model's hair
  reads as a cap and coats as slabs, so keep figures full length rather than close.
- **Seated figures look like busts on a shelf** until they get laps, knees and shins as parts.
- **Captions that say what the picture shows are redundant.** The sleeve carries the plate's facts (number, exposure,
  stop, wind) and the lyric, nothing that explains.
- **Silverpoint read as rain** while its strokes were sparse and random. Even hatching whose weight follows the tone,
  plus a finish map, reads as drawing.
- **Relief:** panels painted after the pilasters covered them where they met (paint pilasters last); even-odd shapes
  (an arcade) filled their holes in the height map until the fill rule was passed through (`rule: 'evenodd'`).
- **Nothing still for long.** Every plate drifts its camera and keeps exposing; a hold of more than a beat or two reads
  as the player freezing.
- **One bad value in a gradient blanks the frame.** Check the console after every load; the still tool prints it.
- **Stale scripts:** serve with `tools/serve.py` (no caching), and reload with a new query after an edit.

