# Screenprint

A music video made of screenprints: posters pulled by hand, one ink at a time, on cheap cream paper. Each ink is a
flat, see-through colour that prints through its own hand-cut stencil, so where two inks cross they make a third (red
over sky blue makes maroon), and tone is made of halftone dots at each ink's own screen angle. The engine simulates
what makes a real one look hand-made: stencil edges that are slightly ragged, ink that lies unevenly, light streaks
where the squeegee starved, dust pinholes, and screens that never quite line up (you can see it in the crosshair
marks in the margins). The picture changes the way a print shop would change it: each ink lands in one squeegee pass
on a beat, parts of the picture print in one after another, poses change by reprinting (stop-motion), and screens slip
out of register when something shakes the press. Figures are real 3D bodies, ray-marched in WebGL and cut into
stencils, with hands whose fingers are posed joint by joint and faces reduced to a few hinted marks. The lyrics are
typed on a strip of purple ditto songsheet under the print, and at the end the sheet lifts off the press.

![A windblown figure holding their hat and a kite string on a halftone hillside, trees and washing behind](img/hero.jpg)

| | |
| --- | --- |
| ![The title card, pulled one ink a beat](img/title.jpg) | ![Leaves hanging from a branch, trembling in stop-motion](img/leaves.jpg) |
| ![The figure close up in a gust, eyes shut, hand on the hat](img/closeup.jpg) | ![Washing billowing on the line, a hand reaching in from each side](img/washing.jpg) |

## Looks in this family

The style lab draws two of the demo's scenes in each look:

- **Screenprint** (the demo): flat inks multiplied on paper, halftones, misregistration. ![](img/look-screenprint.jpg)
- **Slab glass**: the same print re-read as thick chunks of coloured glass set in concrete and lit from behind, as in
  a 1960s church window. ![](img/look-glass.jpg)
- **Pressed flowers**: the same scene laid out on a page of a gardener's notebook, living things in pressed petals and
  leaves, built things in pencil. ![](img/look-pressed.jpg)

## Run the demo

From the repository root:

```
python tools/serve.py
```

then open http://localhost:8000/styles/screenprint/index.html. Press Play (or Space). The page plays live: the first
time you press Play it prints every scene first (a few seconds, with a counter on the button), then plays in step
with the song. If the audio can't load, it plays on a silent clock. Add `#t12.5` to the address to see a still of
12.5 seconds with no page furniture.

Stills and a contact sheet:

```
python tools/still.py styles/screenprint/index.html 2 6 12.5 0:37.5:2.5 --out renders/screenprint --sheet
```

The MP4 (a quick 720p preview with `--fast`; leave it off for 1080p plus a 720p copy):

```
python tools/render_mp4.py styles/screenprint/index.html --out renders/screenprint.mp4 --fast
```

The whole 37.5-second demo (900 frames) renders in about 4 minutes here with `--fast` (0.26 s a frame, with other
renders sharing the machine; a busier run took twice that). Most of the time goes on reading each frame back and
encoding it, plus printing each scene the first time it's needed; drawing a frame itself takes a millisecond or two.

Two working pages sit beside the demo:

- `still.html?s=<name>` prints one scene whole, with no camera or timing (`title`, `hill`, `hillBow`, `leaves`,
  `closeup`, `closeupGust`, `washing`), and `still.html?s=figures` shows the raw figure model (materials in false colour
  above, shade below), for posing figures. Both work with `tools/still.py ... --query s=hillBow`.
- `facelab.html?mode=marks` prints eight heads with one face treatment (`shade`, `two`, `marks`, `blank`), showing the
  figure options: short hair, curls, long hair blown sideways, a domino mask, pointed ears, a hood with a fur edge,
  glasses, braids.

## How it works

Plain canvas 2D, plus one WebGL shader for the figures. No libraries; fonts from Google Fonts (Special Elite for the
typing, Oswald for poster lettering, Kalam for handwriting). The scripts are plain `<script>` tags sharing global
names, loaded in this order:

| File | Job |
| --- | --- |
| `../../examples/poem/lyrics_data.js` | `window.SONG`: the song's timing (lines, word times, beats, sections) |
| `core.js` | sizes, seeded random numbers, noise, polygon helpers, an invented script for signs, `fontsReady()` |
| `print.js` | the medium: `Print` (a sheet and its inks), paper, the halftone, `composite()`, the songsheet strip |
| `figure.js` | the ray-marched figure: head, body, arms by IK, five-fingered hands, coat, hat, hood, scarf, fur |
| `ink.js` | putting a figure into a print (which ink takes which material, the face treatments), things attached to heads, and revealing parts of a print |
| `engine.js` | scenes, baking prints, pose patches, reveals, slipping screens, sprites, the camera, the lyric strip, drawing one frame |
| `props.js` | the demo's things: trees that bend, leaves, washing that billows, clouds, grass, the kite, flying leaves, the figure in the wind, a hand reaching in |
| `sc_title.js`, `sc_hill.js`, `sc_leaves.js`, `sc_closeup.js`, `sc_washing.js` | the demo's scenes |
| `timeline.js` | `SHOTS`: which scene is on screen when, and the camera |
| `player.js` | playback, `#t` stills, and the `window.__video` hooks the render tools call |

### A print

The frame is 1920 x 1080. A print is a sheet with margins; the image area is `IX, IY, IW, IH` (44, 34, 1832, 866) and
scenes draw in image coordinates (0..1832, 0..866). The songsheet lies in the bottom margin.

```js
const P = new Print({ paper: 'cream', seed: 71, inks: inkSet([
  ['sky', 15, 11, [2, -2, .03]],   // name (a colour in INK), screen angle (deg), halftone cell (px), [dx, dy, rotDeg] off register, density
  ['ochre', 0, 9, [3, 2, .05]], ['red', 15, 8, [2, -3, .06]], ['black', 45, 8, [0, 0, 0]] ]) });
P.fill('ochre', pts);          // solid ink through the stencil (edges roughened with wobble)
P.tone('sky', pts, .4);        // a halftone at 40%: dots at the ink's own angle (draw gradients into P.T('sky') too)
P.tint('skin', pts, .55);      // flat partial coverage, no dots (skin)
P.line('black', pts, 3);       // a stroke in the key
P.knockAll(pts);               // cut a shape out of every ink, so what's drawn next doesn't overprint what's behind
P.group('kite'); ...; P.group(null);  // everything knocked out meanwhile is recorded as the 'kite' group's mask
P.build();                     // turns the masks into textured ink layers (the slow step: about 0.5 s a full sheet)
P.composite(g, { pull, off, mono, alpha });  // multiply the inks onto the paper
```

`composite` options: `pull: { ink: 0..1 }` is how far each ink's squeegee pass has got down the sheet (a wavy wipe);
`off: { ink: [dx, dy, rotDeg] }` replaces an ink's registration (slipping screens); `mono: [r, g, b]` prints every
screen in one colour (each at its `MONO_DENS` weight, or `monoDens`), and `alpha` thins the pass.

Paint order matters as in real printing: draw what's behind first, `knockAll` each thing in front before filling it.
`S(ink)`, `T(ink)` and `Tn(ink)` give the raw stencil, tone and tint contexts for anything the helpers don't cover
(text with `fillText`, gradients, figure layers).

### Baking, patches and groups

Building a print is slow, drawing it is fast, so each scene builds its prints once and keeps flattened canvases:

- `bake(P, { keepInks })` flattens a print and returns `{ full, groups, P, rect, ox, oy }`. Keep the inks
  (`keepInks: true`) only for prints you'll pull in ink by ink or slip out of register; that costs 8 MB an ink.
- A **patch** is the same scene built again with one thing changed, printed only inside a rectangle:
  `new Print({ ...opts, patch: [x, y, w, h] })`. The noise, halftone and pinholes are keyed to sheet position, so a
  patch lines up seamlessly with the whole sheet. `drawPatch(g, B)` lays it over. That's a stop-motion pose change.
- A **group** is the part of the picture a thing owns. `reveals(groups, { name: time }, t)` and
  `revealOver(g, baseFlat, full, reveals)` wipe groups in over a base print on their times;
  `pasteGroups(g, B, { name: time }, t)` does the same from any baked print or patch, which is how the hill shows the
  washing and the figure each in their current pose over the landscape's current pose.
- `spritePrint(opts, w, h, draw)` prints a small thing on its own (a kite, a leaf) to draw over the sheet with
  multiply as it moves.

### Figures

```js
const spec = windFigure(30, { look: 1 });            // props.js builds one; the fields are documented in figure.js
const F = placeFigure(P, spec, x, y, WIND_STYLE());   // knock out its silhouette, print each ink, add the face marks
```

`renderFigure(spec)` ray-marches a figure into a buffer of shade, material and plain light (cached by spec).
`figStyle({...})` says per material which ink fills it, where its shadows go into the black key (`dark`) and how much
halftone shadow it gets. Arms are placed by IK: `{ to: wrist [x, y, z] in body space, pole: the elbow's side, palm: the
palm's normal, curl: [thumb, index, middle, ring, pinky] 0 open .. 1.4 fist, spread, thumb }`; `handAt(arm, side,
point)` puts the palm, not the wrist, on a point (a hat's crown). Head units: the head is about 2 units tall, its
centre at the origin, y up, z toward us. There are no legs; a coat's hem ends the figure and a scene draws legs in 2D
(`windLegs`).

`FACE_MODE` in `ink.js` sets how skin prints: `'marks'` (flat skin, a light shadow side, hinted brows, dot eyes that
follow the gaze or a lowered lid when `gazeY <= -.3`, a nose line, the mouth) for close figures; `'blank'`
(`CROWD_FACE_MODE`) for crowds; `'two'` and `'shade'` to compare. `curlCloud`, `hairLocks`, `pointedEars`, `glasses`
and `braids` attach cut shapes to a posed head through `figProj(spec, x, y).head`.

### The timeline

A scene registers `SC[name] = { build: () => data, draw(g, t, data, shot) }`. `draw` paints the whole sheet for song
time `t`. `timeline.js` lists shots; this is the close-up's:

```js
{ t: lineT(3), sc: 'closeup', cam: [[lineT(3), 1.0, 960, 540], [CLOSE_T.gust - .05, 1.05, 900, 500], [lineT(4), 1.03, 940, 525]],
  shake: jolt(CLOSE_T.gust, 18, .4) },
```

Camera keys are `[time, scale, focus x, focus y]` in sheet pixels, eased between keys; a key .02 s after another is
a hard cut in framing. Below 1x the sheet shows on the dark press bed. The last shot has `lift: time`, when the sheet
starts lifting off the press. And this is the close-up's own timing, straight from the words:

```js
const CLOSE_T = { pulls: { sky: lineT(3), ochre: lineT(3) + .15, ... }, fig: wordT(3, 1), kite: wordT(3, 2), gust: wordT(3, 4) };
const CLOSE_S = [[0, 0], [wordT(3, 3), 1], [wordT(3, 4), 2], [wordT(3, 4) + BEAT, 1], [wordT(3, 4) + 2 * BEAT, 2]];
// draw: pull the sky, reveal the figure on "wind", then show the pose stateAt(CLOSE_S, t) on the beats
```

`lineT(l)` and `wordT(l, w)` (0-based) come from `SONG`, as do `beatT(n)`, `BEAT` and `sectionT('outro')`.

### Lyrics

`lyricAt(t)` types the current line word by word on the songsheet strip (`songsheet()` in `print.js`): purple ditto
ink with a soft bleed under a sharper line. Lines that come back (a refrain) are underlined by hand once typed. The
intro types `SONG.title` and `SONG.credit`, and the last line stays up through the outro. The strip lies on the sheet:
it moves with the sheet when the camera shows the whole sheet (and lifts with it at the end), and stays put in screen
space when the camera is in close, so the words stay readable.

### Determinism and caching

Every random choice is seeded or keyed to sheet position; anything that moves on its own (flying leaves, the kite,
slipping screens, trembling) is keyed to the frame number on twos (12 a second), so `renderAt(t)` and `step(t)` always
draw the same picture. Scenes are printed the first time they're needed (`need(name)`) and the least recently used
are dropped past `MAX_BUILT` (5), so a long song never has to hold every print at once. `FIG_CACHE` keeps figure
renders while a scene builds and is cleared after.

## Make your own video in this style

1. **Copy the folder**: `cp -r styles/screenprint projects/my-song` (see [docs/your-own-video.md](../../docs/your-own-video.md)).
   Delete `lab/` if you don't need it.
2. **Time your song**: make a `lyrics_data.js` for it with `tools/audio/to_js.py`, and point the first `<script>` in
   `index.html` at it. `SONG.audio` is resolved relative to `index.html`. The title card and the songsheet read
   `SONG.title`, `SONG.credit` and the lines by themselves.
3. **Keep** `core.js`, `print.js`, `figure.js`, `ink.js`, `engine.js`, `player.js`. **Replace** the `sc_*.js` files, the
   `SHOTS` in `timeline.js`, and whatever you don't need in `props.js`; update the script list in `index.html`.
4. **Write a scene.** The pattern every demo scene follows:

   ```js
   const MY_INKS = [['sky', 15, 11, [2, -2, .03]], ['red', 15, 8, [2, -3, .06]], ['black', 45, 8, [0, 0, 0]]];
   const myOpts = patch => ({ paper: 'cream', seed: 5, patch, inks: inkSet(MY_INKS) });
   function buildMine(P, o = {}) {
     skyGrad(P, 'sky', 0, IH, .2, .9);                          // the background, always printed
     if (o.sun) { P.group('sun'); const s = ellipsePts(1300, 300, 150, 150, 48); P.knockAll(s); P.fill('red', s); P.group(null); }
     return P;
   }
   const MY_T = { pulls: { sky: lineT(0), black: lineT(0) + BEAT }, sun: wordT(0, 3) };
   SC.mine = {
     build: () => { const base = bake(buildMine(new Print(myOpts())).build(), { keepInks: true });
       return { base, baseFlat: flatten(base.P), full: bake(buildMine(new Print(myOpts()), { sun: 1 }).build()) }; },
     draw(g, t, D) {
       if (t < MY_T.sun - .3) return D.base.P.composite(g, { pull: pulls(MY_T.pulls, t) });   // inks landing a beat apart
       revealOver(g, D.baseFlat, D.full.full, reveals(D.full.groups, { sun: MY_T.sun }, t));   // the sun prints in on its word
     },
   };
   ```

   and add a shot: `{ t: lineT(0), sc: 'mine', cam: [[lineT(0), 1, 960, 540], [lineT(1), 1.05, 960, 520]] }`.
5. **Time a move to a word or beat**: land events on `wordT(line, word)` or `beatT(n)`; `wipe(t, te, d)` is 0..1 over
   the `d` seconds before `te`, so a pull or reveal *lands* on the beat. For poses, bake the variants and switch with
   `stateAt([[time, pose], ...], t)`.
6. **Useful knobs**: an ink's `off` (how far out of register it prints), `angle` and `cell` (the halftone screen), and
   `density`; `slip(P, amount, t, { size, only })` for a shiver or a gust; `FACE_MODE`; the paper (`'cream'`,
   `'news'`, `'white'` or an `[r, g, b]`); `MAX_BUILT`; `LIFT_DUR`, `END_FADE` and `HOLD_LAST` in `engine.js`.
   Keep something moving in every shot: a pose change every beat or two, a camera drift, sprites on twos.

## Lab

`lab/index.html` (serve the repository, then http://localhost:8000/styles/screenprint/lab/index.html) draws the
demo's hillside and branch of leaves in each look; the buttons switch, or use `?scene=hill&style=glass`. Stills of
every combination:

```
python tools/lab_stills.py styles/screenprint/lab/index.html --all --out renders/lab --sheet
```

- **screenprint** composites the scene's print as the demo does (with the kite printed into the sheet instead of
  flying over it).
- **glass** (`lab/glass.js`) re-reads that same print: each ink's coverage is blurred until its dots melt into tone and
  the inks are multiplied back into a flat colour map; k-means picks 14 colours, each made into glass (more saturated,
  dark inks lifted to deep colour, paper and near-white to milky opal); the map is broken into Voronoi chunks sized by
  how much area each colour covers; concrete joints run round every chunk and along every change of colour; chunk
  edges are chipped bright; and the panel glows through a window with mullions. It works on any print, so it will
  turn your own scenes into glass too.
- **pressed** (`lab/pressed.js`) draws each scene from its layout (`HILL`, `crestY`, `BRANCH`, `LEAVES`): pencil for the
  land, the posts, the line and the house; petals, leaves and stems for everything alive; the washing and the kite cut
  from pressed pieces; a marigold for the sun; tape and a pencilled label. `pressedFigure()` lays the ray-marched
  figure in petals by material and pencils its face with the same hinted marks the print uses.

## Performance

Measured in headless Chrome on an Apple M-series Mac with the GPU on, while other renders were running (so an idle
machine will be quicker):

- **Drawing a frame** once its scene is printed: median 0.3 ms, 90% under 1.5 ms, worst about 15 ms. Compositing six
  full-size ink layers with multiply is cheap on the GPU.
- **Printing** (`Print.build()`): about 0.5 s for a full sheet of six inks, 0.1 s for a figure-sized patch, 0.1 s to
  ray-march a figure. Each scene prints several sheets and patches: the title about 1 s, the hillside 5-6 s (its base,
  its full print, four tree poses, two washing poses, the figure turning), the leaves 3.5 s, the close-up 5.5 s, the
  washing line 4.5 s. Pressing Play prints them all first, so it waits 10-25 s the first time.
- **Memory**: the title about 50 MB, the hillside 90, the leaves 135, the close-up 90, the washing line 95; about 455 MB
  with all five held (`MAX_BUILT = 5`). Most of it is ink layers kept for pulls and slips (8 MB a full-sheet ink;
  `bake()` crops each kept layer to what it printed). A longer video should set `MAX_BUILT` lower and let scenes
  print as they come up.

What makes it slow: `Print.build()` loops over every pixel of every ink in JavaScript (about 2 million pixels a
full-sheet ink), so the cost is inks x area; patches only pay for their rectangle. Keeping inks costs memory, not
time. Figures are cheap (a WebGL pass each), but `placeFigure` reads the buffer back once per ink.

To render a slice: `python tools/render_mp4.py styles/screenprint/index.html --start 11.25 --end 18.75 --fast`. A frame
depends only on its own time (the scenes build on demand), so a slice matches the full render exactly and
`tools/splice.py` can put it back.

## Lessons and gotchas

- **Halftoned skin reads as sick.** Faces are a flat tint with a few hinted marks, and their shadow comes from a
  featureless head (`faceProxy` in `figure.js`), so it's one clean side of the face instead of islands round the eyes
  and nose. Keep the neck and lips out of the black key, or jaw shadow reads as a beard; a fill light keeps a backlit
  face from going solid.
- **In the flat face modes the lids aren't drawn**: shut eyes come from looking down (`gazeY <= -.3` draws a lowered
  lid line), not from the `lid` parameter.
- **Reveals leave holes** where something in front knocked out something behind that isn't revealed yet. Reveal front
  to back, or put front things in their own group or layer; and paste a group from a print that holds all of it.
- **Marks outside a group's mask never print in.** A line printed over other ink without a knockout isn't in any group;
  record it with `P.rec()` or `P.recLine()`.
- **Two things that change pose independently** can't share a patch: a patch of one repaints the other in its default
  pose. Put landscape poses in landscape-only patches and paste the moving things over them as groups (see
  `sc_hill.js`).
- **Slipping screens need the ink layers.** Only a print baked with `keepInks` can be composited off register; the
  flattened canvases can't.
- **Arms that end mid-sheet look like they float.** A hand reaching in has a sleeve that runs on off the sheet's edge
  (`reachingHand`).
- **Things moving over a print look digital if they glide.** Sprites move on twos and are printed themselves
  (`spritePrint`), with their own halftone and registration.
- **A stretch where nothing happens reads as the player freezing.** Put something on nearly every beat: a pull, a
  group printing in, a pose, a slip; keep the camera drifting between.
- **Flat-poster cuteness** is the risk of the style. Keep the ink texture and visible misregistration, real
  proportions in the figures, stop-motion pose changes rather than bobbing, and grown-up poster design.
- **Blocks of black standing in for text read as censorship.** For writing that shouldn't be read, use the invented
  script (`runeLine`) or a scribble.
- **Load the fonts before building.** A print bakes its text into a stencil once; if the web font hasn't arrived, the
  fallback font is baked in for good. The page awaits `fontsReady()` first.
- **One bad number in a canvas gradient blanks the whole frame**; check the console (the still tool prints it).
- **Memory**: a whole song's prints don't fit at once, so scenes build when first needed and the oldest are dropped.
- **The play overlay never hid** until `.gate[hidden]{display:none}`: `display: grid` beats the `hidden` attribute.
- **Changing only the `#t` part of the address doesn't reload the page**; after editing code, reload.
- **Glass from a print**: blur the inks before clustering colours, or every halftone dot becomes its own chunk of glass.

