# 99 · 说明书插画 / Instruction Manual Art

来源类型：官方风格原文 + 本库中文执行模板  
原作者：Lemo-Opuscar by Lemomo (LemoLab)  
上游原文：https://github.com/lemomo-ai/lemo-opuscar/blob/8ca0dd805e214bcc1d30714cd5b9d21cc02a454b/styles/instruction-manual/STYLE.md  
固定版本：8ca0dd805e214bcc1d30714cd5b9d21cc02a454b  
抓取核对日期：2026-11-24  
本库改动：中文任务模板、中文摘要与编排；原文全文保留。

## 使用前先看

- 保持45度方位与约35.264度俯角，不绕物体转镜；先出箭头再移动，新增零件落位后恢复白色。
- 30fps，逐状态表核对零件数量与装配关系；手掌、指尖与遮挡分别检查，最终整页至少停2.5秒。
- Lemo-Opuscar by Lemomo (LemoLab), https://github.com/lemomo-ai/lemo-opuscar 。风格原文、公共规范及其改编文档按 CC BY-NC 4.0（https://creativecommons.org/licenses/by-nc/4.0/）署名非商业共享；本库新增中文模板与编排。上游另允许为自己的影片（含商业及客户影片）读取、复制、改编文档并随该片项目交付，超出该范围的商业产品、服务或文档再发行需另获授权。代码 MIT、示例画面 CC BY 4.0 仅覆盖可授权部分，第三方素材、六项示例旁白和 Clawd 等另有例外。详见 ATTRIBUTION.md 与 sources/upstream/lemo/LICENSE。
- 案例图许可：CC-BY-4.0；署名与第三方资产详见 sources/upstream/lemo/styles/instruction-manual/demo/CREDITS。六项示例配音的限制也适用于整段原影片，不能只凭画面许可转发音轨。

- 这是代码渲染工作流；聊天文本本身不会自动产生 MP4，需有可执行的项目环境。
- 先看预览再做长片；不要把示例素材的许可自动套到自己的歌曲、照片、字体和品牌上。
- 下方复制区包含全部风格与公共规范，不要求 AI 另外从本机隐藏路径读取文件。

## 完整复制区

【来源与许可】
Lemo-Opuscar by Lemomo (LemoLab), https://github.com/lemomo-ai/lemo-opuscar 。风格原文、公共规范及其改编文档按 CC BY-NC 4.0（https://creativecommons.org/licenses/by-nc/4.0/）署名非商业共享；本库新增中文模板与编排。上游另允许为自己的影片（含商业及客户影片）读取、复制、改编文档并随该片项目交付，超出该范围的商业产品、服务或文档再发行需另获授权。代码 MIT、示例画面 CC BY 4.0 仅覆盖可授权部分，第三方素材、六项示例旁白和 Clawd 等另有例外。详见 ATTRIBUTION.md 与 sources/upstream/lemo/LICENSE。

你是一位能写代码、检查画面并渲染成片的动画导演。请用“说明书插画 / Instruction Manual Art”制作一个属于我的视频。

【我的需求；把花括号内容换成实际值】
主题与一句话故事：{{填写主题和结尾变化}}
用途与观众：{{例如面向普通观众的科普短片}}
内容依据或已有脚本：{{填写；没有则说明需要你写}}
音频、歌词、图片、数据、品牌素材路径：{{填写；没有写“无”}}
素材使用权限与需显示的署名：{{填写来源与许可；不清楚请列待确认项}}
目标时长：30 秒起步；MV 以实测歌曲时长为准
画幅与清晰度：默认横屏 16:9、1920×1080；帧率按本风格原文与引擎规范，未规定时24fps；竖屏须重新构图，不直接裁横屏
语言：简体中文；配音需求：{{有/无、声线与语速}}
必须出现的内容：{{填写}}
禁止出现的内容：{{填写}}
预算与速度：先做低成本验证，再渲染完整片
个人工程名：my-video（可改为英文短名）
确认方式：先给 3 张由真实渲染代码产出的样帧和 5–10 秒预览；我确认风格后再做完整成片

【本风格的核心实现】
用固定等距角度的说明书插画分步装配，白色零件、三档明度与黄色新件形成可回看的整页。
特别检查：
- 保持45度方位与约35.264度俯角，不绕物体转镜；先出箭头再移动，新增零件落位后恢复白色。
- 30fps，逐状态表核对零件数量与装配关系；手掌、指尖与遮挡分别检查，最终整页至少停2.5秒。

【工程与流程】
1. 在工作区单独克隆 https://github.com/lemomo-ai/lemo-opuscar ，检出 8ca0dd805e214bcc1d30714cd5b9d21cc02a454b，保留上游原目录供渲染工具和相对路径使用。图册只归档提示词文档，没有打包全部视频源代码。
在独立个人工程目录实现，参考 styles/instruction-manual/STYLE.md；不得把示例电影的故事、角色、文案、音轨当成我的需求。先读风格规范与 DIRECTOR.md、TECHNIQUE.md。Windows 的 sh 命令在 Git Bash 或 WSL 执行。window.TEXTS(t) 的 pass: true 只用于无需完整阅读的路过文字，不能用于观众必须读懂的信息；字幕另按 SRT 检查。
2. 先检查机器的 Python、Node/浏览器、FFmpeg、字体与 GPU 能力。Lemo 当前要求 FFmpeg 7+；先用 ffmpeg -version 核对。缺少工具或访问权限时明确报告缺什么，不能只描述完成、伪造文件或把截图称为已渲染视频。
3. 把我的需求写成 PLAN.md 或 TREATMENT.md：一句话故事、分镜、逐镜秒数、镜头运动、文字位置、音乐与声音 cue、所需素材、预计成本。涉及事实和数据时写 FACTS.md；没有来源的数字不填。
4. 按主题写旁白并实测音频时长；无需旁白时用画面和声音讲清楚。
5. 先完成 3 张代表开头、关键变化、结尾的样帧，逐张检查；再渲染 5–10 秒低清短段，检查字幕、运动、音画同步与控制台。复杂慢风格先计时，再估算整片。
6. 随机效果固定种子；有历史累积的媒介按顺序渲染。并行前先比较随机抽帧与连续渲染是否一致。
7. 正式导出使用项目文档中的工具与参数，不臆造命令。交付可播放 MP4、720p 预览、源代码、素材清单与许可、字幕（有台词时）、复现说明；保留最终片长、帧率、音频响度与实际渲染耗时。
8. 实际打开并检查成片开头、中间、转场、结尾及全片联系表，确认没有空帧、字体回退、遮挡、裁字、爆音或无意复制的作者片尾签名。交代尚未完成的检查。

下面是完整风格参考与公共制作规范。它们是上游参考资料，不代表我的主题或逐字台词；我的具体需求优先。风格中明确的声音、镜头和媒介限制优先于公共建议，例如无声电影不添加旁白或拟音。遇到 macOS/Linux 示例命令时按当前系统等价转换，不直接在 PowerShell 粘贴 bash 命令。相对资源路径以完整克隆的上游工程为准。


===== 完整风格原文：styles/instruction-manual/STYLE.md =====

# Instruction Manual Art — Style Prompt

> The film is a printed assembly manual: one sheet of off-white paper, black line art in true isometric (45°), flat white parts, faceless people at real proportions, and the manual's own signs (step numbers, parts call-outs, dotted guide lines, flat arrows, magnifier circles, a do/don't box) telling the story. The view never turns; the camera only travels over the page.
> References (grammar only): flat-pack furniture and construction-toy building manuals, aircraft safety cards. Borrow the signs (step number, parts box, do/don't, magnifier, arrow), never a brand's name, logo, figure design, colours or product codes.

## 1. Essence, and what it is not

Rules (they define the style):

- **One angle: true isometric, orthographic.** Azimuth 45° (every object is seen across one vertical edge), elevation 35.264° (arctan 1/√2): the three axes meet at 120° on screen, horizontal edges run at 30°, vertical edges stay vertical, nothing gets smaller with distance. The whole film keeps this one angle.
- **The frame is the paper.** The page is seen square-on; there is no desk, no folded card in 3D, no perspective on the sheet. Every shot is a part of one printed page.
- **Line art with flat fills.** One ink line weight, flat colour, at most three values per object (top lightest), no gradients, no cast shadows.
- **Yellow means "new in this step".** The part added in a step is safety yellow and turns white once it is fitted. Nothing else is yellow (the subtitle marker excepted). The audience learns this in the first steps, so a late yellow can carry the ending.
- **The manual's signs do the explaining**: step numbers, parts boxes with counts, dotted guide lines, arrows lying in the isometric planes, rotation arrows, magnifier circles, a do/don't box, a "click" mark. On-screen words are only numbers and counts.
- **Faceless people at real proportions** whose hands always do something.

Not Isometric Infographic (no coloured diorama, no data panels), not Isometric People Scene (no painted scene, no faces), not Blueprint (dark ground, technical dimensions), not Exploded Teardown (no rendered product, no photoreal materials), not a slide deck (no header bars, centred titles or page turns).

## 2. Materials & rendering

- **Projection**: world units in centimetres, y up; `makeView({cx, cy, s, az: 45, el: 35.264})` maps world → screen. A sphere always projects to a circle, so limbs, hands and cylinders are hulls of circles and stay right at any heading.
- **Painter's order by view depth.** Long parts (rails, posts) are sorted by their nearest point; an assembly that interlocks is drawn in groups from back to front (far end and back rail → the board and what lies on it → front rail, near end, bolt heads), so large flat parts never cut through bars.
- **Fill, then outline, per part**: overlapping parts are separated by a line, a part has no lines inside itself.
- **Paper**: off-white stock with faint fibres that travel with the page on a pan and keep their size on a zoom (printed stock, not a photo of it).
- **Line weight is set in screen pixels** (2.6 px at 1080p) and follows the zoom only partly (about z^0.55, clamped), so the whole page stays crisp when pulled back and lines don't go clumsy close up.
- **Appearing** (reference): a drawing first shows its complete line art with paper-coloured fills, then its colours come in over it. A part is never drawn half-built or floating.
- **Motion blur** (reference): pans smear one frame along the camera path; fast zooms average sub-frames across half a shutter.
- **Hands in close-up** (reference): when only hands are in frame (a magnifier, a "press here" shot), draw them finer than the full-body figures: a palm, a thumb and four separate fingers at real size (≈ 18.5 cm wrist to fingertip), white like the skin elsewhere, and the line where one finger overlaps the next is all that says "fingers" (one or two lines, no nails, creases or shading). The sleeve is the wearer's shirt colour (her light grey `#CFCBC2` reads best against white hands and parts; a white sleeve keeps its cuff line) and runs on until the frame or the magnifier's rim cuts it: an arm never ends inside the frame. Bring the arm in from the nearest edge, so the forearm crosses at most about a third of the frame, and place the hand by what it touches (the fingertip on the button, the palm on the jar). `demo/hand.js` does this; its check sheet is `?f=hands`.

## 3. Colour logic

| Role | Example (our demo) | Rule |
|---|---|---|
| Paper | `#F4F1EA` | ground |
| Ink | `#1E1D1B` | every line, arrow, number |
| Fitted part (top / left / right) | `#FFFFFF` / `#ECE8DF` / `#DCD7CC` | three flat shades |
| New part (top / left / right) | `#F7D35A` / `#F2C230` / `#DEAA1F` | only the part added in this step |
| Greys | `#CFCBC2` / `#9C988F` / `#6B6862` | clothes, trousers, shoes, hair |
| Metal | `#D9D7D1` / `#BDBAB3` / `#A3A099` | bolts, tools |
| Signal red / blue | `#D23A2E` / `#2C66AC` | only the ✗ and the ✓ |

The exact hexes are reference; the logic (paper, ink, white parts in three values, one reserved yellow, red/blue only for verdicts) is the style.

In a procedure that removes or changes things rather than adding them (opening, cleaning, a safety step), yellow marks the one thing the reader acts with or on in that step (the tool, the button, the part that comes off), and returns to white once the step is done.

## 4. Type & subtitles

- On the page only step numbers (a geometric sans, e.g. Inter 700, about 150 px at 1:1, top left of each step's area, printed on the paper and moving with it) and counts in parts boxes ("4×", Inter 600). Everything else is said by drawings and the voice.
- **Subtitles** bottom left, left-aligned: Chinese (e.g. Noto Sans SC 500, 38 px) over English (Inter 500, 32 px, ink at about 78 %), one line each, an 8 px yellow bar on the left marking the line being spoken. No box, outline or shadow; a soft paper-coloured bed (same colour as the page) keeps them readable over line art. Keep subjects out of that corner.
- A title, if any, is printed on the page like a manual's cover or footer, never a title card over the picture.

## 5. Motion quality

- Parts fly along dotted guide lines in straight paths, ease in, and stop with a small settle; a beat of stillness after each one lands.
- Arrow first, motion second: the arrow is drawn, then the part follows it once and holds.
- The new part's yellow fades to white once it is fitted.
- People move between a few key poses with eased interpolation; walking is short shuffled steps when carrying.
- Never moves: the angle, the page, the step numbers' positions.
- **Frame rate and grain**: 30 fps (parts glide along their guides without stepping); mux grain 1, since the paper fibres carry the texture.

## 6. Camera grammar

The camera is a 2D camera over one long sheet: pan, whip, tilt, push, pull, and cuts. It never rotates the view.

| Move | What it expresses | Can serve |
|---|---|---|
| Push into a parts box / object | "this one" | an opening; a detail |
| Pan or whip along the page to the next step | progress | the next step; skipping dull steps |
| Tilt to the next row, the step number entering first | a new stage | a change of section |
| Locked frame on a do/don't box | judging | a rule; a common mistake |
| Push through a shape (the ✓ cell, a magnifier circle) | going into the detail | the right way, shown big; a close-up |
| Shape-matched cut (a bolt head → a round knob) | jumping to the consequence | a mistake revealed; a time jump |
| Pull back to the whole page | the full sequence, the result | an ending; a summary |

Leave a step held still long enough to read its count and its arrow; the subject is at least a third of the view when it is the point.

## 7. Sound palette (reference)

- A small tidy ensemble that counts steps: pizzicato strings, marimba, glockenspiel, felt piano; one bright note per part landing, rising through the chord.
- Paper and flat-pack foley: a carton set down, a lid, wood knocking, a pencil, paper sliding, bolts, a ratchet, the click, a rubber stamp for ✗ and ✓.
- A mistake stops the music dead before the ✗; the ending is near silence, then a single chime.
- Voice (optional): a calm, dry narrator, as if the manual itself were speaking; few words, never reading out the numbers on the page.
- Mix: voice compressed and about 10 dB over the music, music gives way at 300 Hz–4 kHz under it; −14 LUFS, true peak ≤ −1 dB.

## 8. Native moves

- **Parts explosion.** The box opens and its parts fly along their own dotted lines to a counted parts list. *Fits content like:* unboxing; a kit's contents; what a product is made of.
- **Line art grows.** Floor line → object → people → arrows → magnifier, then the flat colours. *Fits content like:* a step being built up; a scene appearing.
- **Arrow-driven assembly.** A flat arrow in the isometric plane, then the part follows it and lands. *Fits content like:* any fitting, inserting, sliding step.
- **New part yellow.** The new part is yellow, then turns white. *Fits content like:* what changed in this step; the one new thing at the end.
- **Magnifier circle.** A small ring on the spot, a leader line, a big circle redrawn at 3–4× with a hand and a rotation arrow. *Fits content like:* tightening, pressing, a latch, a connector.
- **Do / don't box.** One white rounded box split in two: red ✗ beside blue ✓, drawn as strokes. *Fits content like:* safety rules; common mistakes; two ways to hold something.
- **Push through a shape.** The camera dives into the ✓ cell or a magnifier circle and comes out in the next picture. *Fits content like:* zooming into the right way; changing scene inside one page.
- **The whole page.** A final pull back shows every step laid out on one sheet. *Fits content like:* a summary; the full procedure at a glance.

Our demo opens on the parts explosion, uses the push through the ✓ cell as its turn and ends on the whole page. A new film opens and ends another way: a single part flying between cells, a shape-matched cut, a magnifier that opens the film, or an ending on the one last yellow part.

## 9. Pitfalls of the medium

- **The assembly must be one model with a state table.** Every picture of the object (every step, the parts list, the final page) is drawn from the same function with a state; write the table first (step → what is added → what the object has when the step ends → parts used) and add one thing per step. Counts on the parts list must add up across the steps (e.g. bolts 2 + 2 + 4 = 8). Separate drawings per step drift: parts appear early, vanish, or sit in the wrong place.
- **Footprints and guide lines come from the same geometry.** A dotted footprint must be the finished object's real corners; a guide line runs from where the part lies to where it lands. Parts in a box lie flat, stacked at real sizes, and the box is empty only after the last one leaves.
- **Knees bend with the body, not the world.** Set the knee hint from the body's heading, or a pose that is right facing one way breaks when the figure turns.
- **Kneeling hip height comes from leg length**: knee on the floor + one thigh length. A half-kneel: the kneeling knee under the hip, thigh vertical, shin and instep flat behind; the other foot flat, knee about 90°, shin vertical.
- **The far leg is one shade darker** than the near leg, so crossed or overlapping legs never merge into one shape.
- **Sitting on the floor**: cross-legged with the knees open and low and the shins crossed in front reads as sitting; a pelvis on the floor with legs straight forward reads as falling over.
- **Standing**: weight on one leg, the other relaxed and turned out, hips and shoulders tilted against each other. Feet together and arms hanging make figurines.
- **Placement**: never put a person between the viewer and what the step is about, and keep their feet outside the object's footprint. Behind slatted furniture their legs show between the bars and they read as standing inside it: put them at a front corner, or at one end with their back to the viewer.
- **A gesture that matters** (a hand on a shoulder) lands on the side nearest the viewer, with nothing in front of it.
- **Front-on (facing the viewer squarely) reads worst** at this angle; use three-quarter and profile headings.
- **Hair and buns** live in the head's own 3D frame, so they turn, tilt and hide with the head.
- **Small mistakes are hard to see at full-page scale**: a part on upside down needs the ✗ on it and a close-up, not only the voice.
- **No perspective, no turning the view**, no 3D camera orbiting the paper.
- **No brands, logos, product codes, faces or cartoon round-headed figures.**

## 10. Engine

- `demo/iso.js`: `makeView` (orthographic 45°, depth sort, `flush(g)`), `box` and `cyl` (both take `o.xf`, a rigid transform such as `rotAbout`, to tip a lid or swing a part), `prism`, `blob` (hull of spheres), `poly3`, `planeArrow` (an arrow lying in a world plane), `turnArrow` (an arc around an axis), `dashed`/`dashed3`, `cross`, `tick`, `roundRect`, `clickMark`, `rotAbout`; `setLW`, `setFillOverride` (line-art-first appearing), `setGhost`.
- `demo/rig.js`: `person(v, pose)`, two-layer body (pelvis carries the weight; chest leans, bends, twists), head frame with `lookAt`, hair and bun in the head frame, two-bone `ik` with knee and elbow hints; `mixPose`, `walkFeet`. `demo/poses.js`: stand, hands on hips, scratch head, read, half-kneel, sit cross-legged, lean on a rail; `lp` places points in a figure's own frame. A pose's `hands` are wrist targets: the palm centre sits 4.3 cm further along `handDir` and the fingertips 8.2 cm (times the figure's scale), so aim the wrist about 4 cm short of what the palm should touch.
- `demo/hand.js`: `hand(v, o)`, a hand in close-up (relaxed, flat, point, press, grip, pinch; placed by its wrist, its index fingertip `tipAt` or its palm centre `palmAt`), with the sleeve run out to the frame's edge or a magnifier's rim; `index.html?f=hands` shows every pose from the back and the palm side, and a few close-up shots.
- `demo/crib.js`: the one bed model `crib(v, state, overrides)` with its state table `S`, end panels, rails, base, mattress, bolts, `flipL` (the end turned over).
- `demo/page.js`: font names and the magnifier circle. `demo/film.js`: the long page, camera keys, the ten steps, footer, subtitles, motion blur, `window.EV` sound cues and `window.TEXTS` for the reading check.
- Minimal example: a box with a new yellow lid and an arrow.
  ```js
  import { PAL, makeView, box, planeArrow } from './iso.js';
  const v = makeView({ cx: 960, cy: 600, s: 3 });
  box(v, [0, 0, 0], [60, 30, 40]);                              // white body
  box(v, [0, 34, 0], [60, 36, 40], PAL.neu);                    // the new part, yellow, above where it lands
  planeArrow(v, [30, 50, 20], [0, -1, 0], [1, 0, 0], 12, 10);   // down, lying in a vertical plane
  v.flush(g);
  ```

## 11. Variation space

The agent decides the object, how many steps, which steps are told and which are skimmed, the people (or none), the page layout, the story under the procedure, and the music.

- **Structures**: a straight procedure with one mistake and its fix; a do/don't sequence of safety rules; one product's first five minutes; a manual whose last step is something no manual can show.
- **Openings**: a flat box set down; a parts list already printed, then exploded; one step number alone on the paper.
- **Endings**: the whole page; the finished object in its room; one last part turning yellow.
- **Range**: the object can be anything that assembles, operates or must be handled safely (furniture, appliances, tools, a tent, an emergency exit); pages can run in rows, a zigzag or a single column.

---

How our demo was made (story, shots, score, end card, build): [DEMO.md](DEMO.md). Read it after your treatment exists.


===== 完整公共规范：DIRECTOR.md =====

# Directing a Lemo-Opuscar film

The directing method behind every film in this library. Pair it with one `styles/<slug>/STYLE.md` (the style) and [`TECHNIQUE.md`](TECHNIQUE.md) (how to build).

You are the director, not a tech demo. A film is judged in this order: **sound, rhythm, camera, directing** (performance, staging, emotional arc). Good-looking frames are only the starting point.

---

## 1. Take the brief

The user gives a style and a topic, sometimes more (length, language, voice, must-have shots, brand rules). Everything else is your decision. Ask once, in a single message (AGENTS.md, Workflow), then no more questions. Defaults:

- Length **30–60 s**; shorter and tight beats padded. Beyond two or three minutes multiplies time and token cost: tell the user.
- 1920×1080 at 24 fps by default; an output frame rate set in the style's `STYLE.md` (30 or 60 fps, for example) wins, and is what you pass to `--fps` and `mux.sh`; other sizes (vertical 1080×1920, for example) with `--size WxH` on the render tools.
- Voice and subtitles in the language the user writes in. Subtitles burned in and exported as `.srt`.
- **The language on screen is the film's, not the demo's.** Many `STYLE.md` files set a Chinese line above an English line (subtitles, titles, labels): those are the two languages of our demos. A film in one language sets that line alone, in the upper line's place and size. A film in two keeps the stack, its main language on top. For another script, choose an openly licensed face of the same kind (weight, serif or sans, written or printed). The rest of the style's type stays: sizes, placement, how the text arrives.
- Loudness −14 LUFS.

Say it in the questions when it matters: a good Chinese voice uses Microsoft's online service (edge-tts) and needs a connection; offline, Kokoro reads Chinese but sounds plain (TECHNIQUE.md §4).

Requests that only change the plan:

- **No voice, or no subtitles.** Drop those steps and say so in the treatment.
- **Their own voice recording.** Use it as it is; transcribe it with faster-whisper for word timings.
- **Their own material**: logos, photos, footage, and for a style built from real data or scans (its `STYLE.md` says so) their own data, scans, imagery or CAD. Ask whether they have any; what they give comes first, and the sources in the `STYLE.md` are the fallback. Before you download from those sources, tell the user what you will fetch, from where and under which licence. Rights: section 12.

## 2. Find a benchmark first

Before writing anything, pick one or two reference works (films, title sequences, games, ads) that set the bar for this style **and this topic**. They are your choice, made for the user's film; don't borrow the demo's. Write down:

- **What to learn**: composition, pacing, camera grammar, colour logic, score structure.
- **What not to take**: characters, designs, melodies, specific shots, logos, fonts.

The benchmark lifts quality more than any rule below.

## 3. Shape the story

- **One subject, one goal, one turn.** A character (or a single object, product or idea) wants something, something changes, it ends differently from how it began.
- **Hook in the first 3 seconds.** No slow logo reveal before anything happens.
- **An ending that echoes.** Bookend the opening, reveal the scale, or let the character do the thing right the second time.
- **One native move**: a moment only this medium can do (a fold that becomes a transition, ink that blooms into the next scene, a type grid that snaps into the logo). Put it at the emotional peak. `STYLE.md` lists the medium's native moves; pick or invent the one your story needs.
- **Cut the extras.** One gag the audience reads at thumbnail size beats three they can't. If a beat needs explaining, remove it.

## 4. Write the treatment

Write `TREATMENT.md` before drawing anything, and before you open the style's `DEMO.md` or demo code (an Edit & Documentary style gathers its material first: AGENTS.md, "Treatment first"):

1. **Three candidate structures**, a few lines each (for example: a single journey, a before/after, a countdown, a list that turns), then the one you chose and why. Choose the opening image, the ending and the shape of the score from the topic too; the first idea that comes to mind for a style is usually its cliché.
2. **Logline and arc**: one sentence, then setup → turn → ending.
3. **Benchmark**: learn / don't learn (section 2).
4. **Shot list**: for every shot, the framing (wide / full / medium / close / insert), angle, camera move (push, pull, pan, track, crane, zoom), duration, and **why** it is shot that way.
5. **Beat sheet**, second by second.
6. **Cue map**: tempo, bar grid, instrumentation per section, and on which beat every cut, key action and subtitle lands.
7. **Sound design table**: for each section, the ambience bed, the main foley and the music state.
8. **Subtitle and title design**: the type is part of the style.

## 5. Prove the look

- **With characters**: draw a model sheet (turnaround, 3–4 expressions, 2–3 key poses, palette) plus two style frames.
- **Without characters**: three style frames from the film, one of them the signature shot.

Render them with the real drawing code, not a mock-up, and check them yourself against the `STYLE.md` before going on.

### The storyboard (only if the user asked for one)

Render 6–9 key shots with the real drawing code, tiled into one sheet (`core/render/sheet.py`) with shot number, framing, duration and line under each. Send it with the logline and what you are least sure about, and **wait for approval**. If the user didn't ask for one, don't stop.

## 6. Sound is half the film

- **Every visible action has a sound**: landings, page turns, cuts, drips, clicks, cloth. Match the material (paper, wood, metal, ink and glass all sound different).
- **Three layers**: ambience (room, wind, rain, city), foley (tied to actions) and music. Duck the music under dialogue and key foley.
- **At least two real silences**, or near-silences, before the turn or the emotional peak. The first sound after the silence should be one of the most important sounds in the film.
- **Use sound as a transition** at least twice: bring the next scene's sound in early (J-cut) or let the last scene's sound run over the cut (L-cut).
- **Avoid generic "piano and strings".** Score in the instruments of the style's sound palette.

## 7. Rhythm: the music grid comes first

- Write the cue map before animating. The picture locks to the grid, and a script checks every cue (TECHNIQUE.md §3).
- **Vary the pace**: alternate fast and slow, include one clear acceleration or deceleration, and give the audience one breath (a long take or a held pause). A film at one even speed has failed.
- One action, one sound, one cut, but don't cut on every beat. Leave time to see.
- **Pace for the viewer, not the clock**:
  - Hold every subtitle at least 1.8 s, and never shorter than the spoken line + 0.6 s.
  - After text finishes animating in, hold it for roughly (letters ÷ 15 + 1.5) s in English, (characters ÷ 4.5 + 1.5) s in Chinese; `readcheck.mjs` checks this for you.
  - Hold a title card at least 4 s.
  - Give failures and gags enough time to be understood.
  - Fast is fine; make it fast with fewer words per screen, not by cutting before people finish reading.

## 8. Camera: every shot needs a reason

- Use at least **four different camera moves** and real changes of framing. 2D has a camera too: push, pull, parallax, focus pulls, frames within frames.
- **One signature shot** people remember: a oner, a scale reveal, a transition made from the medium itself.
- **Design transitions inside the medium** (a page turn, a carved line growing, ink spreading), as one consistent grammar. Avoid default fades and hard cuts.
- At key moments the subject fills at least a third of the frame height, with clear staging and a readable silhouette.

## 9. Performance

- **Anticipation, action, follow-through** on every meaningful move. Characters change emotion. They do not just slide across the screen.
- **Motion continuity**, especially for characters built from code rigs:
  - Blend every pose with keyframes and easing; never switch poses inside an `if`. The only exception is a deliberate one-frame comic pop.
  - Check shoulders and arms on a large action test sheet (reach, raise, run, kneel) before shooting (TECHNIQUE.md §10).
  - Held props sit **between the palms**, at a depth between the two arms. A hand-over interpolates from one palm to the other. A rolling object turns by distance ÷ radius.
  - Step through key actions at 0.2 s intervals, enlarged.
- Check every expression at final size, especially eyebrow direction: "worried" and "angry" are one flip apart.

## 10. The failures we saw most

- Subject too small, too far away, or pushed against the frame edge.
- Too dark to read, or a colour laid on the same colour (red on red).
- Subtitles covering the subject.
- A gag or failure too fast to understand.
- Blank frames in transitions.
- A timed effect (iris, zoom, follow cam) that doesn't track the subject after the camera moves (one world → screen function, TECHNIQUE.md §2).

## 11. Before you deliver

- Run the review loop (TECHNIQUE.md §8): contact sheets, 0.2 s strips of key actions, one full-speed viewing with sound.
- **One fix round.** Fix everything the review and the checks below find in one round, then check once more. Small fixes that second check turns up (a level, a frame) belong to the same round; anything bigger, tell the user in one line when you deliver. The user's notes after delivery are new rounds: change only what they ask.
- **Not the demo again.** After the treatment, read `DEMO.md` and compare: structure, opening, signature shot, camera path, score shape, ending. At least four of the six must differ; rethink the ones that match. Before delivery, put your contact sheet next to the demo poster (`styles/<slug>/poster.jpg`) as a last check.
- Voice: every line transcribes back correctly (speech-to-text check). For Chinese, one misheard character in a short line is normal: listen, and if it is right, let the check expect what the model heard (TECHNIQUE.md §4).
- Loudness about −14 LUFS; no black frames, no NaN frames; subtitles in sync and not covering key action.
- Every row of the sound design table is actually in the mix.
- Every map, globe or satellite view passes section 13, checked enlarged.
- No LemoLab sign-off: `grep -rniE "lemo ?lab|opus 5\.5" <project folder>` finds nothing outside `LICENSE`, `CREDITS` and the library's path in `LIB=` lines, and you have watched the last seconds of the film (text drawn into an image can't be grepped).

**Deliver**, in the project folder (the complete list):

- `<name>.mp4` (24 fps unless `STYLE.md` sets another rate, about −14 LUFS) and `poster.jpg`;
- `<name>.srt`, when the film has narration, dialogue or subtitles; when the subtitles are burned into the picture, `subtitles_<lang>.srt` instead (desktop players load a `.srt` named like the video on top of the picture, so every line would show twice);
- `TREATMENT.md`;
- `CREDITS`: every third-party asset in the film (sample libraries, music, fonts, images, the voice engine) with its source and licence (TECHNIQUE.md §11);
- the source, with a one-command `build.sh` (TECHNIQUE.md §2).

**Tell the user**, in their language: where the project folder and the film are; that `CREDITS` lists the third-party assets in the film and their licences; and that they are responsible for the materials they use in it.

## 12. Copyright red lines

- References teach grammar only. Don't copy characters, designs, melodies, shots, logos or type designs.
- No existing works, games, brands or events appear in the film unless the user owns them or has the right to use them. That includes the logos, photos and footage the user hands you: use them when they say they have the right, otherwise draw fictional stand-ins.
- Some of our demos are unofficial fan films of real events or characters. Keep the style, and never carry those names, marks or characters into a user's film.

## 13. Maps

These apply to every frame that shows a map, a globe or satellite imagery, in every style.

- **No borders unless the film is about them.** Draw coastlines, terrain, imagery or streets, without national or provincial borders. Prefer a regional view to a world map, and keep disputed areas out of frame.
- **When China is in frame, draw all of it.** Taiwan, Hainan, the South China Sea islands with the dashed line (in frame, or in an inset), and the Diaoyu Islands with Chiwei Yu. Taiwan and the mainland are one country, in the same colour and the same treatment. Zangnan and Aksai Chin are drawn as on China's standard map.
- **Default border data doesn't meet this.** The default boundaries of Natural Earth, world-atlas and OpenStreetMap can't be used to draw China. When the film needs borders, use China-view data (such as Natural Earth's `admin_0_countries_chn` layers, checked against the standard map) or China's standard map service (bzdt.ch.mnr.gov.cn).
- **Words follow the same map.** Taiwan, Hong Kong and Macao are never listed as countries: not in labels, legends, subtitles, the voice-over or data tables. A list that includes them is "countries and regions". Clean a dataset's country field before you chart it.
- **Other disputed areas**: the same; frame them out, or leave their borders undrawn.
- **Check and credit.** Before delivery, enlarge every map shot and check it against these rules. `CREDITS` names the map data, its source and its view (for example "Natural Earth 1:50m, China view").


===== 完整公共规范：TECHNIQUE.md =====

# Technique: how the films are built

Every film here is made from code: no video generation, no stock footage. This page explains the pipeline, to reproduce with our tools in `core/` or in your own stack. Pair it with [`DIRECTOR.md`](DIRECTOR.md) and one `styles/<slug>/STYLE.md`. Every command and flag is in [`core/README.md`](core/README.md).

```
timeline (single source of truth)
   ├─► picture:  web page with render(t) ──► headless Chrome, frame by frame ──► video.mp4
   ├─► voice:    TTS per line ──► speech-to-text check ──► word timings
   ├─► music:    score from the same timeline (samples + synthesis) ──► stems
   ├─► sound:    procedural foley at event times
   └─► subtitles: .srt + burned-in captions
mix (duck, compress, balance) ──► mux with ffmpeg, two-pass loudnorm −14 LUFS ──► film.mp4
```

## 1. Requirements and install

System tools, which the user installs: **Node 20+**, **ffmpeg 7+** (6.x under-reports audio length through `loudnorm`, and `mux.sh` then rejects the file as cut off), and **Python 3.11+** or [uv](https://docs.astral.sh/uv/). Developed on macOS (Apple silicon); Linux should work. On Windows, Git Bash (part of Git for Windows) works: run the same `sh` commands there; WSL also works. 3D and shader-heavy styles want a GPU.

Everything else installs in tiers, from the library root (`$LIB` in skill mode). Install a tier only when the film needs it:

| Command | Adds | Size |
|---|---|---|
| `sh plugin/skills/lemo-opuscar/scripts/setup.sh deps` | core: npm packages, headless browser, Python `.venv` (numpy, scipy, soundfile, soxr, pillow): render, synthesize sound, mux | ~350 MB |
| `… setup.sh deps voice` | Kokoro + model (English, offline), edge-tts (Chinese, online), faster-whisper (voice check) | ~0.55 GB + a Whisper model on first check (~145 MB for English, ~480 MB for Chinese) |
| `… setup.sh deps music` | numba, for plucked strings (`pluck.py`); the sampler itself needs only the core | ~140 MB |
| `sh tools/fetch.sh instruments <lib>` | a sample library: `freepats`, `karoryfer`, `salamander`, `vcsl`, `vsco2ce` or `all` | 70–400 MB each |
| `sh tools/fetch.sh hdri` | HDRIs for 3D styles | 12 MB |

Some styles need packages of their own (a LiDAR reader, a slide-scan decoder, a CAD importer); the style's `STYLE.md` lists them. They are packages, not system tools: install them yourself into a private venv or `node_modules` in the project folder, never into `$LIB/.venv`.

The styles marked ✦ also draw with an image generator, which the library doesn't include and you don't install: the user's own Codex CLI, signed in (`core/image/gen_image.py`), or another image tool they have. Their prompts go to that service (core/README.md, "Image generation").

A synthesized score needs no big download. A sampled one needs the libraries its instruments live in: `sampler.py` downloads the missing ones itself, all at once, when the score is rendered (`LEMO_FETCH=0` turns that off and prints the `fetch.sh` commands instead). Put `"$LIB/.venv/bin/python" core/audio/sampler.py --need <your mix.py>` at the top of a `build.sh`, so they arrive before the long picture render, not after it. A pack needs about twice its size free while it unpacks. Downloads come from npm, PyPI, GitHub Releases and Hugging Face (`HF_ENDPOINT` sets a mirror).

## 2. The picture is a function of time

Each film is a folder with an `index.html` (`<demo>` in the commands) that exposes:

```js
window.DUR = 54.2;                 // seconds
window.render = (t) => { ... };    // draw the frame at time t, deterministic
window.READY = true;               // set once fonts and images are loaded
window.EV = [{t, type, ...}];      // optional: sound / cue events for the mixer
window.TEXTS = (t) => [{id, text, x0, y0, x1, y1}];   // optional: every text visible at t, for readcheck (pass: true = not meant to be read in full: a sign passed by, fine-print credits)
```

**Paths:** pages reach library files with absolute URLs (`/core/lib.js`, `/node_modules/three/build/three.module.js`); scripts and `build.sh` use `$LIB`. Never `../..`.

A `build.sh` that works in both modes (in skill mode, put `LIB=<path setup.sh printed>` at the top):

```sh
#!/bin/sh
set -e
HERE=$(cd "$(dirname "$0")" && pwd)
LIB=${LIB:-$(cd "$HERE/../.." && pwd)}          # clone mode: <repo>/films/<name>/
export LIB
[ -f "$LIB/core/render/video.mjs" ] || { echo "set LIB to the library folder"; exit 1; }
cd "$LIB"
node core/render/events.mjs "$HERE"
node core/render/video.mjs "$HERE" --fps 24 --out "$HERE/out/video.mp4"
"$LIB/.venv/bin/python" "$HERE/mix.py"                               # score, foley, voice → out/mix.wav
sh core/render/mux.sh "$HERE/out/video.mp4" "$HERE/out/mix.wav" "$HERE/<name>.mp4" 24
```

Rules that keep it reliable:

- **Deterministic.** No `Date.now()`, no `Math.random()` without a seed (`core/lib.js` has `mulberry` and `hash`), no state carried from the previous frame. Any frame can be rendered alone, in any order, by any worker.
- **Canvas 2D** for most 2D styles; **three.js** for 3D (§9); **WebGL2** shaders for post passes (film damage, CRT, ink redraw).
- **Animate on twos where the style wants it** (12 fps stepping for stop-motion, pixel or cel looks), but keep the camera and light smooth every frame. A stepped camera reads as lag.
- **One world → screen function.** Any effect that follows a subject (iris, zoom, spotlight) goes through it. Never hand-type screen coordinates.
- **Draw for the frame you render.** The default is 1920×1080; for another size pass `--size WxH` (e.g. `1080x1920`) to every render tool and lay the page out from `innerWidth` × `innerHeight`.

Capture (`core/render/`):

```sh
node core/render/still.mjs <demo> 1.5 12 --range 0:50:2   # review stills; exits on page errors
node core/render/video.mjs <demo> --fps 24 --workers 3     # all frames → <demo>/out/video.mp4
node core/render/events.mjs <demo>                         # export DUR + EV → events.json
node core/render/readcheck.mjs <demo>                      # every on-screen text stays long enough to read
```

To render a second version with other content, pass it to the page and give it its own output: `--q 'content=content_alt.json' --out …/alt.mp4` (the same for `events.mjs`).

Capture is fast because of **JPEG screenshots**, **one browser per worker** and **grain added in ffmpeg**: grain drawn in the page makes every frame incompressible and slow.

## 3. One timeline drives everything

Keep sections, tempo, beats and hit points in one file (`timeline.js`). Export it to JSON and let the score, the mixer, the subtitles and the checks read the same numbers:

```js
export const SECS = [{ id: 'chase', t: 12.0, bpm: 144, beats: 12 }, ...];
export const HIT  = { pratfall: ['chase', 6], ... };   // section + beat
```

A small script (`cuecheck.py`, in `styles/<slug>/demo/tools/` of several demos) compares every visual hit with the music cue it should land on. Aim for 0 ms.

## 4. Voice

- **TTS is only the default.** If the user brings a recording or names a voice, use that. Otherwise:
  - **English**: [Kokoro](https://github.com/thewh1teagle/kokoro-onnx), local, many voices (an unknown `voice` name makes `tts.py` print the full list; `af_` / `am_` are American, `bf_` / `bm_` British; cast the narrator for this film, not the demo's). `core/tts/tts.py lines.json out/` writes one WAV per line and a durations file. Its Chinese voices (`"lang": "cmn"`) work offline but sound plain.
  - **Chinese**: `core/tts/tts_zh.py lines.json out/` uses [edge-tts](https://github.com/rany2/edge-tts) with Microsoft's neural voices (`zh-CN-XiaoxiaoNeural`, `zh-CN-YunxiNeural`…), with the same outputs as `tts.py`, a rate per line and the silence trimmed. **It needs a network connection.**
- Spell numbers out in the TTS text and write them as digits in the subtitles.
- **Check every line**: `core/tts/asr_check.py` transcribes each WAV with faster-whisper and compares it with the script (`--lang zh`: numbers by value, so 十九 matches 19, and the rest character by character); re-generate until it exits 0. A misheard character in a short Chinese line is normal: listen, and if it is right, put what the model heard in the line's `asr` field. It also writes word timestamps for placing lines and subtitles.
- **Before mixing**: TTS has a high peak-to-average ratio. Compress the voice first, then balance by RMS: voice about 10 dB above the music.

## 5. Music

Write an original score from the cue map, in the instruments of the style's sound palette; no generic piano and strings.

- **Samples**: `core/audio/sampler.py` plays real instruments from free libraries (VSCO 2 CE, VCSL, FreePats, Karoryfer, Salamander Grand Piano; list and licences in `core/audio/INSTRUMENTS.md`). Write the score as events `(time, instrument, pitch, duration, velocity, pan)`. Long notes are extended seamlessly, and round-robins avoid the machine-gun effect.
- **Plucked and folk strings** (guqin, pipa, shamisen, banjo…): `core/audio/pluck.py`, physical modelling (Karplus–Strong) with bends and vibrato.
- **Synthesis** with numpy for chip tunes, drones and effects; no download needed.
- **Balance the low end.** Synthetic scores get bass-heavy quickly. Measure energy per band after mixing; keep 20–120 Hz around −3 dB relative to the rest, skip pad notes below MIDI 48, and give the bass some 2nd and 3rd harmonics so it speaks on small speakers.

## 6. Sound effects and mix

- `core/audio/sfx.py` synthesises foley procedurally (click, whoosh, thump, ding, paper, noise beds…) with filters, envelopes and `add(buffer, sound, at, gain, pan)`. Drive it from `window.EV`, so every sound sits exactly on its frame.
- **Master**: `sh core/render/mux.sh video.mp4 mix.wav out.mp4 24 [grain]` muxes, runs a two-pass loudnorm to −14 LUFS with a true-peak limit, adds grain in ffmpeg and prints the measured loudness; it exits non-zero on any failure. On light backgrounds use less grain; for pixel and vector styles, none.
- Films with grain baked into the picture compress badly; re-encode with `-tune grain` and a higher CRF.

## 7. Subtitles

- Export `.srt` with `core/render/srt.py cues.json out.srt` (cues = `[{t0, t1, text}]`), and burn styled captions into the page itself: the caption design is part of the style.
- Timing rules are in DIRECTOR.md §7.

## 8. Review loop

1. Contact sheets: a frame every 1–2 s with `still.mjs --range`, tiled with `core/render/sheet.py`. At least two full passes.
2. Frame strips at 0.2 s for every key action: hand-overs, falls, hits.
3. On the final file: `ffmpeg -af ebur128` (loudness), `blackdetect` (blank frames), whisper again on the final mix if it has voice.
4. Watch it once, at full speed, with sound.

## 9. 3D notes

- three.js r170 rendered headless through WebGL2 on the GPU; physical depth of field and GTAO from `core/three/post.js`, rendered at 2× and downsampled.
- Lighting: soft area lights plus a Poly Haven HDRI at low intensity reads more "real" than bright ambient light.
- `core/three/post.js` is written for a perspective camera. For an orthographic camera swap `perspectiveDepthToViewZ` for `orthographicDepthToViewZ` in its depth pass, or the depth of field silently breaks.

## 10. Characters drawn in code

- A 2.5D rig (torso, head, limbs solved per frame) is enough for pantomime.
- Order the shoulder rotation as abduction, then flexion; the reverse order crosses raised arms into an X.
- Let the shoulder girdle rise and move forward as the arm lifts, and don't outline the part of the arm that overlaps the torso: that line is what makes a joint look like a puppet seam.

## 11. Assets, credits and fonts

Only CC0, CC BY or OFL material, each listed in the film's `CREDITS` with its source and licence; `core/audio/sampler.py credits(names)` writes the lines for the instruments you used. Public-domain works count as CC0; "no known restrictions" does not. Data or images under other open licences (ODbL, CC BY-SA, open-hardware licences) only after you have named the licence and its terms (attribution, share-alike) to the user and they agree. The user's own material is fine as it is. Images from an image generator (the ✦ styles) are listed too: which tool and model made them, that they are generated, and where the prompts are kept; drawings the user made are credited to them.

A film that states facts (a style built from real data or scans: its `STYLE.md` says so) keeps a `FACTS.md` in the project folder: each claim with its source URL and the quoted wording, or the measurement that produced it.

Fonts: Google Fonts (OFL), self-hosted in the project. The typefaces a `STYLE.md` names are not in the library; download them (`https://github.com/google/fonts/tree/main/ofl/<family>`) into the project's `fonts/`. `core/fonts/` holds a few Latin display fonts and a Chinese display font with only about 200 glyphs, not enough for running Chinese text. For Chinese, subset a CJK font to the characters you use: the Google Fonts CSS API with `&text=` returns just those glyphs (`https://fonts.googleapis.com/css2?family=Noto+Sans+SC:wght@700&text=<URL-encoded characters>`). Download the font file it points to into the project's `fonts/` and load it with `@font-face`; don't link Google Fonts at render time.

## 12. Where to look in our demos

| If you need… | Look at |
|---|---|
| 2D character animation and lip sync | `styles/scifi-toon/`, `styles/cel-anime-80s/` |
| a timeline-driven score with cue checking | `styles/microgame/`, `styles/silent-film/` |
| an image-to-ink redraw and film-damage post pass | `styles/silent-film/demo/engine/` |
| a brush or stroke engine | `styles/watercolor/`, `styles/ink-wash/`, `styles/impasto/` |
| 3D with depth of field and real materials | `styles/brick-toy/`, `styles/paper-popup/` |
| a CRT or VHS look | `core/post/crt.js`, `styles/ascii-crt/`, `styles/backrooms/` |

Each style's `DEMO.md` says how its demo was built. Open it and the code only after your treatment exists, to learn a technique, never to rebuild our film (an Edit & Documentary style's material tools in `demo/tools/` come first: AGENTS.md, "Treatment first"). In skill mode, get the source with `sh <skill folder>/scripts/setup.sh demo <slug>`. Copied demo code often reaches the library with `../..`: replace that with `$LIB` or absolute URLs.


## 原作者媒介陷阱与经验摘录

## 9. Pitfalls of the medium

- **The assembly must be one model with a state table.** Every picture of the object (every step, the parts list, the final page) is drawn from the same function with a state; write the table first (step → what is added → what the object has when the step ends → parts used) and add one thing per step. Counts on the parts list must add up across the steps (e.g. bolts 2 + 2 + 4 = 8). Separate drawings per step drift: parts appear early, vanish, or sit in the wrong place.
- **Footprints and guide lines come from the same geometry.** A dotted footprint must be the finished object's real corners; a guide line runs from where the part lies to where it lands. Parts in a box lie flat, stacked at real sizes, and the box is empty only after the last one leaves.
- **Knees bend with the body, not the world.** Set the knee hint from the body's heading, or a pose that is right facing one way breaks when the figure turns.
- **Kneeling hip height comes from leg length**: knee on the floor + one thigh length. A half-kneel: the kneeling knee under the hip, thigh vertical, shin and instep flat behind; the other foot flat, knee about 90°, shin vertical.
- **The far leg is one shade darker** than the near leg, so crossed or overlapping legs never merge into one shape.
- **Sitting on the floor**: cross-legged with the knees open and low and the shins crossed in front reads as sitting; a pelvis on the floor with legs straight forward reads as falling over.
- **Standing**: weight on one leg, the other relaxed and turned out, hips and shoulders tilted against each other. Feet together and arms hanging make figurines.
- **Placement**: never put a person between the viewer and what the step is about, and keep their feet outside the object's footprint. Behind slatted furniture their legs show between the bars and they read as standing inside it: put them at a front corner, or at one end with their back to the viewer.
- **A gesture that matters** (a hand on a shoulder) lands on the side nearest the viewer, with nothing in front of it.
- **Front-on (facing the viewer squarely) reads worst** at this angle; use three-quarter and profile headings.
- **Hair and buns** live in the head's own 3D frame, so they turn, tilt and hide with the head.
- **Small mistakes are hard to see at full-page scale**: a part on upside down needs the ✗ on it and a close-up, not only the voice.
- **No perspective, no turning the view**, no 3D camera orbiting the paper.
- **No brands, logos, product codes, faces or cartoon round-headed figures.**


