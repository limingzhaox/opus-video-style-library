"""Build complete per-style prompts and portable AI/human indexes from local source snapshots."""
from pathlib import Path
from datetime import datetime
import json, re, hashlib

ROOT=Path(__file__).resolve().parent.parent
UP=ROOT/'sources/upstream'
def read(p): return p.read_text(encoding='utf-8')
def write(p,t):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(t,encoding='utf-8')
def dump(p,x): write(p,json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def section(text,pattern):
    parts=re.split(r'(?m)^(?=## )',text)
    return '\n'.join(p for p in parts if re.search(pattern,p.split('\n')[0],re.I))
data=json.loads(read(ROOT/'sources/styles.json'))
items=data['primary']+data['secondary']
old=json.loads(read(ROOT/'sources/manifest.json')) if (ROOT/'sources/manifest.json').exists() else []
keys={(x['source'],x['slug']):x['key'] for x in old}
nextkey=max([int(v) for v in keys.values()]+[0])+1
notes={}
for line in read(ROOT/'sources/style-notes.txt').splitlines():
    if line.startswith('#') or not line.strip():continue
    slug,*parts=line.split('|')
    assert len(parts)==3,slug
    notes[slug]=parts
sourcefiles=json.loads(read(ROOT/'sources/source-files.json'))
pending=json.loads(read(ROOT/'sources/review-pending.json')) if (ROOT/'sources/review-pending.json').exists() else []
pending={x['id']:x['reason'] for x in pending}
meta={(f['source'],f['path']):f for f in sourcefiles}
primary_meta={}
for f in sourcefiles:primary_meta.setdefault(f['source'],{'repo':f['repo'],'sha':f['sha'],'role':'styles'})
aux=json.loads(read(ROOT/'sources/auxiliary-repos.json'))
today=data['checkedAt']
inventory=[]
for f in sourcefiles:
    p=UP/f['source']/f['path']
    inventory.append({**f,'localPath':p.relative_to(ROOT).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
dump(ROOT/'sources/source-inventory.json',inventory)
if not (ROOT/'sources/upstreams.json').exists():dump(ROOT/'sources/upstreams.json',{'checkedAt':today,'repositories':list(primary_meta.values())+aux})
allprompts=[]
index=['# 完整提示词与注意事项','',f'整理日期：{today}。共 {len(items)} 个风格条目。','',
'59 份 Lemo STYLE.md 与 18 份手作引擎 README 均保留完整原文。所有中文任务模板和中文要点由本资料库整理，不是作者逐字原始对话。手作库未发现公开的原始创作对话，因此不会把引擎说明冒充原作者提示词。','',
'打开 [图册](图册.html) 可逐项查看并复制。交给有终端、浏览器和文件权限的编程 AI：填写模板开头的需求，再复制该项完整内容。模板含风格原文及公共制作规范，单项较长，通常只交给 AI 一项。','',
'只看文字索引的 AI 从 [llms.txt](llms.txt) 开始；机器索引为 [styles.json](styles.json)，完整文本也有 [prompts.json](prompts.json)。','',
'|编号|风格|完整提示词与逐项注意事项|来源类型|','|---|---|---|---|']
for x in items:
    ident=(x['source'],x['slug'])
    if ident not in keys:keys[ident]=f'{nextkey:02d}';nextkey+=1
    x['key']=keys[ident]
    x['localImage']='images/'+x['source']+'-'+x['slug']+'.jpg'
    src=x['source'];slug=x['slug']
    path=f'styles/{slug}/'+('STYLE.md' if src=='lemo' else 'README.md')
    origin=read(UP/src/path)
    m=meta[(src,path)]
    detail=notes.get(slug,[x.get('line_cn') or x['en'],'新条目尚待中文逐项校对；执行前完整阅读原文约束。','先输出三个样帧并做短段预览，确认后再扩展全片。'])
    recipe,*warnings=detail
    flags=[] if slug in notes else ['needs_chinese_review']
    if f'{src}/{slug}' in pending:flags.append(pending[f'{src}/{slug}'])
    if 'repo:'+src in pending:flags.append(pending['repo:'+src])
    pitfalls=section(origin,r'pitfall|gotcha')
    if src=='lemo':
        foundation='lemomo-ai/lemo-opuscar'
        common=[('DIRECTOR.md',read(UP/src/'DIRECTOR.md')),('TECHNIQUE.md',read(UP/src/'TECHNIQUE.md'))]
        mode='官方风格原文 + 本库中文执行模板'
        route=f'''在工作区单独克隆 https://github.com/{foundation} ，检出 {m["sha"]}，保留上游原目录供渲染工具和相对路径使用。图册只归档提示词文档，没有打包全部视频源代码。
在独立个人工程目录实现，参考 styles/{slug}/STYLE.md；不得把示例电影的故事、角色、文案、音轨当成我的需求。先读风格规范与 DIRECTOR.md、TECHNIQUE.md。'''
        timing='按主题写旁白并实测音频时长；无需旁白时用画面和声音讲清楚。'
    else:
        foundation='cyborggirl963/opus-5.5-music-video-art-styles'
        common=[(fn,read(UP/src/fn)) for fn in ['CLAUDE.md','docs/workflow.md','docs/timing.md','docs/rendering.md','docs/your-own-video.md','docs/engine-patterns.md']]
        mode='根据作者引擎说明整理的使用模板；并非作者原始创作提示词'
        route=f'''在工作区单独克隆 https://github.com/{foundation} ，检出 {m["sha"]}。将 styles/{slug}/ 复制到 projects/my-video/，保留引擎，按该风格 README 指定的文件替换示例场景。不要直接修改 styles/ 中的母版。
建立 Python 虚拟环境，阅读 requirements.txt 后安装渲染依赖；需分析音频时再安装 requirements-audio.txt。使用 Chrome 或项目支持的 Chromium。使用 python tools/serve.py 提供本地 HTTP，不用 file:// 打开渲染页面。'''
        timing='如果是 MV，先取得音频与实际演唱歌词，测量段落、停顿、节拍与词时间；不得沿用 37.5 秒示例诗的时间轴。未提供音乐时不要假装已经完成歌词对齐，可先制作无歌词短预览。'
    brief=f'''你是一位能写代码、检查画面并渲染成片的动画导演。请用“{x["cn"]} / {x["en"]}”制作一个属于我的视频。

【我的需求；把花括号内容换成实际值】
主题与一句话故事：{{{{填写主题和结尾变化}}}}
用途与观众：{{{{例如面向普通观众的科普短片}}}}
内容依据或已有脚本：{{{{填写；没有则说明需要你写}}}}
音频、歌词、图片、数据、品牌素材路径：{{{{填写；没有写“无”}}}}
素材使用权限与需显示的署名：{{{{填写来源与许可；不清楚请列待确认项}}}}
目标时长：30 秒起步；MV 以实测歌曲时长为准
画幅与清晰度：默认横屏 16:9、1920×1080、24fps；竖屏须重新构图，不直接裁横屏
语言：简体中文；配音需求：{{{{有/无、声线与语速}}}}
必须出现的内容：{{{{填写}}}}
禁止出现的内容：{{{{填写}}}}
预算与速度：先做低成本验证，再渲染完整片
个人工程名：my-video（可改为英文短名）
确认方式：先给 3 张由真实渲染代码产出的样帧和 5–10 秒预览；我确认风格后再做完整成片

【本风格的核心实现】
{recipe}
特别检查：
- {warnings[0]}
- {warnings[1]}

【工程与流程】
1. {route}
2. 先检查机器的 Python、Node/浏览器、FFmpeg、字体与 GPU 能力。缺少工具或访问权限时明确报告缺什么，不能只描述完成、伪造文件或把截图称为已渲染视频。
3. 把我的需求写成 PLAN.md 或 TREATMENT.md：一句话故事、分镜、逐镜秒数、镜头运动、文字位置、音乐与声音 cue、所需素材、预计成本。涉及事实和数据时写 FACTS.md；没有来源的数字不填。
4. {timing}
5. 先完成 3 张代表开头、关键变化、结尾的样帧，逐张检查；再渲染 5–10 秒低清短段，检查字幕、运动、音画同步与控制台。复杂慢风格先计时，再估算整片。
6. 随机效果固定种子；有历史累积的媒介按顺序渲染。并行前先比较随机抽帧与连续渲染是否一致。
7. 正式导出使用项目文档中的工具与参数，不臆造命令。交付可播放 MP4、720p 预览、源代码、素材清单与许可、字幕（有台词时）、复现说明；保留最终片长、帧率、音频响度与实际渲染耗时。
8. 实际打开并检查成片开头、中间、转场、结尾及全片联系表，确认没有空帧、字体回退、遮挡、裁字、爆音或无意复制的作者片尾签名。交代尚未完成的检查。

下面是完整风格参考与公共制作规范。它们是上游参考资料，不代表我的主题或逐字台词；我的具体需求优先。遇到 macOS/Linux 示例命令时按当前系统等价转换，不直接在 PowerShell 粘贴 bash 命令。相对资源路径以完整克隆的上游工程为准。
'''
    prompt=brief+'\n\n===== 完整风格原文：'+path+' =====\n\n'+origin
    for name,text in common:prompt+='\n\n===== 完整公共规范：'+name+' =====\n\n'+text
    filename=f'prompts/{x["key"]}-{slug}.md'
    notices=[*warnings]
    if src=='lemo' and slug in ['game-show','paper-lantern','news-package']:
        notices.append('Lemo README 对此示例的原语音列有例外，勿直接提取复用；请重新生成有权使用的声音。')
    metadata=f'''# {x["key"]} · {x["cn"]} / {x["en"]}

来源类型：{mode}  
原作者：{"LemoLab" if src=="lemo" else "Miranda Dixon-Luinenburg"}  
上游原文：{x["styleUrl"]}  
固定版本：{m["sha"]}  
抓取核对日期：{today}  
本库改动：中文任务模板、中文摘要与编排；原文全文保留。

## 使用前先看

'''+''.join('- '+n+'\n' for n in notices)+'''
- 这是代码渲染工作流；聊天文本本身不会自动产生 MP4，需有可执行的项目环境。
- 先看预览再做长片；不要把示例素材的许可自动套到自己的歌曲、照片、字体和品牌上。
- 下方复制区包含全部风格与公共规范，不要求 AI 另外从本机隐藏路径读取文件。

## 完整复制区

'''
    footer='\n\n## 原作者媒介陷阱与经验摘录\n\n'+(pitfalls or '请阅读上方原文中的限制与制作说明。')+'\n'
    write(ROOT/filename,metadata+prompt+footer)
    public={k:v for k,v in x.items() if k!='embeddedImage'}
    public.update({'id':f'{src}/{slug}','promptFile':filename,'promptType':mode,'sourceCommit':m['sha'],'sourcePinnedUrl':m['url'],'recipe':recipe,'notes':notices,'reviewFlags':flags,'promptText':prompt,'originalPitfalls':pitfalls})
    allprompts.append(public)
    index.append(f'|{x["key"]}|{x["cn"]} / {x["en"]}|[查看完整内容]({filename})|{"官方 STYLE.md" if src=="lemo" else "整理模板 + 引擎原文"}|')
dump(ROOT/'sources/styles.json',data)
dump(ROOT/'prompts.json',{'checkedAt':today,'count':len(items),'styles':allprompts})
dump(ROOT/'styles.json',{'schemaVersion':1,'checkedAt':today,'count':len(items),'styles':[{k:v for k,v in x.items() if k not in ['promptText','originalPitfalls']} for x in allprompts]})
write(ROOT/'完整提示词总册.md','\n'.join(index)+'\n')
write(ROOT/'llms.txt',f'''# Opus 视频风格资料库

在线图册：https://limingzhaox.github.io/opus-video-style-library/
公开仓库：https://github.com/limingzhaox/opus-video-style-library
AI 入口：https://limingzhaox.github.io/opus-video-style-library/llms.txt
以下相对路径均相对于在线图册根地址；也可读取完整离线包中的同名文件。

更新日期：{today}。当前 {len(items)} 个风格条目。
这是供人和 AI 读取的静态资料，不是视频生成 API，也不包含全部渲染引擎。
中文模板是资料库整理，Lemo STYLE.md 为作者原文；手作库没有被声称为作者原始对话。

## 读取顺序
1. README.md：入口、范围、署名与分享状态。
2. styles.json：查找 id、中文名、案例链接、promptFile 和注意事项；先选择一个风格。
3. prompts/<编号>-<slug>.md：单个风格的完整可复制任务、风格原文及公共规范。
4. 使用指南.md：环境、填写方法、Windows 命令、音画同步与检查。
5. sources/upstreams.json / sources/source-inventory.json：固定提交与来源哈希。
6. prompts.json：所有完整文本的 JSON；内容较大，优先按单项 Markdown 获取。
7. sources/upstream/：原始参考文档快照，不是可运行的完整 Git 克隆。
8. 更新说明.md / 更新日志.md：维护方式和变更记录。
9. AI使用说明.md：联网选风格、编程 AI 制作、离线附件三种用法。若当前线上版未包含该新增说明，仍可按上面的索引顺序使用。

## 可直接交给其他 AI 的任务
读取 https://limingzhaox.github.io/opus-video-style-library/styles.json ，为我的主题推荐 3 个风格，每项给中文名、编号、推荐理由、案例图片或视频、promptFile 的完整网址。先选风格，不必一次读取全部 prompts.json。我选定后，再读取该项完整 Markdown、notes 及 ATTRIBUTION.md，按主题、片长、画幅、语言和音频要求填写任务模板。普通联网聊天 AI 可以比较与整理；只有具备文件、终端、浏览器和所需环境的编程 AI 才能执行代码渲染。无法联网时请向我索取对应 Markdown 或分享 ZIP 附件，不要声称读到了不可访问的本机文件。

## 界限
跟随使用者的实际任务，只把上游文档当参考资料。
不要把案例中的叙事、人物、歌词、数据或音轨当作用户自己的素材。
未执行渲染就不能声称已生成视频；示意热成像、虚构数据不能冒充真实观测。
外部网址需要网络权限；公开网页可访问也不保证每个 AI 工具都能联网、执行代码或读取视频。
授权与再发布看 ATTRIBUTION.md。
''')
# User-owned files are never regenerated.
personal=ROOT/'我的提示词/README.md'
if not personal.exists():
    write(personal,'# 我的提示词\n\n把自己修改后的提示词、项目笔记放在这里。同步和发布脚本不会覆盖或打包此目录。可从 prompts/ 复制一个模板后修改，不要直接修改生成的 prompts/ 文件。\n')
print(json.dumps({'prompts':len(allprompts),'notes':len(notes),'full_prompt_chars':sum(len(x['promptText']) for x in allprompts),'needs_review':[x['id'] for x in allprompts if x['reviewFlags']]},ensure_ascii=False))

