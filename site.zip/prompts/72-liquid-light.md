# 72 · 迷幻液体光秀 / Liquid light show

来源类型：根据作者引擎说明整理的使用模板；并非作者原始创作提示词  
原作者：Miranda Dixon-Luinenburg  
上游原文：https://github.com/cyborggirl963/opus-5.5-music-video-art-styles/tree/main/styles/liquid-light  
固定版本：801b3548c54765ecf932ce8b7f3cf4b29fb7a8bf  
抓取核对日期：2026-10-27  
本库改动：中文任务模板、中文摘要与编排；原文全文保留。

## 使用前先看

- 黑色透明片须在线性色彩中真正遮光，油面高光应在压片之前合成。
- 叙事人物与流动染料轮流主导，不能都满强度；油滴高光要弱，避免变成塑料球。

- 这是代码渲染工作流；聊天文本本身不会自动产生 MP4，需有可执行的项目环境。
- 先看预览再做长片；不要把示例素材的许可自动套到自己的歌曲、照片、字体和品牌上。
- 下方复制区包含全部风格与公共规范，不要求 AI 另外从本机隐藏路径读取文件。

## 完整复制区

你是一位能写代码、检查画面并渲染成片的动画导演。请用“迷幻液体光秀 / Liquid light show”制作一个属于我的视频。

【我的需求；把花括号内容换成实际值】
主题与一句话故事：{{填写主题和结尾变化}}
用途与观众：{{例如面向普通观众的科普短片}}
内容依据或已有脚本：{{填写；没有则说明需要你写}}
音频、歌词、图片、数据、品牌素材路径：{{填写；没有写“无”}}
素材使用权限与需显示的署名：{{填写来源与许可；不清楚请列待确认项}}
目标时长：30 秒起步；MV 以实测歌曲时长为准
画幅与清晰度：默认横屏 16:9、1920×1080、24fps；竖屏须重新构图，不直接裁横屏
语言：简体中文；配音需求：{{有/无、声线与语速}}
必须出现的内容：{{填写}}
禁止出现的内容：{{填写}}
预算与速度：先做低成本验证，再渲染完整片
个人工程名：my-video（可改为英文短名）
确认方式：先给 3 张由真实渲染代码产出的样帧和 5–10 秒预览；我确认风格后再做完整成片

【本风格的核心实现】
用染料、油水和载物玻璃的真实叠层投影营造六十年代液体灯光秀。
特别检查：
- 黑色透明片须在线性色彩中真正遮光，油面高光应在压片之前合成。
- 叙事人物与流动染料轮流主导，不能都满强度；油滴高光要弱，避免变成塑料球。

【工程与流程】
1. 在工作区单独克隆 https://github.com/cyborggirl963/opus-5.5-music-video-art-styles ，检出 801b3548c54765ecf932ce8b7f3cf4b29fb7a8bf。将 styles/liquid-light/ 复制到 projects/my-video/，保留引擎，按该风格 README 指定的文件替换示例场景。不要直接修改 styles/ 中的母版。
建立 Python 虚拟环境，阅读 requirements.txt 后安装渲染依赖；需分析音频时再安装 requirements-audio.txt。使用 Chrome 或项目支持的 Chromium。使用 python tools/serve.py 提供本地 HTTP，不用 file:// 打开渲染页面。
2. 先检查机器的 Python、Node/浏览器、FFmpeg、字体与 GPU 能力。缺少工具或访问权限时明确报告缺什么，不能只描述完成、伪造文件或把截图称为已渲染视频。
3. 把我的需求写成 PLAN.md 或 TREATMENT.md：一句话故事、分镜、逐镜秒数、镜头运动、文字位置、音乐与声音 cue、所需素材、预计成本。涉及事实和数据时写 FACTS.md；没有来源的数字不填。
4. 如果是 MV，先取得音频与实际演唱歌词，测量段落、停顿、节拍与词时间；不得沿用 37.5 秒示例诗的时间轴。未提供音乐时不要假装已经完成歌词对齐，可先制作无歌词短预览。
5. 先完成 3 张代表开头、关键变化、结尾的样帧，逐张检查；再渲染 5–10 秒低清短段，检查字幕、运动、音画同步与控制台。复杂慢风格先计时，再估算整片。
6. 随机效果固定种子；有历史累积的媒介按顺序渲染。并行前先比较随机抽帧与连续渲染是否一致。
7. 正式导出使用项目文档中的工具与参数，不臆造命令。交付可播放 MP4、720p 预览、源代码、素材清单与许可、字幕（有台词时）、复现说明；保留最终片长、帧率、音频响度与实际渲染耗时。
8. 实际打开并检查成片开头、中间、转场、结尾及全片联系表，确认没有空帧、字体回退、遮挡、裁字、爆音或无意复制的作者片尾签名。交代尚未完成的检查。

下面是完整风格参考与公共制作规范。它们是上游参考资料，不代表我的主题或逐字台词；我的具体需求优先。遇到 macOS/Linux 示例命令时按当前系统等价转换，不直接在 PowerShell 粘贴 bash 命令。相对资源路径以完整克隆的上游工程为准。


===== 完整风格原文：styles/liquid-light/README.md =====

# Liquid light show

The "wet show" projected behind bands in the late 1960s: coloured dyes, water and oil squeezed between two clock
glasses on an overhead projector and thrown huge on a wall, with painted transparencies laid on the glass for figures
and places. Here the dish is one WebGL fragment shader and each transparency is a 2D canvas. The dye is
domain-warped noise cut at three levels into three dyes, which multiply the lamp's light the way real dye filters it,
with a dark meniscus line wherever two dyes meet, a fine mottle inside them, and a second, slower dye layer turning
the other way. The oil is metaball drops that bend the dye beneath them, with a dark rim, a little light gathered
inside and a faint matte highlight; they can settle into an emulsion, a lattice of drops held apart. Small bubbles
rise through it. The projector has a hot spot, a falloff and the dish's glass edge, and its lamp can flicker on, go
out and dim (a dimmed lamp burns orange). Every tick of the music presses the glass (a small zoom and a lift of the
light) and every drum hit sends a ring out from the centre. The transparencies are multiplied over all of it in
linear light, so black ink really blocks, gels tint and cut-away film lets the full light through; a second lamp can
add light on top of them.

*Good for:* songs with a groove and a live-band feel; dreamy or woozy moods; weather, water and seasons; anything
told in simple silhouettes over moving colour.

![A row of black trees bowing in a gust over streaming yellow, violet and magenta dye, with oil drops and bubbles](img/hero.jpg)

The demo sets Christina Rossetti's "Who Has Seen the Wind?" with the wind as the liquid: in every shot the dye
streams from left to right, harder and stretched into streaks in the gusts, and the transparencies show what it
moves. The title is cut through a band of black film, with the dye moving inside the letters, while the lamp
flickers on. Stanza one: a kite in open colour, where the liquid leads, then the sheet slides down to the two people
flying it, where the picture leads; a branch whose gel leaves tremble on "trembling" until the gust tears them off;
the lamp goes out. Stanza two comes back on a different dye: washing on a line and a walker with a red umbrella
leaning into the wind, then a row of trees that bow on "bow" and "down" while the liquid goes all out, and the kite,
loose now, passing by. At the end the wind drops, the oil settles into an even emulsion under a low sun, and the
lamp dims.

| | |
| --- | --- |
| ![A kite and its tail in open dye, the string running down out of the picture](img/sky.jpg) | ![A branch across the dish with leaves of coloured gel, oil drops behind them](img/leaves.jpg) |
| the liquid leads: a kite in open colour (0:06) | leaves of coloured gel, trembling (0:13) |
| ![Washing of coloured gels on a line, someone pegging it out and a walker with a red umbrella](img/washing.jpg) | ![Four trees on a ridge at dusk, a low sun, the oil settled into an even emulsion](img/emulsion.jpg) |
| the picture leads: washing on a line and a walker (0:24) | the emulsion settles under a low sun (0:36) |

## Looks in this family

This family has one look, so there's no style lab. Its range is inside the look: ten dye palettes in `dish.js`, and
how far each scene lets the liquid lead (`wild`, `calm`, `figAmt`, below).

## Run the demo

```bash
python tools/serve.py
```

Then open `http://localhost:8000/styles/liquid-light/index.html`. Play, or press Space; drag the bar to scrub. Add
`#t12.5` to the address for a still of 12.5 s with the page around it hidden (after editing code, reload with a new
query, `index.html?r=2#t12.5`, because changing only the `#` part doesn't reload).

```bash
python tools/still.py styles/liquid-light/index.html 2 6 12.5 0:37.5:2.5 --sheet   # stills and a contact sheet
python tools/render_mp4.py styles/liquid-light/index.html --fast                    # renders/liquid-light-720p.mp4
python tools/render_mp4.py styles/liquid-light/index.html                           # 1080p and 720p
```

It plays live: a frame takes 7-10 ms to draw on an Apple-silicon Mac, GPU included. A `--fast` render of the whole
37.5 s takes 36-46 s here, depending on what else the machine is doing (about 33 ms a frame including reading the
frame back and encoding it).

## How it works

Plain scripts sharing global names, loaded in this order by `index.html`:

| File | Job |
|---|---|
| `../../examples/poem/lyrics_data.js` | `window.SONG`: the lines, word times and beat grid |
| `pulses.js` | `window.AUDIO`: the ticks, drum hits and loudness the dish pulses to, made from `SONG`'s beat grid and word times |
| `figs.js` | `window.F`: painting a transparency (ink, gels, cut-away film, the second lamp), the figure rigs, and things the wind moves: a tree that bows, a forking bough, gel leaves, grass, a kite, an umbrella, cloth on a line, streamers |
| `dish.js` | `window.DISH`: the dye palettes, every scene parameter's default, oil-drop helpers and presets, timing helpers |
| `scenes.js` | the demo: `window.SCENES`, the shot list, and `window.POSTER`, the frame shown before Play (replace this file) |
| `engine.js` | the WebGL dish, scene blending and pushes, the integrals tabulated at load, the lyric band, `window.__video` |
| `index.html` | the page and the player |

Fonts: Jost from Google Fonts, for the lyric band and the title.

### The dish, pixel by pixel

`engine.js` draws each frame with one full-screen fragment shader. For a pixel in the picture it:

1. presses the glass: the point moves toward the centre by `0.7% x pulse`; a drum hit's ring displaces it radially;
2. evaluates the oil field (the sum of every drop's `r² / d²`, blended toward the emulsion lattice) and its gradient,
   and bends the point it samples the dye at by the gradient: the drop is a lens;
3. samples the dye: the pattern value at the point (turned, swirled, stretched along the wind and carried by it) is
   cut at `thr` into dye A (below `thr[0]`), B (between `thr[1]` and `thr[2]`) and C (above), each multiplying the
   water's `base` colour deeper toward its middle; a dark line where the value crosses a threshold (the meniscus);
   a fine mottle; the second dye layer; the bubbles;
4. adds the oil: its tint, a silver option, the dark rim at the drop's edge, light gathered inside, the highlight;
5. multiplies by the transparency (or the two, mid-change), converted to linear light;
6. adds the second lamp and the mist;
7. applies the lamp: a hot spot, falloff, the lamp's level (orange as it dims), saturation, the glass edge, grain,
   a soft tone curve.

The strip below the picture (the bottom 120 px) is the lyric band, drawn on its own canvas and passed straight
through.

### Coordinates

- **A transparency** is a 1920x1080 canvas in slide pixels, y down. The engine shows it at 8/9 size, centred on the
  1920x960 picture, so its whole height shows and anything left of about x = 30 or right of 1890 falls outside the
  dish. The dish's glass edge is a circle of radius 929 slide px round (960, 540), so the frame's corners are dark.
- **The dish** (drops, wind, mist) is in dish units: x from -1 to 1 across the picture, y from -0.5 at the bottom to
  0.5 at the top. `DISH.fromSlide(x, y)` turns slide pixels into dish units, `[(x - 960) / 1080, (540 - y) / 1080]`,
  and `DISH.viewToDish(view, x, y)` does it through a camera view.
- **Moving a transparency** on the glass: `F.cam(c, cx, cy, k)` puts scene point (cx, cy) at the centre at zoom k.
  Keep every sheet drifting a few pixels (`F.cam(c, 960 + 10 * Math.sin(t * 0.6), 540, 1)`): a sheet that never
  moves looks pasted on.

### Scenes

`window.SCENES` is a list in order of start time. Each scene is:

```js
{ t0, fade, slide, name, p, at(lt, t), drops(ft, lt, t), draw(ctx, lt, t) }
```

- `t0`: when it starts (song seconds). `fade`: seconds of dissolve from the scene before (0 or none is a cut).
  `slide: [dx, dy]`: instead of dissolving, push the new sheet in from that side (`[-1, 0]` is from the left) and the
  old one out ahead of it, both on the glass at once, over `fade` seconds. It reads as the operator changing sheets.
- `p`: parameters, usually a palette plus changes, `DISH.P('warm', { wild: 0.6 })`. `at(lt, t)`: parameters that
  change with time; `lt` is seconds into the scene, `t` song time. Numbers and arrays both blend through a fade.
- `drops(ft, lt, t)`: the oil drops now, `[[x, y, radius, [r, g, b]], ...]` in dish units, at most 32. `ft` is
  pattern time, so drops that wander by it slow down and freeze with the liquid.
- `draw(ctx, lt, t)`: paints the transparency. The context starts cleared (clear glass) with no transform.

The kite scene from `scenes.js`: pushed in from the left on the first sung line, liquid-led while it looks at the sky
(`wild` 0.85, little `calm`), picture-led once the sheet has slid down to the people (`wild` 0.38, the ground calm),
with a gust on "wind?":

```js
const kiteWind = (t) => 0.4 + 0.08 * Math.sin(t * 1.9) + 0.7 * gust(t, W(0, 4) - 0.35, W(0, 4) + 0.1, W(0, 4) + 1.5);
{ t0: LINE(0), fade: 0.75, slide: [-1, 0], name: 'kite', p: P('warm', { flow: 1.2 }), draw: kiteScene,
  at: (lt, t) => { const w = kiteWind(t), u = ease(7.3, 9.0, t);
    return windP(w, { wild: lerp(0.85, 0.38, u) + 0.15 * gust(t, W(0, 4) - 0.3, W(0, 4), W(0, 4) + 1),
      calm: lerp(0.2, 0.85, u), flow: 1.1 + 0.8 * w, swirl: 0.35 }); },
  drops: (ft, lt, t) => cloudDrops(6, 11, [[1.0, 0.9, 0.7], AMBER, [1.0, 0.82, 0.55]], ft, t, { rmax: 0.1, sx: 1.0 }) },
```

`windP(w, extra)` turns a wind strength into `wind`, `streak`, `turn: 0` and `swirl: 0.4`, and the same `kiteWind`
drives the grass, the coats and the kite in `kiteScene`, so the liquid and the pictures move together.

### Parameters

Defaults are in `DISH.DEFAULTS`; a scene's `p` and `at()` override them.

| Parameter | Default | What it does |
|---|---|---|
| `base`, `A`, `B`, `C`, `thr`, `scale` | `warm` palette | the water's colour, three dyes, the pattern values where each starts, the size of the dye bands. Palettes: `warm`, `green`, `dawn`, `day`, `clean`, `cold`, `cool`, `dusk`, `rose`, `full` |
| `wild` | 0.3 | how psychedelic, 0..1: the dyes' strength and contrast, the bands' size, how much of the second layer shows. Low when the picture leads, high when the liquid does |
| `calm` | 0.85 | calms the liquid in the lower part of the dish, so figures on the ground read |
| `sat` | 1 | saturation of the whole picture |
| `flow` | 1 | how fast the dye folds (the rate of pattern time; 0 freezes it) |
| `turn`, `swirl` | 0.02, 1 | how fast the dish turns (radians per unit of pattern time) and the slow eddy at its centre (0..1) |
| `wind`, `streak` | [0, 0], 0 | the liquid carried, in dish units per second, and stretched along the wind (1 = twice as long) |
| `oilTint`, `silver`, `spec` | amber, 0, 0.03 | the oil's colour (for drops without their own, and the emulsion), a pale metallic look, the highlight |
| `lattice`, `latScale`, `latMask` | 0, 0.085, 1 | the emulsion: how far the drops give way to an even lattice, its spacing, and (1) keeping it above the horizon |
| `mistAmt`, `mistY`, `mistSlope`, `mistX`, `mistX0`, `mistCol` | 0 (off) | a band of mist: its strength, its top edge's height and slope, its leading and trailing edges (move `mistX` to roll it in), its colour |
| `mistGlow`, `mistGlowCol`, `mistT` | 0 | the mist lights up toward `mistGlowCol` with the voice (`AUDIO.venv`); `mistT` is its own clock (default pattern time) |
| `lamp` | 1 | the projector lamp, 0..1 |
| `figAmt` | 1 | how strongly the transparencies print: lower is a ghost of the picture over the liquid |
| `neg` | 0 | shows the sheets as a negative |
| `pulse`, `layer2`, `bub`, `rip` | 1 | how much the ticks press the glass; the second dye layer; the bubbles; the drum ring |

### Painting a transparency (`figs.js`)

A transparency is paint on clear film. What you draw is what blocks or tints the light:

- **Ink:** `F.INK` blocks it completely; `F.INKF` (86%) is for far planes, so a black figure in front still reads.
  Shapes: `poly(c, pts, fill)`, `circ(c, x, y, r)`, `ell(c, x, y, rx, ry, rot)`, `rr(c, x, y, w, h, r)`,
  `line(c, pts, width)`, `limb(c, a, b, w0, w1)`, `chain(c, pts, widths)`, `floor(c, y)` (ground from y down).
- **Gels:** any translucent colour tints the light: `F.gel(c, 'rgba(255,90,70,0.75)', () => ...)`, or just a fill
  with alpha. A gel multiplies with the dye under it.
- **Cut-away film:** `F.clear(c, fn)` erases what `fn` draws (so the full light comes through), `F.pane(c, x, y, w,
  h, tint)` clears a window and lays a gel in it, `F.cutText(c, text, x, y, font)` cuts letters.
- **The second lamp:** `F.glow(c, g => ...)` draws light onto a layer added over the sheet (in the sheet's
  transform), `F.unglow(c, g => ...)` cuts shapes out of it (ink in front of a light), `F.halo(c, x, y, r, rgb, a)`
  is a soft round light. Use it for anything brighter than the dish: a lantern, a low sun.
- **People,** always whole figures, `h` px tall standing on `yF`: `F.profile(c, o)` side on, facing `f` (1 right, -1
  left), with `arms` and `armsBack` as a pose name (`'down'`, `'raise'`, `'point'`, `'reach'`, `'gesture'`, `'carry'`,
  `'fold'`...) or your own `[[elbow x, y], [wrist x, y]]` in body units (the shoulder is at `[1, -31]`, the hip at
  `[0, 0]`, forward is +x); `walk` (a phase in radians), `kneel`, `lean`, `headTilt`, `build`, `belly`, `hair`
  (`'short'`, `'bun'`, `'ponytail'`, `'cap'`, `'mop'`, `'curls'`), `coat` (`'long'` or `'short'`), `scarf`; `wind`
  (-1..1) and `t` stream the hair, scarf and coat hem; `hold(c, x, y, s, f)` draws what the front hand holds. It
  returns `{ headX, headY, hand }`, the front hand in your coordinates, for tying a string to it.
  `F.front(c, o)` faces us (arms `'down'`, `'folded'`, `'up'`) and `F.seated(c, o)` sits behind a table top `yT`.
- **Things the wind moves:** `F.tree(c, x, yB, h, bend, { t, shake, seed, crown })` bows toward +x (the angle at
  height u is `bend * u^1.9`, and the crown streams downwind); `F.bough(c, from, angle, len, width, depth, { bend,
  shake, droop, lift, t, seed, nodes })` forks, and fills `nodes` with points for hanging leaves; `F.leaf(c, x, y,
  len, angle, gel)`; `F.grass(c, x0, x1, yB, h, bend, t, { ground })`; `F.kite(c, x, y, s, rot, t, { cols, tailAng })`
  returns where its string is tied; `F.umbrella(c, x, y, s, angle, { gel, inv })` (`inv` blows it inside out);
  `F.cloth(c, a, b, len, t, wind, { gel, phase, stripe })` hangs from a line and lifts in the wind;
  `F.streamer(c, x, y, angle, len, w0, w1, t, { amp, sag })` is a ribbon with a wave running to its free end.
  Also `F.windowFrame(c, x, y, w, h, tint)` and `F.snow(c, x, y, w, h, t)`.

### Oil drops (`dish.js`)

`DISH.drift(n, seed, o, ft, carry)` makes `n` drops that wander round their own places: `o.sx` spreads them across,
`o.y0` and `o.yr` give the band of heights, `o.rmin`/`o.rmax` the sizes, `o.ax`/`o.ay` how far they wander,
`o.speed`, and `o.col` or `o.cols`. Pass `carry = LS.driftAt(t)` (how far the wind has carried the liquid) and they
travel with the wind and wrap round the dish. Presets in `DISH.D`: `few`, `warm`, `burst` (many colours, wild),
`split` (pairs that come apart and won't hold together), `held` (a grid), `one` (a single quivering drop),
`leaving` (drops sliding off the edge of the dish). A drop can sit on a feature of the sheet: map the point with
`DISH.fromSlide` (or `F.mapPt` through a transform). The branch scene's drops swell on every tick with
`LS.pulseAt(t)`.

### The pulse

`window.AUDIO = { ticks, kicks, env, venv }`:

- `ticks: [[time, strength], ...]`: each presses the glass and lifts the light for about a tenth of a second
  (`LS.pulseAt(t)`, 0..1.4);
- `kicks: [[time, strength], ...]`: each one stronger than 0.3 sends a ring out from the centre over 1.2 s;
- `env`, `venv`: the mix's and the voice's loudness, 24 values a second, 0..1. The lamp breathes a few per cent with
  `env`; the mist can glow with `venv`.

`pulses.js` makes these from the song's beat grid: a tick on every eighth note (the bar's first beat strongest, the
off-beats weakest), a kick at the start of every sung line, and a voice envelope from the word times. It works for
any `lyrics_data.js` with a beat grid. The engine also exports `LS.ticksBefore(t)`, `LS.envAt(t)`, `LS.venvAt(t)`,
`LS.flowTime(t)` and `LS.driftAt(t)` for scenes.

### The lyric band

A 120 px band under the picture shows the current line, each word lighting (with a short glow) as it's sung and the
rest waiting at 16%; a line appears 0.12 s before its first word and fades 2.2 s after its last or when the next
begins; a long line shrinks to fit. Lines in a section whose name starts with `chorus` are set in gold italics.
Before the first line, the band shows `SONG.credit` in italics under the title slide (the title itself is a scene,
cut through black film). The font and colours are in `drawLyrics` and `drawCredit` in `engine.js`.

### Determinism

Nothing carries over from one frame to the next: a frame is a function of `t` alone, so `step(t)` and `renderAt(t)`
are the same function, frames can be drawn in any order, and a slice rendered on its own matches a full render.
What accumulates (pattern time, the dish's turn, how far the wind has carried the dye, in the dish and in each dye
layer's own coordinates) is integrated once at load from the scenes' parameters, every 0.05 s, and looked up. Random
choices come from seeded generators (`DISH.rng`), and the grain changes on twos. The only caches are the canvases:
two sheet slots, the second lamp and the band.

## Make your own video in this style

1. **Copy the folder and your song:** `cp -r styles/liquid-light projects/my-song` and
   `cp ~/Music/my-song.mp3 projects/my-song/song.mp3` (see [docs/your-own-video.md](../../docs/your-own-video.md)).
2. **Time your lyrics** ([docs/timing.md](../../docs/timing.md)) so you end up with `projects/my-song/lyrics_data.js`
   (written by `tools/audio/to_js.py`), and in `index.html` change `../../examples/poem/lyrics_data.js` to
   `lyrics_data.js`. The page now plays the demo under your song, pulsing to your beat grid.
3. **Keep** `engine.js`, `figs.js`, `dish.js`, `pulses.js` and the player. **Rewrite** `scenes.js`; the demo's scenes
   are there to borrow from. Change the title, subtitle and `aria-label` in `index.html`.
4. **A scene:** a draw function and an entry in `SCENES`. For example, a porch at dusk with a lit window:

   ```js
   function porch(c, lt, t) {
     F.cam(c, 960 + 10 * Math.sin(t * 0.6), 540, 1.0);                  // the sheet drifts a little on the glass
     F.floor(c, 900);
     F.windowFrame(c, 300, 420, 260, 300, 'rgba(255,210,140,0.45)');    // clear film under an amber gel
     F.halo(c, 430, 570, 260, [255, 200, 120], 0.35);                     // the window glows past the frame
     F.profile(c, { x: 1200, yF: 900, h: 380, f: -1, hair: 'bun', coat: 'long', wind: 0.3, t });
   }
   // in SCENES, in time order:
   { t0: LINE(3), fade: 0.6, name: 'porch', p: P('dusk', { wild: 0.35 }), draw: porch,
     at: (lt, t) => ({ wind: [0.1, 0] }), drops: (ft) => DISH.D.few(ft) },
   ```

   Keep figures standing in the lower third, where `calm` settles the liquid, and give gels real colour.
5. **Timing:** `B(n)` is beat n, `LINE(i)` line i's start, `W(i, k)` when word k of line i is sung (all in
   `scenes.js`). Changes go on line starts (a new scene, a push), hits on beats and words: the demo's gusts are
   `gust(t, W(0, 4) - 0.35, W(0, 4) + 0.1, W(0, 4) + 1.5)`, rising into "wind?", and its lamp dims through the last
   bar with `lamp: lerp(1, 0.08, ease(B(57), B(60) - 0.05, t))`. The ticks and rings need nothing: they follow
   `AUDIO`.
6. **Real percussion:** for a song with drums, measured onsets pulse better than the grid. Measure them with
   `tools/audio/pulses.py`, which writes `audio_data.js` in exactly this shape (see
   [docs/timing.md](../../docs/timing.md#hits-and-loudness)), and load it in place of `pulses.js`:

   ```bash
   python tools/audio/pulses.py song.mp3 --percussion perc.mp3 --drums drums.mp3 --vocals vocals.mp3 \
       --out projects/my-song/audio_data.js
   ```

   Stems give much cleaner hits; without them give just the mix.

7. **Knobs worth knowing:** `wild` and `calm` (who leads, picture or liquid); `flow`, `wind` and `streak` (how the
   liquid moves; `windP` in `scenes.js` is a good starting point for wind); `lamp` with `DISH.flicker(t, t0, dur,
   from, to)` for a lamp failing or coming on; `lattice` for the emulsion; `figAmt` to fade a sheet to a ghost;
   `slide` for changes that feel hand-made; the palettes in `DISH.PAL`; `SPEED` and `bendOf` in `scenes.js`.
8. **Look at it** with `python tools/still.py projects/my-song/index.html 0:30:1 --sheet`, and preview slices with
   `render_mp4.py --start --end --fast`.

## Lab

None: this family has one look. To try palettes or parameters on your own scenes, open your page at a `#t` still and
edit `scenes.js`, or give a scene a long stretch of time with `at()` stepping through the values you want to compare.

## Performance

- A frame takes 7-10 ms (median) in headless Chrome on an Apple-silicon Mac, GPU work included, and up to about
  20 ms while two sheets are on the glass during a push or dissolve. The page plays live at the display's rate.
- The cost is the shader (two domain-warped noise patterns a pixel, and the oil field evaluated five times a pixel
  for its refraction, once per drop) and uploading the sheets as textures every frame: one or two 1920x1080 sheets,
  the second lamp's layer when a scene uses it, and the band.
- Memory: three 1920x1080 canvases (two sheet slots and the second lamp) and the band, about 25 MB, and the same again
  as textures; a few MB of JavaScript.
- A whole `--fast` render: 36-46 s here, about 33 ms a frame including readback and encoding. The files are larger than most styles' because the whole dish moves every frame: the demo's 720p copy
  runs about 3.3 Mbps. (Weaker grain doesn't help; tested.)
- To render a stretch: `python tools/render_mp4.py styles/liquid-light/index.html --start 26 --end 31 --fast`.

## Lessons and gotchas

- **Ink must really block.** Multiply the transparency over the light in linear colour (`pow(rgb, 2.2)`): in gamma
  space even 1% of the lamp leaking through black paint showed as a visible navy.
- **The sheet lies on top of everything in the dish.** The oil's highlights and caustics were first added after the
  sheet, and showed as grey smudges over black ink. Multiply the sheet in last; only the second lamp and the mist go
  over it.
- **Glossy drops look like plastic balls.** Keep the oil matte: a strong tint, a dark rim, a faint highlight.
- **Far planes in 86% ink** (`F.INKF`), so a black figure in front of a building or a hill still reads.
- **Let the picture or the liquid lead, not both at once.** With the dye at full strength, figures and gels get lost;
  lower `wild` and keep the ground `calm` when the picture matters, and turn the liquid up (and the sheet down with
  `figAmt`) when the liquid is the subject. Varying this from scene to scene is most of the style.
- **One dye layer looked flat and slow.** The second, slower layer turning the other way, the bubbles, a ring on each
  drum hit and more drops made it feel alive.
- **Turning round a far-off point shears the dye into rings.** Swirling the dish round coordinates that the wind had
  carried far from the centre wound the dye into concentric circles, and changing the band size slid it. So the drift
  is integrated at load in each dye layer's own turned and scaled coordinates, and the turn, the swirl and the scale
  only ever act on the dish's own small coordinates. Anything you add that accumulates should be integrated the same
  way.
- **The dish's own swirl fights the wind.** Turn `swirl` down and `turn` off (as `windP` does) when the dye should
  stream one way.
- **An even lattice reads as a halftone screen.** Each emulsion drop is nudged off its place and given its own size.
- **A ring can push the picture past the sheet's edge.** Beyond a sheet at rest the engine repeats its edge pixels;
  only a sliding sheet has clear glass beyond it. (Otherwise every drum hit flashed white slivers under the ground.)
- **Round drops as leaves read as berries or beads.** Gel leaves (a leaf of coloured film with an ink edge and
  midrib) read as leaves, with the drops quivering behind them. A gel multiplies with the dye under it, and orange over
  blue comes out brown: calm the dye behind gel pictures.
- **Pale gels vanish over pale dye.** White sheets on a washing line came out as empty outlines; give gels real
  colour.
- **Mist over black ground reads as a flat khaki or grey sheet.** Keep the mist over the liquid, or thin.
- **In a dissolve every parameter blends,** so the old scene's mist, drops and wind hang over the new picture for the
  length of the fade: clear them before the change, or push the new sheet in with `slide`.
- **The lamp shouldn't go to black.** A dimmed lamp burns orange, and a blink between sections keeps a faint filament
  glow, so no frame is blank; the ticks keep pulsing in the dark, which keeps the frame alive.
- **A silhouette carries the whole person.** Body shape has to read side on as well as from the front; thin limbs at
  small sizes vanish into the dye bands; small features (glasses, a nose) disappear. Cut anything that must show
  inside a silhouette out of it, or lay a gel in it.
- **Two figures that overlap become one blob.** Keep people apart, or have one pass the other quickly.
- **A sheet that never moves looks pasted on,** even over moving dye. Drift every transparency a few pixels.
- **Title letters cut through black film need a heavy face:** thin strokes show too little dye to read.
- **The oil drops are capped at 32 a frame:** the shader loops over them five times a pixel.
- **Grain that changes every frame bloats the MP4;** here it changes on twos.
- **Wait for the fonts.** The page builds only after every script has loaded and the fonts have been asked for, and
  warns in the console if Jost didn't arrive (the MP4 tool stops rather than render in a fallback face).
- **Changing only the `#t` part of the address doesn't reload the page;** reload with a new query after editing code.



===== 完整公共规范：CLAUDE.md =====

# Instructions for Claude

This repository makes music videos in code: each style in `styles/` is an engine that draws every frame on an HTML
canvas (or WebGL / three.js) in a hand-made-looking medium, timed to a song, and `tools/` renders them to MP4. Read
`README.md` for the map, then the doc for whatever you're doing.

## When someone wants a video for their song

Follow [docs/workflow.md](docs/workflow.md). It's a conversation, not a build order to rush through:

1. **Get the inputs:** the song (mp3), the lyric sheet as sung, and ask whether they have stems and MIDI (Suno and
   stem splitters provide them) and any reference images.
2. **Ask the concept questions before building anything:** who is singing, who "you" is, whose voice the chorus is,
   what the key images (especially the ending) mean, how much the video may show, what stays out. Don't guess at
   these; an open question is better than a confident wrong answer. If the song belongs to a larger world, read
   whatever they give you about it, and keep a list of every detail the video invents, flagged as unconfirmed.
3. **Measure the song** ([docs/timing.md](docs/timing.md)): tempo, sections, stops and hits, and every word's time.
   Time to the audio, not to the lyric sheet's markings.
4. **Pitch three looks and recommend one:** the medium and why it suits this song, the organizing object, a small
   visual grammar and an arc, a section-by-section plan keyed to timestamps, and the open questions. The styles in
   `styles/` are the starting points (each README says what it's good at); a new medium is fine too
   ([docs/engine-patterns.md](docs/engine-patterns.md)).
5. **Style lab:** the same three or four moments drawn in each candidate look. Show the stills.
6. **Checkpoint:** build one section (20-90 s), render it (`--fast`), send it, get notes.
7. **Build the rest** section by section, then render the final MP4s. The MP4 is what gets shared.

Build a project in `projects/<song-slug>/`, copied from a style folder ([docs/your-own-video.md](docs/your-own-video.md)).
Don't change `styles/` for one person's video. Keep notes in `projects/<song-slug>/PLAN.md` as you go: their answers
and rulings, the measured sections and sync points, the shot list, the invented details, and their feedback on each
round. A later session should be able to pick up from that file alone.

## Working practices

- **Look at what you render.** Make stills and contact sheets (`tools/still.py ... --sheet`) and open the images.
  Check every frame on the sheet: edges, blank frames, the camera inside things, covered text, long freezes.
- **Read the console output** the tools print. A single bad canvas gradient value blanks a frame.
- **Preview slices with `--fast`**; render the full 1080p only at the end. Styles that carry state between frames
  must be rendered in order (the tools do this).
- **Keep it deterministic:** seeded randomness keyed to the frame, never `Math.random()` per frame.
- **Follow the page contract** in [docs/rendering.md](docs/rendering.md) (`window.__video`, `window.SONG`,
  `<canvas id="film">`, `#t<seconds>` stills) so the tools work.
- Apply the lessons in [docs/workflow.md](docs/workflow.md#what-the-notes-taught-true-for-every-style): busy
  enough, no long freezes, obvious changes, varied choruses, whole figures rather than close-up hands.
- The person's audio is git-ignored. If their lyrics or story are private, keep the project out of any public
  remote (add it to `.git/info/exclude`, or keep it outside the repo and pass `--root` to the tools).

## Setup

```bash
python3 -m venv .venv && .venv/bin/pip install -r requirements.txt -r requirements-audio.txt
```

Google Chrome must be installed (or `.venv/bin/python -m playwright install chromium`). To preview in the desktop
app's browser pane, create `.claude/launch.json` running `python3 tools/serve.py 8000` on port 8000 (git-ignored).
Use the server, never `file://`: module pages don't load from files and a plain server caches stale scripts.



===== 完整公共规范：docs/workflow.md =====

# How a video gets made

These videos were made in conversation: a person with a song and a clear sense of what it's about, and Claude
writing and rendering the code. The process below is what worked over a dozen songs. It suits working with Claude
Code (see [CLAUDE.md](../CLAUDE.md), which tells Claude to follow it), and it works just as well by hand.

The short version: **decide what the song is about, measure it, pitch three looks, test the look on a few scenes,
build one section, get notes, then build the rest.** Each step is cheap next to the one after it, so mistakes get
caught while they're still cheap.

## 1. Gather the inputs

- **The song** as an mp3 (or anything ffmpeg reads).
- **The lyric sheet** as plain text, one sung line per line, with `#section` markers (see
  [examples/poem/lyrics.txt](../examples/poem/lyrics.txt)). Write it the way it's sung: if the singer repeats a line
  that isn't on the sheet, add it.
- **Stems, if you have them.** An isolated vocal stem makes transcription far cleaner. Suno exports stems as audio
  and as MIDI per instrument; the MIDI's tempo map gives an exact beat grid, and the vocal MIDI gives note onsets to
  snap words to (see [timing.md](timing.md)).
- **Reference images, if any.** Mood boards and concept art are useful for content (what's in the world, what
  people wear, what the place looks like) even when the style will be different.

## 2. Decide what the song is about

Before any pictures, answer the questions that decide the concept. A video can't be good if these are guesses.

- **Who is singing,** and to whom? Who is "you"? It's often not who it seems, and it can change between verses.
- **Whose voice is the chorus?** The singer's, an imagined audience's, a crowd's, a custom's?
- **What do the key images mean?** Especially the closing one.
- **How much may the video show?** If the song belongs to a larger story, what would be a spoiler?
- **What stays out?** Eras, events, people, kinds of imagery.

If the song is part of a larger world (a novel, a game, a band's mythology), read up on it first, and **keep a list
of every detail the video invents**: a place's layout, what a prop says, who stands where. Show that list to
whoever owns the world, and treat nothing on it as settled until they say so.

## 3. Measure the song

Time the video to what the audio does, not to what the lyric sheet says. (AI song generators in particular ignore
markings like "quiet" or "almost unaccompanied".) With the tools in [timing.md](timing.md):

- tempo, and whether it changes;
- the sections and their loudness: which chorus is the big one, where it drops to almost nothing;
- **the stops and hits.** Musical stops, dropouts and the hit that ends a bridge make the best sync points: the
  place to freeze, cut, switch a light off, or change the whole picture;
- every word's time.

## 4. Pitch three looks

Offer three directions and recommend one. For each:

- **the medium** (paper cut, embroidery, marbled paper...) and why it suits this song. The strongest choices mean
  something: marbled paint for a song about water, where nothing stays put; a lantern lecture for a song sung by
  someone lecturing; a desk of files and stamps for a song about a record that doesn't add up;
- **the organizing object:** the one thing the whole video is, such as a desk under a lamp, a hanging read along
  its length, a printed sheet, a painted wagon's panels, a board of pasted-up photographs;
- **a small visual grammar:** a few rules that give the images meaning (stamps are the audience's verdicts, frost
  is the stillness, the camera's date flickers between years), and an **arc** over the song (clean to decayed,
  night to morning, empty to crowded);
- a **section-by-section plan** keyed to timestamps, giving each section one main image;
- the questions still open.

The [styles/](../styles) folder has eighteen engines to start from, and each one's README says what it's good at.
A new song can also want a new medium: the engines share their patterns ([engine-patterns.md](engine-patterns.md)),
so a new one is less work than it sounds.

## 5. Style lab

Draw the same three or four key moments in each candidate look, side by side, as stills (and a few seconds of motion
if the look depends on how it moves). Comparing like with like makes the choice easy, and it shows the problems
early: people who look like mannequins, faces that look ill, a palette that turns cute. Every family here with more
than one look has a lab page (`styles/<family>/lab/`) built this way.

Expect the first choice to be refined: "this look, but with the other one's colours", or "this, for the scenes in the
other world only". Mixing is fine.

## 6. Checkpoint

Build a real section before the whole song: 20-30 seconds of the section that carries the concept, or the first
90 seconds. Render it as an MP4 and get notes on the look, the pace, the figures, the text. This is where most of
the useful notes arrive, and they're cheap to act on now.

## 7. Build the whole song

Section by section. After each, render stills across it (`tools/still.py ... a:b:2 --sheet`) and look at every one:
frame edges, blank frames, things the camera cuts through, text that's unreadable or covered. Fix, then move on.
When it's all there, render the MP4, then scan it at one frame every two seconds.

## 8. Notes, and fixing a stretch

Notes on a full video are usually local: one stretch feels empty, one chorus repeats the last, a transition jerks.
Re-render only that slice and splice it in ([rendering.md](rendering.md#fixing-one-stretch)).

## 9. Deliver an MP4

Share the MP4, not the web page. A browser player's pause and scrub can feel unreliable, and people give up on it.
`tools/render_mp4.py` writes a 1080p file and a smaller 720p one for sending.

## 10. Revising a finished video

A second or third pass (new conventions, a list of fixes, a stretch that needs more going on) works best as: a short
written plan of every change; then before/after sheets, stills from the old render and the new build at the same song
times side by side; then the full render. The sheets let the notes land on exactly what changed. When picking stills
for review, catch short effects at their peak: a flash or a bolt that lasts half a second is easy to miss.

## What the notes taught (true for every style)

- **Busy enough.** Something new on nearly every beat, or at least every line. A stretch with nothing happening
  reads as a mistake, not a rest. When a stretch feels empty, fill it with callbacks (translucent overlays of earlier
  scenes) and background life (children, animals, people passing) rather than restaging it.
- **No long freezes.** A four-second still reads as the player stalling. Keep holds to a beat or two, or keep
  something drifting: a slow camera move, breathing light, smoke.
- **Make small changes obvious.** A face swapping for another face, a detail changing on a paper: if it matters,
  make it big and push the camera in on it. Subtle changes go unseen.
- **Too clean reads as dead.** A video that stays tidy all the way through can feel flat; give it an arc.
- **Vary the repeats.** The second chorus shouldn't replay the first. New scenes, with brief flashes back to the
  first chorus's pictures on key words, keep the echo without the repetition. A motif that does something different
  each chorus (ribbons that knot, then plait, then slip) works well.
- **Whole figures beat close-up hands.** Big silhouettes of hands and arms read as clubs, poles or chess pieces. A
  whole figure, even small and mostly still, carries a beat better.
- **Faces:** realistic halftone or heavy shading can make people look ill. Stylized faces (dot eyes, lowered lids
  when looking down) for close figures and blank faces for crowds read better.
- **What makes a look cute** (sometimes wanted, often not): flat candy fills, rounded sack-shaped figures with blob
  heads, even lighting, bobbing walks. For solemn songs, use weight, texture, uneven light and stillness instead.
- **Real texts make good props.** A period document, a real letter or hymn, an actual map give a scene weight even if nobody
  can read them.
- **Impossible places need ordinary things in them.** Floating or folded land only reads as land when it carries
  trees, lit windows, snow on its ground side, smoke going the "wrong" way.
- **Decide about text in the picture.** A lyric band under the picture is one choice; no readable text at all
  (squiggles for writing) is another; either way, be consistent. Captions that only repeat the lyric are redundant.
- **Fake text is worse than no text.** A card of invented glyphs that flickers reads as a screen of foreign writing.
  Use pictograms, squiggles, or nothing. Likewise on-screen read-outs (temperatures, timecodes) in a "technical"
  medium: keep them only if they mean something.
- **Show the medium working.** When a look risks feeling static (a photograph, a print, a drawing), let the viewer
  watch it being made: a plate exposing, inks printing in on the beats, stitches sewn in, a slide pushed into the
  lantern. It answers "static and unclear" without changing the look.
- **Vary what leads a scene.** In a medium with a life of its own (liquid light, marbling, sand), let some scenes be
  led by the pictures and some by the medium, rather than the same mix throughout.
- **Props must sit in hands.** A rope, a ring, a cloth or a cup that floats near a hand reads as broken. Anchor held
  things to the rig's hand points and check every one in stills.
- **Arms that move naturally:** pose them by where the hand and elbow should be, blend joint angles rather than
  positions, let the forearm trail the upper arm, and add breathing and small weight shifts. Arms that slide
  straight between poses look like a puppet's.
- **Bodies carry identity.** In silhouette, heat or other outline-first looks the outline is all a viewer gets: if
  someone is heavily built, or small and round, the shape must show it. Keep sizes consistent (an animal is as big in
  every shot).
- **Shapes read as other shapes.** A figure lying flat reads as a collapsed body (have them sit or doze upright unless
  a death is meant); a pyramid of sacks in a lit doorway reads as a hooded head; a fan of hair strands reads as a
  feathered headdress. Look at every silhouette as a stranger would.



===== 完整公共规范：docs/timing.md =====

# Timing a song

Everything in a video hangs off the song's clock: the lyric band lights each word as it's sung, pieces land on
beats, scenes change on line starts, the lamp goes out in a dropout. This page is how to get those times. The tools
are in [tools/audio/](../tools/audio); each prints its own help with `--help`.

Setup (once): `pip install -r requirements-audio.txt` (librosa, scipy, faster-whisper, mido). The Whisper model
downloads the first time it's used.

## The pipeline

```bash
# 1. the shape of the song: tempo, loudness, sections
python tools/audio/analyze.py song.mp3

# 2. words with timestamps, from the vocal stem if you have one
python tools/audio/transcribe.py vocals.mp3 --lyrics lyrics.txt --out whisper.json

# 3. your lyric sheet matched to Whisper's words
python tools/audio/align.py lyrics.txt whisper.json --out lines.json

# 4. snap each word to where the voice starts it (vocal MIDI and/or vocal audio)
python tools/audio/snap.py lines.json --midi vocals.mid --audio vocals.mp3 --out snapped.json

# 5. the page's data file
python tools/audio/to_js.py snapped.json --out projects/my-song/lyrics_data.js --title "My Song" \
    --audio song.mp3 --audio-file projects/my-song/song.mp3 --bpm 96 --beats-per-bar 4
```

Then open the video with the lyrics showing and listen through. Fix what's off by editing `lyrics_data.js`
directly: it's plain data.

## Step by step

### 1. The shape of the song

`analyze.py` prints the global tempo and the local tempo every 20 s, a table of loudness, brightness and rhythmic
busyness every few seconds, and guesses at section boundaries. Read it next to the lyric sheet. You're looking for:

- which sections are loud and which drop out: the video's big and quiet moments should follow them;
- tempo changes (a slow intro, a half-time bridge);
- **stops and hits.** `onsets.py song.mp3 --from 140 --to 155` zooms in on a stretch: the strongest onsets, the
  beats, and the loudness every quarter second, so a dropout shows as a run of low numbers. These are the best
  sync points a song offers: the place for everything to freeze, for a cut, for a light to go off.

`sections.py song.mp3 --lines lines.json` compares the sections' loudness, drums and tonal energy once you know
where they are.

### 2. Transcribe

`transcribe.py` runs faster-whisper with word timestamps. Give it the **vocal stem** if there is one; sung vocals
over a full mix transcribe much worse. The `small` model is usually enough and takes about a minute. `--lyrics`
passes the start of your lyric sheet as a prompt, so names and odd words come out spelled your way. `medium` can
rescue mumbled lines, but over a long song it can drift further than `small`.

Expect Whisper's times to run **early**, typically a few tenths of a second and sometimes by more than a second,
and to hear some words wrong, especially names and unusual words. Step 3 doesn't care about wrong words; steps 4 and
the listen-through fix the times.

### 3. Align

`align.py` lines your sheet up against Whisper's words (a sequence match, so misheard or missing words don't break
it; unmatched words get times interpolated from their neighbours). It prints each line with a match count like
`m7/9`. Low counts are where to listen first. Watch for:

- **numbers:** Whisper writes "1974" as one token for three sung words. The script spells out years and small
  numbers before matching, but check them;
- **hyphenated words** and contractions;
- **a misheard last line** ("Let it go" for "Letting go"): the end of a song, over a fade, is where Whisper guesses;
- **repeats and ad-libs** the singer added: put them on the sheet as sung, or they'll be squeezed between
  neighbours.

### 4. Snap to the voice

`snap.py` moves each word to the nearest sung-note onset within 0.32 s: note onsets from the **vocal MIDI** first
(if you have it), then onsets detected in the **vocal audio**. It first reports the median offset between the words
and the onsets; if Whisper ran early across the whole song, pass that back as `--shift` so everything moves before
snapping.

After snapping, some things still need a human ear:

- **line starts that land in silence** or on the tail of the previous word: move them to where the voice comes in;
- **choruses and held notes:** a melisma or a long held word confuses onsets;
- **MIDI quantization:** Suno's MIDI is quantized to sixteenth notes and can sit about 0.3 s off the voice.

For those, `onsets.py vocals.mp3 --from 25 --to 27 --pitch` prints the sung pitch and loudness every 50 ms: the
word starts where the pitch appears and the loudness jumps.

### 5. Write the page data

`to_js.py` writes `lyrics_data.js`, which sets `window.SONG`:

```js
window.SONG = {
  title: "My Song", credit: "", audio: "song.mp3", duration: 212.4,
  bpm: 96, beatsPerBar: 4, firstBeat: 0.35,
  sections: [["verse1", 12.3, 41.0], ...],
  beats: [0.35, 0.975, ...],            // only with --beats: exact beat times
  lines: [{section: "verse1", text: "Who has seen the wind?", t0: 12.3, t1: 14.9,
           words: [["Who", 12.3], ["has", 12.9], ...]}, ...],
};
SONG.beat(n)  // the time of beat n
```

Every style in this repo reads that shape (see [examples/poem/lyrics_data.js](../examples/poem/lyrics_data.js)).

## Beats

For a steady song, `--bpm` and `--first-beat` (the time of the first downbeat) are enough: `SONG.beat(n)` is
`firstBeat + n * 60 / bpm`. Find the first beat with `onsets.py` on the song's opening seconds.

If the tempo drifts or changes, use exact beat times instead:

- **from MIDI stems:** Suno writes a tempo event on every beat, so the tempo map is an exact beat grid.
  `midi.py drums.mid --beats-out beats.json` (any of the song's MIDI files will do);
- **from the audio:** `analyze.py song.mp3 --beats-out beats.json` (librosa's estimate; check it).

Pass the file to `to_js.py --beats beats.json`; `SONG.beat(n)` then reads from the list.

## Hits and loudness

Some styles pulse, flash or move with the music itself rather than the words: a lamp that breathes with the mix, a
ring on every drum hit, mouths that open with the voice. `pulses.py` measures those:

```bash
python tools/audio/pulses.py song.mp3 --percussion perc.mp3 --drums drums.mp3 --vocals vocals.mp3 --out projects/my-song/audio_data.js
```

It writes `window.AUDIO = {fps, ticks, kicks, env, venv, vdb}`: small hits (`ticks`) and big ones (`kicks`) as
`[time, strength]`, the mix's and the voice's loudness 24 times a second (`env`, `venv`, 0..1), and the voice's
loudness in decibels mapped to 0..1 (`vdb`, better for mouths). Stems give much cleaner hits than the mix; without
them everything comes from the mix. The liquid light show reads this file as it is; any style can read the arrays.

## Suno specifics

- The stem download gives an audio file and a MIDI file per instrument. The lead vocal stem transcribes cleanly.
- The MIDI files carry a key-signature event that the `mido` library can't decode (it raises
  `KeySignatureError`). `tools/audio/midi.py` patches mido to read it as C; import `load()` from it in your own
  scripts to get the fix.
- The MIDI tempo map has one event per beat: an exact beat grid, including tempo changes after an intro.
- Vocal MIDI notes are quantized and can sit up to ~0.3 s off the voice: good anchors for snapping, not ground truth.
- Suno ignores dynamics on the lyric sheet ("quiet", "spoken", "almost unaccompanied"). Measure.

## Checking by eye and ear

Open the page, play it with the sound on, and watch the lyric band. Words that light up early are the common
fault. For a close look, `#t25.3` on the page's URL shows the frame at 25.3 s with the band as it is then.



===== 完整公共规范：docs/rendering.md =====

# Previewing and rendering

Every video here is a web page that draws its frames on a canvas. You watch it in a browser while you work, and
when it's done a script steps through it frame by frame in headless Chrome and pipes the frames to ffmpeg. This
page covers the page contract the tools rely on, previewing, stills, MP4s, and fixing a stretch.

Setup (once): `pip install -r requirements.txt` (Playwright, imageio-ffmpeg, Pillow, numpy). The tools drive your
installed Google Chrome; if you don't have it, `python -m playwright install chromium` gets Playwright's own.
imageio-ffmpeg bundles an ffmpeg with x264 and AAC, so there's nothing else to install.

## The page contract

A video page (a style's `index.html`, or a copy of one for your song):

- draws into `<canvas id="film" width="1920" height="1080">`;
- loads its song data as `window.SONG` (see [timing.md](timing.md#5-write-the-page-data)) and plays `SONG.audio`
  in an `<audio>` element, falling back to a silent clock if the audio can't load;
- sets `window.__video`:
  - `ready`: true once everything is built;
  - `duration`: the song's length in seconds;
  - `step(t)`: draw song time `t` the way playback does. The MP4 renderer calls it at 24 fps, strictly in order;
  - `renderAt(t)`: draw a still of time `t` from a fresh state (catching up whatever the frames before it built);
  - either may return a Promise (a page that builds scenes asynchronously); the tools wait for it;
  - `error`: set this to the error text if building fails, and the tools stop and print it;
  - optionally `shots` and `probe(t)` for 3D pages (see `tools/probe.py`);
- shows a still when the URL ends in `#t<seconds>` (e.g. `index.html#t12.5`), with the page chrome hidden;
- draws only while playing: a paused player shouldn't keep redrawing its frame on every animation frame (the tools
  draw and read back each frame in one call, but a page that redraws on its own fights anything else that draws);
- is **deterministic**: all randomness comes from seeded generators keyed to the frame number, never
  `Math.random()` per frame, so a given moment always draws the same picture. An MP4 depends on it.

A style-lab page sets `window.__lab = { ready, scenes, styles, render(scene, style) }`, where `render` draws one
scene in one look and returns the canvas.

## Previewing

```bash
python tools/serve.py            # serves the repository at http://localhost:8000/ and lists the demo pages
```

Open a page from the list. Use this server rather than `python -m http.server` or opening the file directly:

- pages that use ES modules or load files **don't work from `file://`**;
- a plain server lets the browser **cache scripts**, so after an edit you can be looking at the old code. This
  server sends no-cache headers;
- audio and video only seek when the server answers **Range requests**; this one does.

**Stills in the browser:** add `#t<seconds>` to the URL. Changing only the `#` part doesn't reload the page, so
after editing code, reload with a new query (`index.html?r=2#t30`).

**Always check the console** after a load. One bad value in a canvas gradient (a NaN colour stop) throws, and the
whole frame goes blank.

**In Claude Code's desktop app**, the preview pane can run the server for you: create `.claude/launch.json` with
```json
{ "version": "0.0.1", "configurations": [
  { "name": "videos", "runtimeExecutable": "python3", "runtimeArgs": ["tools/serve.py", "8000"], "port": 8000 } ] }
```
(it's git-ignored).

## Stills and contact sheets

```bash
python tools/still.py styles/paper-cut/index.html 5 12.5 30          # three stills
python tools/still.py styles/paper-cut/index.html 0:37.5:2.5 --sheet # a frame every 2.5 s, tiled into one image
python tools/lab_stills.py styles/embroidery/lab/index.html --all --sheet
```

Output goes to `renders/` (git-ignored). The contact sheet is the fastest way to review a whole video: look at every
frame on it, not just the ones you changed. Things to look for: frame edges showing the end of the world, blank or
black frames, the camera inside an object, text covered or cut off, two scenes' seams, something frozen too long.

## MP4s

```bash
python tools/render_mp4.py styles/marbling/index.html                    # renders/marbling.mp4 and -720p.mp4
python tools/render_mp4.py projects/my-song/index.html --out "renders/My Song.mp4"
python tools/render_mp4.py projects/my-song/index.html --start 60 --end 90 --fast   # quick preview of a slice
```

- Two files: 1080p (x264 `slow`, CRF 23, AAC 192k: roughly 5 Mbps for a busy picture) and `-720p` (CRF 25: about
  1 Mbps, small enough to send).
- `--fast` writes only the 720p with the `veryfast` preset. Busy, grainy frames can take many times longer to
  encode with the slow preset than to draw, so use `--fast` for previews and the normal mode for the final.
- The audio comes from `SONG.audio` unless you pass `--audio`. A slice gets short audio fades.
- **Fonts:** the styles load their type from Google Fonts. If a font request fails (a flaky network), canvas text
  silently falls back to a default font, so `render_mp4.py` and `render_frames.py` check the page's fonts after it
  builds and stop if any failed. Run again, or pass `--allow-font-fallback` if you really mean it. The still tools
  print a warning instead.
- 24 fps. Frames are rendered **in order**: many styles draw each frame over the one before (frost that grows,
  ghosting, marbled paint that keeps its history), so a frame can't be drawn on its own.
- Speed depends on the style and on how much the machine is doing: from about 40 ms a frame (paper cut, painted
  enamel, archive desk) to 250 ms or more (sand, the pinscreen, screenprint's printing), including reading the frame
  back and encoding. Each style's README gives its numbers. A four-minute song is 5,760 frames: a few minutes for the
  fast styles, half an hour or more for the slow ones (see the next section for splitting a render across browsers).

## Long renders: frames on disk, resumable, in parallel

For a long song in a slow style, render the frames to a folder instead of straight into ffmpeg:

```bash
python tools/render_frames.py projects/my-song/index.html --dir renders/frames/my-song --jobs 3
python tools/encode.py renders/frames/my-song --out "renders/My Song.mp4"
```

- Frame `i` is `<dir>/<i:05d>.jpg` and shows song time `(i + 0.5) / 24`. Frames already on disk are skipped, so an
  interrupted render continues where it stopped when you run the same command again, and deleting a stretch's
  frames and re-running redoes just that stretch.
- `--jobs N` renders N runs of frames in N browsers at once. Each run starts with `renderAt()` at its first frame,
  which catches up styles whose frames depend on earlier ones, then steps in order. (Tested: a resumed run's frames
  match a straight-through render pixel for pixel.) GPU-heavy styles gain less, since the browsers share one GPU.
- `encode.py` takes the audio from the folder's `meta.json` (the page's `SONG.audio`), cuts it to the frames on
  disk, and writes the same 1080p and 720p files as `render_mp4.py`.
- **A render that sits before its first frame** is usually the machine, not the page: with other renders or heavy
  WebGL pages running, Chrome can take minutes to start or to build a page. `render_mp4.py` prints the page's URL when
  it's loaded and a progress line every 240 frames.
- **Heavy 3D pages:** building every set of a long WebGL video at once can hang the GPU. Render such a video in
  segments (`--start`/`--end` runs into the same frame folder, each run building only what its stretch needs), and
  on a machine that other renders are sharing, run one segment at a time.

## Fixing one stretch

A full render can take a while. To fix one stretch, render only that slice at full quality and splice it into the
finished file at whole frames:

```bash
python tools/render_mp4.py projects/my-song/index.html --start 120 --end 135 --out renders/fix.mp4
python tools/splice.py "renders/My Song.mp4" renders/fix.mp4 --at 120 --out "renders/My Song v2.mp4"
```

A slice opens with `renderAt(t)`, which catches up styles whose frames build on earlier ones, so its frames match the
full render's and the splice is seamless.

## Checking a 3D video's framing

`python tools/probe.py styles/diorama/index.html` asks the page, for the start, middle and end of every shot,
whether anything stands between the camera and its subject, or whether the camera is inside something. In a crowded
set it finds blocked views much faster than contact sheets.

## Sharing

Share the MP4. If you also want a review page (the video with notes around it), keep in mind that some hosts cap
file sizes: split a long 720p video into parts at scene changes and play them in sequence against the song, and
serve it from something that answers Range requests.



===== 完整公共规范：docs/your-own-video.md =====

# Making a video for your own song

The hands-on steps, from an mp3 to an MP4. For the creative side (what to decide before building, how to pick a
look) see [workflow.md](workflow.md). If you're working with Claude Code, you can just ask it to make a video for
your song: [CLAUDE.md](../CLAUDE.md) walks it through all of this.

## 1. Set up

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt            # rendering
pip install -r requirements-audio.txt      # timing a song (Whisper, librosa, MIDI)
```

You need Google Chrome installed (or run `python -m playwright install chromium`).

## 2. Start a project folder from a style

Pick a style from the [gallery](../README.md#the-styles) and copy its folder:

```bash
cp -r styles/paper-cut projects/my-song
cp ~/Music/my-song.mp3 projects/my-song/song.mp3
```

Audio files are git-ignored, so your song stays out of the repository.

In `projects/my-song/index.html`, change the lyrics script from the demo's
```html
<script src="../../examples/poem/lyrics_data.js"></script>
```
to your own
```html
<script src="lyrics_data.js"></script>
```
(Relative paths from `projects/my-song/` resolve just as they did from `styles/<style>/`, so anything else the
page loads from the repo keeps working.)

## 3. Time the lyrics

Write the lyric sheet (`projects/my-song/lyrics.txt`, one sung line per line, `#section` markers), then run the
pipeline in [timing.md](timing.md). It ends with `projects/my-song/lyrics_data.js`.

## 4. Look at it

```bash
python tools/serve.py
```

Open `http://localhost:8000/projects/my-song/index.html`. The demo's scenes now play under your lyrics for as long as
the demo lasts. That's the moment to decide the plan: which scene goes where, which line lands on which image.

## 5. Replace the demo's scenes with yours

Every style's README has a "Make your own video in this style" section that says which files are the demo (its
scenes, sets, shots or timeline) and which are the engine. Keep the engine; rewrite the demo files. Work a section
at a time:

```bash
python tools/still.py projects/my-song/index.html 30:60:2 --sheet   # stills every 2 s across 0:30-1:00
```

Look at every still on the sheet. Check the console output printed at the end.

## 6. Render

```bash
python tools/render_mp4.py projects/my-song/index.html --start 30 --end 60 --fast   # a quick 720p preview
python tools/render_mp4.py projects/my-song/index.html --out "renders/My Song.mp4"  # the final, 1080p + 720p
```

To fix one stretch later without re-rendering everything, see
[rendering.md](rendering.md#fixing-one-stretch).



===== 完整公共规范：docs/engine-patterns.md =====

# How the engines are built

The eighteen engines in [styles/](../styles) share no code at run time: each folder is self-contained, written for one
song in one medium (a few began as copies of another's files, such as the 3D pipeline or the ray-marched figure). But they
share a shape, and knowing it makes any of them easy to read and a new one quicker to write. This page is that
shape, plus the browser gotchas that cost the most time.

## Simulate the process, not the look

Each engine models how its medium is physically made, and the imperfections come out right on their own:

| medium | what the code does |
| --- | --- |
| screenprint | each ink is a stencil mask plus a halftone; inks are pulled one at a time and multiplied onto paper, each a little out of register, with squeegee streaks and pinholes |
| linocut | a block is a list of gouge cuts and inked areas; the key block prints black over watercolour washes |
| wool embroidery | wool is laid and couched from tiles, outlines are stem-stitched, light is couched gold thread |
| marbled paper | paint floats as closed outlines on a bath; drops, combs and swirls are exact maps applied to every point |
| magic lantern | slides are baked as tinted glass; a frame stacks glass by multiplying and throws it through a lens |
| painted enamel | two-colour bristle strokes with a highlight flick toward the light, then gold leaf |
| paper cut | cut shapes with a lit rim and a soft shadow, layered in depth and lit from behind |
| mosaic | tesserae are laid in rows along the outlines, then grouted |
| sand on a lightbox | sand thickness is a density field; the lamp shows through as `exp(-k * thickness)`; fingers clear lines |
| carved diorama | each piece is a signed-distance sculpture meshed in the browser; tool marks are a bump in the piece's own space |
| photomontage | photographs are painted in greys, then given a print's grain, halation and tone curve, and cut out with drifting scissors |
| pinscreen | a field of pins at different heights, lit from a low angle, each pin's shadow falling on the next |
| archive desk | every paper is pre-rendered with its shadow, grain, foxing and torn fibres; stamps are inked, then eroded |
| night poster | a shape's shadow is the band a shifted copy of it fails to cover; night mixes colours toward navy while lamps keep their brightness |
| batik | a real 3D set lit by two coloured lamps is rendered into buffers; wax resists where both lamps reach, each dye takes where only one does, and the wax cracks |
| long-exposure glass plate | each frame integrates many light drawings over the exposure, so whatever moved is a smear and whatever stood still is sharp; then halation, dust and the emulsion's edge |
| silverpoint | even hatching whose weight follows the tone; lines can't be erased, and tarnish from grey to brown with age |
| carved relief | the scene becomes a height field, shaded by a raking light with its own cast shadows |
| liquid light show | oil, water and dye in a dish on a projector: warped-noise dye bands, metaball oil drops with a meniscus, and drawn transparencies whose black ink really blocks the lamp |
| thermal camera | a scene rendered as temperatures and mapped through a camera palette, with a thin visible-light edge overlay, warm breath and fading heat prints |
| showboat stage | painted flats given brushwork by a sampled-stroke pass, lit by a light map in which the actors are lit through their own silhouettes |

A filter that makes a clean digital picture look like linocut never convinces for long. A few rules about how the
real thing is made go much further.

## One frame

Almost every engine's frame function looks like this:

```
renderFrame(t):
  shot = the shot covering t
  set  = shot.set, baked on first use           (the still layers: land, buildings, background)
  cam  = shot.cam(t)                            (keyframed, eased)
  draw the set's layers through the camera       (parallax: nearer layers move more)
  draw what moves at t                           (figures, props, light, weather)
  post: light (a multiplied lamp or light map), grain, vignette, the medium's texture
  if t is inside a transition: draw the next shot too and mix (dissolve, wipe, push)
  the lyric band / margin / caption for t
  fade in and out at the ends
```

The canvas is 1920x1080. Several styles keep the picture above a band for the lyrics (e.g. 1920x960 + 120).

## Sets, shots, cameras

- **Sets** (or scenes, worlds, plates) are places. Their still parts are drawn once into offscreen canvases the first
  time they're needed ("baked"), then only composited. Keep a memory budget: the whole song's sets rarely fit at
  once, so drop the least recently used. Bake at load what the first seconds need, so playback doesn't hitch.
- **Shots** are stretches of song time: `{t0, t1, set, cam, ...}` plus a function that poses what moves.
- **Camera keys** are `[time, x, y, zoom, ...]` with easing between them. Two useful rules:
  - push in with **lens zoom**, not by travelling into the layers: depth travel blows the nearest layer up (snow
    becomes moons);
  - **never let the camera see past the edge** of what's drawn. Check the frame corners on every new camera.
- **Transitions:** dissolves, drop wipes (a new picture spreading inside a drop), push and pull (from a room to the
  picture on its screen), panels (pull back to a page of panels, push into another), re-laying one medium as another
  past a moving line.

## Time: on twos, and in step with the song

- Hand-made animation moves **on twos**: pose changes at 12 fps inside 24 fps video. Several engines step motion at
  12 fps (`tm12 = Math.floor(t * 12) / 12`) while the camera moves at the full 24, which keeps the hand-made feel
  without a juddering camera. Texture "boil" (grain, ink noise) often changes at 8 fps.
- **Ease into fast moves**, or drive them with real time: a move that starts at full speed jumps at 12 fps.
- **Hits on beats, changes on lines.** `SONG.beat(n)` and each line's `t0` and word times are the anchors. A word
  lighting in the lyric band typically fades up over `[t - 0.04, t + 0.16]`.
- **Keep something moving.** A hold longer than a beat or two reads as the player freezing. A slow drift, a breathing
  light or drifting smoke keeps a still picture alive.

## Determinism and frame-to-frame state

- All randomness comes from seeded generators (`mulberry32(seed)`) and noise keyed to the frame number. Never call
  `Math.random()` while drawing a frame. The same `t` must give the same picture, or an MP4 won't match what you
  checked.
- Some styles **carry state from frame to frame**: frost that grows, ghosting of the previous frame, a charcoal
  drawing that's erased and redrawn, marbled paint whose outlines remember every comb. Those must be stepped in
  order. `renderAt(t)` then means "rebuild the state from the start of this scene up to t", and each engine's README
  says how it does that.
- When a view steps backwards in time (a camera effect that holds frames, a scrub), keep what's already baked rather
  than rebuilding it from scratch each step, or rendering crawls.

## Figures

- **Whole figures**, posed. Every engine has a rig: jointed silhouettes, contour-drawn people, ray-marched signed
  distance bodies, carved 3D pieces. Most use **two-bone IK** for arms (and often legs), so a hand can be put exactly
  on a rope, a cup or another hand. Each rig spells it its own way: `reachArm()` in paper cut, an arm given as
  `{t: [x, y]}` in embroidery or `{at: [x, y]}` in painted enamel; the style READMEs show how.
- Build **every figure of a kind from one model**, so its anatomy is the same in every shot; vary only pose,
  clothing and age.
- Things that make figures read wrong, all hit at least once: round heads read as teddy bears (give them a muzzle
  or a jaw); coats that hang along the body turn a crouching figure into a plank (hang them toward world-down);
  digitigrade legs with a long stride look like sitting on a stool; two figures leaving the same way merge into one
  blob; close-up arm silhouettes read as clubs or poles.

## Light

- A **lamp** is a radial gradient drawn with `multiply` (or a light map multiplied onto the whole picture). Its
  warmth and brightness carry most of a scene's mood.
- **Self-lit things** (flames, lit windows, glowing marks) go in their own layer drawn after the light map, plus a
  glow. A reflective shape in front should erase the self-lit layer behind it.
- On pale paper, `screen` adds almost nothing; `soft-light` plus a weaker `screen` shows coloured light.
- Glass only darkens: a moving piece has to pass over light glass, or it vanishes.

## Text in the picture

- Load fonts before drawing and wait for them (`document.fonts.load(...)` for each face and script you use), or text
  falls back to a default font. `document.fonts.load` resolves even when the font never arrived, so check the
  result (or `document.fonts.check(...)`) before building. Put `<meta charset="utf-8">` at the top of the page for
  any non-ASCII text.
- **Start building only when every script has loaded** (`DOMContentLoaded`, or put the start call at the end of the
  last script). A build started from a font promise plus a short timer can win the race against later scripts when
  the fonts come from cache, and the page fails to build only sometimes.
- Keep the lyrics readable: if the camera zooms, keep the text out of the zoom (a band or margin drawn in screen
  space).

## Browser gotchas that cost hours

- **One bad gradient value kills the frame.** `addColorStop` with a NaN or an out-of-range offset throws, and nothing
  after it draws. Check the console after every change.
- **`destination-out` uses the current fill's alpha.** A fill left translucent from the last wash only half-erases.
  Set `fillStyle = '#000'` before erasing.
- **`[hidden]` loses to `display: grid`.** Add `.gate[hidden] { display: none }` for overlay elements.
- **Globals collide.** Plain scripts share one global scope; a helper named like an existing function (`hand`,
  `line`) silently replaces it.
- **Tiling seams:** a texture tiled from a sampled corner shows seams on big pieces; downsample the whole texture.
- **WebGL:** GLSL has reserved words you'd never guess (`patch`); creating a texture while another is bound can
  overwrite a texture unit (create textures on a scratch unit such as TEXTURE15); a three.js `InstancedMesh` keeps the
  bounds of its first draw unless `frustumCulled = false`.
- **Headless loads:** wait for the page with `wait_until='commit'` and your own ready flag; a page that builds a lot
  at load can time out waiting for the load event.
- **Grain that changes every frame bloats the MP4.** Change it on twos.

## Starting a new engine

1. Copy the style closest to what you want. Keep its player (`index.html`, the playback and `window.__video` parts
   of its engine) and its lyric code.
2. Write the medium: the few functions that turn a shape into your medium's marks. Test them on stills first, on a
   page that just draws one scene (a lab page).
3. Draw the same key scenes in your medium and in one or two alternatives. Choose.
4. Then sets, shots and the song.



## 原作者媒介陷阱与经验摘录

## Lessons and gotchas

- **Ink must really block.** Multiply the transparency over the light in linear colour (`pow(rgb, 2.2)`): in gamma
  space even 1% of the lamp leaking through black paint showed as a visible navy.
- **The sheet lies on top of everything in the dish.** The oil's highlights and caustics were first added after the
  sheet, and showed as grey smudges over black ink. Multiply the sheet in last; only the second lamp and the mist go
  over it.
- **Glossy drops look like plastic balls.** Keep the oil matte: a strong tint, a dark rim, a faint highlight.
- **Far planes in 86% ink** (`F.INKF`), so a black figure in front of a building or a hill still reads.
- **Let the picture or the liquid lead, not both at once.** With the dye at full strength, figures and gels get lost;
  lower `wild` and keep the ground `calm` when the picture matters, and turn the liquid up (and the sheet down with
  `figAmt`) when the liquid is the subject. Varying this from scene to scene is most of the style.
- **One dye layer looked flat and slow.** The second, slower layer turning the other way, the bubbles, a ring on each
  drum hit and more drops made it feel alive.
- **Turning round a far-off point shears the dye into rings.** Swirling the dish round coordinates that the wind had
  carried far from the centre wound the dye into concentric circles, and changing the band size slid it. So the drift
  is integrated at load in each dye layer's own turned and scaled coordinates, and the turn, the swirl and the scale
  only ever act on the dish's own small coordinates. Anything you add that accumulates should be integrated the same
  way.
- **The dish's own swirl fights the wind.** Turn `swirl` down and `turn` off (as `windP` does) when the dye should
  stream one way.
- **An even lattice reads as a halftone screen.** Each emulsion drop is nudged off its place and given its own size.
- **A ring can push the picture past the sheet's edge.** Beyond a sheet at rest the engine repeats its edge pixels;
  only a sliding sheet has clear glass beyond it. (Otherwise every drum hit flashed white slivers under the ground.)
- **Round drops as leaves read as berries or beads.** Gel leaves (a leaf of coloured film with an ink edge and
  midrib) read as leaves, with the drops quivering behind them. A gel multiplies with the dye under it, and orange over
  blue comes out brown: calm the dye behind gel pictures.
- **Pale gels vanish over pale dye.** White sheets on a washing line came out as empty outlines; give gels real
  colour.
- **Mist over black ground reads as a flat khaki or grey sheet.** Keep the mist over the liquid, or thin.
- **In a dissolve every parameter blends,** so the old scene's mist, drops and wind hang over the new picture for the
  length of the fade: clear them before the change, or push the new sheet in with `slide`.
- **The lamp shouldn't go to black.** A dimmed lamp burns orange, and a blink between sections keeps a faint filament
  glow, so no frame is blank; the ticks keep pulsing in the dark, which keeps the frame alive.
- **A silhouette carries the whole person.** Body shape has to read side on as well as from the front; thin limbs at
  small sizes vanish into the dye bands; small features (glasses, a nose) disappear. Cut anything that must show
  inside a silhouette out of it, or lay a gel in it.
- **Two figures that overlap become one blob.** Keep people apart, or have one pass the other quickly.
- **A sheet that never moves looks pasted on,** even over moving dye. Drift every transparency a few pixels.
- **Title letters cut through black film need a heavy face:** thin strokes show too little dye to read.
- **The oil drops are capped at 32 a frame:** the shader loops over them five times a pixel.
- **Grain that changes every frame bloats the MP4;** here it changes on twos.
- **Wait for the fonts.** The page builds only after every script has loaded and the fonts have been asked for, and
  warns in the console if Jost didn't arrive (the MP4 tool stops rather than render in a fallback face).
- **Changing only the `#t` part of the address doesn't reload the page;** reload with a new query after editing code.


