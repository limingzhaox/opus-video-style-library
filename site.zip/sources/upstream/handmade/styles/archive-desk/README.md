# Archive desk

A desk under one hanging lamp, seen from straight above. Papers arrive, slide, stack and leave on keyframed tracks,
while the lyrics are typed onto a statement page one word at a time. Everything is drawn with plain 2D canvas: no
libraries and no image files. It looks like real paper and film because each object is pre-rendered with the
things real ones have:
- **Paper:** a baked soft shadow, a grain texture overlaid on the base colour, darkened edges, foxing spots, and
  torn edges with pale fibres.
- **Rubber stamps:** the ink is eroded with noise and has dropouts, and each stamp lands with a small squash.
- **Typewriting:** every letter sits a little off its line, a little rotated and unevenly inked, with a faint
  double strike.
- **Black-and-white photographs:** painted in greys at low resolution, then printed. The print pass adds surface
  mottling, halation, an S-curve with lifted blacks, grain, toning, a vignette, scratches and a white border.
- **Newsprint:** a photograph can be reprinted as newspaper halftone, a staggered grid of ink dots on grey torn
  newsprint under a masthead and a headline, the columns too small to read.
- **Pencil:** strokes take their colour from a noise tile, so they pick up the paper's tooth, and rubbing out
  leaves grey ghosts.

On top of the objects:
- **Light:** the lamp's pool is multiplied over the desk, and a cool window light carries the shadows of a tree
  outside.
- **Frost and smoke:** frost grows in from the frame's edges, and smoke rises from a cigarette in curl-noise strands.
- **Decay:** a system borrowed from worn VHS tape (tearing, colour split, rolling, held frames, static), plus a
  green surveillance-camera overlay.

The demo is a weather office's case file on the wind, over Christina Rossetti's "Who Has Seen the Wind?".
- **What you see:**
  - The title is typed onto the file's label as the lamp flickers on.
  - Photographs show what the wind moves: a weathervane, a field, a harbour, poplars, washing, a kite.
  - Two witnesses are stamped NO WITNESS on "I" and "you".
  - A contact sheet of aspen leaves is circled in china marker while the leaves tremble.
  - An anemometer strip records the song's own gusts.
  - On "passing by", the local paper's report of the gale lands, its photograph of the poplars in halftone.
  - A forecaster's surface chart unfolds and gets its isobars, fronts and wind arrows.
  - A pencil tree is drawn upright, rubbed out on "bow" and drawn again bowing.
- **The ending:** a gust clears the desk and blows the typed words off the page. The smoke settles to rise straight
  up.

![The desk near the end of the demo: the surface chart, a pencil tree bowing, the wind scale, a newspaper clipping of the gale, the anemometer strip stamped PASSED BY, and the typed poem](img/hero.jpg)

| | |
|---|---|
| ![The contact sheet under a working magnifier, the wind scale circled at force 3](img/leaves.jpg) | ![The surveillance camera zoomed in on the chart, with the line as a caption](img/cctv.jpg) |
| ![The surface chart with isobars, fronts and wind arrows, frost starting at the edges](img/chart.jpg) | ![The last gust: papers gone, the typed letters blowing off the page](img/gust.jpg) |

## Run the demo

From the repository root:

```
python tools/serve.py
```

Then open http://localhost:8000/styles/archive-desk/index.html. It plays live in the browser, in step with the
song: a frame takes about 10 ms to draw. Space plays and pauses, and the bar scrubs. If the song can't load, the
video plays on a silent clock.

- **A still:** add `#t12.5` to the address (any time in seconds) for a full-width still of that moment. Changing
  only the `#` part doesn't reload the page; after editing code, reload.
- **Stills to PNG, with a contact sheet:**
  `python tools/still.py styles/archive-desk/index.html 2 6 12.5 0:37.5:2.5 --sheet`
- **MP4:** `python tools/render_mp4.py styles/archive-desk/index.html --fast` writes `renders/archive-desk-720p.mp4`.
  - On an otherwise idle Apple M4, the whole 37.5 s demo (900 frames) took 36 s in `--fast` mode: about 40 ms a
    frame, including reading the canvas back and encoding.
  - With several other renders running it took about 4 minutes.
  - Without `--fast` it writes 1080p and 720p with the slow x264 preset. That is several times slower, because
    busy frames are expensive to encode.

## How it works

### Files and load order

Plain scripts that share global names, loaded in this order by `index.html`:

| File | Job |
|---|---|
| `../../examples/poem/lyrics_data.js` | `window.SONG`: the song's timing (shared by every style) |
| `data.js` | `LINES`, built from `SONG`; `MAPDATA`, the projected coastline for the chart; `mapXY(lon, lat)` |
| `core.js` | Math, seeded random, value noise, fbm and curl noise; fonts; wood, paper, grain and static textures; `makeObj` (paper objects); stamps and seals; `photoTreat`; `makeFace` portraits; `makeGroup` |
| `objects.js` | The timeline: `addObj`, pose tracks (`P`, `K2`, `life`, `sweep`), `stampOn`, song-time helpers (`LT`, `WT`, `BEAT`), and draw-on helpers (`drawOn`, `revealText`, `marker`, `foldView`, `scribble`) |
| `sketch.js` | Pencil: the `Sheet` class (timed strokes, text, dots, erasures), stroke helpers, and the `SK` shape library (tree, spruce, house, figure, grass, gust lines) |
| `photos.js` | `photoPrint` and its painting helpers; the scenes in `PH` (street, shopfront, field, harbour, forest, vane, poplars, washing, kite, leaves); newsprint (`halftone`, `newsClipping`); `portraitPrint`, `contactSheet`, `blowUp` |
| `scene.js` | The demo: every object on the desk, built and timed. Replace this for your video |
| `engine.js` | The draught (wind), the typed transcript, frost, smoke, the lamp and window light, camera, decay and the surveillance camera, playback, and `window.__video`. Each section starts with the demo's keyframe lists |

The page follows the repository's contract: it draws into `<canvas id="film" width="1920" height="1080">` and sets
`window.__video = {ready, duration, step(t), renderAt(t)}` (`error` if the build fails). `#t<seconds>` shows a
still.

### Objects and tracks

Desk coordinates are pixels of a 1920x1080 desk (the camera at scale 1 shows exactly that). An object is a
pre-rendered canvas plus a pose function.

```js
makeObj(w, h, opts, draw)   // -> {c, w, h, pad, S}: a canvas of the object with its soft shadow baked in
```

`draw(g, r)` paints in the object's own coordinates (0..w, 0..h) with a seeded random `r`. Useful `opts`:
- `base`, `texA`, `age`: paper colour, grain strength and edge darkening.
- `grid` and `fox`: squared paper and foxing spots.
- `round` (corner radius) or `path` (any Path2D outline; `tornPoly` gives torn ones).
- `fill(g, path, r)`: paint a non-paper object (ashtray, magnifier) yourself.
- Shadow: `shA`, `shB`, `shX`, `shY`, or `shadow: false`.
- `S`: pixel density.
- `after(g, r)`: draw outside the clip, such as torn-edge fibres.

```js
addObj(id, canvas, z, track, {dyn, draw, loose, flut, jit})
```

- `track` is a list of keys `[t, x, y, degrees, alpha, scale, ease]`. The ease shapes the move into that key.
  Before the first key the object isn't there; after the last it stays put.
- `P(t, [x, y, deg, scale], alpha, ease)` makes one key.
- `K2([t, [x, y, deg, scale], alpha, ease], ...)` makes a track whose moves ease in and out unless you say
  otherwise.
- `dyn(g, t)` draws animated things on top in the object's coordinates: typing, pencil, marker, a chart trace.
- `draw(g, t, o)` replaces the canvas altogether. The folding chart and the magnifier use it.
- `z` is fixed for the whole video.
- `loose` and `flut` say how the draught treats the object (see below).

A real example from the demo: the weathervane photograph arrives as "seen" is sung, and gets shoved aside when
the chart comes in.

```js
ph('VANE', PH.vane(41, 260, 300, {turn: .14}), 260, 300, 41, 20,
   [[WT(0,2)-.55, [650,-260,16]], [WT(0,2), [560,262,-5], 1, easeOut], [18.45, [560,262,-5]], [19.1, [420,150,-12]]]);
```

`ph` is a local shorthand in `scene.js` for `addObj(id, photoObj(canvas, w, h, seed), z, K2(...keys), {loose: 1, flut: .8})`.

### Timing to the song

- `LINES[i] = [section, text, start, end, [word start times]]`, built in `data.js` from `SONG.lines`.
- `LT(i)` is line i's start. `WT(i, j)` is when word j of line i is sung; j = -1 is the last word.
- `BEAT(n)` is beat n (`SONG.beat`).
- Everything in `scene.js` is written against these, so a stamp lands on its word:

```js
stampOn('W1', WT(1,1), 'NO WITNESS', 85, 168, -9, 22, 2, 5.1, VIOLET, .16);  // lands on "I"
stampOn('FOLDER', BEAT(5), {...sealCanvas('WEATHER OFFICE * OBSERVATIONS * ', 'No. 4', VIOLET, 3.3), w: 124, h: 124}, 392, 258, -14, 0, 0, 0, VIOLET, .15);
```

The full signature is `stampOn(id, t, text, x, y, deg, size, borders, seed, color, burst)`:
- `x`, `y` are in the object's coordinates.
- `text` may be a ready canvas `{c, w, h}`, such as a seal.
- `burst` flashes static as the stamp lands.

### How the lyrics are shown

The typed transcript (`engine.js`, "the transcript") is the lyric display:
- Each section of the song gets its own page, headed "RECORD OF STATEMENT".
- The page slides in just before the section's first line and leaves just before the next section's.
- Each word starts typing when it is sung, plus a small lag (`LAG`). Its letters are spread over the time until the
  next word, 22-70 ms apart.
- Long lines wrap. About 16 rows fit on a page at the default `TSIZE` 24 and `TLH` 40.
- `BRACKETS` draws a pencil bracket beside chosen lines.
- `BLOW_T` makes the last page's letters lift off and blow away at the end.
- A finished page is drawn from a cache.

While the surveillance camera is on, the picture is too coarse to read, so the line in `CCTV_CAP` is also
captioned word by word in the camera's font.

Keep the transcript readable: when the camera zooms, keep the page in frame. Zooms up to about 1.06 centred at
x 960 or more do.

### The draught

`WIND(t)` is one curve: 0 is still, .4 a breeze, 1 a gust, 2 a gale. It is `.42 * swell(t) + kf(GUST_K, t)`, all
times `kf(CALM_K, t)`:
- **`swell`** follows the demo tune's own wind noise, which rises and falls every 7.5 s.
- **`GUST_K`** adds gusts on chosen words.
- **`CALM_K`** lets the end go still.

Everything the wind touches reads the same curve:
- **Papers** with `flut` shiver with smooth noise, scaled by the wind.
- **Papers** with `loose` get shoved by each entry in `PUSH` (`[start, seconds, dx, dy, degrees]`), each by a
  slightly different amount. The last entry is the gust that clears the desk.
- **Smoke** is pushed along `WDIR` as it ages.
- **Dust** drifts by the wind summed over time.
- **The hanging lamp** sways.
- **The branches** outside the window bow, more at the tips, plus `BOW_K`.
- **The anemometer strip** in `scene.js` plots it.

### Light

`lightPass` builds a half-size light map, then multiplies it over the desk:
- **The lamp:** a radial gradient whose warmth (`LW_K`), brightness (`LB_K`) and position (`LX_K`, `LY_K`) are
  keyframed. It flickers on at the start and browns out on the last beat (`LAMP_OFF`).
- **The window:** a parallelogram of cool light (`WIN`, `WIN_K`, `WINC`) with the window frame and a swaying tree
  cut out of it. It is drawn in a quarter-size buffer, blurred and added. It is faded near the lamp, where it
  would only burn out pale paper.

The lights are added together before they multiply the desk. That is what lets the window light the desk when the
lamp is off.

### Photographs, portraits, pencil

- **`photoPrint(w, h, seed, paint, opts)`** paints in greys with `gv(v)` through the helpers:
  - `phSky`, `phStreaks` (wind-dragged cloud), `phRidge`, `phForest`, `phConifer`.
  - `phBroadleaf` and `phPoplar`, both with a `bend`.
  - `phGrass`, `phWaves`, `phPerson` (with `lean` and `flap` for wind), `phCar`, `phPole`, `phWire`.

  Then it prints the result. `opts.q` sets how coarse the negative is (5.5 for a blow-up); `contrast`, `grain`,
  `tone`, `border` and `fade` do what they say.
- **`PH.*`** are ready scenes. Each takes `(seed, w, h, opts)`.
- **`makeFace(p)`** builds a parametric portrait:
  - `hair`: short, parted, swept, bald, curly, cap, shaved, long or bun.
  - `beard`: full, moustache or stubble.
  - `glasses`, `clothes`, face shape, lighting side and toning.

  `FACES` has presets. `portraitPrint(p, w, h, seed)` prints one with the same finish as the other photographs.
  `blowUp(p, seed, w, h)` makes a grainy enlargement.
- **`halftone(g, src, x, y, w, h, {cell, ink, paper, gain, lift})`** reprints a photograph (any canvas, such as a
  `PH.*` print made with `border: 0`) as newspaper halftone: one round dot per cell of a staggered grid, its radius
  growing with the square root of the darkness, so a mid-grey keeps its weight.
- **`newsClipping(seed, w, h, {paper, date, head, photo, photoH})`** makes a clipping as a paper object: torn
  newsprint, the masthead and date over a double rule, a headline, the photograph in halftone, a caption and columns
  of body text drawn as grey bars. The demo's:

  ```js
  const news = newsClipping(56, 340, 300, {paper: 'The Coast Weekly', date: 'Saturday', head: 'Gale in the night',
    photo: PH.poplars(57, 320, 170, {bend: .95, border: 0}), photoH: 128});
  addObj('NEWS', news, 53, K2([WT(7,3)-.5, [1500,-300,20]], [WT(7,3)+.05, [1086,592,-5,.82], 1, easeOut]), {loose: 1, flut: .7});
  ```
- **`contactSheet(seed, frame, {cols, rows, fw, fh})`** lays film strips of frames. `frame(k, w, h)` paints frame k,
  and `at(k)` gives a frame's corner, for circling in china marker with `marker`.
- **`new Sheet(w, h)`** is a pencil layer in a paper's coordinates. Add timed operations, call `finish()`, then
  `sheet.draw(g, t)` from the paper's `dyn`:
  - `line(points, t0, t1, {w, a, col, erase, ghost})`; `lines` spreads several strokes over one span.
  - `text`, `dot`, `rubOut`, `smudge`.

  A stroke with `erase: t` is rubbed out to a grey ghost at t. Finished operations are baked into the sheet's own
  canvas, so a sheet costs almost nothing once it's drawn.
- **`SK.tree(x, y, h, bend, seed)`** returns the tree's parts separately (`trunkLow`, `trunkHigh`, `limbs`, `crown`,
  `shade`). The same seed with a different `bend` gives the same tree bowed. That is how the demo rubs out the
  upright crown and redraws it bent.

### Camera, frost, smoke, decay

- **`CAMK`**: `[t, x, y, scale]` keys, eased in and out; `x`, `y` are the desk point at the frame's centre.
  `SHAKE_K` adds noise shake. For a cut, put two keys a hundredth of a second apart (`[224.0, ...], [224.01, ...]`).
- **Frost** grows in from the frame's edges from `F_EDGE.t0`, at `F_EDGE.sp` pixels a second. Each tuft is a short
  stem with 60-degree side needles. It lives in screen space (frost on the glass), is grown incrementally into its
  own canvas, and is drawn as a thin shadow, a blue-grey body and a white core.
- **Smoke:** `makeEmitter({t0, t1, src, dir, spd, n, rate, wind, seed})` makes curl-noise strands simulated at
  120 steps a second. They are drawn in long, low-opacity chunks at quarter, half and full resolution, plus a
  shadow pass cast away from the lamp.
- **Decay:** one curve, `CKF` (0 clean to 1 ruined), drives tearing, rolling, colour split, displaced blocks,
  ghosting, desaturation, scanlines, flicker, held frames and random intrusions. Each effect only starts above its
  own threshold, so a low curve stays clean.
  - `CCTV_WIN` lists surveillance windows and the chance the camera is on in each 5-frame block.
  - `CCTV_ZOOM` zooms that camera onto part of an object. While it is on, the scene runs at 8 frames a second.
  - `STATIC` adds bursts; stamps add their own.
- **Focus pulls and spotlights:** `FOCUS` blurs everything except some objects (the title card uses it), and
  `SPOT` darkens everything except some objects.

### Determinism and caching

- There is no `Math.random()` per frame. Textures and objects come from seeded `mulberry32`, and per-frame
  randomness is `hashi(frame, salt)` with frame = floor(t × 24). A given time always looks the same.
- Everything is built at load in `buildAll()`: textures, every object canvas, page caches, frost needles and the
  window tree. Building on first use caused visible hitches.
- `step(t)` draws the way playback does. It skips a frame already drawn and keeps the deliberate held frames.
- Frost growth, smoke, pencil sheets and ghosting carry state from the frame before, so an MP4 must be rendered
  in order, as `render_mp4.py` does.
- `renderAt(t)` makes a clean still from any state. The frost regrows, the smoke re-simulates the 6 s that are
  visible, and the sheets rebuild.
- Small steps back in time, from the surveillance camera's 8 fps clock, keep what has been built.

## Make your own video in this style

1. **Copy the folder:** `cp -r styles/archive-desk projects/my-song`, and put your mp3 in it as `song.mp3`
   (see [docs/your-own-video.md](../../docs/your-own-video.md)).
2. **Make your song's timing file** with `tools/audio/to_js.py`, which writes a `lyrics_data.js` of the same shape
   ([docs/timing.md](../../docs/timing.md)). Point the first script tag in `index.html` at it:
   `<script src="lyrics_data.js"></script>`. `SONG.audio` must be the song's path relative to `index.html`.
3. **Change the title** and subtitle in `index.html`. The title card types `SONG.title` and `SONG.credit` onto the
   case file's label, so those come from your timing file.
4. **Keep** `core.js`, `objects.js`, `sketch.js`, `photos.js` and most of `engine.js`. Rewrite `scene.js`, and redo
   the keyframe lists at the top of each `engine.js` section:
   - `GUST_K`, `CALM_K`, `PUSH`, `swell`.
   - `BRACKETS`, `BLOW_T`.
   - `F_EDGE`.
   - `CAMK`, `SHAKE_K`.
   - `LW_K`, `LB_K`, `LX_K`, `LY_K`, `LAMP_OFF`.
   - `WIN`, `BOW_K`.
   - `FOCUS`, `SPOT`.
   - `CKF`, `CCTV_WIN`, `CCTV_CAP`, `CCTV_ZOOM`, `STATIC`.

   `swell` follows the demo tune's wind; set it to a constant, or to your song's loudness.
5. **Replace `data.js`'s map** if you want a chart of somewhere else. `MAPDATA` is `{w, h, lon0, lat1, k, c, land}`,
   with land rings as flat `[x, y, ...]` lists in map pixels. The demo's is Natural Earth 1:50m land (public domain,
   from the world-atlas package), clipped to the British Isles, projected with x = (lon - lon0)·k·c and
   y = (lat1 - lat)·k, and simplified. See `tools/maps/` for making one. Remember the simplification gotcha below.
6. **Add an object:** build its canvas with `makeObj` (or `photoObj(PH.field(seed), w, h, seed)`), then `addObj` it
   with a track keyed to your words:

   ```js
   const note = makeObj(300, 200, {seed: 7, base: '#ece6d4'}, (g, r) => typeText(g, 'Filed.', 30, 60, 22, r));
   addObj('NOTE', note, 45, K2([LT(3)-.5, [900,1400,10]], [LT(3), [900,700,-4], 1, easeOut]), {loose: .7, flut: .4});
   stampOn('NOTE', WT(3,-1), 'RECEIVED', 150, 130, -6, 30, 2, 9, RED, .3);
   ```

   - **To have it arrive on a word,** end its arrival key at `WT(i, j)`.
   - **To make it leave,** add `sweep(at, to, t0)` keys or a key with alpha 0.
   - **For pencil,** make a `Sheet`, add strokes timed to words, and draw it from the object's `dyn`.
   - **To land a move on a beat,** use `BEAT(n)`. Change things on line starts (`LT`).
7. **Check stills across the whole song** with `tools/still.py ... 0:<duration>:2 --sheet`. Look at the frame
   edges, the transcript, and every stamp. Then render with `--fast`.

Useful knobs:
- **Typing:** `TSIZE`, `TLH` and `TMAXW` set the type's size, row height and line length.
- **Pages:** `TRP` is where the page lies.
- **Paper:** an object's `flut` and `loose`.
- **Decay:** `CKF`'s height. Stay under about .3 for a clean look, around .5 for visible damage.
- **Frost:** `F_EDGE.sp`.
- **Window:** `WINC` and `WIN_K` for its strength.
- **Photos:** `photoPrint`'s `contrast` and `grain`.

## Performance

Measured in headless Chrome with the GPU on, on an Apple M4 with nothing else running:
- **`step(t)` in order:** 10 ms a frame on average (median 8 ms, 95th percentile 16 ms), so it plays live
  comfortably. With the machine busy with other renders it was about 18 ms.
- **`renderAt(t)`, a cold still:** 70-135 ms, mostly re-simulating six seconds of smoke.
- **Building at load:** about 1.5 s including fonts.
- **Memory:** the JavaScript heap is small (about 11 MB). The canvases are most of it, roughly 150 MB: a dozen
  full-frame and half-size buffers plus every pre-rendered paper.

What makes a frame slow:
- the smoke simulation (strands × points × two curl lookups, 5 steps a frame);
- the surface chart and the anemometer trace, which are redrawn every frame;
- full-frame composites in the decay pass (colour split, ghosting);
- the magnifier, which copies what's under its lens.

To render a slice, pass `--start` and `--end` to `render_mp4.py`.
- **Its first frame rebuilds the state** that carries over: frost grows to that moment, smoke re-simulates the
  visible 6 s, and pencil sheets bake.
- **The slice matches a full render** except for small differences in the smoke. Splice it in with
  `tools/splice.py`.

## Lessons and gotchas

- **A perfectly clean desk looks too tidy.** A decay arc fixes it: clean at the start and increasingly corrupted,
  with static, dropped frames and surveillance overlays flickering in and out. Gate the random intrusions behind a
  threshold on the curve, or they spoil the clean opening.
- **Small changes need to be obvious.** A swap between two similar faces went unnoticed. Make faces clearly
  different people, and move the camera in when a change matters.
- **Smoke looked like a solid white tube.** Overlapping round-capped segments stack their opacity. Draw longer
  chunks at low opacity, in several layers.
- **Frost:** long branching lines look like twigs, and random short needles look like static. Short tufts growing
  inward from the edges look like frost. On pale paper, white needles vanish, so give them a blue-grey body, a
  thin shadow and a white core.
- **Edge effects belong in screen space.** Frost grown in desk coordinates showed as a hard inset rectangle once
  the camera pulled back.
- **Photos:** plain silhouettes read as default avatar icons. A photo reads as a photo once it has shading,
  features, grain and toning. Run portraits through the same print as everything else, or they look pale beside
  the other photos.
- **A single bad value in a canvas gradient** (NaN or Infinity in a colour stop or a radius) kills the whole
  frame. Read the console after every load; the tools print it.
- **Build caches at load, not on first use:** building on first use caused a 120 ms hitch mid-song.
- **Character encoding:** put `<meta charset="utf-8">` first, or text in other scripts comes out garbled.
- **The play overlay never hid:** `display: grid` beat the `hidden` attribute. Add `.gate[hidden]{display:none}`.
- **Serve over HTTP:** some previewers open `file://` pages as static snapshots with no scripts.
- **Stale scripts after an edit:** a plain Python server lets the browser cache them. `tools/serve.py` sends
  no-cache headers.
- **Map outlines:** simplifying a closed outline can collapse it to two points, so split it at the point farthest
  from its start first. Outlines that cross the date line draw lines straight across the map; shift their
  longitudes per outline.
- **Global names collide.** These are plain scripts in one namespace. `core.js` has a global `hand()` for
  handwriting, and a line helper of the same name broke every text on the desk; hence `hl()`.
- **The surveillance camera's clock:** at 8 fps its scene time steps backwards between blocks. Every pencil sheet
  rebuilt itself from scratch on each step, and the render crawled. The same steps back also restarted the smoke
  and regrew all the frost, giving 60 ms spikes. Sheets, frost and smoke now all keep their state through steps
  back of up to 0.3 s.
- **Overlays on paper** (tracing paper, the window light) have to be modest. Tracing paper needs to be milky
  (alpha about .6) with lines darker than the drawing under it. Light added near the lamp burns pale paper out, so
  the window light fades near the lamp.
- **Encoding is the slow part.** Busy frames are hard to encode: with x264's slow preset at two sizes, a test ran
  at about 0.4 s a frame although drawing took 3-10 ms. Use `--fast` for previews.
- **Render in order.** Frost, smoke and ghosting depend on the frame before.
- **Layering:** z is fixed per object. Raising one paper to cover another can put it above something else later,
  so plan z per scene, or raise several together.
- **Holds:** a hold of several seconds reads as the player freezing. Keep holds to a beat or two, and keep
  something drifting: the lamp breathing, dust, smoke, branch shadows.
- **Time to the measured audio,** not to the lyric sheet's labels. Song generators ignore dynamics markings.
  Speech-to-text word times can run early by a second or more, so check them against the vocal before timing
  stamps to words.
- **Cutting a hole** with `destination-out` removes only as much as the fill's alpha. A leftover translucent
  `fillStyle` left the magnifier's lens 88% black.
- **The surveillance camera's zoom reads the clean picture.** It used to crop the frame after the decay pass, so
  whenever that frame was torn or rolled the zoom magnified displaced strips and landed on the wrong part of the
  desk. It now crops the scene before decay (`SCN`) and adds its own degradation after.
- **See-through objects need their own shadow.** `makeObj` bakes a solid shadow under the whole outline, which shows
  through glass or anything translucent. Give such an object `shadow: false` and draw a soft blurred shadow yourself
  at the start of its `fill`.
- **Halftone dots grow with the square root of the darkness**, because a dot's ink is its area; a radius straight
  from the darkness makes the mid-tones too pale. Batch a row of dots into one path: a clipping has thousands.

