# Painted enamel

The picture is a panel painted in glossy enamel on the side of a wagon. Every stroke is a bundle of bristles loaded with two
colours side by side, so base coats keep their brush marks and a single stroke shades itself. Highlights are crisp one-stroke
flicks set in from the edge that faces the nearest light; the far edge gets a darker band; cloth folds are a dark stroke with
a light flick beside it; every shape is lined in a thin dark outline; anything precious is gold leaf, laid in squares and
burnished, catching the light as it turns. The panel sits in a gilded bead moulding on the wagon's green boards, under a
slightly amber varnish with a fine craze, with a cartouche of little lamps on top and two ribbons along the bottom.
Night isn't painted darker: it is a **light map** (an ambient colour plus a pool of light for every fire, lamp and lit window)
multiplied onto the paint, with flames, lit glass and windows on a separate self-lit layer the night doesn't touch, and glows
screened on top. Figures are small skeletons with two-bone IK arms, so a hand can meet a lantern or a gate exactly; trees are
painted once and bent every frame by the wind. Plain HTML canvas, no libraries.

![Two cloaked travellers walking into the wind at dusk, a red banner streaming, one holding a lit lantern, painted in enamel in a gilt frame on a green wagon](img/hero.jpg)

The demo sets Christina Rossetti's "Who Has Seen the Wind?" (37.5 s): travellers walk a windy road at dusk, a bough of gold
leaves trembles, a gust runs through the long grass, and as night falls a village lights its windows and street lamps, a
windmill turns, the poplars bow, and at an inn the travellers light the porch lamp and go in before the wind slams the gate.

| | |
|---|---|
| ![A bough of gold and red leaves hanging over a valley at dusk; far below a tiny caravan with lit lanterns](img/bough.jpg) | ![The caravan on the road at dusk, a wagon and pack beast, poplars bent by a gust, long grass streaming](img/road-gust.jpg) |
| ![At an inn's gate at night, one traveller lifts a lantern to light the porch lamp while the other holds the gate open onto a lit courtyard](img/inn.jpg) | ![A village on a hill at night, windows and street lamps lit, poplars bowing in the wind, a gilded weathervane](img/village.jpg) |

## Looks in this family

- **Enamel** (the demo's look): the painter in `paint.js`, the light map, and the wagon frame. ![The village at night in enamel](img/look-enamel.jpg)
- **Chalkboard**: the same scene calls drawn in coloured chalk on a slate board kept for years, with notes chalked into grooves round the edges. ![The village at night in coloured chalk on a slate board](img/look-chalkboard.jpg)

## Run the demo

From the repository root:

```bash
python tools/serve.py
```

then open <http://localhost:8000/styles/painted-enamel/index.html>. Space plays and pauses; drag the bar to scrub. Add
`#t12.5` to the address for a still at 12.5 s (the page furniture hides and the canvas fills the window; change the number
and the frame redraws). The page spends about 5 seconds building (it paints the still layers of the five sets, the tree
sprites and the varnish) and then plays live. On an Apple-silicon Mac a frame takes about 20-60 ms to draw, so it plays at
roughly full speed, dropping frames in the busiest shots; the MP4 is always smooth.

Stills (with a contact sheet) and the MP4:

```bash
python tools/still.py styles/painted-enamel/index.html 2 6 12.5 0:37.5:2.5 --sheet
python tools/render_mp4.py styles/painted-enamel/index.html --fast        # 720p preview
python tools/render_mp4.py styles/painted-enamel/index.html               # 1080p and 720p
```

A `--fast` render of the whole 37.5 s (900 frames) takes 35-70 seconds here (about 40-75 ms a frame including the readback
and the encoder, depending on what else the machine is doing), plus a few seconds to build; the full-quality render spends
longer in the encoder.

## How it works

### Files, in load order

| file | job |
|---|---|
| `../../examples/poem/lyrics_data.js` | the song: `window.SONG` with the title, credit, audio, duration, beats, sections and each line's word times |
| `core.js` | the frame size (1920x1080 canvas; the picture is 1920x960, the lyric band below), maths, a seeded random (`mulberry32`), value noise (`vn2`, `fbm2`), colours as `[r,g,b]`, shapes, splines, fonts, a plain lyric band |
| `paint.js` | the enamel painter: the brush (`bristles`, `comma`), gold leaf (`leafFill`), the palette `PAINT`, light colours `LIGHTCOL`, `makePainter` (the style object `S`), `lightScene` (the night), sprites |
| `props.js` | pictograms (`GL`, `glyphLines`, `tally`), street lamps, cottages and their windows, tapered branches, conifers |
| `rig.js` | the posable figures: `traveller`, `packBeast`, `wagonSide`, `cookPot`, two-bone IK (`ik2`), `hangSwing` |
| `wind.js` | the wind (`windAt`, `windStr`, `windInt`) and what it moves: bending trees, grass, leaves in flight, a banner, washing, chimney smoke, clouds, a weathervane, a windmill, a swinging sign, stars, the moon; and weather: storms and rain |
| `frame.js` | the wagon: boards, moulding and flourishes, varnish and craze, the cartouche of lamps, the ribbons, the gap seen during a slide |
| `shots.js` | the demo's timeline: `LINES`, timing helpers, the breeze and gusts, nightfall, the frame's cues, `SHOTS` |
| `sets_dusk.js`, `sets_night.js` | the demo's five sets: `road`, `walkers`, `branch`, `village`, `inn` |
| `engine.js` | baking sets, the lit scene, the camera, wipes and slides, the frame composite, the lyric band, `renderAt(t)` |
| `player.js` | the page: play, pause, scrub, `#t` stills, the silent clock when the song won't load, `window.__video` |

All plain scripts sharing globals, as in the rest of this repository.

### Shapes, colours and the style object `S`

A shape is `shp(rings)`: one or more closed rings of `[x,y]` points, with its bounding box `bb` and a lazily built `path`.
Build rings with `rect`, `ell`, `blob`, `archPts`, `scallop` (a scalloped round, how folk painters draw a tree's crown),
`smoothRing(points)` (a closed Catmull-Rom curve) and `spline(points, closed, step)`.

Colours are keys into `PAINT` (`'cloakB'`, `'leafGold'`...) or plain `[r,g,b]`. Add your own with
`Object.assign(PAINT,{river:[120,160,190]})`; the sets and `wind.js` each add theirs that way.

Everything is painted through `S`, which `makePainter(T, lights)` returns. The chalkboard look implements the same calls, so
a set, a figure or a prop never needs to know which look is drawing it.

| call | paints |
|---|---|
| `S.fill(shape, key, o)` | a shape. `o.role` picks the treatment: `cloth`, `wood`, `wall` (with `o.blocks`), `roof`, `thatch`, `foliage`, `fur`, `hair`, `skin`, `leather`, `metal`, `ceramic`, `stone`, `rock`, `land`, `floor` (flags toward `o.vanish`), `paper`, `snow`, `sky`, `dark`, `leaf` (gold leaf: `o.sheen` 0..1 for the catch, `o.dim`), `window` and `glass` (self-lit; `o.k` how lit), `embers` (self-lit). Also `o.folds` (polylines), `o.dir` (brush direction), `o.line:false` (no lining), `o.depth` |
| `S.line(pts, key, w, o)` | a stroke. Roles: default round stroke with a lit side (`pole`, `strap`, `rope`, `limb` look the same), `grain`, `crack`, `leafline` (a gold line), `road`, `water`, `thread` (self-lit), `blade` (grass: `o.k` shows the pale side), `streak` (a long cloud: `key` on top, `o.key2` underneath) |
| `S.lamp(x, y, size, lit, o)` | a box lantern. Lit, it adds a pool to the light map (via `S.extra`) and paints its glass self-lit with a gold-leaf flame; `o.k` 0..1 brings it up gradually |
| `S.flame(x, y, w, h, o)` | tongues of two-colour strokes and sparks, self-lit, with glows; `o.t` animates, `o.lean` bends it with the wind |
| `S.glow(x, y, r, key, k, o)` | a soft glow on the screened layer (`o.flat` squashes it) |
| `S.smoke(pts, w, o)`, `S.steam(x, y, w, h, t, o)` | smoke along a path; steam rising |
| `S.sky(o)` | a gradient laid on with long strokes (`o.top`, `o.mid`, `o.low`, `o.h`), stars, optional aurora curtains. `o.motes` puts motes in place of the stars: points of light in the aurora's colours, some strung in short curving lines, no glints |
| `S.star(x, y, s, k)`, `S.glyph(name, x, y, s, key)` | a star; a pictogram from `GL` |
| `S.faceProfile(shape, o)` | a face deep in a hood, the chin and nose caught by light (`o.lit`) |
| `S.clip(shape, fn)`, `S.tf(setup, draw)` | clip, or transform (`setup(ctx)` is applied to each layer), whatever `fn`/`draw` paints |
| `S.layer(d)` | depth 0..1 for what follows: below .36 things fade toward the haze colour and get finer lining |
| `S.seed(n)` | set the brush seed (see Determinism) |
| `S.backlit(on)` | shapes painted while on become dark silhouettes on the self-lit layer: a figure walking into a bright doorway |
| `S.sprite(key, {w,h,ox,oy,at}, paint)`, `S.bent(sprite, x, y, bend)` | paint something once into its own layers, then draw it bent (below) |

### The night: three layers and a light map

A scene is painted into three 1920x960 canvases: `g` reflective paint, `e` self-lit paint (flames, lit glass and windows,
stars, the moon) and `gl` glows. A reflective shape knocks out whatever self-lit paint and glow lies behind it, so a figure
in front of a lamp hides it and a cloud passing over the moon covers it. Then `lightScene(layers, lights, ambient)` builds the
light map (a vertical gradient between the two ambient colours, plus a radial pool `{x,y,r,k,c}` for each light, added),
multiplies it onto `g`, draws `e` on top and screens `gl` over that. Dusk and night are nothing but the ambient colours and
the lights: `ambientFor(t)` in `shots.js` slides from a warm dusk to a blue night as `NIGHT(t)` goes from 0 to 1.

The same lights tell the painter which side of each shape catches the light, so the highlight flicks face the nearest fire.

### Sets

A set is an object in `SETS`:

```js
SETS.walkers={
  lightsAt(t){const n=NIGHT(t);return[{x:-160,y:640,r:1800,col:'dusk',k:.9*(1-n*.7)}];},   // or lights:[...]
  ambientAt:t=>ambientFor(t),                                                            // or ambient:[top,bottom]
  back(S){...},             // painted once: sky, hills, the wall, the road
  prep(S){...},             // painted once: the tree sprites
  front(S){...},            // painted once, over the moving things (optional)
  dyn(S,t,shot){...},       // every frame, between back and front: trees bending, the two travellers, the banner
  dynFront(S,t,shot){...},  // every frame, over everything: grass, flying leaves
};
```

`col` is a key into `LIGHTCOL` (`fire`, `lamp`, `window`, `dusk`, `moon`, `ember`). A set can also have `post(g,t,shot)`, run
on the finished scene (rain streaks, say). `back` and `front` are baked once, so anything that differs between two shots of
the same set belongs in `dyn`; `shot.act` tells a set which way it's being used.

### Shots, the camera and transitions

`SHOTS` in `shots.js` lists each shot in order. A real one from the demo:

```js
{id:'walkers', t0:LT(1), set:'walkers', inT:WP(), cam:[[LT(1),900,500,1.06],[LT(2),1040,505,1.1]]},
```

`t0` is when it starts (here: the start of line 2). `cam` is a list of keys `[time, x, y, zoom]` in the set's 1920x960
picture; the camera eases between them and adds a slow drift so nothing sits dead still. Zoom 1 shows the whole set; the
crop can't leave the picture, so near an edge a high zoom is pushed back inward. `inT` is how the shot comes in: `WP()` a
painted wipe (new paint brushed across the old in broad strokes, `WP(.8)` for a slower one), `{type:'slide',dur:1.2}` (the
whole wagon slides away and the next one comes on, a lantern swinging in the gap: the demo uses it at the second verse),
`{type:'fade',dur}` up from black, or nothing for a cut. A shot can also carry `pics`: a lit still of another set, rising over
the picture as gold light and fading (the demo's last bars use one).

### Timing to the song

`shots.js` turns `SONG` into helpers: `LT(i)` is when line `i` starts, `WT(i,j)` when word `j` of line `i` is sung,
`BEAT(n)` is beat `n`, `SEC.verse2` is a section's `[name, start, end]`. Motion is written as functions of `t`:
`ramp(t,t0,t1,a,b)` eases from `a` to `b`, `bump(t,t0)` swells and falls around `t0`. For example, B's lantern catches on
"you:" and flares:

```js
const lanternK=t=>sstep(WT(1,3),WT(1,3)+.3,t);                                   // in sets_dusk.js
if(lk>0&&hB.lamp)S.glow(hB.lamp[0],hB.lamp[1],70,'lampLit',1.2*bump(t,WT(1,3)+.08,.08,.45));
```

The village's windows light one per beat of the second verse's first line (`BEAT(31)` to `BEAT(36)`), and the frame's
cues are all word times: the ribbons tie on "passing through" (`KNOT=[WT(3,3),WT(3,4)+.7]`).

### The wind

`BREEZE(t)` (a strength of about 0.1-0.6) and `GUSTS` (`{t, v, w, k}`: a bump of wind whose middle crosses x=960 at time `t`,
moving right to left at `v` px/s, `w` px wide, `k` strong) are set in `shots.js`. From them `wind.js` gives:

- `windStr(x,t)`: the strength at `x`, with some turbulence; `windAt(x,t)` the same as a signed push (negative: to the left);
- `windInt(t)`: how much wind has blown so far, tabulated once. Leaves, clouds and windmill sails move by it, so they hurry
  in a gust and never jump;
- `treeBend(x,t,k)`: how far a tree bows, following the wind a moment late.

Every prop takes `t` and asks the wind itself: `treeSprite` + `windTree` (round trees, poplars and pines, painted once and
bent in strips along a curve of constant length, so a tree that bows also dips), `grassBand`, `flyingLeaves` (gold leaf
that flashes as it turns over), `banner` (a swallowtail with a gold roundel), `washing`, `smokeStream`, `cloudBank`,
`weathervane`, `windmillBody` + `windmillSails`, `swingSign`, `starField`, `moonDisc` (`o.shadow` puts part of it in
shadow: .2 is a gibbous moon). Figures take `o.wind` and stream their cloaks, hoods and scarves; hanging lanterns lean and
swing with `hangSwing(t, wind)`.

For skies that aren't ours, `wind.js` also has weather the demo doesn't use (call it from a set's `dyn`, or `post`):

- `stormSky(S, t, {cx, cy, R, squash, arms, spin, seed, k, clip, bolts})`: a slow vortex of cloud with a glowing green
  eye. Lightning crawls along its arms three times a second, and bolts go up into the eye from each `[x, y]` of `bolts`,
  each on its own period; the flashes go into the light map, so the land under them flickers. `clip` keeps it in the sky.
- `retreatingStorm(S, t, edge, k, {dir, lit, seed})`: a storm going off over the edge of the sky, dark banks beyond
  `edge` with their trailing edge lit by the light coming back behind them, lightning still flickering in them. Move
  `edge` with time and it leaves; `dir` -1 sends it off to the left.
- `rainStreaks(g, t, {n, len, w, alpha, col, seed, toward})`: rain over the finished scene (from `post(g, t)`), slanted
  by the wind. With `toward: {edge, r, side}`, rain near land turned on its side bends to fall toward that land's own
  ground (`edge` is its ground line; `side` says which side of it is open air) instead of down.

These paint straight onto the enamel painter's layers (`S.T`), so the lab's chalk look leaves them out.

### Figures (`rig.js`)

`traveller(S, x, y, h, o)` poses a cloaked figure standing on `(x,y)`, `h` tall, facing `o.face` (1 right, -1 left).
`o.pose` holds `mode` (`stand`, `walk`, `sit`), `phase` (of the stride: use distance walked / (h/2) and the feet don't slide),
`lean`, `head` (looks up), `crouch`, and the arms `armF` (near) and `armB` (far). An arm is `{to:[u,v]}` in the figure's own
units or `{at:[x,y]}` in set pixels, so a hand lands exactly on a door, a pole or a lamp; `hold` puts something in the hand
(`lantern` with `lit`, `k` and `swing`; `pole` with `pole:[foot,top]`; `staff`, `stick`, `bowl`, `bread`). `o.gear` hangs a
`frame` pack or a `sack` on the back. `o.wind` streams the cloak; `o.tail` adds a scarf end; `o.lit` lights the face.
`packBeast` and `wagonSide` (springs that sag, wheels that roll with distance, `tilt` to rock, `flutter` for the canvas top, a
swinging lamp) work the same way.

### The frame

`drawCartouche(O, lamps, cold, {group})` draws the row of lamps; `lampsFor(t)` lights lamp `i` at `LAMP_T[i]` (one per line
in the demo, in two groups of four). `drawRibbons(O, state, t, wind)` draws the two ribbons from a state
`{tie, braid, part, loop, back, close}`, each 0..1: tie a knot, plait with a third strand, come undone and blow away, tie
one half, come back, tie again. `ribbonState(t)` in `engine.js` builds it from the cue times in `shots.js`. When two very
different ribbon shapes follow each other they dissolve through two small band canvases.

### Lyrics

`drawLyrics(O, t)` in `engine.js` writes the current line in the band under the picture, each word lighting as it is sung.
A line shows from a little before its first word until a little after it ends, never leaves before its last word has lit, and
waits for the line before it. Before `TITLE[1]` the band shows `SONG.title · SONG.credit` instead. `LINES` is `SONG.lines`
reshaped as `[section, text, start, end, [word times]]`.

### Determinism and caching

- There is no `Math.random`: everything random is `mulberry32` with fixed seeds, or noise of position and time.
- Brush strokes are seeded per shape (`S.seed(n)` plus a counter that goes up with every shape), so a shape painted again the
  next frame gets the same strokes. The counter means that adding or dropping a shape shifts the strokes of everything after
  it; the sets call `S.seed()` before each figure, `cottageWindows` before each window and `flyingLeaves` before each leaf,
  so a lamp lighting up, an arm appearing or a leaf leaving the picture doesn't make its neighbours' paint boil.
- A scene is repainted "on twos", 12 times a second, like hand-painted animation; the camera, the frame and the lyrics move
  at 24. `renderScene` keeps the last painted scene per slot and reuses it until the twelfth of a second changes.
- `back`, `front` and sprites are painted once (`bakeSet`, kept for up to nine sets); `prepareAll()` builds everything at load
  so the first frame of a set doesn't stall.
- `step(t)` and `renderAt(t)` are the same function and any frame can be drawn from scratch, in any order.

## Make your own video in this style

1. Copy the folder: `cp -r styles/painted-enamel projects/my-song` (or anywhere under the repository).
2. Make your song's `lyrics_data.js` with the audio tools (`tools/audio/to_js.py`, the last step of
   [docs/timing.md](../../docs/timing.md)) and point the first script tag of `index.html` at it. `SONG.audio` is the song's
   path relative to the page.
3. **Keep** `core.js`, `paint.js`, `props.js`, `rig.js`, `wind.js`, `frame.js`, `engine.js` and `player.js`.
   **Replace** `shots.js` (your timeline) and the `sets_*.js` files (your scenes); update the script tags if you rename them.
4. In `shots.js` set `TITLE` (when the title card shows), `LAMP_T` and `LAMP_GROUP` (a dozen lamps at most: one per section
   works for a long song), the ribbon cues (`KNOT`, `BRAID`, `UNBRAID`, `PART`, `LOOP`, `BACK`, `CLOSE`: set any you don't
   want beyond the end of the song), `BREEZE` and `GUSTS` (or `BREEZE=t=>0` and `GUSTS=[]` for a still night), `NIGHT` and
   the two ambient colours.
5. Add a set: copy one from `sets_dusk.js` and change it. Paint what never moves in `back` (use `S.layer(d)` to push far
   things into the haze), sprites in `prep`, what moves in `dyn`, and whatever stands in front of the action in `front`
   (a wall a figure walks behind). Give it `lightsAt(t)` and `ambientAt(t)`.
6. Add shots to `SHOTS`, one per line or per phrase: `{id, t0, set, inT, cam}`. Put changes on line starts (`t0:LT(i)`) and
   frame the camera with `#t` stills.
7. Time a move to a word: `const k=ramp(t,WT(5,1),WT(5,1)+.8)` goes from 0 to 1 over the 0.8 s after word 2 of line 6. On a
   beat: `bump(t,BEAT(40))`. Everything is a function of `t`, so there is no state to reset when you scrub.
8. Check it: `python tools/still.py projects/my-song/index.html 0:END:2.5 --sheet`, read the console errors it prints (a
   single `NaN` in a gradient blanks a frame), then render.

Useful knobs:

- the look of the paint: `bristles` options (`alpha`, `ragged`, `var`), the flick width in `flicks` (`fw`), `lining`'s
  weight, `leafFill`'s gradient and catch;
- the night: `AMB_DUSK`, `AMB_NIGHT` and `NIGHT(t)` in `shots.js`, each light's `r` and `k`, `LIGHTCOL`;
- the frame: `X0, Y0, PWd, PHd` (the panel), the board and lining colours in `buildFrameStatic`, the varnish's craze
  strength in `buildVarnish` (0.2);
- the wind: `BREEZE`, `GUSTS`, `treeBend`'s factor (0.16), each prop's `lean`/`speed` option;
- pace: the wipe length in `WP(d)`, the slide's `dur`, the camera keys.

## Lab

Open <http://localhost:8000/styles/painted-enamel/lab/index.html> and use the buttons, or
`lab/index.html?scene=village&style=chalkboard`. Render every scene in every look:

```bash
python tools/lab_stills.py styles/painted-enamel/lab/index.html --all --sheet
```

The lab draws two moments of the demo (the road at dusk at 5.6 s, the village at 27.9 s) through each look, calling the
demo's own sets. `lab/lab.js` lists them in `LAB_SCENES` (a set, a time, a camera and the lyric line to show).

- **Enamel** is the video's own path: `renderInto` paints the set with the enamel painter and the light map, and
  `composePicture` puts it in the wagon frame.
- **Chalkboard** (`lab/style_chalk.js`) sends the same calls to a chalk style. Masses are laid with the side of the chalk and
  then outlined; hatching sits on the side toward the light; fires, lamps and windows are rubbed into glows; a later shape
  rubs out what's behind it. The board's tooth decides where chalk takes, so light pressure breaks into specks. There is no
  light map: the board is lit by one lamp above it. The whole set is drawn smaller in the middle of a slate board with years
  of rubbed-out marks, notes chalked into grooves along the top (wind, leaves, lamps, windows, the moon) and a column down the
  right that keeps count (gusts so far, leaves down, a lamp ringed for the current line). Sprites are chalked into their own
  canvases with a solid mask for rubbing out.

## Performance

- **Build:** about 5 s at load (the five sets' still layers, sixteen tree sprites, the varnish's craze, the outro's gold
  picture). Longer when other heavy work is running.
- **Per frame:** about 20-60 ms to draw on an Apple-silicon Mac, most of it the moving paint: figures (a few dozen shapes
  each, every one a bundle of strokes), grass blades, leaves, and the light map. The same scene is reused for alternate frames
  (on twos). A painted wipe or a slide draws two scenes, so its frames cost about double.
- **MP4:** about 40-75 ms a frame for a `--fast` render including readback and encoding, so the whole demo takes about a
  minute. (With several other heavy renders running on the same machine it took three times as long.)
- **Memory:** about 350 MB of canvases, most of it baked layers (three 1920x960 canvases per set, six with a front layer).
  JavaScript itself uses little.
- **What makes it slow:** big `foliage` shapes painted every frame (hundreds of leaf strokes each: paint trees once as sprites
  and bend them), many blades of grass, and canvas filters (blur, brightness) used per frame. Everything that can be made once
  is made once.
- **A slice:** `python tools/render_mp4.py styles/painted-enamel/index.html --fast --start 15 --end 21`. Every frame depends
  only on its time, so a slice matches the full render and can be spliced in with `tools/splice.py`.

## Lessons and gotchas

- **Washed out and sepia:** a warm overlay, a heavy amber varnish and a strong craze turned a first painted pass into mud
  tiles. The light map (multiply, then self-lit paint on top), crisp flicks instead of soft bevels, and a fine craze fixed it.
- **Soft highlight bands round every shape read as an airbrushed bevel.** Separate one-stroke flicks set in from the lit
  edge read as paint. Four parallel fold strokes read as claw marks: use one dark stroke with one light flick beside it.
- **Glows wash over whatever is in front of them** until every reflective shape knocks out the self-lit paint and glow
  behind it. A figure walking into a bright doorway looked translucent until drawn as a dark silhouette (`S.backlit`), since
  the light map can't tell which side of a figure faces the light.
- **A hood opening painted flat black reads as a void.** Light the chin and the tip of the nose from the fire.
- **Things at the wrong height read as other things:** a bedroll carried at head height looked like a hat brim.
- **Long ribbons of paper arcing between two figures read as pale tubes across their faces.** Keep small things in hands.
- **A still layer is baked once per set,** so anything that differs between two shots of the same set (who stands where,
  what's lit) must be painted in `dyn`.
- **Lyric timing:** lines stay 0.8 s after they're sung but never leave before their last word has lit, and the next line
  doesn't show across a cut.
- **Smoke drawn as round-capped segments stacks its opacity into a solid tube.** Draw it as a few long strokes at low opacity,
  layered.
- **Trees built from many small clumps looked like stacked cabbages.** A few big scalloped lobes, the back ones darker, read
  as painted trees; poplars as one tall flame with a lighter one inside it.
- **Random light and dark leaf strokes read as camouflage.** Use a light tone and a mid tone.
- **Gold leaf multiplied by a dim light map looks like beige paint.** Give it a small glint (a glow) when it turns to face the
  light, and keep the burnished catch small and yellow rather than white.
- **Three stacked strokes for a cloud read as a flying saucer.** One or two long tapered streaks with a lit underside read
  as cloud.
- **A gust is only visible against calm.** Drop the breeze just before it (a lull), and the travelling band of bent, pale grass
  and bowing trees stands out.
- **A tree rotated about its foot looks like it is falling over.** Bend it in strips along a curve of constant length, so the
  crown dips as it bows.
- **A gesture behind another figure is lost.** When a hand has to meet something (a lamp), make sure nobody stands between it
  and the camera; painting order decides who covers whom.
- **Sky painted per frame lands on the baked buildings.** Clip clouds and stars to the sky.
- **A dark sky with white stars reads as an ordinary night on Earth.** To make a night plainly somewhere else, change
  its lights (motes in the aurora's colours, some strung in short lines, with no cross-shaped glints) or its weather.
- **A plain dark storm is just a dark sky.** Give it a shape you can read at a glance (a slow spiral with a lit eye,
  lightning crawling along its arms, bolts going up into it rather than down) and put the flashes in the light map, so
  the land under it flickers with them. A darkness that is weather rather than night reads best on its way out: a storm
  going off over the edge of the sky, its trailing edge lit by the light coming back.
- **Rain obeys the ground it falls on.** Near land turned on its side, rain that still falls straight down reads as a
  mistake; bend it toward that land's own ground, more the closer it gets.
- **Build what the first frame needs at load.** A tree sprite first needed mid-shot stalls that frame, and a sprite requested
  with different options than it was made with comes back as the cached one: give each sprite one function that makes it.
- **A fade from pure black gives a blank first frame.** Start from a dim picture instead.
- **The camera can't leave the set.** A zoomed camera centred near an edge is pushed back inward, so frame with stills.
- **Check the console.** One bad value in a canvas gradient kills the whole frame; the still tool prints errors.
- **The browser caches scripts.** Serve with `tools/serve.py`, which doesn't, or an edit can keep running its old version.

