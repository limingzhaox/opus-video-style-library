# Flat vector poster

A small, separate engine for a bright, flat, screen-printed poster look: every shape is one flat colour with a single
weight of ink outline, skies are stepped bands rather than gradients, and the only soft edges are pools of light.
People are rounded silhouettes with a rim of light on one side, trees are clusters of round blobs with a lighter cap,
and things that move (figures, trees, grass, a kite) are drawn on twos, twelve drawings a second, for a hand-made
feel. A faint grain keeps the flat colour from banding. The picture sits above a band where the words of the song
appear one at a time. It is quick: a frame takes a couple of milliseconds to draw.

![A child in a red hat flying a kite over a flowering meadow on a blustery day, round trees on the hill behind, "Neither I nor you:" in the band below](img/hero.jpg)

## Run the demo

From the repository root:

```
python tools/serve.py
```

then open <http://localhost:8000/styles/flat-poster/index.html>. It plays live, in step with the audio. Add `#t12.5`
to the address for a still at 12.5 seconds. Space plays and pauses; the bar scrubs.

```
python tools/still.py styles/flat-poster/index.html 2 6 12.5 0:37.5:2.5 --out renders/flat-poster --sheet
python tools/render_mp4.py styles/flat-poster/index.html --out renders/flat-poster.mp4 --fast
```

A `--fast` render of the 37.5-second demo drew its 900 frames in about 20 seconds here.

![A branch of round leaves close up against the sky](img/branch.jpg)

## How it works

| file | job |
| --- | --- |
| `../../examples/poem/lyrics_data.js` | `window.SONG`: the song's title, credit, audio, tempo and word times |
| `core.js` | frame size, maths, easing and keyframes (`kf`), seeded randomness (`rnd`, `RNG`, `vn`), colour helpers, and the song's timing: `DUR`, `LINES`, `BEAT`, `BAR`, `word(line, text)`, `lineAt(t)` |
| `art.js` | the vocabulary: palette `PAL`, inked shapes, skies (day or night bands, a glow below the horizon, an aurora), sun, clouds, round trees that sway, grass tufts, flowers, a kite, a butterfly, lanterns, tents, pennants, birches, hands, and figures (`drawWalker`: a child, a hooded traveller with a pack, a traveller in furs, a robed figure, a shepherd, a cowled figure) |
| `meadow.js` | the demo: the wind, the multiplane meadow, the close shots, and the shot list `SHOTS` |
| `engine.js` | draws the picture and the lyric band for each frame, runs the player, and sets `window.__video` |

### The frame

The canvas is 1920 x 1080: the picture is the top `PIC_H` (960) pixels and the lyric band the bottom `BAND_H` (120).
`renderFrame(t)` picks the shot whose `[t0, t1)` contains `t`, clears the picture, calls the shot's `draw(g, t)`,
adds the grain and draws the band. Each frame is sampled in the middle of its 1/24-second slot, so the live player
and the MP4 show the same drawing.

### Shots

```js
const SHOTS = [
  { t0: 0, t1: 11.25, draw(g, t) { drawMeadow(g, t, camAt(CAM_A, t)); } },
  { t0: 11.25, t1: 15, draw: drawBranch },
  ...
];
```

A shot draws the whole picture in screen space. For depth, the meadow is a multiplane: `layerXf(g, cam, p)` puts a
layer under a camera `{ x, y, z }` (a point in the main layer's units at the centre of the picture, and a zoom), and
each layer moves by its parallax factor `p` (far hills `.15`, the middle ridge `.45`, the meadow `1`, the grass in front
`1.4`). `camAt(keys, t)` eases between camera keys. `drawMeadow(g, t, cam, options)` draws the sky, sun and clouds in
screen space, then the far hills, the ridge with its row of trees, the meadow with its grass, flowers and the child
with the kite, and the foreground grass, each in its own layer.

### Shapes

Everything is a `Path2D`: `poly(points)`, `smooth(points)` (rounded through the midpoints), `ellipseP`, `capsule`,
`taper(points, widths)` for limbs and stalks. `inked(g, path, fill, lineWidth)` fills and outlines;
`inkedGroup(g, paths, fill, lineWidth)` outlines several overlapping parts as one shape (stroke them all at double
width, then fill them all). `sil(g, parts, fill, { lw, rim, rdx, rdy })` does the same and adds a rim of light on one
side, by filling the rim colour and refilling the body shifted away from the light. Figures are drawn in local units,
feet at (0, 0) and up negative, then placed with `translate` and `scale`; `f = -1` mirrors them.

### The wind

`meadow.js` has a steady breeze with a gust peaking on a word in every line: `GUSTS = [[word(6, 'heads,'), 1.3], ...]`.
`windAt(t, lag)` is the wind's strength; `windRun(t)`, how much air has gone by, carries clouds and petals, so they
speed up in a gust. Trees, grass and flowers take a `bend` from about -1 to 1; the row of trees on the ridge gets the
gust a little later from tree to tree, so it bows in a wave. When the wind "is passing through", a slanted band of
lighter green runs across the meadow and the grass under it leans harder.

![A pale band of wind running through the meadow grass, the child with the kite string, petals blowing](img/grass-wave.jpg)

### The band

The title (in capitals) and the credit show until the first sung line and come back after the last. Each line appears
word by word from its word times. `BAND_NOTES = [[from time, text], ...]` in the scene file puts a note at the right-hand
end (the demo has none), and `BAND = { bg, rule, fg, dim }` sets its colours. The fonts are League Gothic and Libre
Caslon Text from Google Fonts.

### Determinism

No `Math.random()`: `rnd(a, b)` is a hash and `RNG(seed)` a seeded stream, and the wind's running total is computed once
and kept. Every frame depends only on its time, so `step(t)` and `renderAt(t)` agree and any slice renders the same.

## Make your own video in this style

1. **Copy the folder**: `cp -r styles/flat-poster projects/my-song` (see [docs/your-own-video.md](../../docs/your-own-video.md)).
2. **Your song**: make a `lyrics_data.js` with `tools/audio/to_js.py`, point the first `<script>` in `index.html` at it,
   and set `SONG.audio` to your audio file's path relative to the page. Change the page title and heading.
3. **Keep** `core.js`, `art.js` and `engine.js`.
4. **Replace `meadow.js`** with your own scene file. It must define `SHOTS`; it may define `buildScene()` (run once at
   load, for anything you want to lay out in advance), `BAND` colours and `BAND_NOTES`.
5. **Add a shot**: add `{ t0, t1, draw(g, t) }` to `SHOTS`. Draw the sky first (`drawSky(g, t, { horizon, bands: PAL.day })`),
   then back to front.
6. **Time things to the song**: `word(2, 'trembling,')` is when that word is sung in the third line (lines count from
   0); `BEAT` and `BAR` are a beat and a bar in seconds. Move on the word; change shots on line starts.
7. **Check** stills across the whole song with `tools/still.py ... --sheet`, then render.

Useful knobs: the palette `PAL` (the `day` and `night` sky bands especially), the band's colours `BAND`, the picture
and band heights `PIC_H` and `BAND_H` in `core.js`, the ink weight (the `lw` arguments; 2 to 3 pixels at full size),
the grain's strength (`.05` in `renderFrame`), and each layer's parallax factor in `LAYER`.

![A row of round trees on a ridge bowing in a gust](img/trees-bow.jpg)

## Performance

A frame takes one or two milliseconds of script (the still tool prints it) and about 25 ms in all when rendering to
MP4, most of that reading the frame back and encoding it. Nothing is built at load beyond a grain texture, so the page is
ready at once and plays smoothly live. All the cost is fills and strokes; the most expensive thing in the demo is the
meadow's 190 tufts and flowers, redrawn every frame. Render a slice with `--start` and `--end` if you only need part of it.

## Lessons and gotchas

- **What makes it cute**: flat candy colours, rounded "sack" figures with blob heads, even lighting and bobbing walks.
  That suits a nursery poem. For anything grave it reads as goofy: take out the bob, light figures from one side with
  a rim (`sil`'s `rim` option), use a darker palette with the night bands, make figures taller and narrower, and let
  shapes be angular.
- **Stepped bands, not gradients.** Skies and hills in a few flat bands keep the poster look; save gradients for pools
  of light (`glowAt`), drawn with `screen` so they brighten rather than tint.
- **Outline groups as one shape** (`inkedGroup`, `sil`), or every overlap shows an ink line inside the silhouette.
- **Keep the player idle when paused.** If the page's loop keeps drawing the paused time, it draws over the frames the
  render tools ask for between their calls. The loop here only draws while playing.
- **Sample the middle of the frame slot** (`(k + .5) / 24`), so playback and the rendered MP4 agree.
- **Page basics**: put `<meta charset="utf-8">` first, and add `.gate[hidden]{display:none}`, because `display: grid`
  on the play overlay otherwise wins over the `hidden` attribute.

