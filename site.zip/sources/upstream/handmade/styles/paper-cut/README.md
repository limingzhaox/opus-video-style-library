# Backlit paper cut

Shadow theatre in layers. Every shape is cut from tinted paper and lit from behind, and each layer sits at its own
depth, so when the camera moves the layers slide past each other. What makes it read as paper rather than flat
colour: every piece carries the same fibrous paper texture, a thin bright rim where the light catches its upward
edges (with a soft halo soaking into the paper), a band of mist near its base where light leaks between the layers,
and a soft shadow on the layer behind. The sky is a WebGL shader: aurora curtains stepped into a few layers of tissue,
with stars pricked through as pinholes (or tinted motes in their place). Figures are jointed silhouette puppets on
two-bone IK. The land doesn't have to behave: it floats, curls overhead or stands on its edge, and the helpers keep
trees, houses and smoke square to whatever ground they stand on. A place can also grow: its land is baked bare and
what stands on it is a list of sites with the eras they stand in, so a later shot shows it built up, the new houses and
mills set down one by one on the beats. The lyrics sit in a dark paper band under the picture and light up word by word.

The demo is Christina Rossetti's "Who Has Seen the Wind?", so everything in it is about wind you only see in what it
moves: smoke bent over, washing snapping on a line, dry leaves trembling and tearing loose, a walker leaning into it,
another with the wind behind and long hair blown forward over a swinging rope bridge, a row of poplars bowing and
springing back while someone down the road digs it out of a drift, a shovelful on every beat. At the end the valley of
the opening shot has grown: new houses and windmills are set down on the beats, and a windmill hangs under the overhang.

![A village lane at night under an aurora: dry leaves stream off a young tree, washing blows flat on a line, a
walker leans into the wind with a lantern, and a hut on a floating rock strains at its tie ropes](img/hero.jpg)

| | |
|---|---|
| ![The title card under a valley wall that curls overhead, with houses hanging upside down from it](img/valley.jpg) | ![A walker holds the hand-rope of a swinging rope bridge between floating strips of land](img/strips.jpg) |
| ![A row of tall poplars bowing in a gust over a road where two figures brace, hand in hand, while further on someone digs the road out of a drift](img/grove.jpg) | ![The valley at the end, grown: new windmills turning on its floors among more houses](img/grown.jpg) |

Good for: landscapes, weather and night skies; small figures in big places; journeys; places that can't exist. Less
good for faces, close-ups of hands, or anything that has to be read as text (signs here are pictograms and runes).

This family has one look, so there's no style lab.

## Run the demo

```bash
python tools/serve.py
```

Then open `http://localhost:8000/styles/paper-cut/index.html`. It plays live in the browser (built and tested in
Chrome; the aurora needs WebGL2, and without it the sky falls back to a plain gradient). Space plays and pauses,
the bar scrubs. If the audio can't load, it plays on a silent clock. Add `#t12.5` to the address for a still of
12.5 seconds with the page furniture hidden (after editing a script, reload with a new query, e.g. `?r=2#t12.5`,
since changing only the hash doesn't reload).

Stills and a contact sheet, and an MP4 (both from the repository root):

```bash
python tools/still.py styles/paper-cut/index.html 2 14.3 28.3 0:37.5:2.5 --out renders/stills --sheet
python tools/render_mp4.py styles/paper-cut/index.html --fast          # 720p preview
python tools/render_mp4.py styles/paper-cut/index.html                 # 1080p and 720p
```

A `--fast` render of the whole 37.5 s demo (900 frames) took from about one to four minutes here, 66 to 240 ms a
frame depending on what else the machine (an Apple M-series Mac) was running; most of that is reading each frame back
and encoding it, not drawing it. The full-quality encode is slower.

## How it works

### Files, in load order

| File | Job |
|---|---|
| `../../examples/poem/lyrics_data.js` | The song: `window.SONG` (title, credit, audio, duration, bpm, lines with word times). |
| `core.js` | Frame size (a 1920x960 picture over a 120 px lyric band), the song's time range, easing, seeded random, value noise, fonts, and the paper: one tileable grey texture (`makePaper`) and `tint(col)` / `tintPattern(g,col,k,scale)` to make coloured paper from it. |
| `paper.js` | Baking cut pieces (`bakePiece`) and drawing them (`drawPiece`, `glowPiece`, `drawBent`, `bentPoint`); shape helpers (`ridgeShape`, `ridgePoints`, `taper`, `leaf`, `leafPath`, `polyFill`, `ellipseFill`). |
| `sky.js` | The aurora shader (`initSky`, `renderSky(uniforms)`), with white pinhole stars or tinted motes, and a 2D fallback. |
| `puppets.js` | Body plans (`BODY`), forward kinematics (`pfk`), drawing (`pdraw`), long hair that the wind blows (`phair`), two-bone IK (`ik2`), walk and sit cycles, and two things that walk with the figures: a pack beast and a sledge. |
| `shared.js` | Palette, tree generators (`genTree`, `genPoplar`), storm billows and lightning going up (`boltsUp`), snow, blowing snow, the wind (`wind`, `sway`, `swayTree`), integrated clocks, helpers for figures (`armTo`, `reachArm`, `mixLimbs`, `scarf`, and work on the beat: `strokePhase`, `keyPose`, `digPose`, `shovel`), and the sky's uniforms (`sky()`). |
| `props.js` | Pictograms and runes, buildings (longhouses, sheds, wells, shelters, a manor), ropes, snow and ice (with a path dug through a drift, `snowTrench`, and snow thrown off a shovel, `thrownSnow`), lanterns and fires, terrain, impossible ground, and things the wind moves: washing, pennants, a weathervane, a windmill, grass. |
| `engine.js` | Sets, shots and the camera, puppet compositing (`drawPuppet`, `standPuppet`), glow, bloom and vignette, the lyric band and title card, the player, and `window.__video`. |
| `eras.js` | A place that grows: sites with the eras they stand in (`SITE_KINDS`, `bakeSites`, `drawSites`), set down on the beats. |
| `set_valley.js`, `set_lane.js`, `set_strips.js`, `set_grove.js` | The demo's four sets (places). |
| `choreo.js` | The demo's figures: a pose for each one as a function of song time. |
| `timeline.js` | The demo's wind (breeze and gusts), the sky's pulse, and the shot list. |

These are plain scripts sharing global names, so each file's top-level names must be unique (the demo sets use
prefixes: `VDEP`, `LN`, `SDEP`, `GV`).

### A cut piece

```js
const hill=bakePiece({
  x:-300,y:500,w:2520,h:500,          // where it sits in the 1920x960 frame with the camera at rest
  s:1.05,                             // bake resolution: a little over 1 for near layers, which the zoom enlarges
  color:[40,70,82],tex:.3,            // paper colour, and how strongly the texture shows
  rimA:.5,rimW:1.6,rim:[196,236,226], // the lit edge along upward-facing cuts
  fog:{y0:760,y1:600,c:PAL.fog,a:.4}, // mist: none at y1, alpha a at y0 and below
  shadow:{blur:10,a:.4,dy:5},         // a soft shadow on whatever is behind
  shape:g=>ridgeShape(g,ridgePoints(-300,2220,8,x=>620+fbm2(x*.004,3,3)*60),1000),   // the silhouette, filled black
  after:g=>{/* coloured details painted on top, not clipped: lit windows, snow along an edge */}});
drawPiece(g,hill);                    // in a set's draw step
```

`bakePiece` returns `{img, sh, shadow, x, y, w, h, s}`: the tinted, rimmed, misted piece and its shadow sprite.
Everything drawn in `shape()` is one sheet of paper, so detail only shows where it changes the outline. Small trees
drawn inside a filled field vanish; they have to stick up past the edge, be their own piece, or be painted in
`after()`.

`drawBent(g,p,bx,by,A,n)` draws a piece bent about its base point, the way a tree bends: the top moves `A` px
sideways, each height moves in proportion to its square, and the piece is drawn in `n` sheared slices that meet
without gaps. `bentPoint(p,bx,by,A,x,y)` tells you where any point of it went, so leaves and blown snow stay on
their twigs. `glowPiece(g,p,k)` brightens a piece as if the light behind it grew (for flares).

### Sets

A set is a place: pieces baked once, then drawn in depth steps.

```js
defineSet('hill',{
  build:function*(){const P=this.P={};      // bake into this.P; yield between big pieces so baking can spread over frames
    P.hill=bakePiece({/* as above */});yield;
    const T=genTree(7,{x:900,y:700,h:320,tw:18,spread:1,leaf:0,dens:0,fruitP:0,fr:0,cutP:0,n:4});
    P.tree={p:bakeTree(T,[16,28,36],1.1),x:900,y:700,h:320,ph:0,give:.2};},
  sky:(t,cam,sh)=>nightSky(t,cam,sh),       // the aurora's uniforms, or null for a flat `bg` colour
  steps:[                                   // drawn in this order, each through its own layer matrix
    {d:12,draw:(g,t,M,cam,sh,S)=>drawPiece(g,S.P.hill)},
    {d:5,draw:(g,t,M,cam,sh,S)=>swayTree(g,t,S.P.tree)}],
  post:(g,t,cam,sh,S)=>{}});                // optional: a screen-space overlay after the layers
```

`d` is the layer's depth. `layerMatrix(d,cam)` moves a layer by `cam.x * 2.5/d` px for a camera move of `cam.x`, so a
layer at `d=2.5` moves one for one, and one at `d=25` a tenth as much. That difference is all the depth there is:
every layer is drawn at the same scale, so draw far things small. Useful depths: far peaks 50-70, middle distance
15-35, the stage 5-10, the foreground 2.5-3. Make each piece wider than the frame by the camera's travel times
`2.5/d` on each side, or the camera will see its edge.

Draw code gets `g` with the layer matrix already set, `t` (song time), `M` (that matrix), `cam`, `sh` (the shot, whose
`v` holds per-shot options) and `S` (the set). For things that span layers (a rope bridge from a near cliff to a far
strip), map each end with `layerMatrix(d,cam).transformPoint(...)` and draw in screen space: see `stripBridges()`.

### Shots and the camera

A shot puts one set on screen from its time until the next shot's:

```js
{t:7.5,set:'lane',cam:[[7.5,330,0,0,0,0,1],[11.25,170,0,0,0,-120,1.06],[15,40,-10,0,0,-352,1.3]],v:{walker:laneWalker}},
```

A camera key is `[t, x, y, z, ty, tx, zm]`, eased (`easeSine`) from key to key:

- `x`, `y`: dolly. Nearer layers move more (parallax).
- `z`: travel into the layers. Avoid it: the nearest layers blow up.
- `ty`, `tx`: shift every layer the same (a tilt or pan with no parallax). The sky follows `ty`.
- `zm`: lens zoom about the centre, the same for every layer. Push in with this.

To put a point at layer x `p` (depth `d`) at screen x `X` with zoom `zm` and dolly `x`: `tx = (X-960)/zm - p + 960 + x*2.5/d`.
Other shot fields: `fade` (dissolve in from the previous shot, seconds), `shake:[[t,amp,decay]]` (a jolt on a hit),
`ease` (another easing), `v` (anything the set's draw code reads, like `walker` above).

### Figures

Body plans in `BODY`: `stocky` (short limbs, fur-hemmed coat, pointed ears), `hooded`, `bare` (the same build
bare-headed, for long hair), `child` and `elder`. Legs are `kind:'plant'` (flat feet) or `kind:'digi'` (walking on the
toes, with an extra ankle joint, for animals and creatures built that way). A pose is a plain object:

```js
const B=BODY.hooded,q={x,face:-1,             // x on the layer; facing left
  lean:.35,look:-.04,                         // lean forward (radians); tilt the head
  legs:walkLegs(B,ph,.72),                    // ph counts strides
  arms:[{s:.5,e:.35},{s:.3,e:.3}],            // shoulder angle, and the elbow relative to the upper arm
  coatSwing:-.26,                             // hem angle: + swings it forward, - blows it back
  after:(g,j)=>scarf(g,j,t,w)};               // extra shapes cut in the same silhouette
q.arms[1]=reachArm(B,q,Y,sc,[hx,hy],-1);      // or bend the near arm so its hand lands on a point of the layer
```

Angles are measured from straight down, positive toward the way the figure faces. `walkLegs`, `walkArms` and
`sitLegs` give limb sets; `mixLimbs(a,b,k)` blends two, so a walk can ease into a braced stance.
`armTo(B,q,T,side,bend)` and `reachArm(...)` bend an arm so the hand lands on a point (a rope, a rail, someone
else's hand: in the grove, the adult and the child both reach for the same point, so their hands meet).
`drawPuppet(g,M,B,q,col,rimA,sc)` draws a near figure cut from paper with a lit edge and a soft shadow;
`drawFigure(g,B,q,col,sc)` draws a flat silhouette for distant ones. Both return the joints (`j.arms[0].Hd` is a
hand, for `drawLanternAt`). `standPuppet(g,M,q,Y,t)` does the bookkeeping for a figure on the ground: it works out the
pelvis height from the pose so the feet land on `Y` (or `q.seated` above it), scales the figure by `q.sc` about its
feet, and draws `q.hold(g,joints,t)` (something carried, in its own colour) after it. Two more pose fields for
`drawPuppet`: `rot` lays the figure over (it is drawn upright, turned about the pelvis, and its lit edge is cut to face
up after the turn) and `alpha` fades it, for someone going in at a lit door.

Long hair: give a pose `hair:{w, t}` (the wind at the figure, and time) and `phair` cuts filled locks from the crown
and the back of the head. In a calm they hang down the back; as the wind rises they stream downwind, to the right on
screen whichever way the figure faces, turning over the top of the head (never under the chin), each lock waving along
its length. With the wind behind, a breeze is enough to blow it forward past the face. Options: `n` locks (8), `len`
in head radii (2.6). The strips' walker wears it (`choreo.js`).

Work on the beat, like digging, is a stroke that lands on each beat of a list: `strokePhase(t,beats,dur,at)` gives the
phase 0..1 of the stroke round the nearest beat (the landing, a throw or a blow, `at` of the way through), and
`keyPose(u,keys)` eases a pose between keyed poses (numbers, and numbers inside arrays and objects, blend). `digPose`
uses `DIG_KEYS` (rest, scoop, toss, rest): the near hand holds the shaft at an angle `tool`, and the far hand reaches
the end of the handle by IK. `shovel(g,j,q)` cuts the shovel in the figure's silhouette (the pose's `after`) and
`shovelLoad` puts snow on the blade (its `hold`). With the props `snowTrench` (the drift still ahead of the digger,
the dug trough, a bank that grows) and `thrownSnow` (each shovelful arcs off the blade and breaks up, and a gust
carries it away downwind), that is the grove's digger, whole:

```js
const ROAD_DIG={x0:1520,x1:1760,beats:[43,44,45,46,47,48,49,50,51,52,53].map(b=>SONG.beat(b)),sc:.58};
const u=strokePhase(t,ROAD_DIG.beats),q=digPose(BODY.hooded,{b:BODY.hooded,x,face:1,sc:.58,legs:[{h:.42,k:-.55},{h:-.28,k:-.12}]},u);
q.after=(g,j)=>shovel(g,j,q);                                       // then standPuppet(g,M,q,Y,t) in the set's step
```

### The wind

`timeline.js` sets a steady `BREEZE` (keyframes) and a list of `GUSTS`, each `[peak time, strength, rise, hold,
release]`. A gust peaks at `WIND_X0` at its time and travels right at `WIND_C` px a second, so a row of trees bows one
after another.

- `wind(t,x)` is the air: smoke, snow, washing, pennants and grass follow it.
- `sway(t,x)` is what springy things do: they lean with the gust, then spring back past upright and settle.
- `windClock(t)` is how far the air has moved (the wind integrated over time); `windClk(t)` is the clock smoke puffs
  ride, and `windDrift(t,k)` feeds `drawFlakes`, so gusts push snow and smoke along without anything jumping.
- `swayTree(g,t,T)` draws a tree baked as its own piece, bent by `sway`: `T = {p, x, y, h, ph, give, fq, n}`, where
  `give` is how far the top goes per unit of sway (a share of `h`). It returns the bend, for `bentPoint`.

The props that respond: `clothShape` (washing pegged at two points), `flagShape` (pennants and swallow-tailed
banners), `weathervane`, `windmill` + `windmillSails`, `grassBlades`, `plume` (chimney smoke leaving "up" for its
house, then bent downwind, for houses at any angle), `windStreaks` (strips of blowing snow), `spindrift` (snow blown
off tree tops). The live ones return a path; fill it with `litFill(g,shape,col,rim)`, which cuts it in paper with a
lit top edge.

### Impossible land

- `floatLand(g,y,x0,x1,depth,seed,o)` / `floatRock(...)`: land hanging in the air, with a ragged underside, roots and
  icicles. Rotate the canvas a quarter turn first and it stands on its edge (`set_strips.js`).
- `smoothPts`, `curveFrames(C,step)`, `onFrame(g,F,f)`: frames along any curve, so trees, houses and posts stand
  square to it, sideways on a wall or upside down under an overhang. `snowOnCurve` lays snow on the ground side.
  The ground is the curve's left-hand side, so list a curve's points in the direction that puts the left on the
  ground (`set_valley.js` lists its curling wall from the tip back to the foot).
- `ropeBridge` (at one depth), `spanBridge` (between depths, in screen space, with sag and sway), `ropeLadder`,
  `portal` (a tunnel mouth), `plume` (smoke that goes "up" for each house, whichever way that is).
- On such land everything obeys its own ground: smoke leaves "up" for its house before the wind takes it, icicles and
  pennants hang toward the house's ground (so under an overhang they point up at the rock), snow lies on the roof's
  own top, and anything being set down drops along the frame's own "down". Draw it all inside the frame (`onFrame`, or
  `atSite` for a site), and only the wind keeps the screen's direction.

### A place that grows (eras.js)

A set can show one place at several times. Bake its terrain bare, and list what is built on it as sites, each with
the eras it stands in:

```js
const VSITES=[
  {at:'L3',era:[0,1],kind:'house',x:560,o:{gw:30,len:70,wh:16,rh:19,wins:3,chimney:true}},   // stands from the first view
  {at:'L3',era:[1,1],kind:'windmill',x:700,h:70,rise:0},                                    // only later; lands on riseAt[0]
  {at:'fold',era:[1,1],kind:'windmill',u:.385,h:58},                                        // part way along the fold's curve: under the overhang
];
yield* bakeSites(P,VSITES,{                                  // in the set's build: each site becomes its own small piece
  L3:{y:P.L3y,col:[39,66,79],s:1.06,fog:{y0:560,y1:470,c:PAL.fog,a:.42}},                     // a layer: its ground y(x) and its paper
  fold:{frameAt:u=>P.foldF.at(P.foldF.L*u),col:[38,66,79],snow:[196,220,220],smoke:1.2}});   // a curve: frames along it
{d:VDEP.L3,draw:(g,t,M,c,sh,S)=>{drawPiece(g,S.P.L3);drawSites(g,t,sh,S,'L3');}}              // in the layer's step
```

A shot picks the era with `v.era`; with `v.rising` and `v.riseAt` (times, usually beats), each site that has a `rise`
number drops into place over the 0.3 s before its time, so it lands on the beat. A site stands at `x` on the layer's
ground (`y(x)` plus `dy`, default 4), or at `u` of the way along the layer's curve (`frameAt`), turned to stand square
to it, sideways or upside down. The kinds in `SITE_KINDS`: `house` (a longhouse: `o` as for `longhouse`), `windmill`
(`h`; its sails turn with the wind), `shelter` (`sh`: `'tent'`, `'lean'`, `'sledge'` stood on end, or `'dome'` of snow
blocks, with a small fire at its mouth), `manor` (`s`, `dir`; a pennant flies from its tower) and `bridge` (`a`, `b`,
`sag`). Add a kind by writing `SITE_KINDS.name=(s,L,oncurve)=>({box, shape(g), after(g), wins, fires, smokes, sails,
flags})`, drawn at its own foot. `drawSites` lights the windows and fires (`v.lit(t,i)` sets each one, counted across
all the sites), bends the chimney smoke with the wind, turns the sails and flies the pennants.

In the demo the valley is era 0 in the opening shot and era 1 at the end: two houses and three windmills are set down
on beats 55 to 57, and a house and a windmill hang from the fold. The trees and the rope line on the fold keep clear
of the later sites only as far as each one needs, so the first view is still wooded round them.

### The sky

A set's `sky()` returns `sky({t, ta, storm, hit, flare, panY, poster, motes})`:

- `ta`: the aurora's own clock (`auroraClock(t)`). Its speed is `skySpeed(t)` in `timeline.js`, summed at build, so
  speeding up never makes the curtains jump.
- `storm` 0..1: the curtains drop toward the horizon, brighten and pale. The demo ties it to the wind.
- `hit` 0..1: a storm front; the low sky goes pale and the stars go out.
- `flare` 0..1: a brief flare. `skyFlare(t)` puts one on every bar line and a bigger one where each sung line starts.
- `panY`: the camera's tilt (`cam.ty/PH`). `poster`: 0 smooth, 1 fully stepped tissue layers (default 0.72).
- `motes` 0..1: 0 pricks white stars through the sheet; 1 puts motes in their place, points of light tinted in the
  aurora's colours (teal, green, violet, a little pale gold), drifting slowly, a few strung in short lines of four,
  as faint as the stars. The strips set uses them (`nightSky(t,cam,sh,{motes:1})`), for the one place that plainly
  isn't the sky we know.

`boltsUp(g,t,t0,list,seed)` (in `shared.js`) is weather that isn't: violet-white lightning going up from a ridge into
the storm for half a second after a hit at `t0`, jagged with a branch or two, from each `[x, yBase, height]` of the
list. Draw it in the storm's step, and put `t0` on the hit. (The demo has no storm; it's ready for one.)

### Lyrics and title

`engine.js` turns `SONG.lines` into `LYRICS`: a line fades in 0.4 s before its first word and gives way to the next
line; each word lights with a warm glow over `[t-0.04, t+0.16]` of its time; long lines shrink to fit. The title card
(`SONG.title` in italics, `SONG.credit` beside it) shows from 0.25 s until the first line.

### Determinism and caching

- Every frame is a function of song time. Nothing carries from one frame to the next, so `renderAt(t)` and `step(t)`
  draw the same picture (`step` only skips a redraw within the same 1/24 s). Randomness comes from seeded
  `mulberry32` generators and `hashi(x,y)` keyed to indices, never `Math.random()`.
- Sets are baked on first use, one piece per `yield`. After the page loads, the remaining sets bake in the
  background; during playback the sets of the next 9 seconds bake a piece per frame. At most `MAX_LIVE` (7) sets stay
  baked; the least recently used is dropped.
- Paper tiles are cached per colour. Colours given to `tint`, `tintPattern` and `litFill` must be fixed values: a
  colour computed each frame bakes a new 512 px tile every frame.

## Make your own video in this style

1. **Copy the folder**: `cp -r styles/paper-cut projects/my-song` and put your `song.mp3` beside it (see
   [docs/your-own-video.md](../../docs/your-own-video.md)).
2. **Time the song**: [docs/timing.md](../../docs/timing.md) ends with `tools/audio/to_js.py` writing your
   `lyrics_data.js`. In `index.html`, change the first script from `../../examples/poem/lyrics_data.js` to
   `lyrics_data.js`, and change the `<title>`, heading, subtitle and the canvas's `aria-label`. The engine reads the
   duration, lyrics, title and credit from `SONG`; the demo's shots keep playing until you replace them.
3. **Keep** `core.js`, `paper.js`, `sky.js`, `puppets.js`, `shared.js`, `props.js`, `engine.js` and `eras.js`. **Replace**
   `set_*.js`, `choreo.js` and `timeline.js` (and list your set files in `index.html`, before `choreo.js`).
   The demo's sets are good starting points: a wide landscape (`set_valley.js`), a street-level stage with figures
   (`set_lane.js`), floating land (`set_strips.js`), a row of trees (`set_grove.js`).
4. **Add a set** with `defineSet` (above). Build back to front: far ridges, middle layers, the stage, the foreground.
   Give anything that moves its own piece (or draw it live); keep the rest baked.
5. **Add shots** to `SHOTS`, in time order, one per stretch of song. Cut on line starts (`SONG.lines[i].t0`).
6. **Time a move to a word or a beat**: word times are `SONG.lines[i].words[j][1]`, beats `SONG.beat(n)`. For example
   a gust that peaks on the fifth word of the first line, and a figure who stops on beat 44:

   ```js
   const word=(i,j)=>SONG.lines[i].words[j][1];
   GUSTS.push([word(0,4),.55,1.3,.3,1.0]);
   const stopAt=SONG.beat(44);   // then in the figure's pose: walking before stopAt, braced after
   ```

7. **Check** with stills every second or two across each new stretch (`tools/still.py ... a:b:1 --sheet`), then
   render.

Useful knobs:

| Knob | Where | What it does |
|---|---|---|
| `BREEZE`, `GUSTS`, `WIND_C` | `timeline.js` | The wind's steady level, its gusts, and how fast a gust crosses the picture. |
| `give`, `fq` on a tree | set files | How far a tree bows, and how fast it quivers. |
| `skySpeed`, `skyStir`, `skyFlare` | `timeline.js` | How fast the aurora moves, how much it stirs, how hard it flares. |
| `poster` (sky uniform) | `sky()` in `shared.js` | 0 smooth aurora, 1 fully stepped tissue layers. |
| `PAL` | `shared.js` | Colours. Layer tones run from far and pale to near and dark. |
| `rimA`, `rimW`, `rim`, `fog`, `shadow` | each `bakePiece` | How lit the cut edges are, the mist between layers, the shadow. |
| `PUP_S` | `engine.js` | Resolution of the puppet buffer (raise it for very large figures). |
| `FADE_IN`, `FADE_OUT`, `POSTER_T` | `timeline.js` | Fades at the ends of the film, and the frame shown before Play. |
| `MAX_LIVE` | `engine.js` | How many sets stay baked at once (memory against re-baking). |
| `VSITES`, `v.era`, `v.riseAt` | `set_valley.js`, `timeline.js` | What stands in the valley in each era, and when each new thing lands. |
| `motes` (sky uniform) | a set's `sky()` | White pinhole stars (0) or tinted, drifting motes (1). |
| `DIG_KEYS` | `shared.js` | The digging stroke's poses (rest, scoop, toss) and the shovel's angle in each. |

## Performance

- Drawing a frame takes about 13 ms (median, measured in Chrome on an Apple M-series Mac), up to about 50 ms during
  a dissolve (two shots drawn). The first frame of a set pays for uploading its pieces, up to about 180 ms; the page
  bakes every set in the background after load, so live playback rarely sees it.
- Memory: 55-90 MB of canvases per set, about 285 MB for the demo's four. A site (eras.js) is a small piece with its
  shadow, a few hundred KB; the valley's 15 add a few MB and well under a millisecond a frame.
- What costs: large pieces (every layer is about 2500 px wide), bent pieces (each drawn in 12-20 slices, twice with its
  shadow), live paper paths (grass, leaves, washing), the bloom pass, and dissolves.
- Rendering: 66-240 ms a frame with `tools/render_mp4.py --fast`, most of it spent reading the frame back and
  encoding (the latest whole render: 900 frames in 68 s, about 76 ms each, with other renders running). Frames don't
  depend on each other, so a slice renders the same as the whole.
- To render only a stretch: `python tools/render_mp4.py styles/paper-cut/index.html --start 26 --end 34 --fast`.

## Lessons and gotchas

- **Start building only when every script has loaded.** The engine file loads before the sets and the timeline;
  wait for `DOMContentLoaded` before building, or a cached (fast) font load lets the build start before the later
  scripts have run.
- **Texture joins:** tinting a quarter of the paper texture showed repeat lines on big pieces. Tint the whole
  (tileable) texture, downsampled, and scale the pattern up.
- **GLSL reserved words** (such as `patch`) as variable names break the shader. The error only shows in the console.
- **A single bad value in a canvas gradient kills the whole frame.** Read the console after every change.
- **Load the fonts with the text they'll draw** (`fontsReady()` in `core.js`), or the title and first lines fall back
  to a default face for a frame or two.
- **The play overlay is `display:grid`, which beats the `hidden` attribute**, so it never hid until the page's CSS
  got `.gate[hidden]{display:none}`.
- **Storms:** a storm read as a flat white band until it was built from overlapping scalloped billows, each with its
  own lit top edge. Snow spilling over a ridge showed rectangular blocks until it became a lobed curtain. A flare
  went pink until the violet in the aurora was reduced.
- **A valley of flat bands reads as a layered cake.** Steep U-shaped cross-sections at receding depths, trees on the
  steep parts, and a foreground ledge fix it. Anything that fills a valley (ice, water, mist) should fill each layer up
  to a level rather than sit in it as a box.
- **Floating land exposes the bottom of the sky**, which is bright. A dark gradient behind the strips turns it into a
  deep gulf.
- **Impossible land needs land on it.** A curling wall read as a pale wave with thorns, and land on its edge as a
  plain cliff, until they had things at a readable size: trees in stands, houses with lit windows, a rope line with
  lanterns, snow on the ground side, a ragged underside with ice pointing the "wrong" way, smoke going the "wrong"
  way.
- **Push in with `zm`, not `z`.** Depth travel blows up the nearest layer: snowflakes become moons.
- **Effects that belong to a layer must be drawn in its frame.** Light from an open door drawn at the wrong depth split
  into two or three pale panels when the camera moved. Draw it with that layer's `layerMatrix(d,cam)`.
- **Figures:** a very thin figure looked like a stick insect until it was given a deep chest; round heads read as
  teddy bears until they had a small muzzle; a walk on the toes (`'digi'` legs) looked like sitting on a stool until
  its stride was shortened; two figures leaving the same way merged into one blob.
- **Pale objects with glowing marks read as lanterns.** Make them pale with a dark stamped mark instead.
- **Big close-up silhouettes of hands and arms read as clubs, poles or chess pawns.** Show whole figures; a mostly
  still figure holding a rope carries a moment fine.
- **Guide ropes at knee height are too low to hold.** Put them at about hip height for the figures that use them.
- **A figure that changes how it's drawn** (on a layer, then on a screen-space bridge, then on a far strip) must keep
  the same stride phase, scale and draw order across the change, or it pops for a frame.
- **Reaching hands must stay in reach.** When two figures hold hands by reaching for one point, check every pose: a
  crouch lowers the shoulder, and the hands part.
- **Anything that bends must be its own piece**, and `bentPoint` must use the same bend as `drawBent` (measured from
  the piece's top, padding included), or attached leaves drift off their twigs. Bake a row of small trees in groups of
  three: one piece per row can only shear as a block, so no gust can travel along it.
- **Slices must overlap, but a shadow can't.** A bent piece is drawn in slices that overlap by a pixel so no gap
  shows; its soft shadow, drawn the same way, darkened into faint horizontal lines where the slices doubled up. Only
  the opaque piece overlaps its slices.
- **Drive speeds with integrated clocks** (`makeClock`), never `t * speed(t)`: when the speed changes, everything
  riding it jumps.
- **Blowing-snow streaks across the sky read as searchlights**; keep them below the horizon. Snow blown off tree tops
  drawn as round soft dots reads as a row of bokeh; stretch the puffs along the wind and thin them out.
- **Keep something moving.** Every shot here has a camera drift, snow, and the wind working on something; a hold of
  more than a beat or two looks like the player froze.
- **A place that grows keeps its sites.** Bake the land bare and list every building as a site with its eras, so each
  later view keeps the earlier houses where they stood; a view built separately for each era drifts. Clear the land
  (trees, posts) round a later site only as far as it needs, or the first view has bare patches where nothing stands
  yet. Set new things down so they land on the beat, over the 0.3 s before it, not after it.
- **On hanging land, everything obeys its own ground** except the wind: smoke, icicles, pennants and snow on roofs
  are drawn in the frame of their bit of curve, and things being set down there drop along that frame's "down". A
  pennant's streaming is the one thing that keeps the screen's direction (to the right with the wind), so it's
  mirrored on land that is turned over.
- **A shovel raised over the head reads as an axe or a hammer.** Toss at shoulder height. Aim the shaft by an angle
  held in the near hand and bring the far hand to its end by IK: a shaft laid through two hands placed by their own
  angles points wherever they happen to be, often straight up.
- **A figure with no height is never drawn.** Stand every figure on the ground from its pose (`standPuppet` works out
  the pelvis height from where the feet land) instead of giving each one a `y`.
- **Hair:** single strands read as antennae or a spiky crest, and locks that end in rounded tips read as the fingers
  of a mitten; filled, tapering, wavy locks read as hair. Turned from hanging to streaming by blending their direction,
  locks swept under the chin read as a beard: turn them over the top of the head. With the wind behind a figure, even a
  breeze blows hair forward; halfway there, it stands up like a crest.
- **A GLSL name that clashes breaks the whole sky.** Adding the motes with a variable already declared in the shader
  (a `vec2` used by the curtains) made it fail to compile, and the page fell back to a flat gradient. Give new shader
  code its own names, and read the console.
- **Infinity poisons smoothstep.** A helper that returns `Infinity` for "none" (the top of a fill level on a layer
  that has none) gave `sstep(a,b,Infinity)`, which is NaN, and a NaN alpha blanks what it touches. Guard such values.
- **Short effects need the right instant for a still.** The rising bolts fade within a quarter of a second, so a still
  0.3 s after the hit shows nothing; ask for a few hundredths of a second after it.
- **A figure lying down outdoors reads as a collapsed body.** One asleep on its feet, head down, reads as dozing.
- **Loads read by how they're held.** Sacks hugged against the chest at a walking pace read as carried; a sack held
  over the head with a leaping stride didn't, and sacks stacked upright in a lit doorway read as a hooded head until they
  were laid flat like sandbags. Snow on a head drawn as a row of dots read as pearls, then as a skullcap: a lumpy cap
  clipped to the head's outline, with loose flakes on the shoulders, reads as snow.
- **Bring people in from the cut.** A figure that pops into the middle of the frame mid-shot is a glitch; have them in
  the shot from its first frame, or walk them in from an edge, and fade them (`alpha`) where they go in at a door.
- **A shot's figures must last through the dissolve out of it.** The next shot's `fade` draws this one for a while
  longer; a pose function that returns nothing from the moment its shot ends makes its figures vanish while the picture
  is still nearly fully visible. Keep them until the fade is done.

