# Photomontage

A music video built like a 1920s-30s constructivist photomontage, shown as the paste-up itself rather than the printed
poster: photographs cut out with scissors or torn, glued to grey card beside planes of black and red paper, bold block
lettering on hard diagonals, pencilled guidelines and crop marks. Pieces land on the board on the words and stay, so the
board fills up as the song goes, and a camera travels over it. What makes it read as paper and photographs rather than
flat graphics: every piece is a canvas with alpha laid with a soft shadow down and to the right (the paper lifting a
little), a lit top edge and a darker lower edge; the paper has fibres and uneven dye; scissor cuts drift and nick where
two cuts meet; torn edges show a pale fibrous core. The photographs are paintings in greys given a print's surface:
painted at a lower resolution, then halation, a mottled paper texture, an S-curve with lifted blacks, grain, a vignette
and a warm or cool tone. People come from a ray-marched figure model, and every one is a different face. Some pieces
are drawn instead: the same figure model and the same paintings engraved in pen and ink (an outline, lines where the
tone turns, hatching in the shadows), sketch maps in pencil on tracing paper, a wash spreading across a map, papers in an
invented script. The lyric is typeset on a paper strip glued under the picture. For part of the song the board freezes
and turns into a **pinscreen** (Alexandre Alexeieff and Claire Parker's screen of pins, where the picture is the pins'
shadows), rendered in WebGL2, and rolls over into a moving landscape, then rolls straight off it again.

![A paste-up title card: "Who has seen the wind?" in block type on a black diagonal band, a red disc, and a cut-out photograph of a figure holding their hat in the wind](img/hero.jpg)

## Looks in this family

The lab (`lab/index.html`) draws the same two moments of the poem in four looks.

- **Photomontage** (the demo): cut photographs, paper and block type laid on grey card, a caption strip under it.
  ![The hill as a paste-up](img/look-photomontage.jpg)
- **Pinscreen**: the picture made of the shadows of pins lit from the side, velvety and soft, with a film subtitle.
  ![The hill on the pinscreen](img/look-pinscreen.jpg)
- **Drafting sheet**: the place drawn in plan, section and elevation on draughting linen, annotated in pencil, red crayon and pen.
  ![The hill as a drafting sheet](img/look-drafting.jpg)
- **Drawing**: the same painting engraved in pen and wash on drawing paper, and the country as a pencil sketch map with
  the gust hatched across it, the line pencilled underneath.
  ![The hill as a pen-and-wash drawing](img/look-drawing.jpg)

More frames from the demo: [the faces](img/faces.jpg), [the wind passing through](img/through.jpg) (a scrap blown off,
its outline left, and the gust drawn over a sketch map), [the hillside on the pins](img/pins.jpg),
[the trees bowing](img/trees.jpg), [someone passing by, drawn in ink over a photograph](img/passing.jpg).

## Run the demo

From the repository root:

```
python tools/serve.py
```

then open http://localhost:8000/styles/photomontage/index.html. It builds for a few seconds (every piece is made once
at load), then plays live with the song: Play or the space bar, and the slider to scrub. Add `#t12.5` to the URL to
show a single still at 12.5 s. In Chrome the paste-up plays at 15-24 frames a second, depending on the machine; the
pinscreen stretch (18.1-26.25 s) is heavier, so while playing the player shades the pins at half resolution, and even so
it runs at 10-20 frames a second. Render the MP4 to see it at its best. If the audio can't load, it plays on a silent
clock.

Stills and video (repository-relative paths):

```
python tools/still.py styles/photomontage/index.html 3 12.5 21 0:37.5:2.5 --sheet
python tools/render_mp4.py styles/photomontage/index.html --fast          # 720p preview
python tools/render_mp4.py styles/photomontage/index.html                 # 1080p and 720p
python tools/render_mp4.py styles/photomontage/index.html --fast --start 17 --end 27   # a slice
```

A full `--fast` render of the 37.5 s demo (900 frames) took 1 minute 16 seconds here, with other renders running on
the same machine: a few seconds to build, then 59 s for the frames, about 66 ms a frame on average including reading
each one back and encoding it. Under heavier load it has taken four times as long, mostly in the 195 or so
pinscreen frames.

`parts.html` shows the parts on their own, a sheet at a time (`parts.html?p=people`, `faces`, `heads2d`, `land`,
`things`, `papers`, `drawn`, `inkpeople`, `pins`, `pinraw`, `pinzoom`); use it while making a new piece.

## How it works

### Files, in load order

The engine (keep these):

| file | job |
|---|---|
| `core.js` | sizes (1920 x 1080), seeded random numbers (`RNG`, `hash2`), value noise (`vnoise`, `fbm`), polygon helpers (`wobble` makes a line hand-drawn), the web fonts and `fontsReady()` |
| `figure.js` | the figure model: one signed-distance person (head with face shape numbers, hair, hood, mask, hat; torso, arms with jointed hands placed by IK, a coat or cloak with folds, collar, scarf, legs), ray-marched in WebGL and read back as shade and material per pixel. `renderFigure(spec)` |
| `people.js` | who the model draws: `faceParams(k)` a different face for person k, `clothesAlb(k)` the greys of their skin, hair and clothes, `person(o)` the spec |
| `photo.js` | photographs: `photoFinish(canvas, o)` (the print surface), `photo(w, h, seed, paint, o)` (paint low, finish, scale up), `figurePhoto(spec)` (a figure in greys on film), hair extras (curls, wind-blown strands, spectacles) |
| `faces2d.js` | cheap painted ID heads for crowds: `idHead(p)`, `crowdHead(k, o)` |
| `figs.js` | people as photographs: `figGrey(o)` (unprinted, to paint into a scene), `placeFig()`, `figPhoto(o)` (printed and cut out with a sliver of background) |
| `heads.js` | figure-model heads as small ID prints: `modelHead(o)`, `idPrint(k)` |
| `terrain.js` | a stretch of hill country as a height field: `relief()` (hill shading), `contours()`, `profile()`, `mapFeatures()`, `surveySheet()` (a printed map) |
| `pasteup.js` | the paste-up's materials: `boardTex`, `scissorPoly` / `cutOut`, `tornPoly` / `tearOut`, `cutFigure`, `laypiece`, `paperPiece`, `typePiece`, `captionStrip`, `pencilGuides`, `cropMarks` |
| `pieces.js` | kinds of piece, cached by name: `sheet`, `docPrint`, `scrap`, `band`, `disc`, `plane`, `arrowPiece`, `word`, `heavy`, `noteSlip` (pencil, crayon or pen), `pinPiece` (a drawing pin), `mapIn` and `mapCut` (a piece's own pixels to the board), `ring` |
| `pinscreen.js` | the pinscreen: `pinscreen(picture, o)`, `lamp()`, the calibration `pinLUT`, `softPaint()`, the rollers `roll()`, `rollerBlend()` and `rollMask()`, `zoomPic()` (a push-in on a picture), `filmBand()` |
| `drawn.js` | drawn pieces: `engrave()` (pen work from any grey picture), `inkFigure()`, `inkWash()`, `inkHead()` and `headStrip()`, `tracing()` (tracing paper), `spreadWash()` (a wash spreading over a map), pen lines and hatching (`penLine`, `penHatch`), an invented script (`runeBlock`) and handwriting too small to read (`scribble`) |
| `engine.js` | the film: the board, `put()` and piece states, wipes, gusts and jolts, pieces taken away (`gone`, `outlineOf`, `blankOf`), haze, inks, the camera, the caption strip, the pinscreen windows, `drawFrame(t, canvas)` |

The demo (replace these with your own):

| file | job |
|---|---|
| `places.js` | painters in greys: sky, trees that bend (`paintTree`, and kept `treeSprite`s), grass that waves, the hillside, a branch and leaves, a weathervane, an anemometer, cloth on a line, a windmill |
| `scenes.js` | the demo's pieces: `printPhoto()` and `objectPhoto()` (the two ways to turn a painting into a piece), the photographs, substitution cycles, people, papers (a Beaufort card, an observation log), map scraps, the kite; drawn ones: `sketchMap()` (the country in pencil on tracing paper), `gustWash()`, `walkerDrawing()`. Also `gust(t)`, the demo's wind strength |
| `memory.js` | the moving pictures for the pinscreen window: `memories()` |
| `shots.js` | everything laid on the board against the song: stations, pieces, inks, camera keys, gusts, the pinscreen window. `buildShots()` |
| `index.html` | the page and player; builds everything, then `window.__video.step(t)` |

### The board and its pieces (`engine.js`)

The board is one big grey card in world coordinates (1 unit = 1 pixel at zoom 1). `put(c, at, o)` adds a piece and
returns it:

- `c`: a canvas (or a function returning one, or an **array** of canvases: a substitution cycle, where `o.frame(t)`
  picks which one shows, the way a cut-out animator swaps drawings).
- `at`: `[x, y]` on the board where the piece's anchor lands (its centre unless `o.ax` / `o.ay` give another point in
  the piece's own pixels, such as a tree's base or a leaf's stem).
- `o.t`: when it lands. `o.mode`: `'drop'` (falls onto the board, bigger and higher at first, then settles with a tiny
  bounce; the default), `'slide'` (from `o.from = [dx, dy]`), `'fade'` or `'none'`. `o.dur`, `o.rot`, `o.s` (scale),
  `o.z` (stacking; default: the order you add them), `o.shadow`, `o.lift`, `o.alpha`.
- `o.leave`, `o.leaveTo`, `o.leaveDur`: take it off again (lifted away, or slid off). `o.hide`: `[[t0, t1], ...]`.
- `o.move(t, st)`: change its state as time passes. `st` has `x, y, s, sx, rot, a, lift`. Ready-made ones:
  `swayMove(amp, freq, phase, env)`, `trembleMove(amp, phase, env)`, `turnMove(ang0, amp, freq)` (a weathervane turning
  about its rod: the width follows a cosine), `flyMove(t0, vx, vy, spin)`.
- `o.wipe = { t0, t1, ang, seed, amp }`: the piece appears along a ragged front running across it at angle `ang` (in the
  piece's own frame; 0 runs left to right), from t0 to t1: a wash, a frost or a flood spreading over the sheet under it.
  Give such a piece `shadow: 0`.
- `slip(piece, t, dx, dy, dr)`: knock it off its mark at t. Slipping two pieces the same way keeps them in register
  (a map and the layer drawn over it).
- `gone(piece, t, o)`: take a piece off the board at t and leave its pencilled outline where it lay (`outlineOf(canvas)`),
  or with `o.blank` a grey blank of its shape (`blankOf`), the gap a picture leaves. By default it's lifted away;
  `o.leaveTo` slides it off, and `o.fly = [vx, vy, spin]` blows it away: a copy flies off above everything for
  `o.life` seconds while the original goes. Call it while building, after the piece is put.
- `mapIn(canvas, at, rot, s)` maps a point in a piece's own pixels to the board, for laying things on a piece (a ring
  round a line of a document, leaves on a branch); `mapCut` does the same for a piece cut out of a bigger sheet, from
  the sheet's pixels (`cutOut` keeps where it cut). To lay a layer the size of a sheet exactly over it (a drawing over
  a map), put the layer at `mapCut(cut, at, rot, s)(w / 2, h / 2)` with the same `rot` and `s`.

`prepPiece()` makes each piece's lit edge and blurred shadow once, at load; `pieceState(p, t)` works out where it is at
time t; `drawBoard(t)` draws every piece and ink in z order through the camera. `JOLTS` holds hits (a number: every
piece already down shakes) and gusts (`{ t, at, dir, speed, amp }`: a push downwind that runs across the board at
`speed`, so pieces nearer `at` move first). `inkOn(points, t, o)` draws a line on the board over `o.dur` seconds (with an
arrowhead if `o.arrow`). `HAZE` entries blow mist across the whole frame.

### The camera

`CAM` is a list of keys `[t, x, y, zoom, rot, ease]`: the board point at the centre of the frame, the zoom, a rotation,
and how to get there from the key before (`'io'` by default, `'o'`, `'i'`, `'lin'`, or `'cut'` to jump). Zoom is
interpolated in log space, so push-ins feel even. The demo moves between stations in the half second before each line
starts, and drifts slowly while it's there.

### The pinscreen windows

`MEM` holds windows `{ t0, t1, prog: [[t, name, rollDur, rollAngle], ...] }`. At `t0 - .35` the board freezes and fades
into its own picture on the pins; each `prog` entry rolls in over `rollDur` seconds and is fully up at `t`; at `t1` it
rolls back to the board as it will be at `t1 + .35`, so the camera can cut somewhere new while the pins are up (the
demo cuts from the hillside photograph to the trees). Pictures come from `memories()` in `memory.js`: a grey canvas at
half the frame size (light = pins flush, dark = pins far out), or a function of t that repaints every frame, which is
how the trees on the pins keep bowing.

A window can instead roll the pins straight over the live board and off it again, with no pinned copy of the board:
`direct: true` (or `'in'` or `'out'` for one end), with `inDur`, `inAng`, `outDur`, `outAng`. The pins then start
rolling in at `t0` and are gone by `t1`, and the board under the roller's front is live, so the camera may still move.
The demo's window starts the old way (the push-in into the hill photograph turns to pins, the same hill) and ends
direct: the walkers roll off and the trees station comes back in colour through the front, its pieces landing as it
clears (`rollMask(u, ang)` is the front, the same ragged edge as `roll()`).

`zoomPic(src, z, fx, fy)` crops a picture painted once at full size to a slow push-in for the pins: key `z` to t in a
picture function for a camera move inside the pinscreen (`parts.html?p=pinzoom`).

`pinscreen(picture, o)` turns the picture into pin pushes through a calibration (`pinLUT`: how dark the screen comes out
for each push with these lamps, inverted), then a WebGL2 shader works out, for every pixel of the screen, whether a pin
upstream of each lamp shades it. Two coloured lamps from opposite sides give shadows of two colours, and pin heads catch
the light. The frame is shaded at twice its size and scaled down (`PIN_SS`), with a little grain and vignette.

### Photographs and people

- `photo(w, h, seed, paint, o)`: paint in greys at a lower resolution (`o.q`), finish it as a print (`photoFinish`),
  scale it back up with a little blur. `printPhoto()` (in `scenes.js`) adds a white border and cuts it out with scissors
  (`o.torn` tears it instead) and returns anchors you gave from the painter; `objectPhoto()` prints a thing on its own and
  cuts round its outline, leaving a sliver of the print's grey.
- People: `figPhoto({ k, pose, body, armL, armR, headYaw, ... })` renders person k, textures hair and cloth, prints it
  and cuts it out. `figGrey()` leaves it unprinted, to paint into a scene so it shares that photograph's light and grain.
  `idPrint(k)` is an ID-photo head; `crowdHead(k)` a much cheaper painted one for crowds. Every k is a different face.
- Arms are placed by where the wrist goes (`to: [x, y, z]` in head units, the head's centre at 0, 0, 0; +x is the
  figure's left, +y up, +z toward the camera), with an elbow hint (`pole`), the palm's direction and each finger's curl.

### Drawn pieces (`drawn.js`)

Among the photographs some pieces are drawn, made from the same sources. `engrave(greyCanvas, o)` turns any grey
picture with alpha into pen work, pixel by pixel: ink where the alpha ends (the outline), ink where the tone turns
sharply, hatching where it's dark (one direction past `h1`, a second past `h2`, a third past `h3`, `hatch` pixels
apart), and the tone itself kept as a light `wash` on the paper.

- `inkFigure(o)`: person k from the figure model (the same options as `figGrey`) engraved. Drawn clothes default to
  pale greys (`INK_ALB`), so only the shadow side is hatched; `o.tint = { material: [r, g, b] }` washes one material in
  a colour (the walker's red scarf is `{ 19: [168, 52, 40] }`), `o.blankFace` leaves the face a blank oval. Cut it from
  its sheet with `cutFigure(f.c, { bg: .93, sliver: 5, bgGrad: false })`, a sliver of paper round the drawing.
- `inkWash(w, h, paint, o)`: a place painted by any painter in `places.js`, engraved on a sheet of drawing paper with
  more of its tone kept as wash (the lab's drawing look is `paintHillside` this way).
- `inkHead(k, o)` and `headStrip(n, seed, o)`: heads drawn in pen (hair, a cap, long hair, a hood, a headscarf; open
  mouths; `wind` sweeps the loose ends), and a sketchbook strip of them in staggered rows for a crowd.
- `tracing(w, h, draw)`: a sheet of tracing paper, partly see-through, to draw on in pencil; `sketchMap()` in
  `scenes.js` draws the demo's country on one (contours from `terrain.js`, hachures down the steep sides, its river
  and road, the wood, feathered wind arrows).
- `spreadWash(w, h, o)`: a clear layer with a pale hatched wash behind a ragged front and the front inked: lay it
  over its sheet and reveal it with `put(..., { wipe })`. The demo's gust crosses the sketch map this way.
- `penLine(g, pts, o)` (a wobbling pen line), `penHatch(g, poly, o)`, `penDot`; `runeBlock(g, seed, x, y, rows,
  cols, ...)` (rows of an invented script, for writing that must not say anything) and `scribble(g, x0, x1, y)`
  (handwriting too small to read).

All of them are canvases like any other piece: `put()` them, cut them, lay photographs over them.

### Lyrics

The page loads the song's `lyrics_data.js` (`window.SONG`); `engine.js` turns `SONG.lines` into `LYR`
(`[[line start, [[t, word], ...]], ...]`). `stripAt(t)` gives the words of the current line sung so far; each is
typeset once on a paper strip (`captionStrip`, cached per text) and glued along the bottom of the frame, so a word
appears as it is sung. The intro's title card is ordinary pieces, built from `SONG.title` and `SONG.credit`.

### A real example

The second station, "Who has seen the wind?" (`shots.js`):

```js
put(plane([[0, 0], [700, 140], [250, 640]], 'red', 16), at('look', -470, -70), { t: sung(0, 0) - .05, z: -50, shadow: .3 });
put(lookerPhoto().piece, at('look', -420, 40), { t: sung(0, 0), s: 1.3 });          // "Who"
put(band(1900, 150, 'black', 31), at('look', 250, -320), { t: sung(0, 1), rot: .12 }); // "has"
put(eyeStrip(0), at('look', 300, -190), { t: sung(0, 2), rot: -.04, s: 1.25 });       // "seen"
put(heavy('WIND?', { size: 170, fg: 'white', bg: 'black' }), at('look', 300, 120), { t: sung(0, 4), rot: -.06 });
put(vaneArrow(), at('look', 740, -122), { t: beat(10) + .08, move: (t, st) => { turnMove(.5, .5, .35, 1)(t, st); swayMove(.05, .6)(t, st); } });
put(anemoCycle(), at('look', -770, 180), { t: beat(11), s: .9, frame: t => Math.floor(t * 8.5 * 10 / (Math.PI * 2 / 3)) % 10 });
CAM.push([6.9, 1530, 10, 1.06], [7.5, ST.faces[0], ST.faces[1], 1.0]);                  // travel on to the next line
```

`sung(line, word)` is when a word is sung and `beat(n)` when beat n falls; `at(station, dx, dy)` is a point near a
station.

### Determinism and caching

A frame is a pure function of the song time t: every random number is seeded, and every motion (`move`, `frame`, gusts,
haze, the pinscreen's pictures) is computed from t. So `step(t)` and `renderAt(t)` are the same function, frames can be
drawn in any order, and a slice renders exactly like the same stretch of the full video. Everything expensive is built
once at load and cached: pieces (`pc`, `once`, `prepPiece`), figure renders (by spec), caption strips (by text), tree
sprites (by bend), the pinscreen calibration (by lamps), the roller's noise and its front over the frame (by
angle). Drawn pieces are engraved once, like photographs are printed once.

## Make your own video in this style

1. Copy the folder: `cp -r styles/photomontage projects/my-song` (see [docs/your-own-video.md](../../docs/your-own-video.md)).
2. Make your song's timing: run `tools/audio/to_js.py` on it to get a `lyrics_data.js` ([docs/timing.md](../../docs/timing.md)),
   put it and the audio in your folder, and point the page's `<script src="../../examples/poem/lyrics_data.js">` at your file.
   `SONG.audio` must be the audio's path relative to the page.
3. Keep the engine files (the first table). Replace `places.js`, `scenes.js`, `memory.js` and `shots.js`, or edit them.
4. Lay out stations in `shots.js`: a point on the board per line or section (`ST`), about 1500 apart across and 1150
   down, so a neighbour's edge shows at the side of the frame and the board feels continuous. Travel the rows like a
   page.
5. For each line, `put()` pieces at `sung(line, word)` and on beats, then push camera keys: arrive at the station on the
   line start, drift a little (zoom 1.0 to 1.06), and move on in the last half second.
6. New pieces: paint a place in greys in `places.js` (light from the upper left; return anchors you'll need, such as
   where a figure stands), then print it in `scenes.js` with `printPhoto` or `objectPhoto`, or draw it with `inkWash`;
   a person is `figPhoto` or `inkFigure`. Look at it in `parts.html` before laying it on the board. Coloured paper,
   type and notes come ready-made from `pieces.js`; drawings, tracing paper and written papers from `drawn.js`.
7. Movement that isn't a piece landing: a `move` function (sway, tremble, turn, fly), a substitution cycle (an array of
   canvases and `frame(t)`), a wipe, a gust in `JOLTS`, a piece blown away with `gone(p, t, { fly })`, an ink line,
   haze, or the camera.
8. A pinscreen window: add a picture to `memories()` and a `MEM` entry; push the camera in on something and hold still
   before `t0 - .35`, and put down what should be on the board when it comes back before `t1 + .35`. With `direct`,
   the pins roll straight over the live board from `t0` and off it by `t1`, and the camera needn't stop.
9. Check with `python tools/still.py projects/my-song/index.html 0:END:2.5 --sheet` and look at every frame, then render.

Useful knobs: `PAPER_COL` (the paper colours), `boardTex` / `tileBoard` colour, `photoFinish` options (grain,
contrast, lift, tone, vignette), a piece's `shadow` and `lift`, the drop's `dur`, gust `amp` and `speed`, the pinscreen
lamps (`PIN_LAMPS` in `engine.js`) and pitch, `softPaint` blur before the pins.

## Lab

Open http://localhost:8000/styles/photomontage/lab/index.html and pick a scene and a look (or
`lab/index.html?s=hill&st=pinscreen` for one full-size). Render them all:

```
python tools/lab_stills.py styles/photomontage/lab/index.html --all --sheet
```

- **Photomontage**: `laypiece()` lays each piece once on a `boardTex()` card with pencilled guides and crop marks: the
  film's look as a single still.
- **Pinscreen**: the scene painted in greys (`paintHillside` with two walkers on the ridge; `relief()` of the terrain
  with its river and roads in light and the wind as pale streaks), softened with `softPaint()` the way a pinscreen
  artist builds tone with rollers, pinned with two lamps, and a subtitle band (`filmBand`).
- **Drafting sheet** (`lab/sheet.js`): draughting linen (`linen`), India ink at several weights (`ink`, `inkPoly`),
  hatching where ground is cut (`hatch`), template lettering (`letter`), the border, grid references, title block and
  revision table (`sheetFrame`), and three annotating hands with their own grain (`handText`, `handLine`, `handCircle`:
  pencil, crayon, pen). People are the figure model traced as an architect's scale figure (`figLines`). Everything is
  drawn at twice the frame size and scaled down (`sheetOut`). The scenes (`lab/scenes.js`) take the knoll's section
  and the map's contours from `terrain.js`, and draw trees as elevation symbols, each bent tree over its calm outline.
- **Drawing** (`drawn.js`): the hill is the same `paintHillside` painting as the pinscreen's, with its two walkers,
  engraved as one pen-and-wash drawing (`inkWash`) on drawing paper; the map is the demo's `sketchMap` at full size
  with `spreadWash` over it, the gust caught two thirds of the way across. The line is pencilled under each.

## Performance

- Build: about 3-4 s at load (the figure renders, the photographs' print finish, the engravings and the pieces'
  shadows; `engrave()` is a pass over every pixel of a drawing, a few tens of milliseconds for a figure). Memory: the
  prepared pieces are about 200 MB of canvas.
- Drawing a paste-up frame takes about 25-40 ms here (every piece in view is drawn with its shadow; the final pull-back
  over the whole board is the slowest, up to 100 ms). A pinscreen frame takes 80-100 ms here and 200-300 ms on a busy
  machine: painting the moving picture, rolling one picture into the next, shading the pins at twice the size in WebGL,
  and a grain pass in JavaScript. With `PIN_SS = 1` (what the player uses while playing) it is several times quicker.
  A direct roll adds a quarter-size mask per frame, which costs little. The MP4 tool adds the time to read each frame
  back and encode it.
- To render a slice: `--start` and `--end` on `render_mp4.py`. Because a frame depends only on t, a slice matches the
  full video exactly (`tools/splice.py` can drop it into a finished MP4).

## Lessons and gotchas

- **Mannequins.** The figure model's heads look like shop-window dummies when big and clean. Small, soft, grainy, with
  a hard print curve, strand texture in the hair and a jacket rather than a cloak, they pass as photographs. Hats, long
  hair and scarves help more than any lighting change; keep portraits small, and use the painted `crowdHead` for crowds.
- **A painting reads as a photograph** when it is painted at a lower resolution and printed with grain, halation,
  mottling and a vignette. Big flat shapes don't: foliage needs hundreds of small dabs with gaps of sky, ground needs a
  texture laid over it, and a sky needs soft clouds.
- **Standing figures** in long coats read as blocks unless the arms do something (hold a hat, shade the eyes). Pasted
  into another photograph, a figure has to be big enough to hold its own.
- **Bare papers make a thin board.** Every station wants a photograph of a place or a person, a coloured plane or disc,
  and block type, not only documents.
- **Pale ellipses on dark ground** read as lily pads or snow. Build ground from short strokes and small stones.
- **Tiled noise must wrap its lattice** (periodic value noise), or the grid of tiles shows on every textured surface.
- **Substitution cycles must draw the same random numbers at every step**, or the thing changes shape between frames:
  the trees decide which leaves exist before the wind moves them.
- **`cutOut` must restore its canvas state.** It clipped and translated the new canvas's context and left it that way,
  so anything drawn on the cut piece afterwards (a torn edge's rim) landed offset.
- **`photoFinish` must keep a figure's alpha** (its halation and grain spill into transparent pixels) and reset the
  caller's transform; it puts the mask back at the end.
- **Pin shadows saturate to black at mid-greys** unless the shadow length scales with the pin spacing and a calibration
  maps wanted darkness to push (`pinLUT`).
- **Pins as terrain heights** (a relief model) give height-as-darkness, not lit relief, because the shadows fall on the
  screen, not on the neighbouring pins. For land on the pins, pin a hill-shaded picture.
- **Vector pictures look like flat vector art on the pins.** Soften them first (`softPaint`: heavy blur plus a little of
  the original) and keep the pin spacing generous.
- **The pins double the picture if the camera is still moving** when the board freezes. End the push-in and hold before
  the pins take over.
- **A picture on the pins for less than about 0.6 s reads as a flicker.** Hold each one at least that long; every extra
  beat comes out of the next station.
- **Big white mounts looked cloudy** because the paper's dye blotches scaled with area. They are capped, and fainter on
  big sheets.
- **Web fonts can fail to load** on a slow network, and then every piece of type is silently drawn in Times.
  `fontsReady()` checks that each family actually has a loaded face and asks for the stylesheet again.
- **Two files defining the same function**: the later script silently wins. Keep names unique across files.
- **The pins are the slow part.** Most of the cost is shading at twice the size and the grain pass; for live playback,
  shade at 1x without grain.
- **A pinned copy of the board reads as a blurry duplicate** of papers the viewer has just seen, and nothing happens
  on it. Where the board and the picture don't need that link, roll the pins straight over the live board and off it
  (`direct`): the colour comes back through the roller's front.
- **Drawn figures need pale clothes.** Engraved as they are, a photograph's greys (a dark coat, dark hair) come out
  hatched solid; give the figure light greys and let the lighting decide where the hatching goes.
- **A drawing scaled up must scale its marks.** A sketch map drawn at twice the size with the same hachure spacing,
  stroke length and symbol size comes out empty; size them all from the sheet's width (`sketchMap`'s `k`).
- **A piece that blows away should be a copy on top.** Raising the original's stacking order would put it over its
  neighbours for the whole film; `gone(..., { fly })` hides the original and flies a copy above everything.
- **Ease a moving front once.** A front whose position was eased and then eased again crossed its picture in a third of
  the time; key a front by hand (times and positions) when it has to arrive on particular words.
- **Something coming at the camera** (a wall, a front) grows at an even rate on screen only if its distance is
  interpolated as 1/z, not z.
- **Black marks vanish on black paper**: question marks and arrows laid over a black band need grey or white paper.
- **The figure model can't sit.** For a seated person, cut the figure at the hips on the seat and paint the legs in
  the coat's dark.
- **Long robes on the figure model read as stiff slabs**; narrower shoulders and more folds read as cloth.
- **Camera keys written section by section can interleave** where two sections overlap in time, and the camera jumps
  away and back; sort them (the demo does) and check where one section hands over to the next.
- **A piece laid later hides what's under it**: a figure standing in front of a door hid the light through it. Look at
  each new piece against what it covers.
- **Anything a pinscreen picture leaves unpainted comes out black** (pins fully out). Paint the whole frame.
- **At a whole-board view one small change can't be seen**: push the camera in after it, or change something big.

