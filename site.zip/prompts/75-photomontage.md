# 75 · 照片拼贴蒙太奇 / Photomontage

来源类型：根据作者引擎说明整理的使用模板；并非作者原始创作提示词  
原作者：Miranda Dixon-Luinenburg  
上游原文：https://github.com/cyborggirl963/opus-5.5-music-video-art-styles/tree/main/styles/photomontage  
固定版本：801b3548c54765ecf932ce8b7f3cf4b29fb7a8bf  
抓取核对日期：2026-10-27  
本库改动：中文任务模板、中文摘要与编排；原文全文保留。

## 使用前先看

- 肖像小幅、带印刷纹理并有动作线索，过大过干净会像模特假人。
- 每站画面有照片主体、色面与文字的关系，不只堆文件；真实照片仍要独立核对许可。

- 这是代码渲染工作流；聊天文本本身不会自动产生 MP4，需有可执行的项目环境。
- 先看预览再做长片；不要把示例素材的许可自动套到自己的歌曲、照片、字体和品牌上。
- 下方复制区包含全部风格与公共规范，不要求 AI 另外从本机隐藏路径读取文件。

## 完整复制区

你是一位能写代码、检查画面并渲染成片的动画导演。请用“照片拼贴蒙太奇 / Photomontage”制作一个属于我的视频。

【我的需求；把花括号内容换成实际值】
主题与一句话故事：{{填写主题和结尾变化}}
用途与观众：{{例如面向普通观众的科普短片}}
内容依据或已有脚本：{{填写；没有则说明需要你写}}
音频、歌词、图片、数据、品牌素材路径：{{填写；没有写“无”}}
素材使用权限与需显示的署名：{{填写来源与许可；不清楚请列待确认项}}
目标时长：30 秒起步；MV 以实测歌曲时长为准
画幅与清晰度：默认横屏 16:9、1920×1080、24fps；竖屏须重新构图，不直接裁横屏
语言：简体中文；配音需求：{{有/无、声线与语速}}
必须出现的内容：{{填写}}
禁止出现的内容：{{填写}}
预算与速度：先做低成本验证，再渲染完整片
个人工程名：my-video（可改为英文短名）
确认方式：先给 3 张由真实渲染代码产出的样帧和 5–10 秒预览；我确认风格后再做完整成片

【本风格的核心实现】
以剪贴照片、撕纸、灰卡、红黑几何和斜向大字形成构成主义拼贴。
特别检查：
- 肖像小幅、带印刷纹理并有动作线索，过大过干净会像模特假人。
- 每站画面有照片主体、色面与文字的关系，不只堆文件；真实照片仍要独立核对许可。

【工程与流程】
1. 在工作区单独克隆 https://github.com/cyborggirl963/opus-5.5-music-video-art-styles ，检出 801b3548c54765ecf932ce8b7f3cf4b29fb7a8bf。将 styles/photomontage/ 复制到 projects/my-video/，保留引擎，按该风格 README 指定的文件替换示例场景。不要直接修改 styles/ 中的母版。
建立 Python 虚拟环境，阅读 requirements.txt 后安装渲染依赖；需分析音频时再安装 requirements-audio.txt。使用 Chrome 或项目支持的 Chromium。使用 python tools/serve.py 提供本地 HTTP，不用 file:// 打开渲染页面。
2. 先检查机器的 Python、Node/浏览器、FFmpeg、字体与 GPU 能力。缺少工具或访问权限时明确报告缺什么，不能只描述完成、伪造文件或把截图称为已渲染视频。
3. 把我的需求写成 PLAN.md 或 TREATMENT.md：一句话故事、分镜、逐镜秒数、镜头运动、文字位置、音乐与声音 cue、所需素材、预计成本。涉及事实和数据时写 FACTS.md；没有来源的数字不填。
4. 如果是 MV，先取得音频与实际演唱歌词，测量段落、停顿、节拍与词时间；不得沿用 37.5 秒示例诗的时间轴。未提供音乐时不要假装已经完成歌词对齐，可先制作无歌词短预览。
5. 先完成 3 张代表开头、关键变化、结尾的样帧，逐张检查；再渲染 5–10 秒低清短段，检查字幕、运动、音画同步与控制台。复杂慢风格先计时，再估算整片。
6. 随机效果固定种子；有历史累积的媒介按顺序渲染。并行前先比较随机抽帧与连续渲染是否一致。
7. 正式导出使用项目文档中的工具与参数，不臆造命令。交付可播放 MP4、720p 预览、源代码、素材清单与许可、字幕（有台词时）、复现说明；保留最终片长、帧率、音频响度与实际渲染耗时。
8. 实际打开并检查成片开头、中间、转场、结尾及全片联系表，确认没有空帧、字体回退、遮挡、裁字、爆音或无意复制的作者片尾签名。交代尚未完成的检查。

下面是完整风格参考与公共制作规范。它们是上游参考资料，不代表我的主题或逐字台词；我的具体需求优先。遇到 macOS/Linux 示例命令时按当前系统等价转换，不直接在 PowerShell 粘贴 bash 命令。相对资源路径以完整克隆的上游工程为准。


===== 完整风格原文：styles/photomontage/README.md =====

# Photomontage

A music video built like a 1920s-30s constructivist photomontage, shown as the paste-up itself rather than the printed
poster: photographs cut out with scissors or torn, glued to grey card beside planes of black and red paper, bold block
lettering on hard diagonals, pencilled guidelines and crop marks. Pieces land on the board on the words and stay, so the
board fills up as the song goes, and a camera travels over it. What makes it read as paper and photographs rather than
flat graphics: every piece is a canvas with alpha laid with a soft shadow down and to the right (the paper lifting a
little), a lit top edge and a darker lower edge; the paper has fibres and uneven dye; scissor cuts drift and nick where
two cuts meet; torn edges show a pale fibrous core. The photographs are paintings in greys given a print's surface:
painted at a lower resolution, then halation, a mottled paper texture, an S-curve with lifted blacks, grain, a vignette
and a warm or cool tone. People come from a ray-marched figure model, and every one is a different face. Some pieces
are drawn instead: the same figure model and the same paintings engraved in pen and ink (an outline, lines where the
tone turns, hatching in the shadows), sketch maps in pencil on tracing paper, a wash spreading across a map, papers in an
invented script. The lyric is typeset on a paper strip glued under the picture. For part of the song the board freezes
and turns into a **pinscreen** (Alexandre Alexeieff and Claire Parker's screen of pins, where the picture is the pins'
shadows), rendered in WebGL2, and rolls over into a moving landscape, then rolls straight off it again.

![A paste-up title card: "Who has seen the wind?" in block type on a black diagonal band, a red disc, and a cut-out photograph of a figure holding their hat in the wind](img/hero.jpg)

## Looks in this family

The lab (`lab/index.html`) draws the same two moments of the poem in four looks.

- **Photomontage** (the demo): cut photographs, paper and block type laid on grey card, a caption strip under it.
  ![The hill as a paste-up](img/look-photomontage.jpg)
- **Pinscreen**: the picture made of the shadows of pins lit from the side, velvety and soft, with a film subtitle.
  ![The hill on the pinscreen](img/look-pinscreen.jpg)
- **Drafting sheet**: the place drawn in plan, section and elevation on draughting linen, annotated in pencil, red crayon and pen.
  ![The hill as a drafting sheet](img/look-drafting.jpg)
- **Drawing**: the same painting engraved in pen and wash on drawing paper, and the country as a pencil sketch map with
  the gust hatched across it, the line pencilled underneath.
  ![The hill as a pen-and-wash drawing](img/look-drawing.jpg)

More frames from the demo: [the faces](img/faces.jpg), [the wind passing through](img/through.jpg) (a scrap blown off,
its outline left, and the gust drawn over a sketch map), [the hillside on the pins](img/pins.jpg),
[the trees bowing](img/trees.jpg), [someone passing by, drawn in ink over a photograph](img/passing.jpg).

## Run the demo

From the repository root:

```
python tools/serve.py
```

then open http://localhost:8000/styles/photomontage/index.html. It builds for a few seconds (every piece is made once
at load), then plays live with the song: Play or the space bar, and the slider to scrub. Add `#t12.5` to the URL to
show a single still at 12.5 s. In Chrome the paste-up plays at 15-24 frames a second, depending on the machine; the
pinscreen stretch (18.1-26.25 s) is heavier, so while playing the player shades the pins at half resolution, and even so
it runs at 10-20 frames a second. Render the MP4 to see it at its best. If the audio can't load, it plays on a silent
clock.

Stills and video (repository-relative paths):

```
python tools/still.py styles/photomontage/index.html 3 12.5 21 0:37.5:2.5 --sheet
python tools/render_mp4.py styles/photomontage/index.html --fast          # 720p preview
python tools/render_mp4.py styles/photomontage/index.html                 # 1080p and 720p
python tools/render_mp4.py styles/photomontage/index.html --fast --start 17 --end 27   # a slice
```

A full `--fast` render of the 37.5 s demo (900 frames) took 1 minute 16 seconds here, with other renders running on
the same machine: a few seconds to build, then 59 s for the frames, about 66 ms a frame on average including reading
each one back and encoding it. Under heavier load it has taken four times as long, mostly in the 195 or so
pinscreen frames.

`parts.html` shows the parts on their own, a sheet at a time (`parts.html?p=people`, `faces`, `heads2d`, `land`,
`things`, `papers`, `drawn`, `inkpeople`, `pins`, `pinraw`, `pinzoom`); use it while making a new piece.

## How it works

### Files, in load order

The engine (keep these):

| file | job |
|---|---|
| `core.js` | sizes (1920 x 1080), seeded random numbers (`RNG`, `hash2`), value noise (`vnoise`, `fbm`), polygon helpers (`wobble` makes a line hand-drawn), the web fonts and `fontsReady()` |
| `figure.js` | the figure model: one signed-distance person (head with face shape numbers, hair, hood, mask, hat; torso, arms with jointed hands placed by IK, a coat or cloak with folds, collar, scarf, legs), ray-marched in WebGL and read back as shade and material per pixel. `renderFigure(spec)` |
| `people.js` | who the model draws: `faceParams(k)` a different face for person k, `clothesAlb(k)` the greys of their skin, hair and clothes, `person(o)` the spec |
| `photo.js` | photographs: `photoFinish(canvas, o)` (the print surface), `photo(w, h, seed, paint, o)` (paint low, finish, scale up), `figurePhoto(spec)` (a figure in greys on film), hair extras (curls, wind-blown strands, spectacles) |
| `faces2d.js` | cheap painted ID heads for crowds: `idHead(p)`, `crowdHead(k, o)` |
| `figs.js` | people as photographs: `figGrey(o)` (unprinted, to paint into a scene), `placeFig()`, `figPhoto(o)` (printed and cut out with a sliver of background) |
| `heads.js` | figure-model heads as small ID prints: `modelHead(o)`, `idPrint(k)` |
| `terrain.js` | a stretch of hill country as a height field: `relief()` (hill shading), `contours()`, `profile()`, `mapFeatures()`, `surveySheet()` (a printed map) |
| `pasteup.js` | the paste-up's materials: `boardTex`, `scissorPoly` / `cutOut`, `tornPoly` / `tearOut`, `cutFigure`, `laypiece`, `paperPiece`, `typePiece`, `captionStrip`, `pencilGuides`, `cropMarks` |
| `pieces.js` | kinds of piece, cached by name: `sheet`, `docPrint`, `scrap`, `band`, `disc`, `plane`, `arrowPiece`, `word`, `heavy`, `noteSlip` (pencil, crayon or pen), `pinPiece` (a drawing pin), `mapIn` and `mapCut` (a piece's own pixels to the board), `ring` |
| `pinscreen.js` | the pinscreen: `pinscreen(picture, o)`, `lamp()`, the calibration `pinLUT`, `softPaint()`, the rollers `roll()`, `rollerBlend()` and `rollMask()`, `zoomPic()` (a push-in on a picture), `filmBand()` |
| `drawn.js` | drawn pieces: `engrave()` (pen work from any grey picture), `inkFigure()`, `inkWash()`, `inkHead()` and `headStrip()`, `tracing()` (tracing paper), `spreadWash()` (a wash spreading over a map), pen lines and hatching (`penLine`, `penHatch`), an invented script (`runeBlock`) and handwriting too small to read (`scribble`) |
| `engine.js` | the film: the board, `put()` and piece states, wipes, gusts and jolts, pieces taken away (`gone`, `outlineOf`, `blankOf`), haze, inks, the camera, the caption strip, the pinscreen windows, `drawFrame(t, canvas)` |

The demo (replace these with your own):

| file | job |
|---|---|
| `places.js` | painters in greys: sky, trees that bend (`paintTree`, and kept `treeSprite`s), grass that waves, the hillside, a branch and leaves, a weathervane, an anemometer, cloth on a line, a windmill |
| `scenes.js` | the demo's pieces: `printPhoto()` and `objectPhoto()` (the two ways to turn a painting into a piece), the photographs, substitution cycles, people, papers (a Beaufort card, an observation log), map scraps, the kite; drawn ones: `sketchMap()` (the country in pencil on tracing paper), `gustWash()`, `walkerDrawing()`. Also `gust(t)`, the demo's wind strength |
| `memory.js` | the moving pictures for the pinscreen window: `memories()` |
| `shots.js` | everything laid on the board against the song: stations, pieces, inks, camera keys, gusts, the pinscreen window. `buildShots()` |
| `index.html` | the page and player; builds everything, then `window.__video.step(t)` |

### The board and its pieces (`engine.js`)

The board is one big grey card in world coordinates (1 unit = 1 pixel at zoom 1). `put(c, at, o)` adds a piece and
returns it:

- `c`: a canvas (or a function returning one, or an **array** of canvases: a substitution cycle, where `o.frame(t)`
  picks which one shows, the way a cut-out animator swaps drawings).
- `at`: `[x, y]` on the board where the piece's anchor lands (its centre unless `o.ax` / `o.ay` give another point in
  the piece's own pixels, such as a tree's base or a leaf's stem).
- `o.t`: when it lands. `o.mode`: `'drop'` (falls onto the board, bigger and higher at first, then settles with a tiny
  bounce; the default), `'slide'` (from `o.from = [dx, dy]`), `'fade'` or `'none'`. `o.dur`, `o.rot`, `o.s` (scale),
  `o.z` (stacking; default: the order you add them), `o.shadow`, `o.lift`, `o.alpha`.
- `o.leave`, `o.leaveTo`, `o.leaveDur`: take it off again (lifted away, or slid off). `o.hide`: `[[t0, t1], ...]`.
- `o.move(t, st)`: change its state as time passes. `st` has `x, y, s, sx, rot, a, lift`. Ready-made ones:
  `swayMove(amp, freq, phase, env)`, `trembleMove(amp, phase, env)`, `turnMove(ang0, amp, freq)` (a weathervane turning
  about its rod: the width follows a cosine), `flyMove(t0, vx, vy, spin)`.
- `o.wipe = { t0, t1, ang, seed, amp }`: the piece appears along a ragged front running across it at angle `ang` (in the
  piece's own frame; 0 runs left to right), from t0 to t1: a wash, a frost or a flood spreading over the sheet under it.
  Give such a piece `shadow: 0`.
- `slip(piece, t, dx, dy, dr)`: knock it off its mark at t. Slipping two pieces the same way keeps them in register
  (a map and the layer drawn over it).
- `gone(piece, t, o)`: take a piece off the board at t and leave its pencilled outline where it lay (`outlineOf(canvas)`),
  or with `o.blank` a grey blank of its shape (`blankOf`), the gap a picture leaves. By default it's lifted away;
  `o.leaveTo` slides it off, and `o.fly = [vx, vy, spin]` blows it away: a copy flies off above everything for
  `o.life` seconds while the original goes. Call it while building, after the piece is put.
- `mapIn(canvas, at, rot, s)` maps a point in a piece's own pixels to the board, for laying things on a piece (a ring
  round a line of a document, leaves on a branch); `mapCut` does the same for a piece cut out of a bigger sheet, from
  the sheet's pixels (`cutOut` keeps where it cut). To lay a layer the size of a sheet exactly over it (a drawing over
  a map), put the layer at `mapCut(cut, at, rot, s)(w / 2, h / 2)` with the same `rot` and `s`.

`prepPiece()` makes each piece's lit edge and blurred shadow once, at load; `pieceState(p, t)` works out where it is at
time t; `drawBoard(t)` draws every piece and ink in z order through the camera. `JOLTS` holds hits (a number: every
piece already down shakes) and gusts (`{ t, at, dir, speed, amp }`: a push downwind that runs across the board at
`speed`, so pieces nearer `at` move first). `inkOn(points, t, o)` draws a line on the board over `o.dur` seconds (with an
arrowhead if `o.arrow`). `HAZE` entries blow mist across the whole frame.

### The camera

`CAM` is a list of keys `[t, x, y, zoom, rot, ease]`: the board point at the centre of the frame, the zoom, a rotation,
and how to get there from the key before (`'io'` by default, `'o'`, `'i'`, `'lin'`, or `'cut'` to jump). Zoom is
interpolated in log space, so push-ins feel even. The demo moves between stations in the half second before each line
starts, and drifts slowly while it's there.

### The pinscreen windows

`MEM` holds windows `{ t0, t1, prog: [[t, name, rollDur, rollAngle], ...] }`. At `t0 - .35` the board freezes and fades
into its own picture on the pins; each `prog` entry rolls in over `rollDur` seconds and is fully up at `t`; at `t1` it
rolls back to the board as it will be at `t1 + .35`, so the camera can cut somewhere new while the pins are up (the
demo cuts from the hillside photograph to the trees). Pictures come from `memories()` in `memory.js`: a grey canvas at
half the frame size (light = pins flush, dark = pins far out), or a function of t that repaints every frame, which is
how the trees on the pins keep bowing.

A window can instead roll the pins straight over the live board and off it again, with no pinned copy of the board:
`direct: true` (or `'in'` or `'out'` for one end), with `inDur`, `inAng`, `outDur`, `outAng`. The pins then start
rolling in at `t0` and are gone by `t1`, and the board under the roller's front is live, so the camera may still move.
The demo's window starts the old way (the push-in into the hill photograph turns to pins, the same hill) and ends
direct: the walkers roll off and the trees station comes back in colour through the front, its pieces landing as it
clears (`rollMask(u, ang)` is the front, the same ragged edge as `roll()`).

`zoomPic(src, z, fx, fy)` crops a picture painted once at full size to a slow push-in for the pins: key `z` to t in a
picture function for a camera move inside the pinscreen (`parts.html?p=pinzoom`).

`pinscreen(picture, o)` turns the picture into pin pushes through a calibration (`pinLUT`: how dark the screen comes out
for each push with these lamps, inverted), then a WebGL2 shader works out, for every pixel of the screen, whether a pin
upstream of each lamp shades it. Two coloured lamps from opposite sides give shadows of two colours, and pin heads catch
the light. The frame is shaded at twice its size and scaled down (`PIN_SS`), with a little grain and vignette.

### Photographs and people

- `photo(w, h, seed, paint, o)`: paint in greys at a lower resolution (`o.q`), finish it as a print (`photoFinish`),
  scale it back up with a little blur. `printPhoto()` (in `scenes.js`) adds a white border and cuts it out with scissors
  (`o.torn` tears it instead) and returns anchors you gave from the painter; `objectPhoto()` prints a thing on its own and
  cuts round its outline, leaving a sliver of the print's grey.
- People: `figPhoto({ k, pose, body, armL, armR, headYaw, ... })` renders person k, textures hair and cloth, prints it
  and cuts it out. `figGrey()` leaves it unprinted, to paint into a scene so it shares that photograph's light and grain.
  `idPrint(k)` is an ID-photo head; `crowdHead(k)` a much cheaper painted one for crowds. Every k is a different face.
- Arms are placed by where the wrist goes (`to: [x, y, z]` in head units, the head's centre at 0, 0, 0; +x is the
  figure's left, +y up, +z toward the camera), with an elbow hint (`pole`), the palm's direction and each finger's curl.

### Drawn pieces (`drawn.js`)

Among the photographs some pieces are drawn, made from the same sources. `engrave(greyCanvas, o)` turns any grey
picture with alpha into pen work, pixel by pixel: ink where the alpha ends (the outline), ink where the tone turns
sharply, hatching where it's dark (one direction past `h1`, a second past `h2`, a third past `h3`, `hatch` pixels
apart), and the tone itself kept as a light `wash` on the paper.

- `inkFigure(o)`: person k from the figure model (the same options as `figGrey`) engraved. Drawn clothes default to
  pale greys (`INK_ALB`), so only the shadow side is hatched; `o.tint = { material: [r, g, b] }` washes one material in
  a colour (the walker's red scarf is `{ 19: [168, 52, 40] }`), `o.blankFace` leaves the face a blank oval. Cut it from
  its sheet with `cutFigure(f.c, { bg: .93, sliver: 5, bgGrad: false })`, a sliver of paper round the drawing.
- `inkWash(w, h, paint, o)`: a place painted by any painter in `places.js`, engraved on a sheet of drawing paper with
  more of its tone kept as wash (the lab's drawing look is `paintHillside` this way).
- `inkHead(k, o)` and `headStrip(n, seed, o)`: heads drawn in pen (hair, a cap, long hair, a hood, a headscarf; open
  mouths; `wind` sweeps the loose ends), and a sketchbook strip of them in staggered rows for a crowd.
- `tracing(w, h, draw)`: a sheet of tracing paper, partly see-through, to draw on in pencil; `sketchMap()` in
  `scenes.js` draws the demo's country on one (contours from `terrain.js`, hachures down the steep sides, its river
  and road, the wood, feathered wind arrows).
- `spreadWash(w, h, o)`: a clear layer with a pale hatched wash behind a ragged front and the front inked: lay it
  over its sheet and reveal it with `put(..., { wipe })`. The demo's gust crosses the sketch map this way.
- `penLine(g, pts, o)` (a wobbling pen line), `penHatch(g, poly, o)`, `penDot`; `runeBlock(g, seed, x, y, rows,
  cols, ...)` (rows of an invented script, for writing that must not say anything) and `scribble(g, x0, x1, y)`
  (handwriting too small to read).

All of them are canvases like any other piece: `put()` them, cut them, lay photographs over them.

### Lyrics

The page loads the song's `lyrics_data.js` (`window.SONG`); `engine.js` turns `SONG.lines` into `LYR`
(`[[line start, [[t, word], ...]], ...]`). `stripAt(t)` gives the words of the current line sung so far; each is
typeset once on a paper strip (`captionStrip`, cached per text) and glued along the bottom of the frame, so a word
appears as it is sung. The intro's title card is ordinary pieces, built from `SONG.title` and `SONG.credit`.

### A real example

The second station, "Who has seen the wind?" (`shots.js`):

```js
put(plane([[0, 0], [700, 140], [250, 640]], 'red', 16), at('look', -470, -70), { t: sung(0, 0) - .05, z: -50, shadow: .3 });
put(lookerPhoto().piece, at('look', -420, 40), { t: sung(0, 0), s: 1.3 });          // "Who"
put(band(1900, 150, 'black', 31), at('look', 250, -320), { t: sung(0, 1), rot: .12 }); // "has"
put(eyeStrip(0), at('look', 300, -190), { t: sung(0, 2), rot: -.04, s: 1.25 });       // "seen"
put(heavy('WIND?', { size: 170, fg: 'white', bg: 'black' }), at('look', 300, 120), { t: sung(0, 4), rot: -.06 });
put(vaneArrow(), at('look', 740, -122), { t: beat(10) + .08, move: (t, st) => { turnMove(.5, .5, .35, 1)(t, st); swayMove(.05, .6)(t, st); } });
put(anemoCycle(), at('look', -770, 180), { t: beat(11), s: .9, frame: t => Math.floor(t * 8.5 * 10 / (Math.PI * 2 / 3)) % 10 });
CAM.push([6.9, 1530, 10, 1.06], [7.5, ST.faces[0], ST.faces[1], 1.0]);                  // travel on to the next line
```

`sung(line, word)` is when a word is sung and `beat(n)` when beat n falls; `at(station, dx, dy)` is a point near a
station.

### Determinism and caching

A frame is a pure function of the song time t: every random number is seeded, and every motion (`move`, `frame`, gusts,
haze, the pinscreen's pictures) is computed from t. So `step(t)` and `renderAt(t)` are the same function, frames can be
drawn in any order, and a slice renders exactly like the same stretch of the full video. Everything expensive is built
once at load and cached: pieces (`pc`, `once`, `prepPiece`), figure renders (by spec), caption strips (by text), tree
sprites (by bend), the pinscreen calibration (by lamps), the roller's noise and its front over the frame (by
angle). Drawn pieces are engraved once, like photographs are printed once.

## Make your own video in this style

1. Copy the folder: `cp -r styles/photomontage projects/my-song` (see [docs/your-own-video.md](../../docs/your-own-video.md)).
2. Make your song's timing: run `tools/audio/to_js.py` on it to get a `lyrics_data.js` ([docs/timing.md](../../docs/timing.md)),
   put it and the audio in your folder, and point the page's `<script src="../../examples/poem/lyrics_data.js">` at your file.
   `SONG.audio` must be the audio's path relative to the page.
3. Keep the engine files (the first table). Replace `places.js`, `scenes.js`, `memory.js` and `shots.js`, or edit them.
4. Lay out stations in `shots.js`: a point on the board per line or section (`ST`), about 1500 apart across and 1150
   down, so a neighbour's edge shows at the side of the frame and the board feels continuous. Travel the rows like a
   page.
5. For each line, `put()` pieces at `sung(line, word)` and on beats, then push camera keys: arrive at the station on the
   line start, drift a little (zoom 1.0 to 1.06), and move on in the last half second.
6. New pieces: paint a place in greys in `places.js` (light from the upper left; return anchors you'll need, such as
   where a figure stands), then print it in `scenes.js` with `printPhoto` or `objectPhoto`, or draw it with `inkWash`;
   a person is `figPhoto` or `inkFigure`. Look at it in `parts.html` before laying it on the board. Coloured paper,
   type and notes come ready-made from `pieces.js`; drawings, tracing paper and written papers from `drawn.js`.
7. Movement that isn't a piece landing: a `move` function (sway, tremble, turn, fly), a substitution cycle (an array of
   canvases and `frame(t)`), a wipe, a gust in `JOLTS`, a piece blown away with `gone(p, t, { fly })`, an ink line,
   haze, or the camera.
8. A pinscreen window: add a picture to `memories()` and a `MEM` entry; push the camera in on something and hold still
   before `t0 - .35`, and put down what should be on the board when it comes back before `t1 + .35`. With `direct`,
   the pins roll straight over the live board from `t0` and off it by `t1`, and the camera needn't stop.
9. Check with `python tools/still.py projects/my-song/index.html 0:END:2.5 --sheet` and look at every frame, then render.

Useful knobs: `PAPER_COL` (the paper colours), `boardTex` / `tileBoard` colour, `photoFinish` options (grain,
contrast, lift, tone, vignette), a piece's `shadow` and `lift`, the drop's `dur`, gust `amp` and `speed`, the pinscreen
lamps (`PIN_LAMPS` in `engine.js`) and pitch, `softPaint` blur before the pins.

## Lab

Open http://localhost:8000/styles/photomontage/lab/index.html and pick a scene and a look (or
`lab/index.html?s=hill&st=pinscreen` for one full-size). Render them all:

```
python tools/lab_stills.py styles/photomontage/lab/index.html --all --sheet
```

- **Photomontage**: `laypiece()` lays each piece once on a `boardTex()` card with pencilled guides and crop marks: the
  film's look as a single still.
- **Pinscreen**: the scene painted in greys (`paintHillside` with two walkers on the ridge; `relief()` of the terrain
  with its river and roads in light and the wind as pale streaks), softened with `softPaint()` the way a pinscreen
  artist builds tone with rollers, pinned with two lamps, and a subtitle band (`filmBand`).
- **Drafting sheet** (`lab/sheet.js`): draughting linen (`linen`), India ink at several weights (`ink`, `inkPoly`),
  hatching where ground is cut (`hatch`), template lettering (`letter`), the border, grid references, title block and
  revision table (`sheetFrame`), and three annotating hands with their own grain (`handText`, `handLine`, `handCircle`:
  pencil, crayon, pen). People are the figure model traced as an architect's scale figure (`figLines`). Everything is
  drawn at twice the frame size and scaled down (`sheetOut`). The scenes (`lab/scenes.js`) take the knoll's section
  and the map's contours from `terrain.js`, and draw trees as elevation symbols, each bent tree over its calm outline.
- **Drawing** (`drawn.js`): the hill is the same `paintHillside` painting as the pinscreen's, with its two walkers,
  engraved as one pen-and-wash drawing (`inkWash`) on drawing paper; the map is the demo's `sketchMap` at full size
  with `spreadWash` over it, the gust caught two thirds of the way across. The line is pencilled under each.

## Performance

- Build: about 3-4 s at load (the figure renders, the photographs' print finish, the engravings and the pieces'
  shadows; `engrave()` is a pass over every pixel of a drawing, a few tens of milliseconds for a figure). Memory: the
  prepared pieces are about 200 MB of canvas.
- Drawing a paste-up frame takes about 25-40 ms here (every piece in view is drawn with its shadow; the final pull-back
  over the whole board is the slowest, up to 100 ms). A pinscreen frame takes 80-100 ms here and 200-300 ms on a busy
  machine: painting the moving picture, rolling one picture into the next, shading the pins at twice the size in WebGL,
  and a grain pass in JavaScript. With `PIN_SS = 1` (what the player uses while playing) it is several times quicker.
  A direct roll adds a quarter-size mask per frame, which costs little. The MP4 tool adds the time to read each frame
  back and encode it.
- To render a slice: `--start` and `--end` on `render_mp4.py`. Because a frame depends only on t, a slice matches the
  full video exactly (`tools/splice.py` can drop it into a finished MP4).

## Lessons and gotchas

- **Mannequins.** The figure model's heads look like shop-window dummies when big and clean. Small, soft, grainy, with
  a hard print curve, strand texture in the hair and a jacket rather than a cloak, they pass as photographs. Hats, long
  hair and scarves help more than any lighting change; keep portraits small, and use the painted `crowdHead` for crowds.
- **A painting reads as a photograph** when it is painted at a lower resolution and printed with grain, halation,
  mottling and a vignette. Big flat shapes don't: foliage needs hundreds of small dabs with gaps of sky, ground needs a
  texture laid over it, and a sky needs soft clouds.
- **Standing figures** in long coats read as blocks unless the arms do something (hold a hat, shade the eyes). Pasted
  into another photograph, a figure has to be big enough to hold its own.
- **Bare papers make a thin board.** Every station wants a photograph of a place or a person, a coloured plane or disc,
  and block type, not only documents.
- **Pale ellipses on dark ground** read as lily pads or snow. Build ground from short strokes and small stones.
- **Tiled noise must wrap its lattice** (periodic value noise), or the grid of tiles shows on every textured surface.
- **Substitution cycles must draw the same random numbers at every step**, or the thing changes shape between frames:
  the trees decide which leaves exist before the wind moves them.
- **`cutOut` must restore its canvas state.** It clipped and translated the new canvas's context and left it that way,
  so anything drawn on the cut piece afterwards (a torn edge's rim) landed offset.
- **`photoFinish` must keep a figure's alpha** (its halation and grain spill into transparent pixels) and reset the
  caller's transform; it puts the mask back at the end.
- **Pin shadows saturate to black at mid-greys** unless the shadow length scales with the pin spacing and a calibration
  maps wanted darkness to push (`pinLUT`).
- **Pins as terrain heights** (a relief model) give height-as-darkness, not lit relief, because the shadows fall on the
  screen, not on the neighbouring pins. For land on the pins, pin a hill-shaded picture.
- **Vector pictures look like flat vector art on the pins.** Soften them first (`softPaint`: heavy blur plus a little of
  the original) and keep the pin spacing generous.
- **The pins double the picture if the camera is still moving** when the board freezes. End the push-in and hold before
  the pins take over.
- **A picture on the pins for less than about 0.6 s reads as a flicker.** Hold each one at least that long; every extra
  beat comes out of the next station.
- **Big white mounts looked cloudy** because the paper's dye blotches scaled with area. They are capped, and fainter on
  big sheets.
- **Web fonts can fail to load** on a slow network, and then every piece of type is silently drawn in Times.
  `fontsReady()` checks that each family actually has a loaded face and asks for the stylesheet again.
- **Two files defining the same function**: the later script silently wins. Keep names unique across files.
- **The pins are the slow part.** Most of the cost is shading at twice the size and the grain pass; for live playback,
  shade at 1x without grain.
- **A pinned copy of the board reads as a blurry duplicate** of papers the viewer has just seen, and nothing happens
  on it. Where the board and the picture don't need that link, roll the pins straight over the live board and off it
  (`direct`): the colour comes back through the roller's front.
- **Drawn figures need pale clothes.** Engraved as they are, a photograph's greys (a dark coat, dark hair) come out
  hatched solid; give the figure light greys and let the lighting decide where the hatching goes.
- **A drawing scaled up must scale its marks.** A sketch map drawn at twice the size with the same hachure spacing,
  stroke length and symbol size comes out empty; size them all from the sheet's width (`sketchMap`'s `k`).
- **A piece that blows away should be a copy on top.** Raising the original's stacking order would put it over its
  neighbours for the whole film; `gone(..., { fly })` hides the original and flies a copy above everything.
- **Ease a moving front once.** A front whose position was eased and then eased again crossed its picture in a third of
  the time; key a front by hand (times and positions) when it has to arrive on particular words.
- **Something coming at the camera** (a wall, a front) grows at an even rate on screen only if its distance is
  interpolated as 1/z, not z.
- **Black marks vanish on black paper**: question marks and arrows laid over a black band need grey or white paper.
- **The figure model can't sit.** For a seated person, cut the figure at the hips on the seat and paint the legs in
  the coat's dark.
- **Long robes on the figure model read as stiff slabs**; narrower shoulders and more folds read as cloth.
- **Camera keys written section by section can interleave** where two sections overlap in time, and the camera jumps
  away and back; sort them (the demo does) and check where one section hands over to the next.
- **A piece laid later hides what's under it**: a figure standing in front of a door hid the light through it. Look at
  each new piece against what it covers.
- **Anything a pinscreen picture leaves unpainted comes out black** (pins fully out). Paint the whole frame.
- **At a whole-board view one small change can't be seen**: push the camera in after it, or change something big.



===== 完整公共规范：CLAUDE.md =====

# Instructions for Claude

This repository makes music videos in code: each style in `styles/` is an engine that draws every frame on an HTML
canvas (or WebGL / three.js) in a hand-made-looking medium, timed to a song, and `tools/` renders them to MP4. Read
`README.md` for the map, then the doc for whatever you're doing.

## When someone wants a video for their song

Follow [docs/workflow.md](docs/workflow.md). It's a conversation, not a build order to rush through:

1. **Get the inputs:** the song (mp3), the lyric sheet as sung, and ask whether they have stems and MIDI (Suno and
   stem splitters provide them) and any reference images.
2. **Ask the concept questions before building anything:** who is singing, who "you" is, whose voice the chorus is,
   what the key images (especially the ending) mean, how much the video may show, what stays out. Don't guess at
   these; an open question is better than a confident wrong answer. If the song belongs to a larger world, read
   whatever they give you about it, and keep a list of every detail the video invents, flagged as unconfirmed.
3. **Measure the song** ([docs/timing.md](docs/timing.md)): tempo, sections, stops and hits, and every word's time.
   Time to the audio, not to the lyric sheet's markings.
4. **Pitch three looks and recommend one:** the medium and why it suits this song, the organizing object, a small
   visual grammar and an arc, a section-by-section plan keyed to timestamps, and the open questions. The styles in
   `styles/` are the starting points (each README says what it's good at); a new medium is fine too
   ([docs/engine-patterns.md](docs/engine-patterns.md)).
5. **Style lab:** the same three or four moments drawn in each candidate look. Show the stills.
6. **Checkpoint:** build one section (20-90 s), render it (`--fast`), send it, get notes.
7. **Build the rest** section by section, then render the final MP4s. The MP4 is what gets shared.

Build a project in `projects/<song-slug>/`, copied from a style folder ([docs/your-own-video.md](docs/your-own-video.md)).
Don't change `styles/` for one person's video. Keep notes in `projects/<song-slug>/PLAN.md` as you go: their answers
and rulings, the measured sections and sync points, the shot list, the invented details, and their feedback on each
round. A later session should be able to pick up from that file alone.

## Working practices

- **Look at what you render.** Make stills and contact sheets (`tools/still.py ... --sheet`) and open the images.
  Check every frame on the sheet: edges, blank frames, the camera inside things, covered text, long freezes.
- **Read the console output** the tools print. A single bad canvas gradient value blanks a frame.
- **Preview slices with `--fast`**; render the full 1080p only at the end. Styles that carry state between frames
  must be rendered in order (the tools do this).
- **Keep it deterministic:** seeded randomness keyed to the frame, never `Math.random()` per frame.
- **Follow the page contract** in [docs/rendering.md](docs/rendering.md) (`window.__video`, `window.SONG`,
  `<canvas id="film">`, `#t<seconds>` stills) so the tools work.
- Apply the lessons in [docs/workflow.md](docs/workflow.md#what-the-notes-taught-true-for-every-style): busy
  enough, no long freezes, obvious changes, varied choruses, whole figures rather than close-up hands.
- The person's audio is git-ignored. If their lyrics or story are private, keep the project out of any public
  remote (add it to `.git/info/exclude`, or keep it outside the repo and pass `--root` to the tools).

## Setup

```bash
python3 -m venv .venv && .venv/bin/pip install -r requirements.txt -r requirements-audio.txt
```

Google Chrome must be installed (or `.venv/bin/python -m playwright install chromium`). To preview in the desktop
app's browser pane, create `.claude/launch.json` running `python3 tools/serve.py 8000` on port 8000 (git-ignored).
Use the server, never `file://`: module pages don't load from files and a plain server caches stale scripts.



===== 完整公共规范：docs/workflow.md =====

# How a video gets made

These videos were made in conversation: a person with a song and a clear sense of what it's about, and Claude
writing and rendering the code. The process below is what worked over a dozen songs. It suits working with Claude
Code (see [CLAUDE.md](../CLAUDE.md), which tells Claude to follow it), and it works just as well by hand.

The short version: **decide what the song is about, measure it, pitch three looks, test the look on a few scenes,
build one section, get notes, then build the rest.** Each step is cheap next to the one after it, so mistakes get
caught while they're still cheap.

## 1. Gather the inputs

- **The song** as an mp3 (or anything ffmpeg reads).
- **The lyric sheet** as plain text, one sung line per line, with `#section` markers (see
  [examples/poem/lyrics.txt](../examples/poem/lyrics.txt)). Write it the way it's sung: if the singer repeats a line
  that isn't on the sheet, add it.
- **Stems, if you have them.** An isolated vocal stem makes transcription far cleaner. Suno exports stems as audio
  and as MIDI per instrument; the MIDI's tempo map gives an exact beat grid, and the vocal MIDI gives note onsets to
  snap words to (see [timing.md](timing.md)).
- **Reference images, if any.** Mood boards and concept art are useful for content (what's in the world, what
  people wear, what the place looks like) even when the style will be different.

## 2. Decide what the song is about

Before any pictures, answer the questions that decide the concept. A video can't be good if these are guesses.

- **Who is singing,** and to whom? Who is "you"? It's often not who it seems, and it can change between verses.
- **Whose voice is the chorus?** The singer's, an imagined audience's, a crowd's, a custom's?
- **What do the key images mean?** Especially the closing one.
- **How much may the video show?** If the song belongs to a larger story, what would be a spoiler?
- **What stays out?** Eras, events, people, kinds of imagery.

If the song is part of a larger world (a novel, a game, a band's mythology), read up on it first, and **keep a list
of every detail the video invents**: a place's layout, what a prop says, who stands where. Show that list to
whoever owns the world, and treat nothing on it as settled until they say so.

## 3. Measure the song

Time the video to what the audio does, not to what the lyric sheet says. (AI song generators in particular ignore
markings like "quiet" or "almost unaccompanied".) With the tools in [timing.md](timing.md):

- tempo, and whether it changes;
- the sections and their loudness: which chorus is the big one, where it drops to almost nothing;
- **the stops and hits.** Musical stops, dropouts and the hit that ends a bridge make the best sync points: the
  place to freeze, cut, switch a light off, or change the whole picture;
- every word's time.

## 4. Pitch three looks

Offer three directions and recommend one. For each:

- **the medium** (paper cut, embroidery, marbled paper...) and why it suits this song. The strongest choices mean
  something: marbled paint for a song about water, where nothing stays put; a lantern lecture for a song sung by
  someone lecturing; a desk of files and stamps for a song about a record that doesn't add up;
- **the organizing object:** the one thing the whole video is, such as a desk under a lamp, a hanging read along
  its length, a printed sheet, a painted wagon's panels, a board of pasted-up photographs;
- **a small visual grammar:** a few rules that give the images meaning (stamps are the audience's verdicts, frost
  is the stillness, the camera's date flickers between years), and an **arc** over the song (clean to decayed,
  night to morning, empty to crowded);
- a **section-by-section plan** keyed to timestamps, giving each section one main image;
- the questions still open.

The [styles/](../styles) folder has eighteen engines to start from, and each one's README says what it's good at.
A new song can also want a new medium: the engines share their patterns ([engine-patterns.md](engine-patterns.md)),
so a new one is less work than it sounds.

## 5. Style lab

Draw the same three or four key moments in each candidate look, side by side, as stills (and a few seconds of motion
if the look depends on how it moves). Comparing like with like makes the choice easy, and it shows the problems
early: people who look like mannequins, faces that look ill, a palette that turns cute. Every family here with more
than one look has a lab page (`styles/<family>/lab/`) built this way.

Expect the first choice to be refined: "this look, but with the other one's colours", or "this, for the scenes in the
other world only". Mixing is fine.

## 6. Checkpoint

Build a real section before the whole song: 20-30 seconds of the section that carries the concept, or the first
90 seconds. Render it as an MP4 and get notes on the look, the pace, the figures, the text. This is where most of
the useful notes arrive, and they're cheap to act on now.

## 7. Build the whole song

Section by section. After each, render stills across it (`tools/still.py ... a:b:2 --sheet`) and look at every one:
frame edges, blank frames, things the camera cuts through, text that's unreadable or covered. Fix, then move on.
When it's all there, render the MP4, then scan it at one frame every two seconds.

## 8. Notes, and fixing a stretch

Notes on a full video are usually local: one stretch feels empty, one chorus repeats the last, a transition jerks.
Re-render only that slice and splice it in ([rendering.md](rendering.md#fixing-one-stretch)).

## 9. Deliver an MP4

Share the MP4, not the web page. A browser player's pause and scrub can feel unreliable, and people give up on it.
`tools/render_mp4.py` writes a 1080p file and a smaller 720p one for sending.

## 10. Revising a finished video

A second or third pass (new conventions, a list of fixes, a stretch that needs more going on) works best as: a short
written plan of every change; then before/after sheets, stills from the old render and the new build at the same song
times side by side; then the full render. The sheets let the notes land on exactly what changed. When picking stills
for review, catch short effects at their peak: a flash or a bolt that lasts half a second is easy to miss.

## What the notes taught (true for every style)

- **Busy enough.** Something new on nearly every beat, or at least every line. A stretch with nothing happening
  reads as a mistake, not a rest. When a stretch feels empty, fill it with callbacks (translucent overlays of earlier
  scenes) and background life (children, animals, people passing) rather than restaging it.
- **No long freezes.** A four-second still reads as the player stalling. Keep holds to a beat or two, or keep
  something drifting: a slow camera move, breathing light, smoke.
- **Make small changes obvious.** A face swapping for another face, a detail changing on a paper: if it matters,
  make it big and push the camera in on it. Subtle changes go unseen.
- **Too clean reads as dead.** A video that stays tidy all the way through can feel flat; give it an arc.
- **Vary the repeats.** The second chorus shouldn't replay the first. New scenes, with brief flashes back to the
  first chorus's pictures on key words, keep the echo without the repetition. A motif that does something different
  each chorus (ribbons that knot, then plait, then slip) works well.
- **Whole figures beat close-up hands.** Big silhouettes of hands and arms read as clubs, poles or chess pieces. A
  whole figure, even small and mostly still, carries a beat better.
- **Faces:** realistic halftone or heavy shading can make people look ill. Stylized faces (dot eyes, lowered lids
  when looking down) for close figures and blank faces for crowds read better.
- **What makes a look cute** (sometimes wanted, often not): flat candy fills, rounded sack-shaped figures with blob
  heads, even lighting, bobbing walks. For solemn songs, use weight, texture, uneven light and stillness instead.
- **Real texts make good props.** A period document, a real letter or hymn, an actual map give a scene weight even if nobody
  can read them.
- **Impossible places need ordinary things in them.** Floating or folded land only reads as land when it carries
  trees, lit windows, snow on its ground side, smoke going the "wrong" way.
- **Decide about text in the picture.** A lyric band under the picture is one choice; no readable text at all
  (squiggles for writing) is another; either way, be consistent. Captions that only repeat the lyric are redundant.
- **Fake text is worse than no text.** A card of invented glyphs that flickers reads as a screen of foreign writing.
  Use pictograms, squiggles, or nothing. Likewise on-screen read-outs (temperatures, timecodes) in a "technical"
  medium: keep them only if they mean something.
- **Show the medium working.** When a look risks feeling static (a photograph, a print, a drawing), let the viewer
  watch it being made: a plate exposing, inks printing in on the beats, stitches sewn in, a slide pushed into the
  lantern. It answers "static and unclear" without changing the look.
- **Vary what leads a scene.** In a medium with a life of its own (liquid light, marbling, sand), let some scenes be
  led by the pictures and some by the medium, rather than the same mix throughout.
- **Props must sit in hands.** A rope, a ring, a cloth or a cup that floats near a hand reads as broken. Anchor held
  things to the rig's hand points and check every one in stills.
- **Arms that move naturally:** pose them by where the hand and elbow should be, blend joint angles rather than
  positions, let the forearm trail the upper arm, and add breathing and small weight shifts. Arms that slide
  straight between poses look like a puppet's.
- **Bodies carry identity.** In silhouette, heat or other outline-first looks the outline is all a viewer gets: if
  someone is heavily built, or small and round, the shape must show it. Keep sizes consistent (an animal is as big in
  every shot).
- **Shapes read as other shapes.** A figure lying flat reads as a collapsed body (have them sit or doze upright unless
  a death is meant); a pyramid of sacks in a lit doorway reads as a hooded head; a fan of hair strands reads as a
  feathered headdress. Look at every silhouette as a stranger would.



===== 完整公共规范：docs/timing.md =====

# Timing a song

Everything in a video hangs off the song's clock: the lyric band lights each word as it's sung, pieces land on
beats, scenes change on line starts, the lamp goes out in a dropout. This page is how to get those times. The tools
are in [tools/audio/](../tools/audio); each prints its own help with `--help`.

Setup (once): `pip install -r requirements-audio.txt` (librosa, scipy, faster-whisper, mido). The Whisper model
downloads the first time it's used.

## The pipeline

```bash
# 1. the shape of the song: tempo, loudness, sections
python tools/audio/analyze.py song.mp3

# 2. words with timestamps, from the vocal stem if you have one
python tools/audio/transcribe.py vocals.mp3 --lyrics lyrics.txt --out whisper.json

# 3. your lyric sheet matched to Whisper's words
python tools/audio/align.py lyrics.txt whisper.json --out lines.json

# 4. snap each word to where the voice starts it (vocal MIDI and/or vocal audio)
python tools/audio/snap.py lines.json --midi vocals.mid --audio vocals.mp3 --out snapped.json

# 5. the page's data file
python tools/audio/to_js.py snapped.json --out projects/my-song/lyrics_data.js --title "My Song" \
    --audio song.mp3 --audio-file projects/my-song/song.mp3 --bpm 96 --beats-per-bar 4
```

Then open the video with the lyrics showing and listen through. Fix what's off by editing `lyrics_data.js`
directly: it's plain data.

## Step by step

### 1. The shape of the song

`analyze.py` prints the global tempo and the local tempo every 20 s, a table of loudness, brightness and rhythmic
busyness every few seconds, and guesses at section boundaries. Read it next to the lyric sheet. You're looking for:

- which sections are loud and which drop out: the video's big and quiet moments should follow them;
- tempo changes (a slow intro, a half-time bridge);
- **stops and hits.** `onsets.py song.mp3 --from 140 --to 155` zooms in on a stretch: the strongest onsets, the
  beats, and the loudness every quarter second, so a dropout shows as a run of low numbers. These are the best
  sync points a song offers: the place for everything to freeze, for a cut, for a light to go off.

`sections.py song.mp3 --lines lines.json` compares the sections' loudness, drums and tonal energy once you know
where they are.

### 2. Transcribe

`transcribe.py` runs faster-whisper with word timestamps. Give it the **vocal stem** if there is one; sung vocals
over a full mix transcribe much worse. The `small` model is usually enough and takes about a minute. `--lyrics`
passes the start of your lyric sheet as a prompt, so names and odd words come out spelled your way. `medium` can
rescue mumbled lines, but over a long song it can drift further than `small`.

Expect Whisper's times to run **early**, typically a few tenths of a second and sometimes by more than a second,
and to hear some words wrong, especially names and unusual words. Step 3 doesn't care about wrong words; steps 4 and
the listen-through fix the times.

### 3. Align

`align.py` lines your sheet up against Whisper's words (a sequence match, so misheard or missing words don't break
it; unmatched words get times interpolated from their neighbours). It prints each line with a match count like
`m7/9`. Low counts are where to listen first. Watch for:

- **numbers:** Whisper writes "1974" as one token for three sung words. The script spells out years and small
  numbers before matching, but check them;
- **hyphenated words** and contractions;
- **a misheard last line** ("Let it go" for "Letting go"): the end of a song, over a fade, is where Whisper guesses;
- **repeats and ad-libs** the singer added: put them on the sheet as sung, or they'll be squeezed between
  neighbours.

### 4. Snap to the voice

`snap.py` moves each word to the nearest sung-note onset within 0.32 s: note onsets from the **vocal MIDI** first
(if you have it), then onsets detected in the **vocal audio**. It first reports the median offset between the words
and the onsets; if Whisper ran early across the whole song, pass that back as `--shift` so everything moves before
snapping.

After snapping, some things still need a human ear:

- **line starts that land in silence** or on the tail of the previous word: move them to where the voice comes in;
- **choruses and held notes:** a melisma or a long held word confuses onsets;
- **MIDI quantization:** Suno's MIDI is quantized to sixteenth notes and can sit about 0.3 s off the voice.

For those, `onsets.py vocals.mp3 --from 25 --to 27 --pitch` prints the sung pitch and loudness every 50 ms: the
word starts where the pitch appears and the loudness jumps.

### 5. Write the page data

`to_js.py` writes `lyrics_data.js`, which sets `window.SONG`:

```js
window.SONG = {
  title: "My Song", credit: "", audio: "song.mp3", duration: 212.4,
  bpm: 96, beatsPerBar: 4, firstBeat: 0.35,
  sections: [["verse1", 12.3, 41.0], ...],
  beats: [0.35, 0.975, ...],            // only with --beats: exact beat times
  lines: [{section: "verse1", text: "Who has seen the wind?", t0: 12.3, t1: 14.9,
           words: [["Who", 12.3], ["has", 12.9], ...]}, ...],
};
SONG.beat(n)  // the time of beat n
```

Every style in this repo reads that shape (see [examples/poem/lyrics_data.js](../examples/poem/lyrics_data.js)).

## Beats

For a steady song, `--bpm` and `--first-beat` (the time of the first downbeat) are enough: `SONG.beat(n)` is
`firstBeat + n * 60 / bpm`. Find the first beat with `onsets.py` on the song's opening seconds.

If the tempo drifts or changes, use exact beat times instead:

- **from MIDI stems:** Suno writes a tempo event on every beat, so the tempo map is an exact beat grid.
  `midi.py drums.mid --beats-out beats.json` (any of the song's MIDI files will do);
- **from the audio:** `analyze.py song.mp3 --beats-out beats.json` (librosa's estimate; check it).

Pass the file to `to_js.py --beats beats.json`; `SONG.beat(n)` then reads from the list.

## Hits and loudness

Some styles pulse, flash or move with the music itself rather than the words: a lamp that breathes with the mix, a
ring on every drum hit, mouths that open with the voice. `pulses.py` measures those:

```bash
python tools/audio/pulses.py song.mp3 --percussion perc.mp3 --drums drums.mp3 --vocals vocals.mp3 --out projects/my-song/audio_data.js
```

It writes `window.AUDIO = {fps, ticks, kicks, env, venv, vdb}`: small hits (`ticks`) and big ones (`kicks`) as
`[time, strength]`, the mix's and the voice's loudness 24 times a second (`env`, `venv`, 0..1), and the voice's
loudness in decibels mapped to 0..1 (`vdb`, better for mouths). Stems give much cleaner hits than the mix; without
them everything comes from the mix. The liquid light show reads this file as it is; any style can read the arrays.

## Suno specifics

- The stem download gives an audio file and a MIDI file per instrument. The lead vocal stem transcribes cleanly.
- The MIDI files carry a key-signature event that the `mido` library can't decode (it raises
  `KeySignatureError`). `tools/audio/midi.py` patches mido to read it as C; import `load()` from it in your own
  scripts to get the fix.
- The MIDI tempo map has one event per beat: an exact beat grid, including tempo changes after an intro.
- Vocal MIDI notes are quantized and can sit up to ~0.3 s off the voice: good anchors for snapping, not ground truth.
- Suno ignores dynamics on the lyric sheet ("quiet", "spoken", "almost unaccompanied"). Measure.

## Checking by eye and ear

Open the page, play it with the sound on, and watch the lyric band. Words that light up early are the common
fault. For a close look, `#t25.3` on the page's URL shows the frame at 25.3 s with the band as it is then.



===== 完整公共规范：docs/rendering.md =====

# Previewing and rendering

Every video here is a web page that draws its frames on a canvas. You watch it in a browser while you work, and
when it's done a script steps through it frame by frame in headless Chrome and pipes the frames to ffmpeg. This
page covers the page contract the tools rely on, previewing, stills, MP4s, and fixing a stretch.

Setup (once): `pip install -r requirements.txt` (Playwright, imageio-ffmpeg, Pillow, numpy). The tools drive your
installed Google Chrome; if you don't have it, `python -m playwright install chromium` gets Playwright's own.
imageio-ffmpeg bundles an ffmpeg with x264 and AAC, so there's nothing else to install.

## The page contract

A video page (a style's `index.html`, or a copy of one for your song):

- draws into `<canvas id="film" width="1920" height="1080">`;
- loads its song data as `window.SONG` (see [timing.md](timing.md#5-write-the-page-data)) and plays `SONG.audio`
  in an `<audio>` element, falling back to a silent clock if the audio can't load;
- sets `window.__video`:
  - `ready`: true once everything is built;
  - `duration`: the song's length in seconds;
  - `step(t)`: draw song time `t` the way playback does. The MP4 renderer calls it at 24 fps, strictly in order;
  - `renderAt(t)`: draw a still of time `t` from a fresh state (catching up whatever the frames before it built);
  - either may return a Promise (a page that builds scenes asynchronously); the tools wait for it;
  - `error`: set this to the error text if building fails, and the tools stop and print it;
  - optionally `shots` and `probe(t)` for 3D pages (see `tools/probe.py`);
- shows a still when the URL ends in `#t<seconds>` (e.g. `index.html#t12.5`), with the page chrome hidden;
- draws only while playing: a paused player shouldn't keep redrawing its frame on every animation frame (the tools
  draw and read back each frame in one call, but a page that redraws on its own fights anything else that draws);
- is **deterministic**: all randomness comes from seeded generators keyed to the frame number, never
  `Math.random()` per frame, so a given moment always draws the same picture. An MP4 depends on it.

A style-lab page sets `window.__lab = { ready, scenes, styles, render(scene, style) }`, where `render` draws one
scene in one look and returns the canvas.

## Previewing

```bash
python tools/serve.py            # serves the repository at http://localhost:8000/ and lists the demo pages
```

Open a page from the list. Use this server rather than `python -m http.server` or opening the file directly:

- pages that use ES modules or load files **don't work from `file://`**;
- a plain server lets the browser **cache scripts**, so after an edit you can be looking at the old code. This
  server sends no-cache headers;
- audio and video only seek when the server answers **Range requests**; this one does.

**Stills in the browser:** add `#t<seconds>` to the URL. Changing only the `#` part doesn't reload the page, so
after editing code, reload with a new query (`index.html?r=2#t30`).

**Always check the console** after a load. One bad value in a canvas gradient (a NaN colour stop) throws, and the
whole frame goes blank.

**In Claude Code's desktop app**, the preview pane can run the server for you: create `.claude/launch.json` with
```json
{ "version": "0.0.1", "configurations": [
  { "name": "videos", "runtimeExecutable": "python3", "runtimeArgs": ["tools/serve.py", "8000"], "port": 8000 } ] }
```
(it's git-ignored).

## Stills and contact sheets

```bash
python tools/still.py styles/paper-cut/index.html 5 12.5 30          # three stills
python tools/still.py styles/paper-cut/index.html 0:37.5:2.5 --sheet # a frame every 2.5 s, tiled into one image
python tools/lab_stills.py styles/embroidery/lab/index.html --all --sheet
```

Output goes to `renders/` (git-ignored). The contact sheet is the fastest way to review a whole video: look at every
frame on it, not just the ones you changed. Things to look for: frame edges showing the end of the world, blank or
black frames, the camera inside an object, text covered or cut off, two scenes' seams, something frozen too long.

## MP4s

```bash
python tools/render_mp4.py styles/marbling/index.html                    # renders/marbling.mp4 and -720p.mp4
python tools/render_mp4.py projects/my-song/index.html --out "renders/My Song.mp4"
python tools/render_mp4.py projects/my-song/index.html --start 60 --end 90 --fast   # quick preview of a slice
```

- Two files: 1080p (x264 `slow`, CRF 23, AAC 192k: roughly 5 Mbps for a busy picture) and `-720p` (CRF 25: about
  1 Mbps, small enough to send).
- `--fast` writes only the 720p with the `veryfast` preset. Busy, grainy frames can take many times longer to
  encode with the slow preset than to draw, so use `--fast` for previews and the normal mode for the final.
- The audio comes from `SONG.audio` unless you pass `--audio`. A slice gets short audio fades.
- **Fonts:** the styles load their type from Google Fonts. If a font request fails (a flaky network), canvas text
  silently falls back to a default font, so `render_mp4.py` and `render_frames.py` check the page's fonts after it
  builds and stop if any failed. Run again, or pass `--allow-font-fallback` if you really mean it. The still tools
  print a warning instead.
- 24 fps. Frames are rendered **in order**: many styles draw each frame over the one before (frost that grows,
  ghosting, marbled paint that keeps its history), so a frame can't be drawn on its own.
- Speed depends on the style and on how much the machine is doing: from about 40 ms a frame (paper cut, painted
  enamel, archive desk) to 250 ms or more (sand, the pinscreen, screenprint's printing), including reading the frame
  back and encoding. Each style's README gives its numbers. A four-minute song is 5,760 frames: a few minutes for the
  fast styles, half an hour or more for the slow ones (see the next section for splitting a render across browsers).

## Long renders: frames on disk, resumable, in parallel

For a long song in a slow style, render the frames to a folder instead of straight into ffmpeg:

```bash
python tools/render_frames.py projects/my-song/index.html --dir renders/frames/my-song --jobs 3
python tools/encode.py renders/frames/my-song --out "renders/My Song.mp4"
```

- Frame `i` is `<dir>/<i:05d>.jpg` and shows song time `(i + 0.5) / 24`. Frames already on disk are skipped, so an
  interrupted render continues where it stopped when you run the same command again, and deleting a stretch's
  frames and re-running redoes just that stretch.
- `--jobs N` renders N runs of frames in N browsers at once. Each run starts with `renderAt()` at its first frame,
  which catches up styles whose frames depend on earlier ones, then steps in order. (Tested: a resumed run's frames
  match a straight-through render pixel for pixel.) GPU-heavy styles gain less, since the browsers share one GPU.
- `encode.py` takes the audio from the folder's `meta.json` (the page's `SONG.audio`), cuts it to the frames on
  disk, and writes the same 1080p and 720p files as `render_mp4.py`.
- **A render that sits before its first frame** is usually the machine, not the page: with other renders or heavy
  WebGL pages running, Chrome can take minutes to start or to build a page. `render_mp4.py` prints the page's URL when
  it's loaded and a progress line every 240 frames.
- **Heavy 3D pages:** building every set of a long WebGL video at once can hang the GPU. Render such a video in
  segments (`--start`/`--end` runs into the same frame folder, each run building only what its stretch needs), and
  on a machine that other renders are sharing, run one segment at a time.

## Fixing one stretch

A full render can take a while. To fix one stretch, render only that slice at full quality and splice it into the
finished file at whole frames:

```bash
python tools/render_mp4.py projects/my-song/index.html --start 120 --end 135 --out renders/fix.mp4
python tools/splice.py "renders/My Song.mp4" renders/fix.mp4 --at 120 --out "renders/My Song v2.mp4"
```

A slice opens with `renderAt(t)`, which catches up styles whose frames build on earlier ones, so its frames match the
full render's and the splice is seamless.

## Checking a 3D video's framing

`python tools/probe.py styles/diorama/index.html` asks the page, for the start, middle and end of every shot,
whether anything stands between the camera and its subject, or whether the camera is inside something. In a crowded
set it finds blocked views much faster than contact sheets.

## Sharing

Share the MP4. If you also want a review page (the video with notes around it), keep in mind that some hosts cap
file sizes: split a long 720p video into parts at scene changes and play them in sequence against the song, and
serve it from something that answers Range requests.



===== 完整公共规范：docs/your-own-video.md =====

# Making a video for your own song

The hands-on steps, from an mp3 to an MP4. For the creative side (what to decide before building, how to pick a
look) see [workflow.md](workflow.md). If you're working with Claude Code, you can just ask it to make a video for
your song: [CLAUDE.md](../CLAUDE.md) walks it through all of this.

## 1. Set up

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt            # rendering
pip install -r requirements-audio.txt      # timing a song (Whisper, librosa, MIDI)
```

You need Google Chrome installed (or run `python -m playwright install chromium`).

## 2. Start a project folder from a style

Pick a style from the [gallery](../README.md#the-styles) and copy its folder:

```bash
cp -r styles/paper-cut projects/my-song
cp ~/Music/my-song.mp3 projects/my-song/song.mp3
```

Audio files are git-ignored, so your song stays out of the repository.

In `projects/my-song/index.html`, change the lyrics script from the demo's
```html
<script src="../../examples/poem/lyrics_data.js"></script>
```
to your own
```html
<script src="lyrics_data.js"></script>
```
(Relative paths from `projects/my-song/` resolve just as they did from `styles/<style>/`, so anything else the
page loads from the repo keeps working.)

## 3. Time the lyrics

Write the lyric sheet (`projects/my-song/lyrics.txt`, one sung line per line, `#section` markers), then run the
pipeline in [timing.md](timing.md). It ends with `projects/my-song/lyrics_data.js`.

## 4. Look at it

```bash
python tools/serve.py
```

Open `http://localhost:8000/projects/my-song/index.html`. The demo's scenes now play under your lyrics for as long as
the demo lasts. That's the moment to decide the plan: which scene goes where, which line lands on which image.

## 5. Replace the demo's scenes with yours

Every style's README has a "Make your own video in this style" section that says which files are the demo (its
scenes, sets, shots or timeline) and which are the engine. Keep the engine; rewrite the demo files. Work a section
at a time:

```bash
python tools/still.py projects/my-song/index.html 30:60:2 --sheet   # stills every 2 s across 0:30-1:00
```

Look at every still on the sheet. Check the console output printed at the end.

## 6. Render

```bash
python tools/render_mp4.py projects/my-song/index.html --start 30 --end 60 --fast   # a quick 720p preview
python tools/render_mp4.py projects/my-song/index.html --out "renders/My Song.mp4"  # the final, 1080p + 720p
```

To fix one stretch later without re-rendering everything, see
[rendering.md](rendering.md#fixing-one-stretch).



===== 完整公共规范：docs/engine-patterns.md =====

# How the engines are built

The eighteen engines in [styles/](../styles) share no code at run time: each folder is self-contained, written for one
song in one medium (a few began as copies of another's files, such as the 3D pipeline or the ray-marched figure). But they
share a shape, and knowing it makes any of them easy to read and a new one quicker to write. This page is that
shape, plus the browser gotchas that cost the most time.

## Simulate the process, not the look

Each engine models how its medium is physically made, and the imperfections come out right on their own:

| medium | what the code does |
| --- | --- |
| screenprint | each ink is a stencil mask plus a halftone; inks are pulled one at a time and multiplied onto paper, each a little out of register, with squeegee streaks and pinholes |
| linocut | a block is a list of gouge cuts and inked areas; the key block prints black over watercolour washes |
| wool embroidery | wool is laid and couched from tiles, outlines are stem-stitched, light is couched gold thread |
| marbled paper | paint floats as closed outlines on a bath; drops, combs and swirls are exact maps applied to every point |
| magic lantern | slides are baked as tinted glass; a frame stacks glass by multiplying and throws it through a lens |
| painted enamel | two-colour bristle strokes with a highlight flick toward the light, then gold leaf |
| paper cut | cut shapes with a lit rim and a soft shadow, layered in depth and lit from behind |
| mosaic | tesserae are laid in rows along the outlines, then grouted |
| sand on a lightbox | sand thickness is a density field; the lamp shows through as `exp(-k * thickness)`; fingers clear lines |
| carved diorama | each piece is a signed-distance sculpture meshed in the browser; tool marks are a bump in the piece's own space |
| photomontage | photographs are painted in greys, then given a print's grain, halation and tone curve, and cut out with drifting scissors |
| pinscreen | a field of pins at different heights, lit from a low angle, each pin's shadow falling on the next |
| archive desk | every paper is pre-rendered with its shadow, grain, foxing and torn fibres; stamps are inked, then eroded |
| night poster | a shape's shadow is the band a shifted copy of it fails to cover; night mixes colours toward navy while lamps keep their brightness |
| batik | a real 3D set lit by two coloured lamps is rendered into buffers; wax resists where both lamps reach, each dye takes where only one does, and the wax cracks |
| long-exposure glass plate | each frame integrates many light drawings over the exposure, so whatever moved is a smear and whatever stood still is sharp; then halation, dust and the emulsion's edge |
| silverpoint | even hatching whose weight follows the tone; lines can't be erased, and tarnish from grey to brown with age |
| carved relief | the scene becomes a height field, shaded by a raking light with its own cast shadows |
| liquid light show | oil, water and dye in a dish on a projector: warped-noise dye bands, metaball oil drops with a meniscus, and drawn transparencies whose black ink really blocks the lamp |
| thermal camera | a scene rendered as temperatures and mapped through a camera palette, with a thin visible-light edge overlay, warm breath and fading heat prints |
| showboat stage | painted flats given brushwork by a sampled-stroke pass, lit by a light map in which the actors are lit through their own silhouettes |

A filter that makes a clean digital picture look like linocut never convinces for long. A few rules about how the
real thing is made go much further.

## One frame

Almost every engine's frame function looks like this:

```
renderFrame(t):
  shot = the shot covering t
  set  = shot.set, baked on first use           (the still layers: land, buildings, background)
  cam  = shot.cam(t)                            (keyframed, eased)
  draw the set's layers through the camera       (parallax: nearer layers move more)
  draw what moves at t                           (figures, props, light, weather)
  post: light (a multiplied lamp or light map), grain, vignette, the medium's texture
  if t is inside a transition: draw the next shot too and mix (dissolve, wipe, push)
  the lyric band / margin / caption for t
  fade in and out at the ends
```

The canvas is 1920x1080. Several styles keep the picture above a band for the lyrics (e.g. 1920x960 + 120).

## Sets, shots, cameras

- **Sets** (or scenes, worlds, plates) are places. Their still parts are drawn once into offscreen canvases the first
  time they're needed ("baked"), then only composited. Keep a memory budget: the whole song's sets rarely fit at
  once, so drop the least recently used. Bake at load what the first seconds need, so playback doesn't hitch.
- **Shots** are stretches of song time: `{t0, t1, set, cam, ...}` plus a function that poses what moves.
- **Camera keys** are `[time, x, y, zoom, ...]` with easing between them. Two useful rules:
  - push in with **lens zoom**, not by travelling into the layers: depth travel blows the nearest layer up (snow
    becomes moons);
  - **never let the camera see past the edge** of what's drawn. Check the frame corners on every new camera.
- **Transitions:** dissolves, drop wipes (a new picture spreading inside a drop), push and pull (from a room to the
  picture on its screen), panels (pull back to a page of panels, push into another), re-laying one medium as another
  past a moving line.

## Time: on twos, and in step with the song

- Hand-made animation moves **on twos**: pose changes at 12 fps inside 24 fps video. Several engines step motion at
  12 fps (`tm12 = Math.floor(t * 12) / 12`) while the camera moves at the full 24, which keeps the hand-made feel
  without a juddering camera. Texture "boil" (grain, ink noise) often changes at 8 fps.
- **Ease into fast moves**, or drive them with real time: a move that starts at full speed jumps at 12 fps.
- **Hits on beats, changes on lines.** `SONG.beat(n)` and each line's `t0` and word times are the anchors. A word
  lighting in the lyric band typically fades up over `[t - 0.04, t + 0.16]`.
- **Keep something moving.** A hold longer than a beat or two reads as the player freezing. A slow drift, a breathing
  light or drifting smoke keeps a still picture alive.

## Determinism and frame-to-frame state

- All randomness comes from seeded generators (`mulberry32(seed)`) and noise keyed to the frame number. Never call
  `Math.random()` while drawing a frame. The same `t` must give the same picture, or an MP4 won't match what you
  checked.
- Some styles **carry state from frame to frame**: frost that grows, ghosting of the previous frame, a charcoal
  drawing that's erased and redrawn, marbled paint whose outlines remember every comb. Those must be stepped in
  order. `renderAt(t)` then means "rebuild the state from the start of this scene up to t", and each engine's README
  says how it does that.
- When a view steps backwards in time (a camera effect that holds frames, a scrub), keep what's already baked rather
  than rebuilding it from scratch each step, or rendering crawls.

## Figures

- **Whole figures**, posed. Every engine has a rig: jointed silhouettes, contour-drawn people, ray-marched signed
  distance bodies, carved 3D pieces. Most use **two-bone IK** for arms (and often legs), so a hand can be put exactly
  on a rope, a cup or another hand. Each rig spells it its own way: `reachArm()` in paper cut, an arm given as
  `{t: [x, y]}` in embroidery or `{at: [x, y]}` in painted enamel; the style READMEs show how.
- Build **every figure of a kind from one model**, so its anatomy is the same in every shot; vary only pose,
  clothing and age.
- Things that make figures read wrong, all hit at least once: round heads read as teddy bears (give them a muzzle
  or a jaw); coats that hang along the body turn a crouching figure into a plank (hang them toward world-down);
  digitigrade legs with a long stride look like sitting on a stool; two figures leaving the same way merge into one
  blob; close-up arm silhouettes read as clubs or poles.

## Light

- A **lamp** is a radial gradient drawn with `multiply` (or a light map multiplied onto the whole picture). Its
  warmth and brightness carry most of a scene's mood.
- **Self-lit things** (flames, lit windows, glowing marks) go in their own layer drawn after the light map, plus a
  glow. A reflective shape in front should erase the self-lit layer behind it.
- On pale paper, `screen` adds almost nothing; `soft-light` plus a weaker `screen` shows coloured light.
- Glass only darkens: a moving piece has to pass over light glass, or it vanishes.

## Text in the picture

- Load fonts before drawing and wait for them (`document.fonts.load(...)` for each face and script you use), or text
  falls back to a default font. `document.fonts.load` resolves even when the font never arrived, so check the
  result (or `document.fonts.check(...)`) before building. Put `<meta charset="utf-8">` at the top of the page for
  any non-ASCII text.
- **Start building only when every script has loaded** (`DOMContentLoaded`, or put the start call at the end of the
  last script). A build started from a font promise plus a short timer can win the race against later scripts when
  the fonts come from cache, and the page fails to build only sometimes.
- Keep the lyrics readable: if the camera zooms, keep the text out of the zoom (a band or margin drawn in screen
  space).

## Browser gotchas that cost hours

- **One bad gradient value kills the frame.** `addColorStop` with a NaN or an out-of-range offset throws, and nothing
  after it draws. Check the console after every change.
- **`destination-out` uses the current fill's alpha.** A fill left translucent from the last wash only half-erases.
  Set `fillStyle = '#000'` before erasing.
- **`[hidden]` loses to `display: grid`.** Add `.gate[hidden] { display: none }` for overlay elements.
- **Globals collide.** Plain scripts share one global scope; a helper named like an existing function (`hand`,
  `line`) silently replaces it.
- **Tiling seams:** a texture tiled from a sampled corner shows seams on big pieces; downsample the whole texture.
- **WebGL:** GLSL has reserved words you'd never guess (`patch`); creating a texture while another is bound can
  overwrite a texture unit (create textures on a scratch unit such as TEXTURE15); a three.js `InstancedMesh` keeps the
  bounds of its first draw unless `frustumCulled = false`.
- **Headless loads:** wait for the page with `wait_until='commit'` and your own ready flag; a page that builds a lot
  at load can time out waiting for the load event.
- **Grain that changes every frame bloats the MP4.** Change it on twos.

## Starting a new engine

1. Copy the style closest to what you want. Keep its player (`index.html`, the playback and `window.__video` parts
   of its engine) and its lyric code.
2. Write the medium: the few functions that turn a shape into your medium's marks. Test them on stills first, on a
   page that just draws one scene (a lab page).
3. Draw the same key scenes in your medium and in one or two alternatives. Choose.
4. Then sets, shots and the song.



## 原作者媒介陷阱与经验摘录

## Lessons and gotchas

- **Mannequins.** The figure model's heads look like shop-window dummies when big and clean. Small, soft, grainy, with
  a hard print curve, strand texture in the hair and a jacket rather than a cloak, they pass as photographs. Hats, long
  hair and scarves help more than any lighting change; keep portraits small, and use the painted `crowdHead` for crowds.
- **A painting reads as a photograph** when it is painted at a lower resolution and printed with grain, halation,
  mottling and a vignette. Big flat shapes don't: foliage needs hundreds of small dabs with gaps of sky, ground needs a
  texture laid over it, and a sky needs soft clouds.
- **Standing figures** in long coats read as blocks unless the arms do something (hold a hat, shade the eyes). Pasted
  into another photograph, a figure has to be big enough to hold its own.
- **Bare papers make a thin board.** Every station wants a photograph of a place or a person, a coloured plane or disc,
  and block type, not only documents.
- **Pale ellipses on dark ground** read as lily pads or snow. Build ground from short strokes and small stones.
- **Tiled noise must wrap its lattice** (periodic value noise), or the grid of tiles shows on every textured surface.
- **Substitution cycles must draw the same random numbers at every step**, or the thing changes shape between frames:
  the trees decide which leaves exist before the wind moves them.
- **`cutOut` must restore its canvas state.** It clipped and translated the new canvas's context and left it that way,
  so anything drawn on the cut piece afterwards (a torn edge's rim) landed offset.
- **`photoFinish` must keep a figure's alpha** (its halation and grain spill into transparent pixels) and reset the
  caller's transform; it puts the mask back at the end.
- **Pin shadows saturate to black at mid-greys** unless the shadow length scales with the pin spacing and a calibration
  maps wanted darkness to push (`pinLUT`).
- **Pins as terrain heights** (a relief model) give height-as-darkness, not lit relief, because the shadows fall on the
  screen, not on the neighbouring pins. For land on the pins, pin a hill-shaded picture.
- **Vector pictures look like flat vector art on the pins.** Soften them first (`softPaint`: heavy blur plus a little of
  the original) and keep the pin spacing generous.
- **The pins double the picture if the camera is still moving** when the board freezes. End the push-in and hold before
  the pins take over.
- **A picture on the pins for less than about 0.6 s reads as a flicker.** Hold each one at least that long; every extra
  beat comes out of the next station.
- **Big white mounts looked cloudy** because the paper's dye blotches scaled with area. They are capped, and fainter on
  big sheets.
- **Web fonts can fail to load** on a slow network, and then every piece of type is silently drawn in Times.
  `fontsReady()` checks that each family actually has a loaded face and asks for the stylesheet again.
- **Two files defining the same function**: the later script silently wins. Keep names unique across files.
- **The pins are the slow part.** Most of the cost is shading at twice the size and the grain pass; for live playback,
  shade at 1x without grain.
- **A pinned copy of the board reads as a blurry duplicate** of papers the viewer has just seen, and nothing happens
  on it. Where the board and the picture don't need that link, roll the pins straight over the live board and off it
  (`direct`): the colour comes back through the roller's front.
- **Drawn figures need pale clothes.** Engraved as they are, a photograph's greys (a dark coat, dark hair) come out
  hatched solid; give the figure light greys and let the lighting decide where the hatching goes.
- **A drawing scaled up must scale its marks.** A sketch map drawn at twice the size with the same hachure spacing,
  stroke length and symbol size comes out empty; size them all from the sheet's width (`sketchMap`'s `k`).
- **A piece that blows away should be a copy on top.** Raising the original's stacking order would put it over its
  neighbours for the whole film; `gone(..., { fly })` hides the original and flies a copy above everything.
- **Ease a moving front once.** A front whose position was eased and then eased again crossed its picture in a third of
  the time; key a front by hand (times and positions) when it has to arrive on particular words.
- **Something coming at the camera** (a wall, a front) grows at an even rate on screen only if its distance is
  interpolated as 1/z, not z.
- **Black marks vanish on black paper**: question marks and arrows laid over a black band need grey or white paper.
- **The figure model can't sit.** For a seated person, cut the figure at the hips on the seat and paint the legs in
  the coat's dark.
- **Long robes on the figure model read as stiff slabs**; narrower shoulders and more folds read as cloth.
- **Camera keys written section by section can interleave** where two sections overlap in time, and the camera jumps
  away and back; sort them (the demo does) and check where one section hands over to the next.
- **A piece laid later hides what's under it**: a figure standing in front of a door hid the light through it. Look at
  each new piece against what it covers.
- **Anything a pinscreen picture leaves unpainted comes out black** (pins fully out). Paint the whole frame.
- **At a whole-board view one small change can't be seen**: push the camera in after it, or change something big.


