# Liquid light show

The "wet show" projected behind bands in the late 1960s: coloured dyes, water and oil squeezed between two clock
glasses on an overhead projector and thrown huge on a wall, with painted transparencies laid on the glass for figures
and places. Here the dish is one WebGL fragment shader and each transparency is a 2D canvas. The dye is
domain-warped noise cut at three levels into three dyes, which multiply the lamp's light the way real dye filters it,
with a dark meniscus line wherever two dyes meet, a fine mottle inside them, and a second, slower dye layer turning
the other way. The oil is metaball drops that bend the dye beneath them, with a dark rim, a little light gathered
inside and a faint matte highlight; they can settle into an emulsion, a lattice of drops held apart. Small bubbles
rise through it. The projector has a hot spot, a falloff and the dish's glass edge, and its lamp can flicker on, go
out and dim (a dimmed lamp burns orange). Every tick of the music presses the glass (a small zoom and a lift of the
light) and every drum hit sends a ring out from the centre. The transparencies are multiplied over all of it in
linear light, so black ink really blocks, gels tint and cut-away film lets the full light through; a second lamp can
add light on top of them.

*Good for:* songs with a groove and a live-band feel; dreamy or woozy moods; weather, water and seasons; anything
told in simple silhouettes over moving colour.

![A row of black trees bowing in a gust over streaming yellow, violet and magenta dye, with oil drops and bubbles](img/hero.jpg)

The demo sets Christina Rossetti's "Who Has Seen the Wind?" with the wind as the liquid: in every shot the dye
streams from left to right, harder and stretched into streaks in the gusts, and the transparencies show what it
moves. The title is cut through a band of black film, with the dye moving inside the letters, while the lamp
flickers on. Stanza one: a kite in open colour, where the liquid leads, then the sheet slides down to the two people
flying it, where the picture leads; a branch whose gel leaves tremble on "trembling" until the gust tears them off;
the lamp goes out. Stanza two comes back on a different dye: washing on a line and a walker with a red umbrella
leaning into the wind, then a row of trees that bow on "bow" and "down" while the liquid goes all out, and the kite,
loose now, passing by. At the end the wind drops, the oil settles into an even emulsion under a low sun, and the
lamp dims.

| | |
| --- | --- |
| ![A kite and its tail in open dye, the string running down out of the picture](img/sky.jpg) | ![A branch across the dish with leaves of coloured gel, oil drops behind them](img/leaves.jpg) |
| the liquid leads: a kite in open colour (0:06) | leaves of coloured gel, trembling (0:13) |
| ![Washing of coloured gels on a line, someone pegging it out and a walker with a red umbrella](img/washing.jpg) | ![Four trees on a ridge at dusk, a low sun, the oil settled into an even emulsion](img/emulsion.jpg) |
| the picture leads: washing on a line and a walker (0:24) | the emulsion settles under a low sun (0:36) |

## Looks in this family

This family has one look, so there's no style lab. Its range is inside the look: ten dye palettes in `dish.js`, and
how far each scene lets the liquid lead (`wild`, `calm`, `figAmt`, below).

## Run the demo

```bash
python tools/serve.py
```

Then open `http://localhost:8000/styles/liquid-light/index.html`. Play, or press Space; drag the bar to scrub. Add
`#t12.5` to the address for a still of 12.5 s with the page around it hidden (after editing code, reload with a new
query, `index.html?r=2#t12.5`, because changing only the `#` part doesn't reload).

```bash
python tools/still.py styles/liquid-light/index.html 2 6 12.5 0:37.5:2.5 --sheet   # stills and a contact sheet
python tools/render_mp4.py styles/liquid-light/index.html --fast                    # renders/liquid-light-720p.mp4
python tools/render_mp4.py styles/liquid-light/index.html                           # 1080p and 720p
```

It plays live: a frame takes 7-10 ms to draw on an Apple-silicon Mac, GPU included. A `--fast` render of the whole
37.5 s takes 36-46 s here, depending on what else the machine is doing (about 33 ms a frame including reading the
frame back and encoding it).

## How it works

Plain scripts sharing global names, loaded in this order by `index.html`:

| File | Job |
|---|---|
| `../../examples/poem/lyrics_data.js` | `window.SONG`: the lines, word times and beat grid |
| `pulses.js` | `window.AUDIO`: the ticks, drum hits and loudness the dish pulses to, made from `SONG`'s beat grid and word times |
| `figs.js` | `window.F`: painting a transparency (ink, gels, cut-away film, the second lamp), the figure rigs, and things the wind moves: a tree that bows, a forking bough, gel leaves, grass, a kite, an umbrella, cloth on a line, streamers |
| `dish.js` | `window.DISH`: the dye palettes, every scene parameter's default, oil-drop helpers and presets, timing helpers |
| `scenes.js` | the demo: `window.SCENES`, the shot list, and `window.POSTER`, the frame shown before Play (replace this file) |
| `engine.js` | the WebGL dish, scene blending and pushes, the integrals tabulated at load, the lyric band, `window.__video` |
| `index.html` | the page and the player |

Fonts: Jost from Google Fonts, for the lyric band and the title.

### The dish, pixel by pixel

`engine.js` draws each frame with one full-screen fragment shader. For a pixel in the picture it:

1. presses the glass: the point moves toward the centre by `0.7% x pulse`; a drum hit's ring displaces it radially;
2. evaluates the oil field (the sum of every drop's `r² / d²`, blended toward the emulsion lattice) and its gradient,
   and bends the point it samples the dye at by the gradient: the drop is a lens;
3. samples the dye: the pattern value at the point (turned, swirled, stretched along the wind and carried by it) is
   cut at `thr` into dye A (below `thr[0]`), B (between `thr[1]` and `thr[2]`) and C (above), each multiplying the
   water's `base` colour deeper toward its middle; a dark line where the value crosses a threshold (the meniscus);
   a fine mottle; the second dye layer; the bubbles;
4. adds the oil: its tint, a silver option, the dark rim at the drop's edge, light gathered inside, the highlight;
5. multiplies by the transparency (or the two, mid-change), converted to linear light;
6. adds the second lamp and the mist;
7. applies the lamp: a hot spot, falloff, the lamp's level (orange as it dims), saturation, the glass edge, grain,
   a soft tone curve.

The strip below the picture (the bottom 120 px) is the lyric band, drawn on its own canvas and passed straight
through.

### Coordinates

- **A transparency** is a 1920x1080 canvas in slide pixels, y down. The engine shows it at 8/9 size, centred on the
  1920x960 picture, so its whole height shows and anything left of about x = 30 or right of 1890 falls outside the
  dish. The dish's glass edge is a circle of radius 929 slide px round (960, 540), so the frame's corners are dark.
- **The dish** (drops, wind, mist) is in dish units: x from -1 to 1 across the picture, y from -0.5 at the bottom to
  0.5 at the top. `DISH.fromSlide(x, y)` turns slide pixels into dish units, `[(x - 960) / 1080, (540 - y) / 1080]`,
  and `DISH.viewToDish(view, x, y)` does it through a camera view.
- **Moving a transparency** on the glass: `F.cam(c, cx, cy, k)` puts scene point (cx, cy) at the centre at zoom k.
  Keep every sheet drifting a few pixels (`F.cam(c, 960 + 10 * Math.sin(t * 0.6), 540, 1)`): a sheet that never
  moves looks pasted on.

### Scenes

`window.SCENES` is a list in order of start time. Each scene is:

```js
{ t0, fade, slide, name, p, at(lt, t), drops(ft, lt, t), draw(ctx, lt, t) }
```

- `t0`: when it starts (song seconds). `fade`: seconds of dissolve from the scene before (0 or none is a cut).
  `slide: [dx, dy]`: instead of dissolving, push the new sheet in from that side (`[-1, 0]` is from the left) and the
  old one out ahead of it, both on the glass at once, over `fade` seconds. It reads as the operator changing sheets.
- `p`: parameters, usually a palette plus changes, `DISH.P('warm', { wild: 0.6 })`. `at(lt, t)`: parameters that
  change with time; `lt` is seconds into the scene, `t` song time. Numbers and arrays both blend through a fade.
- `drops(ft, lt, t)`: the oil drops now, `[[x, y, radius, [r, g, b]], ...]` in dish units, at most 32. `ft` is
  pattern time, so drops that wander by it slow down and freeze with the liquid.
- `draw(ctx, lt, t)`: paints the transparency. The context starts cleared (clear glass) with no transform.

The kite scene from `scenes.js`: pushed in from the left on the first sung line, liquid-led while it looks at the sky
(`wild` 0.85, little `calm`), picture-led once the sheet has slid down to the people (`wild` 0.38, the ground calm),
with a gust on "wind?":

```js
const kiteWind = (t) => 0.4 + 0.08 * Math.sin(t * 1.9) + 0.7 * gust(t, W(0, 4) - 0.35, W(0, 4) + 0.1, W(0, 4) + 1.5);
{ t0: LINE(0), fade: 0.75, slide: [-1, 0], name: 'kite', p: P('warm', { flow: 1.2 }), draw: kiteScene,
  at: (lt, t) => { const w = kiteWind(t), u = ease(7.3, 9.0, t);
    return windP(w, { wild: lerp(0.85, 0.38, u) + 0.15 * gust(t, W(0, 4) - 0.3, W(0, 4), W(0, 4) + 1),
      calm: lerp(0.2, 0.85, u), flow: 1.1 + 0.8 * w, swirl: 0.35 }); },
  drops: (ft, lt, t) => cloudDrops(6, 11, [[1.0, 0.9, 0.7], AMBER, [1.0, 0.82, 0.55]], ft, t, { rmax: 0.1, sx: 1.0 }) },
```

`windP(w, extra)` turns a wind strength into `wind`, `streak`, `turn: 0` and `swirl: 0.4`, and the same `kiteWind`
drives the grass, the coats and the kite in `kiteScene`, so the liquid and the pictures move together.

### Parameters

Defaults are in `DISH.DEFAULTS`; a scene's `p` and `at()` override them.

| Parameter | Default | What it does |
|---|---|---|
| `base`, `A`, `B`, `C`, `thr`, `scale` | `warm` palette | the water's colour, three dyes, the pattern values where each starts, the size of the dye bands. Palettes: `warm`, `green`, `dawn`, `day`, `clean`, `cold`, `cool`, `dusk`, `rose`, `full` |
| `wild` | 0.3 | how psychedelic, 0..1: the dyes' strength and contrast, the bands' size, how much of the second layer shows. Low when the picture leads, high when the liquid does |
| `calm` | 0.85 | calms the liquid in the lower part of the dish, so figures on the ground read |
| `sat` | 1 | saturation of the whole picture |
| `flow` | 1 | how fast the dye folds (the rate of pattern time; 0 freezes it) |
| `turn`, `swirl` | 0.02, 1 | how fast the dish turns (radians per unit of pattern time) and the slow eddy at its centre (0..1) |
| `wind`, `streak` | [0, 0], 0 | the liquid carried, in dish units per second, and stretched along the wind (1 = twice as long) |
| `oilTint`, `silver`, `spec` | amber, 0, 0.03 | the oil's colour (for drops without their own, and the emulsion), a pale metallic look, the highlight |
| `lattice`, `latScale`, `latMask` | 0, 0.085, 1 | the emulsion: how far the drops give way to an even lattice, its spacing, and (1) keeping it above the horizon |
| `mistAmt`, `mistY`, `mistSlope`, `mistX`, `mistX0`, `mistCol` | 0 (off) | a band of mist: its strength, its top edge's height and slope, its leading and trailing edges (move `mistX` to roll it in), its colour |
| `mistGlow`, `mistGlowCol`, `mistT` | 0 | the mist lights up toward `mistGlowCol` with the voice (`AUDIO.venv`); `mistT` is its own clock (default pattern time) |
| `lamp` | 1 | the projector lamp, 0..1 |
| `figAmt` | 1 | how strongly the transparencies print: lower is a ghost of the picture over the liquid |
| `neg` | 0 | shows the sheets as a negative |
| `pulse`, `layer2`, `bub`, `rip` | 1 | how much the ticks press the glass; the second dye layer; the bubbles; the drum ring |

### Painting a transparency (`figs.js`)

A transparency is paint on clear film. What you draw is what blocks or tints the light:

- **Ink:** `F.INK` blocks it completely; `F.INKF` (86%) is for far planes, so a black figure in front still reads.
  Shapes: `poly(c, pts, fill)`, `circ(c, x, y, r)`, `ell(c, x, y, rx, ry, rot)`, `rr(c, x, y, w, h, r)`,
  `line(c, pts, width)`, `limb(c, a, b, w0, w1)`, `chain(c, pts, widths)`, `floor(c, y)` (ground from y down).
- **Gels:** any translucent colour tints the light: `F.gel(c, 'rgba(255,90,70,0.75)', () => ...)`, or just a fill
  with alpha. A gel multiplies with the dye under it.
- **Cut-away film:** `F.clear(c, fn)` erases what `fn` draws (so the full light comes through), `F.pane(c, x, y, w,
  h, tint)` clears a window and lays a gel in it, `F.cutText(c, text, x, y, font)` cuts letters.
- **The second lamp:** `F.glow(c, g => ...)` draws light onto a layer added over the sheet (in the sheet's
  transform), `F.unglow(c, g => ...)` cuts shapes out of it (ink in front of a light), `F.halo(c, x, y, r, rgb, a)`
  is a soft round light. Use it for anything brighter than the dish: a lantern, a low sun.
- **People,** always whole figures, `h` px tall standing on `yF`: `F.profile(c, o)` side on, facing `f` (1 right, -1
  left), with `arms` and `armsBack` as a pose name (`'down'`, `'raise'`, `'point'`, `'reach'`, `'gesture'`, `'carry'`,
  `'fold'`...) or your own `[[elbow x, y], [wrist x, y]]` in body units (the shoulder is at `[1, -31]`, the hip at
  `[0, 0]`, forward is +x); `walk` (a phase in radians), `kneel`, `lean`, `headTilt`, `build`, `belly`, `hair`
  (`'short'`, `'bun'`, `'ponytail'`, `'cap'`, `'mop'`, `'curls'`), `coat` (`'long'` or `'short'`), `scarf`; `wind`
  (-1..1) and `t` stream the hair, scarf and coat hem; `hold(c, x, y, s, f)` draws what the front hand holds. It
  returns `{ headX, headY, hand }`, the front hand in your coordinates, for tying a string to it.
  `F.front(c, o)` faces us (arms `'down'`, `'folded'`, `'up'`) and `F.seated(c, o)` sits behind a table top `yT`.
- **Things the wind moves:** `F.tree(c, x, yB, h, bend, { t, shake, seed, crown })` bows toward +x (the angle at
  height u is `bend * u^1.9`, and the crown streams downwind); `F.bough(c, from, angle, len, width, depth, { bend,
  shake, droop, lift, t, seed, nodes })` forks, and fills `nodes` with points for hanging leaves; `F.leaf(c, x, y,
  len, angle, gel)`; `F.grass(c, x0, x1, yB, h, bend, t, { ground })`; `F.kite(c, x, y, s, rot, t, { cols, tailAng })`
  returns where its string is tied; `F.umbrella(c, x, y, s, angle, { gel, inv })` (`inv` blows it inside out);
  `F.cloth(c, a, b, len, t, wind, { gel, phase, stripe })` hangs from a line and lifts in the wind;
  `F.streamer(c, x, y, angle, len, w0, w1, t, { amp, sag })` is a ribbon with a wave running to its free end.
  Also `F.windowFrame(c, x, y, w, h, tint)` and `F.snow(c, x, y, w, h, t)`.

### Oil drops (`dish.js`)

`DISH.drift(n, seed, o, ft, carry)` makes `n` drops that wander round their own places: `o.sx` spreads them across,
`o.y0` and `o.yr` give the band of heights, `o.rmin`/`o.rmax` the sizes, `o.ax`/`o.ay` how far they wander,
`o.speed`, and `o.col` or `o.cols`. Pass `carry = LS.driftAt(t)` (how far the wind has carried the liquid) and they
travel with the wind and wrap round the dish. Presets in `DISH.D`: `few`, `warm`, `burst` (many colours, wild),
`split` (pairs that come apart and won't hold together), `held` (a grid), `one` (a single quivering drop),
`leaving` (drops sliding off the edge of the dish). A drop can sit on a feature of the sheet: map the point with
`DISH.fromSlide` (or `F.mapPt` through a transform). The branch scene's drops swell on every tick with
`LS.pulseAt(t)`.

### The pulse

`window.AUDIO = { ticks, kicks, env, venv }`:

- `ticks: [[time, strength], ...]`: each presses the glass and lifts the light for about a tenth of a second
  (`LS.pulseAt(t)`, 0..1.4);
- `kicks: [[time, strength], ...]`: each one stronger than 0.3 sends a ring out from the centre over 1.2 s;
- `env`, `venv`: the mix's and the voice's loudness, 24 values a second, 0..1. The lamp breathes a few per cent with
  `env`; the mist can glow with `venv`.

`pulses.js` makes these from the song's beat grid: a tick on every eighth note (the bar's first beat strongest, the
off-beats weakest), a kick at the start of every sung line, and a voice envelope from the word times. It works for
any `lyrics_data.js` with a beat grid. The engine also exports `LS.ticksBefore(t)`, `LS.envAt(t)`, `LS.venvAt(t)`,
`LS.flowTime(t)` and `LS.driftAt(t)` for scenes.

### The lyric band

A 120 px band under the picture shows the current line, each word lighting (with a short glow) as it's sung and the
rest waiting at 16%; a line appears 0.12 s before its first word and fades 2.2 s after its last or when the next
begins; a long line shrinks to fit. Lines in a section whose name starts with `chorus` are set in gold italics.
Before the first line, the band shows `SONG.credit` in italics under the title slide (the title itself is a scene,
cut through black film). The font and colours are in `drawLyrics` and `drawCredit` in `engine.js`.

### Determinism

Nothing carries over from one frame to the next: a frame is a function of `t` alone, so `step(t)` and `renderAt(t)`
are the same function, frames can be drawn in any order, and a slice rendered on its own matches a full render.
What accumulates (pattern time, the dish's turn, how far the wind has carried the dye, in the dish and in each dye
layer's own coordinates) is integrated once at load from the scenes' parameters, every 0.05 s, and looked up. Random
choices come from seeded generators (`DISH.rng`), and the grain changes on twos. The only caches are the canvases:
two sheet slots, the second lamp and the band.

## Make your own video in this style

1. **Copy the folder and your song:** `cp -r styles/liquid-light projects/my-song` and
   `cp ~/Music/my-song.mp3 projects/my-song/song.mp3` (see [docs/your-own-video.md](../../docs/your-own-video.md)).
2. **Time your lyrics** ([docs/timing.md](../../docs/timing.md)) so you end up with `projects/my-song/lyrics_data.js`
   (written by `tools/audio/to_js.py`), and in `index.html` change `../../examples/poem/lyrics_data.js` to
   `lyrics_data.js`. The page now plays the demo under your song, pulsing to your beat grid.
3. **Keep** `engine.js`, `figs.js`, `dish.js`, `pulses.js` and the player. **Rewrite** `scenes.js`; the demo's scenes
   are there to borrow from. Change the title, subtitle and `aria-label` in `index.html`.
4. **A scene:** a draw function and an entry in `SCENES`. For example, a porch at dusk with a lit window:

   ```js
   function porch(c, lt, t) {
     F.cam(c, 960 + 10 * Math.sin(t * 0.6), 540, 1.0);                  // the sheet drifts a little on the glass
     F.floor(c, 900);
     F.windowFrame(c, 300, 420, 260, 300, 'rgba(255,210,140,0.45)');    // clear film under an amber gel
     F.halo(c, 430, 570, 260, [255, 200, 120], 0.35);                     // the window glows past the frame
     F.profile(c, { x: 1200, yF: 900, h: 380, f: -1, hair: 'bun', coat: 'long', wind: 0.3, t });
   }
   // in SCENES, in time order:
   { t0: LINE(3), fade: 0.6, name: 'porch', p: P('dusk', { wild: 0.35 }), draw: porch,
     at: (lt, t) => ({ wind: [0.1, 0] }), drops: (ft) => DISH.D.few(ft) },
   ```

   Keep figures standing in the lower third, where `calm` settles the liquid, and give gels real colour.
5. **Timing:** `B(n)` is beat n, `LINE(i)` line i's start, `W(i, k)` when word k of line i is sung (all in
   `scenes.js`). Changes go on line starts (a new scene, a push), hits on beats and words: the demo's gusts are
   `gust(t, W(0, 4) - 0.35, W(0, 4) + 0.1, W(0, 4) + 1.5)`, rising into "wind?", and its lamp dims through the last
   bar with `lamp: lerp(1, 0.08, ease(B(57), B(60) - 0.05, t))`. The ticks and rings need nothing: they follow
   `AUDIO`.
6. **Real percussion:** for a song with drums, measured onsets pulse better than the grid. Measure them with
   `tools/audio/pulses.py`, which writes `audio_data.js` in exactly this shape (see
   [docs/timing.md](../../docs/timing.md#hits-and-loudness)), and load it in place of `pulses.js`:

   ```bash
   python tools/audio/pulses.py song.mp3 --percussion perc.mp3 --drums drums.mp3 --vocals vocals.mp3 \
       --out projects/my-song/audio_data.js
   ```

   Stems give much cleaner hits; without them give just the mix.

7. **Knobs worth knowing:** `wild` and `calm` (who leads, picture or liquid); `flow`, `wind` and `streak` (how the
   liquid moves; `windP` in `scenes.js` is a good starting point for wind); `lamp` with `DISH.flicker(t, t0, dur,
   from, to)` for a lamp failing or coming on; `lattice` for the emulsion; `figAmt` to fade a sheet to a ghost;
   `slide` for changes that feel hand-made; the palettes in `DISH.PAL`; `SPEED` and `bendOf` in `scenes.js`.
8. **Look at it** with `python tools/still.py projects/my-song/index.html 0:30:1 --sheet`, and preview slices with
   `render_mp4.py --start --end --fast`.

## Lab

None: this family has one look. To try palettes or parameters on your own scenes, open your page at a `#t` still and
edit `scenes.js`, or give a scene a long stretch of time with `at()` stepping through the values you want to compare.

## Performance

- A frame takes 7-10 ms (median) in headless Chrome on an Apple-silicon Mac, GPU work included, and up to about
  20 ms while two sheets are on the glass during a push or dissolve. The page plays live at the display's rate.
- The cost is the shader (two domain-warped noise patterns a pixel, and the oil field evaluated five times a pixel
  for its refraction, once per drop) and uploading the sheets as textures every frame: one or two 1920x1080 sheets,
  the second lamp's layer when a scene uses it, and the band.
- Memory: three 1920x1080 canvases (two sheet slots and the second lamp) and the band, about 25 MB, and the same again
  as textures; a few MB of JavaScript.
- A whole `--fast` render: 36-46 s here, about 33 ms a frame including readback and encoding. The files are larger than most styles' because the whole dish moves every frame: the demo's 720p copy
  runs about 3.3 Mbps. (Weaker grain doesn't help; tested.)
- To render a stretch: `python tools/render_mp4.py styles/liquid-light/index.html --start 26 --end 31 --fast`.

## Lessons and gotchas

- **Ink must really block.** Multiply the transparency over the light in linear colour (`pow(rgb, 2.2)`): in gamma
  space even 1% of the lamp leaking through black paint showed as a visible navy.
- **The sheet lies on top of everything in the dish.** The oil's highlights and caustics were first added after the
  sheet, and showed as grey smudges over black ink. Multiply the sheet in last; only the second lamp and the mist go
  over it.
- **Glossy drops look like plastic balls.** Keep the oil matte: a strong tint, a dark rim, a faint highlight.
- **Far planes in 86% ink** (`F.INKF`), so a black figure in front of a building or a hill still reads.
- **Let the picture or the liquid lead, not both at once.** With the dye at full strength, figures and gels get lost;
  lower `wild` and keep the ground `calm` when the picture matters, and turn the liquid up (and the sheet down with
  `figAmt`) when the liquid is the subject. Varying this from scene to scene is most of the style.
- **One dye layer looked flat and slow.** The second, slower layer turning the other way, the bubbles, a ring on each
  drum hit and more drops made it feel alive.
- **Turning round a far-off point shears the dye into rings.** Swirling the dish round coordinates that the wind had
  carried far from the centre wound the dye into concentric circles, and changing the band size slid it. So the drift
  is integrated at load in each dye layer's own turned and scaled coordinates, and the turn, the swirl and the scale
  only ever act on the dish's own small coordinates. Anything you add that accumulates should be integrated the same
  way.
- **The dish's own swirl fights the wind.** Turn `swirl` down and `turn` off (as `windP` does) when the dye should
  stream one way.
- **An even lattice reads as a halftone screen.** Each emulsion drop is nudged off its place and given its own size.
- **A ring can push the picture past the sheet's edge.** Beyond a sheet at rest the engine repeats its edge pixels;
  only a sliding sheet has clear glass beyond it. (Otherwise every drum hit flashed white slivers under the ground.)
- **Round drops as leaves read as berries or beads.** Gel leaves (a leaf of coloured film with an ink edge and
  midrib) read as leaves, with the drops quivering behind them. A gel multiplies with the dye under it, and orange over
  blue comes out brown: calm the dye behind gel pictures.
- **Pale gels vanish over pale dye.** White sheets on a washing line came out as empty outlines; give gels real
  colour.
- **Mist over black ground reads as a flat khaki or grey sheet.** Keep the mist over the liquid, or thin.
- **In a dissolve every parameter blends,** so the old scene's mist, drops and wind hang over the new picture for the
  length of the fade: clear them before the change, or push the new sheet in with `slide`.
- **The lamp shouldn't go to black.** A dimmed lamp burns orange, and a blink between sections keeps a faint filament
  glow, so no frame is blank; the ticks keep pulsing in the dark, which keeps the frame alive.
- **A silhouette carries the whole person.** Body shape has to read side on as well as from the front; thin limbs at
  small sizes vanish into the dye bands; small features (glasses, a nose) disappear. Cut anything that must show
  inside a silhouette out of it, or lay a gel in it.
- **Two figures that overlap become one blob.** Keep people apart, or have one pass the other quickly.
- **A sheet that never moves looks pasted on,** even over moving dye. Drift every transparency a few pixels.
- **Title letters cut through black film need a heavy face:** thin strokes show too little dye to read.
- **The oil drops are capped at 32 a frame:** the shader loops over them five times a pixel.
- **Grain that changes every frame bloats the MP4;** here it changes on twos.
- **Wait for the fonts.** The page builds only after every script has loaded and the fonts have been asked for, and
  warns in the console if Jost didn't arrive (the MP4 tool stops rather than render in a fallback face).
- **Changing only the `#t` part of the address doesn't reload the page;** reload with a new query after editing code.

