"""Read-only commit check by default. --apply stages source text before replacing snapshots."""
from pathlib import Path
from datetime import datetime
import argparse, concurrent.futures, hashlib, json, sys, time, urllib.error, urllib.request

ROOT=Path(__file__).resolve().parent.parent
SRC=ROOT/'sources'; UP=SRC/'upstream'
parser=argparse.ArgumentParser()
parser.add_argument('--check',action='store_true')
parser.add_argument('--apply',action='store_true')
parser.add_argument('--accept-reviewed',action='store_true',help='Only after human/agent reads source diffs and updates Chinese notes')
args=parser.parse_args()
def read(p):return p.read_text(encoding='utf-8')
def dump(p,x):
    p.parent.mkdir(parents=True,exist_ok=True)
    tmp=p.with_suffix(p.suffix+'.tmp')
    tmp.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    tmp.replace(p)
def get(url):
    request=urllib.request.Request(url,headers={'User-Agent':'Opus-style-library/1.1','Accept':'application/vnd.github+json'})
    for attempt in range(3):
        try:
            with urllib.request.urlopen(request,timeout=45) as r:return r.read().decode('utf-8')
        except urllib.error.HTTPError as error:
            if error.code not in (408,429,500,502,503,504) or attempt==2:raise
        except (urllib.error.URLError,TimeoutError,ConnectionError):
            if attempt==2:raise
        time.sleep(2**attempt)
def api(path):return json.loads(get('https://api.github.com/repos/'+path))
def raw(repo,sha,path):return f'https://raw.githubusercontent.com/{repo}/{sha}/{path}'
def parallel(fn,jobs):
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:return list(pool.map(fn,jobs))
now=datetime.now().astimezone().isoformat(timespec='seconds')
if args.accept_reviewed:
    pending=SRC/'review-pending.json'
    dump(pending,[])
    print(json.dumps({'acceptedReviewedAt':now,'note':'Rebuild and validate before sharing.'}))
    sys.exit(0)
upstreams=json.loads(read(SRC/'upstreams.json'))
repos=upstreams['repositories']
heads=parallel(lambda x:{**x,'latest':api(x['repo']+'/commits/HEAD')['sha']},repos)
changes=[{'repo':x['repo'],'before':x['sha'],'after':x['latest']} for x in heads if x['sha']!=x['latest']]
report={'checkedAt':now,'changedRepositories':changes,'mode':'apply' if args.apply else 'check'}
if not args.apply:
    print(json.dumps(report,ensure_ascii=False,indent=2));sys.exit(0)
# Protect any local edits to source snapshots even when a remote repository is unchanged.
inventory=json.loads(read(SRC/'source-inventory.json'))
for f in inventory:
    p=ROOT/f['localPath']
    if not p.exists() or hashlib.sha256(p.read_bytes()).hexdigest()!=f['sha256']:
        raise SystemExit('Local source modification detected; preserve it before sync: '+f['localPath'])
if not changes:
    dump(SRC/'last-sync.json',report)
    print(json.dumps(report,ensure_ascii=False));sys.exit(0)
stamp=datetime.now().strftime('%Y%m%d-%H%M%S')
stage=SRC/'staging'/stamp
stage.mkdir(parents=True,exist_ok=False)
assert stage.resolve().is_relative_to(SRC.resolve())
data=json.loads(read(SRC/'styles.json'))
files=json.loads(read(SRC/'source-files.json'))
oldfiles={(f['source'],f['path']):f for f in files}
aux=json.loads(read(SRC/'auxiliary-repos.json'))
olditems={x['source']+'/'+x['slug']:x for x in data['primary']+data['secondary']}
pending=json.loads(read(SRC/'review-pending.json')) if (SRC/'review-pending.json').exists() else []
pending={x['id']:x for x in pending}
downloads=[]; new_ids=[]; archived=[]; changed_docs=[]; license_changes=[]
for head in heads:
    if head['sha']==head['latest']:continue
    repo=head['repo']; sha=head['latest']
    if head['role']=='reference':
        path='auxiliary/'+repo.replace('/','__')+'/README.md'
        downloads.append({'source':None,'path':path,'repo':repo,'sha':sha,'url':raw(repo,sha,'README.md')})
        continue
    source='lemo' if repo=='lemomo-ai/lemo-opuscar' else 'handmade'
    if source=='lemo':
        catalog=json.loads(get(raw(repo,sha,'styleboard/catalog.json')))
        if not isinstance(catalog,list) or not catalog:raise ValueError('Unexpected empty catalog')
        incoming={x['slug']:x for x in catalog}
        group=data['primary']
        for slug,entry in incoming.items():
            existing=next((x for x in group if x['slug']==slug),None)
            base={'source':'lemo','repo':'https://github.com/'+repo,
                  'imageUrl':raw(repo,sha,f'docs/frames/{slug}.jpg'),
                  'styleUrl':f'https://github.com/{repo}/blob/{sha}/styles/{slug}/STYLE.md',
                  'videoUrl':f'https://github.com/{repo}/releases/download/films/{slug}.mp4'}
            if existing is None:
                existing={};group.append(existing);new_ids.append('lemo/'+slug)
            existing.update(entry);existing.update(base);existing.pop('archivedUpstream',None)
        common=['DIRECTOR.md','TECHNIQUE.md','LICENSE','README.md','README.zh-CN.md','styleboard/catalog.json']
        paths=common+[f'styles/{slug}/STYLE.md' for slug in incoming]
    else:
        tree=api(repo+'/git/trees/'+sha+'?recursive=1')
        if tree.get('truncated'):raise ValueError('Truncated upstream tree')
        incoming={x['path'].split('/')[1]:{} for x in tree['tree'] if x['path'].startswith('styles/') and x['path'].endswith('/README.md') and len(x['path'].split('/'))==3}
        if not incoming:raise ValueError('No handmade styles found')
        group=data['secondary']
        for slug in incoming:
            existing=next((x for x in group if x['slug']==slug),None)
            if existing is None:
                existing={'slug':slug,'cn':slug+'（待中文校对）','en':slug.replace('-',' ').title(),'cat':'手作材质','line_cn':'新增风格，请完整阅读作者引擎说明并补充中文介绍。','line':'','film':'原作者示例','dur':37.5}
                group.append(existing);new_ids.append('handmade/'+slug)
            existing.update({'source':'handmade','repo':'https://github.com/'+repo,
                             'imageUrl':raw(repo,sha,f'styles/{slug}/img/hero.jpg'),
                             'styleUrl':f'https://github.com/{repo}/blob/{sha}/styles/{slug}/README.md'})
            existing.pop('archivedUpstream',None)
        common=['CLAUDE.md','LICENSE','README.md','requirements.txt','requirements-audio.txt','docs/engine-patterns.md','docs/rendering.md','docs/timing.md','docs/workflow.md','docs/your-own-video.md']
        paths=common+[f'styles/{slug}/README.md' for slug in incoming]
    for item in group:
        if item['slug'] not in incoming:
            item['archivedUpstream']=True;archived.append(source+'/'+item['slug'])
    for path in paths:
        downloads.append({'source':source,'path':path,'repo':repo,'sha':sha,'url':raw(repo,sha,path)})
    for path in common:
        pending['repo:'+source]={'id':'repo:'+source,'reason':'common_documents_or_license_changed','checkedCommit':sha}
def fetch(job):
    content=get(job['url'])
    if len(content)<20:raise ValueError('Unexpected source text: '+job['url'])
    rel=(job['source']+'/' if job['source'] else '')+job['path']
    p=stage/'upstream'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(content,encoding='utf-8')
    return job,content,rel
# A failed download stops here, before any formal source file is touched.
fetched=parallel(fetch,downloads)
for f,content,rel in fetched:
    dest=UP/rel
    if dest.exists() and read(dest)==content:continue
    changed_docs.append(rel)
    if rel.endswith('/LICENSE'):license_changes.append(rel)
    if f['source'] and f['path'].startswith('styles/'):
        ident=f['source']+'/'+f['path'].split('/')[1]
        pending[ident]={'id':ident,'reason':'new_style' if ident in new_ids else 'upstream_changed','checkedCommit':f['sha']}
# Backup only files that will be replaced. Leave stage and backup for audit/recovery.
writes=[]
for job,content,rel in fetched:
    target=UP/rel
    if target.exists() and read(target)==content:continue
    backup=stage/'backup'/rel
    if target.exists():
        backup.parent.mkdir(parents=True,exist_ok=True);backup.write_bytes(target.read_bytes())
    writes.append((target,stage/'upstream'/rel,backup))
done=[]
try:
    for target,temp,backup in writes:
        target.parent.mkdir(parents=True,exist_ok=True);temp.replace(target);done.append((target,backup))
except Exception:
    for target,backup in reversed(done):
        if backup.exists():target.write_bytes(backup.read_bytes())
    raise
for f,content,rel in fetched:
    if f['source']:oldfiles[(f['source'],f['path'])]=f
for head in heads:
    if head['role']=='reference':
        for entry in aux:
            if entry['repo']==head['repo']:entry['sha']=head['latest']
data['checkedAt']=now[:10]
files=list(oldfiles.values())
newinv=[]
for f in files:
    p=UP/f['source']/f['path']
    newinv.append({**f,'localPath':p.relative_to(ROOT).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
report.update({'newStyles':new_ids,'archivedStyles':archived,'changedDocuments':changed_docs,'licenseChanges':license_changes,'reviewRequired':list(pending.values()),'stagingFolder':str(stage.relative_to(ROOT))})
dump(SRC/'styles.json',data);dump(SRC/'source-files.json',files);dump(SRC/'source-inventory.json',newinv)
dump(SRC/'auxiliary-repos.json',aux)
dump(SRC/'upstreams.json',{'checkedAt':now[:10],'repositories':[{k:v for k,v in h.items() if k!='latest'}|{'sha':h['latest']} for h in heads]})
dump(SRC/'review-pending.json',list(pending.values()));dump(SRC/'last-sync.json',report)
log=ROOT/'更新日志.md'
with log.open('a',encoding='utf-8') as out:
    out.write('\n## '+now+'\n\n'+f'- 上游变化：{len(changes)} 个仓库；新风格 {len(new_ids)} 项；变化文档 {len(changed_docs)} 份。\n')
    out.write('- 需要审查：'+('、'.join(pending) if pending else '无')+'。详情见 sources/last-sync.json。\n')
print(json.dumps(report,ensure_ascii=False,indent=2))

