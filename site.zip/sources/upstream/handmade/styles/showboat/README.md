# Showboat stage

A theatre built on a barge, seen from a seat in the stalls: painted backcloths, wings and borders, a wave machine,
trapdoors, scenery flown in and out on ropes, footlights under tin hoods, and a gilt proscenium with the audience's
heads in silhouette below it. The camera is a pinhole camera working in feet, so the stage has real depth: nearer
flats are bigger, the borders hide the flies, and a zoom from the back of the house to an actor's face is one lens
change. What makes it read as a painted stage rather than an illustration: every set piece is painted once as flat
shapes and then given brushwork by a sampled-stroke pass (each short stroke takes the colour under it, lifted or
dropped a little), then pigment grain; the stage is lit by a light map multiplied over it (a wash from above,
footlights from below, hard-edged spots), and actors in a spot are lit through their own silhouette, so the spot
lights the actor and not the cloth behind; and the machinery shows. Trees bow on hinges because a stagehand in the
wing hauls on a line, the wind machine turns in the other wing, leaves tremble on wires, and the scenery arrives on
ropes. The actors are cut-out people drawn front-on in feet, with two-bone arms whose gestures move like joints and
land on their cues. The words stand on an easel at the side of the stage, like a variety theatre's act card, and the
card flips over for each line.

![The stage from the stalls: a painted day sky and lake, two actors bracing against a gust, trees bowing, a boat's
sail behind the hills, stagehands in the wings, footlights, and the lyric card on its easel](img/hero.jpg)

The demo sets Christina Rossetti's "Who Has Seen the Wind?" as a small show. A lamplighter lights the footlights
along the front of the stage under the title card while the house lamps dim. The painted act drop flies out on the
first word, onto a windy hillside by a lake. A woman sings the first verse and loses her boater on "wind?" (the
camera whips in as it goes); a man is blown on from the far wing under an umbrella, holding her hat. The leaves on
their wires tremble in a cold spot while the house goes quiet; a gust passes through, the trees bow one after
another and a boat sails across. For the second verse a dusk cloth and a moon fly in, the umbrella turns inside out
on "wind?", a flood lamp in the house throws their shadows up the sky on "Neither you nor I", and on "bow" the trees
and the actors bow together. The wind carries them off, the act drop comes down, and they take a curtain call in
front of it while posies land from the stalls.

| | |
|---|---|
| ![Leaf cut-outs trembling on wires in a cold spot, the two actors looking up at them](img/leaves.jpg) | ![At dusk, a man's umbrella blown inside out under a flown moon](img/umbrella.jpg) |
| ![The trees bowing on their hinges and the actors bowing with them, at dusk](img/bow.jpg) | ![The curtain call in front of the painted act drop, a posy thrown from the stalls](img/call.jpg) |

Good for: story songs and character songs, anything with a narrator or a performer, comedy, songs that want scene
changes, and songs about a place that can be built as scenery. Less good for fast cutting (it's one stage), or for
songs that need close faces: the actors are cut-out people and read best whole.

This family has one look, so there's no style lab.

## Run the demo

```bash
python tools/serve.py
```

Then open `http://localhost:8000/styles/showboat/index.html`. It plays live in Chrome, smoothly in the wide shots and
at 15-25 frames a second in the close-ups. Space plays and pauses; the bar scrubs. If the audio can't load it plays
on a silent clock. Add `#t12.5` to the address for a still of 12.5 s with the page around it hidden (after editing a
script, reload with a new query, `index.html?r=2#t12.5`, since changing only the `#` part doesn't reload).

```bash
python tools/still.py styles/showboat/index.html 2 6 13.4 20.85 0:37.5:2.5 --sheet   # stills and a contact sheet
python tools/render_mp4.py styles/showboat/index.html --fast                          # renders/showboat-720p.mp4
python tools/render_mp4.py styles/showboat/index.html                                 # 1080p and 720p
```

A `--fast` render of the whole 37.5 s (900 frames) took 81 s here on an Apple-silicon Mac, about 90 ms a frame with
reading back and encoding included; expect more when the machine is busy with other renders.

## How it works

Plain canvas 2D, no libraries. Fonts come from Google Fonts: IM Fell English for the card, Atkinson Hyperlegible for
the page. The scripts share one global scope and load in this order:

| File | Job |
|---|---|
| `../../examples/poem/lyrics_data.js` | `window.SONG`: the title, credit, lines with word times, beat grid |
| `paint.js` | `P`: seeded random `P.rng(seed)`, colour helpers (`mix`, `jit`, `rgb`), a bristle brush stroke, `strokes`, `region`, `wobbly` edges, pigment `grain`, and `P.paintify(canvas, o)`, the sampled-stroke pass |
| `stage.js` | the seat and the camera (`CAM0`, `setCam`, `proj`, `base`), the proscenium opening, `placeFlat`, `finish` (paintify plus grain), `trim`, and the stock pieces: wing flats (`trees`, `reeds`, `rock`, `column`, black `legs`), borders (`cloud`, `leaves`, `drape`, `plain`), a wave-machine row, the floor with its traps |
| `house.js` | `HOUSE`: the proscenium, curtains and audience (painted once), the footlights, the light map, the house light and wall lamps, haze and beams, the grade |
| `figures.js` | `FIG`: the people, their gesture table, the natural-motion tracks, held props, and the renderer with its paint pass |
| `props.js` | item constructors: scenery (`back`, `wings`, `borders`, `flown`, `waves`), wind machinery (`hingedTree`, `leafWires`, `leafFall`, `windMachine`, `sailboat`), effects (`dust`, `fogBank`, `confetti`, `thrownFlower`), furniture and lamps (`table`, `hangingLamp`, `bulb`, `workLights`, `ghostLight`, `crate`, `topple`, `wire`), the house (`stander`), and actors (`actor`, `pathAt`, `voxAt`, `footShadow`) |
| `card.js` | `CARD`: the easel card and its flips, built from `SONG.lines` |
| `scenery.js` | the demo's painted pieces: the act drop, a day and a dusk sky cloth, windmill sails, two hill ground rows, tree trunks and crowns, leaves, clouds, a boat and sail, the moon, a boater |
| `scenes.js` | the demo's show: lighting states, camera keys, the wind, the stagehands, the actors' paths and gestures, and `frameAt(t)` |
| `engine.js` | `compose(t)` (one frame), `window.__video`, and the build |
| `index.html` | the page and the player |

### The stage and the camera

Stage coordinates are feet: x across (0 is centre, negative is the left of the picture), y up from the stage floor,
z depth (0 is the proscenium line, negative is the apron in front of it). The seat is 34 ft back with eyes 5.5 ft up:

```js
const CAM0 = { D: 34, eye: 5.5, f: 1850, cx: 960, cy: 500 };  // distance, eye height, focal length (px), centre
proj(x, y, z)       // -> [screen x, screen y, pixels per foot at depth z], through the current camera
base(x, y, z)       // the same point in the unzoomed picture (for aiming the camera)
setCam(zoom, px, py)   // zoom about the base-picture point (px, py), which lands in the middle of the frame
placeFlat(g, canvas, x0, x1, y0, y1, z, rot = 0, alpha = 1)   // a painted flat covering that stage rectangle
```

Because a zoom here is a longer lens with the principal point moved, it's exactly a 2D scale of the base picture:
the house (proscenium, curtains, audience) is painted once in base coordinates and drawn through the same scale
(`T(X, Y)`, `HOUSE.drawBase`). Everything behind the proscenium is clipped to the opening plus the apron
(`stageClipPath`). The opening is 24 x 12.4 ft (`OPEN`).

### Painted pieces

A piece is a function that paints a canvas once: `PAINT.name = (...) => { ...flat shapes...; return finish(c, seed,
{n, len, w, ang, spread, alpha, jit}) }`. `finish` runs `P.paintify`, which reads the finished flat picture and lays
`n` short bristle strokes over it, each taking the colour at its own start (so every region keeps its colour, but
turns into brushwork), then adds pigment grain. `ang` and `spread` set the strokes' direction (vertical for a hanging
cloth, along the grass for a hill). Pieces are fetched with `get(key, fn)`, which paints each one the first time
it's needed. Sizes, as painted: backcloths 40 x 20 ft at 40 px to the foot (only about the lower 12 ft shows between
the borders and the floor), wings 5 x 16 ft, borders 36 x 6.24 ft, the act drop 25.2 x 13.2 ft (only its lower 10.5
ft shows under the valance), small pieces at 60 px to the foot.

### A frame

`frameAt(t)` in `scenes.js` returns `{items, lights, footAt, front, apron}`. An item is `{z, draw(g)}`: `compose(t)`
sorts the items far to near and draws them inside the proscenium, multiplies the light map over them, then draws the
proscenium and curtains under the house light, the footlights (`footAt(x)` gives each lamp's flame, 0-1), `apron`
items (someone sitting on the stage's edge), the audience, `front` items (people and things in the house), the rim of
stage light on the audience's heads, haze and beams, the grade (a vignette and grain that moves on twos), the card,
and a fade at the ends.

### Light

A light state is `{ambient, wash, foot, house, lamps}`; `LSCHED` says when each takes over and how long the change
takes, and `lightsAt(t)` blends them. From the demo:

```js
day:  { ambient: [186, 182, 178], wash: ['#fff4dc', 0.7], foot: 0.45, house: [28, 24, 24], lamps: 0.04 },
foot: { ambient: [46, 38, 52], wash: ['#f0a070', 0.1], foot: 1.0, house: [26, 20, 20], lamps: 0 },  // footlights only
const LSCHED = [[0, 0.1, 'house'], [2.4, 3.6, 'houseDim'], [3.75, 4.2, 'day'], [LINE(2), LINE(2) + 0.8, 'leaves'], ...];
```

`HOUSE.lightMap` turns the state into a picture: the ambient colour, the wash falling from above the backcloth, the
footlights' glow rising from the front, `spots` (`{x, z, r, c, lv, hard, h, beam}`: a pool on the floor, a faint
column above it, and with `beam` a hazy beam from the house), `pools` (`{x, y, z, r, c, lv, flat}`: a soft light
anywhere, like a lamp's) and `wings` (how much light reaches the wings; the demo keeps them at 0.45, so the
stagehands there are dim). While the stage is drawn, anything that gives light adds itself to the map through
`LIT.ctx`: a hanging lamp, a moon, and any actor with `lit`, whose silhouette is added so a spot lights the actor
without lighting the cloth behind them. The house side has its own light: `house` is its colour, `lamps` the wall
lamps, and the stage spills warm light onto the proscenium's inner edge.

### People

`FIG.render(name, pose, pxPerFoot, opts)` draws a person front-on, in feet, into a canvas of their own; `actor()`
places and lights it. The presets in `FIG.P0` are the demo's `actress` and `actor`, two stagehands (`hand`, `hand2`)
and a `child` (`FIG.kidSized(base, height, overrides)` makes a child of any age: lengths scale with height, widths a
little less, heads less again). A preset is a body plan (heights, widths, arm lengths in feet) plus clothes: `hair`
(`short`, `slick`, `bun`, `long`, `curls`, `hood`), `outer` (`dress`, `suit`, `coat`, `cardigan`, `cloak`, `tunic`,
`work` for shirtsleeves and waistcoat) and extras (`jacket` over a dress, `hat: 'boater'`, `cap`, `flatcap`,
`scarf`, `tie`, `tache`, `beard`).

A pose is `{L, R, bow, lean, tilt, shrug, look, mouth, open, lids, spread, hat, flap, inv, btilt, walk, walkAmt, sit,
back}`: `lean` and `tilt` are radians (+ toward the right of the picture), `bow` 0-1, `look` -1..1, `hat: 0` takes the
hat off, `flap` is the wind on skirts, coat tails and a scarf (-1..1, + blows toward the right), `inv` turns an
umbrella inside out and `btilt` tilts it. Arms (`L`, `R`) are specs:

```js
'point'                                   // a gesture from the table FIG.G
{ g: 'hold', hold: 'hat' }               // a gesture, holding something (hat, umbrella, hankie, letter, mug, coin, flowers, taper)
{ h: [0.7, -1.2], p: [0.9, -1.0] }        // a hand position and a direction for the elbow
FIG.reach('actress', 'R', [1.8, 4.9], [0.8, -0.9], 'hat')   // the hand on a point, in feet from her feet
```

Gestures are measured from the shoulder (x outward, y up) on a reference arm, and give both where the hand is and
where the elbow appears: a hand in front of the body keeps its elbow down at the side, as a real arm reaching toward
you does, so elbows never flip. `FIG.reach` works backwards from a point in feet, for a hand on a rope, a crank or
another hand.

**Tracks.** Most people move by `FIG.poseAt(track, t)`, where a track is `[[time, pose, duration?], ...]`. Each key
starts a spring-like step toward its pose 0.75 of its duration before the key: it is most of the way there on the
key, overshoots a hair and settles. Steps overlap, so keys close together blend instead of jumping. Arms move as
joint angles (the upper arm's direction, the forearm's bend), so hands travel on arcs; a big swing takes longer than
a small one, the forearm trails the upper arm, and the left arm trails the right by a hair. On top of that everyone
breathes, sways and shifts their weight on their own clock, a shoulder lifts when its hand goes above it, the body
leans into a reaching hand, and the head dips on a sung syllable. From the demo:

```js
[B(9) + 0.12, { L: 'reach', R: 'up', hat: 0, look: -0.8, mouth: 'o', lean: -0.05 }, 0.25],   // "wind?": the hat goes
[B(13), { L: 'rest', R: { g: 'chest', finger: true }, hat: 0 }, 0.3],                          // "Neither I"
[B(15), { L: 'rest', R: 'point', hat: 0, look: 0.7 }, 0.3],                                     // "nor you"
```

`FIG.blend(a, b, u)` mixes two poses straight (for things driven by a number, like the stagehand hauling a line).

**Actors.** `actor(name, t, o)` returns the item for one person at time t (or null outside `o.vis`). `o` takes a
place (`x, z`, or `path: [[t, x, z], ...]`, walked with a stride worked out from the distance), `y` (raised or sunk;
a function of t), `pose` or `track`, `sings: [line indices]` (the mouth opens on each word of those lines, from
`SONG`'s word times, via `voxAt`), `flap(t)` (the wind on their clothes), `lit` and `litC` (the silhouette in the
light map), `clip` (hide what's below the floor, for someone rising through a trap) and the paint pass's lighting:
`foot` (warm from below), `spot` (cool from above), `dark` (the top darkened), `rim` and `rimA` (a thin edge of light).

**The paint pass.** After a figure is drawn in flat colours it gets brushwork (the same `paintify`, scaled to the
figure), then edge darkening from a blurred silhouette, a shaded far side, a thin rim of light, and the lighting
gradient. Brush first, then shade: the other way round drags the rim's highlight down thin limbs.

`footShadow(name, actorItem, clothZ, alpha, lamp)` throws a person's shadow up a cloth from a lamp low at the front
(by default the footlights). The shadow grows by (cloth depth - lamp depth) / (actor depth - lamp depth).

### Machinery and wind

```js
flown(key, paint, x, y, w, h, z, { ropes, ropeAt, rot, slipped })  // a piece hanging on ropes that run up out of sight
fly(t, tIn, tOut, dIn, dOut)       // 0 out of sight, 1 landed (a quick fall and a small bounce), back out from tOut
back(key, paint, z, y)             // a backcloth; raise it by y to fly it in or out
hingedTree(keyT, paintT, keyC, paintC, x, z, bow, { trunk, crown, below, shiver, line, t })
leafWires(t, leaves, amp)          // leaf cut-outs twisting on wires; amp 0 still, 1 a gust
leafFall(t, t0, dur, n, seed, speed)   // loose leaves blown across, carried at speed(t) ft/s
windMachine(x, z, angle)           // the slatted drum under canvas; crankAt(x, angle) is its handle, in feet
sailboat(x, z, t, fill)            // a boat in a slot between the wave rows, the sail filling with fill
waves(t, amp, shift)               // the three rows of the wave machine
```

A hinged tree turns on two hinges, 40% of the bow at the trunk's foot and the rest where the crown meets the trunk,
so it bends over rather than tipping; a dark line runs from the crown up into the flies. In `scenes.js`, `windAt(t)`
is a breeze that changes by line plus gusts (`BREEZE`, `GUSTS`), and `windSum(t)` is the wind summed over time
(tabled once at load), which turns the windmill and the wind machine's crank and carries the clouds along their
track. The trees don't follow the wind directly: they follow `HAULS`, the pulls the stagehand in the left wing makes
on their line, each tree a little after the one to its right, springing back past upright when he lets go.

### The camera

`CAMK` is a list of `[time reached, zoom, stage x, y, z to centre, move duration]`. Each move runs over its
duration before its time; moves under 0.35 s are whips (eased out), longer ones ease in and out, and zoom is
interpolated in log. From the demo:

```js
[3.6, 0.98, 0, 5.0, 0, 3.4],          // creep in from the back of the house while the lamps are lit
[5.3, 1.45, -1.4, 5.0, 3.0, 1.5],     // push in toward her as the act drop flies out
[5.85, 2.7, -2.2, 5.7, 2.8, 0.24],    // whip in on "wind?" as her hat goes
[7.4, 1.3, -3.4, 6.2, 2.8, 1.3],      // pull back, following the hat off left
```

Zoom 1 shows the whole proscenium from the seat; 0.84 shows the house round it; about 2.5-3 is a head and shoulders.

### Lyrics

`CARD` stands on an easel in the lower right of the frame and doesn't move with the camera (keep the action out of
that corner). It shows one line at a time and flips the old card up over its top edge (`FLIP` 0.24 s), starting
`LEAD` (0.12 s) before each line's first word. The first card is the title card: `SONG.title` in red small capitals,
a rule, `SONG.credit` in italics; it comes back at the outro. Words in brackets are set in red, for a second voice.
Each card face is painted once and cached.

### Determinism and caching

A frame depends only on t: every random choice comes from `P.rng(seed)` with a fixed seed, the wind's running total
is tabled at load, and nothing carries over from one frame to the next, so `step(t)` and `renderAt(t)` are the same
function and frames can be drawn in any order. The caches: painted pieces (`CACHE`, via `get`), the house canvases,
card faces, and each track's prepared keys. People are drawn fresh every frame. The build draws a few frames to
paint every piece before `__video.ready`, so playback doesn't stop to paint.

## Make your own video in this style

1. Copy the folder and your song: `cp -r styles/showboat projects/my-song`, `cp ~/Music/my-song.mp3
   projects/my-song/song.mp3`.
2. Time your lyrics ([docs/timing.md](../../docs/timing.md)) so you have `projects/my-song/lyrics_data.js` (written by
   `tools/audio/to_js.py`), and in `index.html` change `../../examples/poem/lyrics_data.js` to `lyrics_data.js`. The
   demo's show now plays under your song (for as long as the demo lasts), and the card already shows your lines. See also
   [docs/your-own-video.md](../../docs/your-own-video.md).
3. Keep `paint.js`, `stage.js`, `house.js`, `figures.js`, `props.js`, `card.js`, `engine.js` and the player. Rewrite
   `scenes.js` (the show) and `scenery.js` (your painted pieces); the demo's are there to borrow from.
4. **Scenery:** paint each piece as a `PAINT.name` function ending in `finish(...)`, and put it on stage in
   `frameAt` with `back()` for a backcloth, `wings(spec)` and `borders(kind, depths)` for the masking,
   `{ z, draw: g => placeFlat(g, get(key, PAINT.name), x0, x1, y0, y1, z) }` for a flat or ground row, and `flown()`
   for anything that hangs. Paint what matters where the audience can see it: the lower 12 ft of a backcloth.
5. **People:** add presets to `FIG.P0` (or pass `over: {...}` to one actor), give each a `path` and a `track` keyed
   to the song, and push `actor(name, t, o)` into the items. Use `FIG.reach` when a hand must land on something.
6. **Light:** add states to `LS` and changes to `LSCHED`; add spots and pools per frame (`L.spots.push(...)`) for a
   followspot or a lamp. Mark people in a spot `lit` so the spot lights them and not the cloth.
7. **Camera:** write `CAMK` keys. Wide shots from the house show the theatre; push in for faces and props; whip on
   the hits. Check every new camera's frame edges: a zoom below about 0.84 shows the edge of the painted house.
8. **Timing:** `B(n)` is beat n, `LINE(i)` line i's start, `SONG.lines[i].words[k][1]` word k's time. Put hits (a
   hat flying off, an umbrella turning, a flat landing) on beats and words; change scenes, light states and big camera
   moves on line starts. A gesture key lands on its time, so key it on the word, and remember the move begins up to
   half a second before.
9. **Knobs:** `CAM0` (the seat) and `OPEN` (the proscenium); `BREEZE`, `GUSTS`, `HAULS` and each tree's `bow` (the
   wind and the trees); `leafAmp`; the light states; `wings` in `lightsAt` (how dark the wings are); `finish`'s stroke
   options per piece (`n`, `len`, `w`, `ang`, `spread`, `alpha`, `jit`); the figures' paint pass (`foot`, `spot`,
   `dark`, `rim`); the card's size and place (`CW`, `CH`, `BX`, `CY`) and timing (`LEAD`, `FLIP`); the house's
   colours in `paintProscenium` and `paintCurtains`; the vignette in `HOUSE.grade`.

Mouths follow the word times by default (`voxAt`). For a real vocal you can drive them from the vocal stem's
loudness instead: `python tools/audio/pulses.py song.mp3 --vocals vocals.mp3 --out projects/my-song/audio_data.js`
writes `AUDIO.vdb`, the voice's loudness in decibels mapped so -45 dB is 0 and -15 dB is 1, 24 values a second; load
it before the engine and have `voxAt` read `AUDIO.vdb[Math.floor(t * 24)]`.

## Performance

- Drawing a frame takes about 27 ms on average in Chrome on an Apple-silicon Mac: 15-25 ms for wide shots, 40-60 ms
  for close-ups, and up to about 85 ms on a whip zoom into two people (measured with a pixel read-back after each
  frame, so the GPU's work is counted).
- The cost is in the people: each is drawn fresh every frame into its own canvas and given the paint pass (a
  `getImageData` read-back, a few thousand strokes, a blurred edge), and the canvas grows with the zoom (up to 180
  px to the foot). A footlight shadow adds a silhouette render per person. Scenery costs almost nothing per frame
  once painted.
- The build takes about 2 s: it paints every piece by drawing nine frames.
- Memory: the three house canvases are painted bigger than the frame so the camera can pull back past it (about
  3600 x 2100 px each, 30 MB), plus the backcloths, act drop and three full-frame scratch canvases: about 150 MB.
- A whole `--fast` render: about 80 s for the 900 frames. A slice while you work on one stretch: `python tools/render_mp4.py styles/showboat/index.html --start 18 --end 24
  --fast`, or stills with `tools/still.py`.

## Lessons and gotchas

- **Light the actor's silhouette, not an ellipse.** A spot drawn in the light map as a tall ellipse behind an actor
  read as a glowing capsule. Adding the figure's own silhouette to the light map (`lit`) lights the actor without
  lighting the cloth behind.
- **Brush first, then shade.** When the brush pass ran after the rim light, it dragged the highlight down thin limbs
  and legs came out pale.
- **Haze and fog over actors make them see-through.** Keep the footlights' haze band faint and fog thin, and draw fog
  in depth (`fogBank` items with their own z), never as a layer over everything.
- **`destination-in` inside a clip does nothing** outside the clip, so cut-outs weren't trimmed. `trim()` fills its
  path without a clip, so the outside really is cleared.
- **Sampled strokes streak.** The brush pass takes each stroke's colour from under it, so thin, bright, hard-edged
  features (a sky of hundreds of hard light strips) sampled into long streaks that looked like a digital glitch. Soft
  gradient strips worked.
- **Arms jumped and elbows flipped** in two ways: a gesture that followed another quickly started from the previous
  key instead of from where the arm was, and hands moved as points swinging round the shoulder, so lowering a hand
  from the brow sent the arm up first. The fix is the whole of `poseAt`: gestures give the elbow's place as well as
  the hand's, arms blend as joint angles, and every move is an overlapping spring step. Look at frame-by-frame strips
  of a gesture, not just stills on the keys.
- **A still between keys can catch an arm mid-swing,** because steps start well before their key. Check a gesture at
  its key's time.
- **The rest of "natural":** breathing, a little sway and weight shift, a shoulder that lifts with its hand, a lean
  into a reaching hand, a dark edge on sleeves (an arm in front of a coat of the same cloth disappears without it) and
  a rounded shoulder cap so the arm grows out of the body.
- **Hair as a fan of strands** read as a feathered headdress on small figures. One soft mass with a few paler strands
  reads as hair.
- **Wing flats have to mask.** A cut-out wing with space between its trees left the stagehands behind it standing in
  full view, as big as the actors. Make wings solid out to their outer edge, and keep the wings darker than the stage
  (`wings` in the light map); visible machinery is part of the charm, but it shouldn't compete with the actors.
  (Watch the sign when you cut a wing's inner edge: offsets must point from the inner edge into the flat.)
- **A round crown rotating doesn't read as a bow.** What reads is where the mass goes: hinge the crown low in its
  canvas so turning it swings the leaves sideways and down, give the trunk a share of the bend, and bow a long way
  (about 1 radian) on the word.
- **Hinge plates drawn over a crown** read as black bars in the leaves; leave the upper hinge unseen.
- **Pale pulling lines on a sky read as scratches;** thin dark lines read as rope.
- **Footlights throw enormous shadows.** The lamp is so close to the actors that only the legs of a 4x shadow reach
  the part of the backcloth you can see. A lamp further out in the house gives a 2-2.5x shadow that fits, and the
  cloth needs light of its own for a shadow to show on it.
- **Only the lower 10.5 ft of the act drop shows** under the valance, and only the lower 12 ft of a backcloth between
  the borders and the floor. Ornament painted above that is lost.
- **Gold on gold vanishes.** A gilt scroll on a gilt frame read as nothing; give ornaments a contrasting ground.
- **Stage props are oversized.** Half-foot leaves read as confetti from the stalls; leaves 1-1.5 ft long read as
  leaves. The same goes for anything held up to the house.
- **Clouds painted as spheres look like cotton wool.** A flat base and one light-to-shade gradient across the whole
  cloud reads as cumulus.
- **`P.region` and `P.rgb` take a hex string or an [r, g, b] array.** An `rgba(...)` string parsed as hex gives
  garbage colours (flat neon green in one case). Keep colours as arrays until they reach `fillStyle`.
- **A strip offset only in y has no width when it hangs straight down.** Offset along the strip's normal.
- **The card covers the lower right.** Stage the action away from it and check that corner on every camera.
- **Zooms:** from 0.84 (the whole house) to about 3 (a face). A whip takes about a quarter second; a creep up to
  several seconds. Whip on hits, creep through held moments so nothing sits still.
- **Grain that changes every frame bloats the MP4.** It moves on twos here.
- **One bad value in a gradient blanks the frame.** Check the console after every change; the still tool prints it.

