# 74 · 石质马赛克与沙画 / Stone mosaic and sand

来源类型：根据作者引擎说明整理的使用模板；并非作者原始创作提示词  
原作者：Miranda Dixon-Luinenburg  
上游原文：https://github.com/cyborggirl963/opus-5.5-music-video-art-styles/tree/main/styles/mosaic-and-sand  
固定版本：801b3548c54765ecf932ce8b7f3cf4b29fb7a8bf  
抓取核对日期：2026-11-03  
本库改动：中文任务模板、中文摘要与编排；原文全文保留。

## 使用前先看

- 先解决遮挡再铺颗粒，后景线不能穿过前景；马赛克光感通过暖石和灰缝产生。
- 文字按骨架铺粗线保证可读；两种介质各测一段渲染成本，不能只按平涂动画估时。

- 这是代码渲染工作流；聊天文本本身不会自动产生 MP4，需有可执行的项目环境。
- 先看预览再做长片；不要把示例素材的许可自动套到自己的歌曲、照片、字体和品牌上。
- 下方复制区包含全部风格与公共规范，不要求 AI 另外从本机隐藏路径读取文件。

## 完整复制区

你是一位能写代码、检查画面并渲染成片的动画导演。请用“石质马赛克与沙画 / Stone mosaic and sand”制作一个属于我的视频。

【我的需求；把花括号内容换成实际值】
主题与一句话故事：{{填写主题和结尾变化}}
用途与观众：{{例如面向普通观众的科普短片}}
内容依据或已有脚本：{{填写；没有则说明需要你写}}
音频、歌词、图片、数据、品牌素材路径：{{填写；没有写“无”}}
素材使用权限与需显示的署名：{{填写来源与许可；不清楚请列待确认项}}
目标时长：30 秒起步；MV 以实测歌曲时长为准
画幅与清晰度：默认横屏 16:9、1920×1080；帧率按本风格原文与引擎规范，未规定时24fps；竖屏须重新构图，不直接裁横屏
语言：简体中文；配音需求：{{有/无、声线与语速}}
必须出现的内容：{{填写}}
禁止出现的内容：{{填写}}
预算与速度：先做低成本验证，再渲染完整片
个人工程名：my-video（可改为英文短名）
确认方式：先给 3 张由真实渲染代码产出的样帧和 5–10 秒预览；我确认风格后再做完整成片

【本风格的核心实现】
用同一场景描述分别生成石质镶嵌与背光沙画，颗粒排列随物体轮廓。
特别检查：
- 先解决遮挡再铺颗粒，后景线不能穿过前景；马赛克光感通过暖石和灰缝产生。
- 文字按骨架铺粗线保证可读；两种介质各测一段渲染成本，不能只按平涂动画估时。

【工程与流程】
1. 在工作区单独克隆 https://github.com/cyborggirl963/opus-5.5-music-video-art-styles ，检出 801b3548c54765ecf932ce8b7f3cf4b29fb7a8bf。将 styles/mosaic-and-sand/ 复制到 projects/my-video/，保留引擎，按该风格 README 指定的文件替换示例场景。不要直接修改 styles/ 中的母版。
建立 Python 虚拟环境，阅读 requirements.txt 后安装渲染依赖；需分析音频时再安装 requirements-audio.txt。使用 Chrome 或项目支持的 Chromium。使用 python tools/serve.py 提供本地 HTTP，不用 file:// 打开渲染页面。
2. 先检查机器的 Python、Node/浏览器、FFmpeg、字体与 GPU 能力。Lemo 当前要求 FFmpeg 7+；先用 ffmpeg -version 核对。缺少工具或访问权限时明确报告缺什么，不能只描述完成、伪造文件或把截图称为已渲染视频。
3. 把我的需求写成 PLAN.md 或 TREATMENT.md：一句话故事、分镜、逐镜秒数、镜头运动、文字位置、音乐与声音 cue、所需素材、预计成本。涉及事实和数据时写 FACTS.md；没有来源的数字不填。
4. 如果是 MV，先取得音频与实际演唱歌词，测量段落、停顿、节拍与词时间；不得沿用 37.5 秒示例诗的时间轴。未提供音乐时不要假装已经完成歌词对齐，可先制作无歌词短预览。
5. 先完成 3 张代表开头、关键变化、结尾的样帧，逐张检查；再渲染 5–10 秒低清短段，检查字幕、运动、音画同步与控制台。复杂慢风格先计时，再估算整片。
6. 随机效果固定种子；有历史累积的媒介按顺序渲染。并行前先比较随机抽帧与连续渲染是否一致。
7. 正式导出使用项目文档中的工具与参数，不臆造命令。交付可播放 MP4、720p 预览、源代码、素材清单与许可、字幕（有台词时）、复现说明；保留最终片长、帧率、音频响度与实际渲染耗时。
8. 实际打开并检查成片开头、中间、转场、结尾及全片联系表，确认没有空帧、字体回退、遮挡、裁字、爆音或无意复制的作者片尾签名。交代尚未完成的检查。

下面是完整风格参考与公共制作规范。它们是上游参考资料，不代表我的主题或逐字台词；我的具体需求优先。风格中明确的声音、镜头和媒介限制优先于公共建议，例如无声电影不添加旁白或拟音。遇到 macOS/Linux 示例命令时按当前系统等价转换，不直接在 PowerShell 粘贴 bash 命令。相对资源路径以完整克隆的上游工程为准。


===== 完整风格原文：styles/mosaic-and-sand/README.md =====

# Stone mosaic and sand

Two hand-made media drawn from one scene description. **Stone mosaic**: every picture is cut into small stone,
glass and gold tesserae and set in a mortar bed. The pieces are laid the way a mosaicist lays them, in rows that
follow each shape's outline (the rows ripple round a figure like a halo), with plain straight courses for the
background and small cut pieces in the gaps. Each piece is shaded as a little bevelled block that catches one light,
glass and gold glint, the mortar has its own grain and shadow, and light is shown the old way, as warmer stones
and glowing mortar round a lamp or the sun. Lettering is laid as one row of pieces along the centre line of each
letter, as in Roman inscriptions. **Sand on a lightbox**: every picture is sand on lit glass, as in hand-made sand
animation. Thick sand is dark and thin sand lets the lamp through; edges wobble like a hand pushed them; thin sand
breaks into grains; rubbed areas carry palm sweeps; a fingertip clears lines with a small ridge of pushed sand
beside them; coloured light can be laid under the glass. Figures are drawn by pouring sand, or by pushing it away.

![The hillside laid in stone, the wind in the sky as curling courses](img/hero.jpg)

## Looks in this family

- **Stone mosaic** (`mosaic.js`): tesserae laid along outlines in a mortar bed. ![Stone mosaic](img/look-mosaic.jpg)
- **Sand on a lightbox** (`sand.js`): sand thickness as darkness, pushed and cleared by hand, lit from below. ![Sand on a lightbox](img/look-sand.jpg)

The demo uses both: the first stanza is laid in stone, the second pushed about in sand, and at the end the sand is
re-laid as stone. On the way: the title laid a word to a beat, with a warm pulse running out through the mortar
when it is done; two walkers laid again every third frame as they come down the path; leaves cut loose to tremble;
a kite painted flat on a canvas and re-laid as tesserae every third frame, jumping when the gust reaches it; seeds
on the wind that seem to drift because they shine in travelling bands; figures swept clear of the sand with a
fingertip; trees poured into the sand as they bow.

![The leaves hang trembling: each leaf a loose group of tesserae](img/leaves.jpg)
![A kite painted on a canvas and re-laid as tesserae every third frame, seeds drifting in the sky around it](img/kite.jpg)
![The trees bow down their heads, in sand](img/trees.jpg)
![The sand re-laid as mosaic behind a moving line of light](img/relay.jpg)

## Run the demo

```
python tools/serve.py
```

then open http://localhost:8000/styles/mosaic-and-sand/index.html. Space or the button plays and pauses, the slider
moves through the song, and `index.html#t12.5` opens on a still of 12.5 seconds. If the song can't load, it plays on a silent clock.

It plays live, but not smoothly everywhere: mosaic frames draw in about 15-50 ms, sand frames in 100-230 ms (so the
sand half runs at 4-10 frames a second), and a transition draws both pictures. The first frame of each
new set lays its floor (1-3 s); the player does this in the background after it opens, so wait a few seconds before
pressing Play. For a smooth copy, render it:

```
python tools/still.py styles/mosaic-and-sand/index.html 2 6 12.5 0:37.5:2.5 --out renders/mosaic-and-sand --sheet
python tools/render_mp4.py styles/mosaic-and-sand/index.html --fast
```

The whole 37.5 s demo (900 frames) rendered in about 1 minute 50 seconds with `--fast` on an M-series Mac shared
with other work: about 120 ms a frame on average, including building the page, the one-off bakes, reading each frame
back as a JPEG and encoding it. (On a busier day it took 3.5 minutes.)

## How it works

Plain canvas 2D, no libraries; fonts from Google Fonts (EB Garamond for the lyric band, Cinzel for inscriptions).
Scripts load in this order (`index.html`):

| File | Job |
|---|---|
| `../../examples/poem/lyrics_data.js` | `window.SONG`: title, credit, audio, duration, bpm, sections, lines with word times |
| `core.js` | sizes (`W,H` frame, `PW,PH` picture, `SW,SH` set), maths, seeded random (`mulberry32`, `hashi`), value noise (`vn2`, `fbm2`), colour helpers, shapes (`shp`, `spline`, `resample`, `ell`, `blob`, `wave`, `ribbon`), fonts |
| `figures.js` | whole people from a pose: `figure(o)` side view, `sitter(o)` behind a table, `stander(o)` facing us; props (cape and scarf that stream in the wind, lantern, basket, bundle...); `walkPose(ph)` |
| `items.js` | the scene description: item constructors `Fi` `Li` `Gl` `Do` `Tx`, `figItems`, `scaleItems`, `wrapText`; the header lists every hint both renderers read |
| `mosaic.js` | the mosaic renderer: `MPAL` palette, `makeMosaic`, `shadeMosaic`, `mosaicFromRaster` |
| `sand.js` | the sand renderer: `sandDensity`, `sandShade`, `renderSand` |
| `figs.js` | the film's builders: extra colours, `tree` and `pine` that bend and bow, `leaf`, `swirl`, `gustLine`, `walking`, `standing`, and `kitePicture` (a flat painting for a raster actor) |
| `scenes.js` | scenes described once for both looks (`SCENES.hillside`, `SCENES.washday`), plus `cloud`, `smokePuffs`, `windCourse` |
| `engine.js` | the film engine: sets and baking, moving figures and moving pictures (actors), loose pieces, mosaic and sand frames, cameras, transitions, the timeline `step(t)`, the lyric band, timing and pick helpers (`tagsOf`, `driftPick`), the player |
| `sets.js` | the demo's sets (and `windSeeds`, the seeds in the hill's sky) |
| `shots.js` | the demo's shots, and `buildShots()` |

### A scene is a list of items

```js
Fi(points, colour, role, hints)   // a filled shape      {k:'fill', s, col, role, ...}
Li(points, colour, width, role, hints)   // a stroke     {k:'line', pts, col, w, ...}
Do(x, y, r, colour, hints)        // a spot
Gl(x, y, r, colour, alpha, hints) // light
Tx(x, y, text, font, colour, hints)
```

Later items cover earlier ones. `colour` is a name in `MPAL` (mosaic.js, extended in figs.js) or `[r,g,b,material]`
with material 0 stone, 1 glass, 2 gold. Each renderer reads its own hints and ignores the other's:

- mosaic: `ts` piece size in px; `mode:'echo'` (rows follow the outline all the way in) or `'course'` (`echo` outline
  rows, then straight courses at `courseDir`); `mat`; `skel:true` on text for centre-line lettering; `float:1` on a
  dot (one piece set among the pieces of whatever is under it, without cutting a hole there: snow, seeds on the
  wind); `mos:'skip'`.
- sand: `sd` thickness 0-1 (by default from the role and how dark the colour is); `sg`/`sr` linear or radial ramps of
  thickness; on lines `sand:'draw'` (a line of sand) or `'scratch'` (a fingertip line cleared through it); on fills
  `sand:'clear'` (push the sand away inside the shape); `mos:'only'` keeps an item out of the sand.

Anything else rides along. `tag` is the useful one: shots find the pieces an item was laid as by its tag.

### The mosaic renderer

`makeMosaic(items, opt)` returns `M = {w, h, T, owner, regs, RID, opt}`:

1. The items are drawn flat into a colour picture and a region-id map (one id per item).
2. Edges between regions go through an exact distance transform. Marching squares trace iso-lines of distance /
   piece size, and pieces are laid along them, outline row first (`row: 0`), level by level inward. A piece is
   a quad; it is laid only where it overlaps less than 6% of what is already laid, and shrinks to fit if needed.
3. Regions in `'course'` mode get straight staggered courses after their outline rows. Lines and dots get one
   row of pieces along the stroke (laid before the rows, so they keep their place); `skel` text is thinned
   (Zhang-Suen) and laid along the skeleton. A `float` dot never enters the region map: it is laid first, as one
   piece, and the rows of the region under it simply pass round it.
4. Leftover gaps get small cut pieces (`fill: 1`).

Each piece in `M.T` is `{cx, cy, tx, ty, hl, hw, col, mat, reg, q, tilt, sd, row?, line?, fill?, item?}`: centre,
direction, half-length and half-width, colour, material, region, its quad, a random tilt, a seed, and how it was laid.
`M.owner[i]` is the piece covering pixel `i` (or -1 for mortar).

`shadeMosaic(M, ctx, opt)` shades per pixel: mortar with grain and occlusion near pieces; each piece as a bevelled
block lit from the laying's `light` direction, with stone texture, a glass highlight, or gold's hot glint. Options: `groutGlow(x,y)` ->
`[r,g,b,a]` makes the mortar glow; `pieceTint(t,x,y)` multiplies a piece's colour; `pieceColor(t,M)` replaces it
(this is how the film's variants are made); `alphaOf(i)` for transparent cut-outs.

`mosaicFromRaster(rgba, w, h, opt)` lays any picture: colours posterized into regions (`levels`, or `lumOnly` for a
one-colour picture), tidied by a majority filter; regions bigger than `courseArea` px get `courseEcho` outline rows
and straight courses. Blur the picture a little first, or its texture turns into confetti.

### The sand renderer

`sandDensity(items, opt)` returns `{rho, w, h, opt}`: each item paints its thickness into a density field, fingertip
lines and cleared shapes go into a second field, glows into a third. The field is warped a few pixels by noise so
edges wobble, softened, given fine grain and broad palm sweeps (`opt.sweep` is their angle), and rubbed-thin areas
break into drifts of grains. The plate's rim is darkened (`frame`, `frameW`). `sandShade(rho, w, h, opt)` turns
thickness into light: `exp(-k * rho)` of a lamp with a warm hot spot (`lamp`, `lampEdge`), over the colour of lit sand
(`front`), with `opt.under(x,y)` -> `[r,g,b,amount,gain]` laying coloured light under the glass.

### Sets, shots and the timeline

`defSet(name, spec)` registers a set; `bake(name)` builds it the first time it's needed (least recently used sets are
dropped past `MEMCAP`).

- `kind:'mosaic'`: `items()` laid once at 2112 x 1056 (10% bigger than the picture, so the camera can move), shaded
  into each of `variants` (`{name: shadeMosaic options}`), plus the bare bed with no pieces.
- `kind:'sand'`: `items()` baked to a density field; `opt` for `sandDensity`; `under(x,y,u,t)` for light under glass.
- `kind:'custom'`: `bake()` and `frame(g, B, shot, u, t)` draw it themselves (`relaySet` in sets.js is one).

A shot, from `shots.js` (u is time since the shot began, t is song time):

```js
{id:'hill2', t0:L0(3), set:'hill',                         // line 4 starts
 cam:[[0,1180,560,1.08],[2.4,SW/2,SH/2,OW/SW]],             // [u, x, y, zoom]; smoothstep between keys
 pick:(p,u,t,i,B)=>{ ... return {v:'pale'} or {a:0.5} or null; }}   // per piece, per frame: which variant, how laid
```

More shot fields: `tr:{type, dur, dir}` how it comes in from the shot before (`cut`, `dissolve`, `wipe`, `lift`
(mosaic pieces rise off to show the next picture), `settle`, `sweep` (sand pushed into the next picture), `reveal`,
`flash`); `actors` (below); `loose:{match(item), move(group,u,t) -> [dx,dy,rot,variant]}` groups of laid pieces
cut out as sprites that swing over their empty beds; `glow(x,y,u,t)` light in the mortar (called for every mortar
pixel, so return one reused array, as `titleGlow` in shots.js does); `over(g,u,t)` and `post(g,u,t)` draw on top;
`prep(t)` returns a Promise for anything the shot must load before it can be drawn. Sand shots add `dyn(u,t)`
returning `{blow(x,y,o), items, pour(g,u,t), scratch, clear(g,u,t)}`: blow the whole field along a wind (o gets the
displacement), pour moving shapes and grains, fingertip lines, cleared shapes; and `under` and `light` for the lamp.
`pour` can draw any picture (`g.drawImage(canvas, x, y)`): its opaque parts become sand.

The wipe, lift and settle fronts run across the set they are laid in (`tr.w`, `tr.h` override that), and moving
figures come and go with the front, like the pieces round them.

#### Actors: moving figures and moving pictures

`actors:[{id, items(u,t) | raster(u,t), relay, on(u,t), opt}]` are laid again every `relay` frames (3 reads as laid
stop motion; 1 is smooth and three times the cost), in a small crop, and set into the floor: the floor's pieces under
them are lifted out and the bare mortar shows round their edges. `u` and `t` are the time of the relay step, not of
the frame, so a laying is the same whichever frame asks for it first. `opt` goes to the laying (`fig`, `fineFace`,
`seed`, ...); the set's `mortar` and `light` are used unless it says otherwise.

- `items(u,t)` returns scene items (a figure from `figItems`, a leaf, anything), laid with `makeMosaic`.
- `raster(u,t)` returns `{img, x, y}`: any canvas or image drawn at set scale, and where its top left sits in the set.
  Its opaque part (alpha over `opt.alphaCut`, default 190) is cropped and laid with `mosaicFromRaster`, keeping its
  own colours, posterized into `opt.levels` (default 5) steps a channel. The picture can come from anywhere: a flat
  painting in code (`kitePicture` in figs.js, the demo's kite), a frame of another style's video drawn to a canvas,
  a photograph. Paint it in flat colours with strokes at least as wide as a piece and a half: thinner lines break
  up into crumbs.

```js
actors:[{id:'kite', relay:3, raster:kiteRaster, opt:{fig:5, levels:5, seed:5}}]
// kiteRaster(u,t) -> kitePicture(x, y, tilt, lineEnd, tailPhase, tailWave, size) -> {img, x, y}
```

To relay frames of another video (rendered to PNGs), load them in the shot's `prep(t)` (`await` an `Image`'s load)
and draw the one for `t` in `raster`: `step()` waits for `prep` before it draws.

#### Picks

`pick(p,u,t,i,B)` runs for every piece in every frame, so keep it cheap: `tagsOf(B)[i]` is piece i's tag, looked up
once per baked set. `driftPick(p,i,B,t,tag,{dx,dy,speed,band,low})` makes the pieces of one tag shine in bands that
travel along (dx, dy), which reads as movement: `float` dots become falling snow (`dy:1`) or, in the demo, seeds
blown downwind and up (`{dx:1, dy:-.35, speed:1.3}`).

`step(t)` finds the shot, waits for its `prep` (and the previous shot's, during a transition), draws it (and the one
before, during a transition) into the 1920 x 960 picture, then the lyric band. It returns a Promise; the render
tools wait for it, and the player draws one frame at a time. `renderAt(t)` is the same (nothing depends on the frame
before). The page sets `window.__video = {ready, duration, step, renderAt}`.

### Lyrics

`engine.js` turns `SONG.lines` into `[section, text, t0, t1]` and shows one line at a time in the band under the
picture, in italic EB Garamond, fading in 0.15 s before the line and out 0.3 s after. During the intro the band shows
`SONG.title` in Cinzel capitals and `SONG.credit` under it. The band's colours follow the medium (`BANDCOL`), blending
through a transition. The title set lays `SONG.title` itself as a mosaic inscription, one word to a beat.

### Determinism and caching

All randomness is seeded (`mulberry32`, `hashi`, fixed noise tables); nothing calls `Math.random()`. Moving figures
and pictures are laid again every `relay` frames, keyed by the step number and drawn at the step's own time, so any
frame can be drawn in any order and comes out the same. Caches (`BAKED` sets, `ACT` actor layings, per-set tags,
loose-piece sprites, reused buffers) only save time.

## Make your own video in this style

1. Copy the folder: `cp -r styles/mosaic-and-sand projects/my-song`, and put your mp3 in it (see
   [docs/your-own-video.md](../../docs/your-own-video.md)).
2. Make your song's timing file with `tools/audio/to_js.py` and point `index.html` at it instead of
   `../../examples/poem/lyrics_data.js`. `SONG.audio` should be the path to your mp3 relative to `index.html`.
3. Keep `core.js`, `figures.js`, `items.js`, `mosaic.js`, `sand.js`, `figs.js` and `engine.js`. Replace `scenes.js`,
   `sets.js` and `shots.js` with your own (the title set reads `SONG.title` and `SONG.credit`, so it works as is).
4. Add a set. Coordinates are set space, 2112 x 1056:

   ```js
   defSet('field',{opt:{fig:7,fineFace:5,bg:13,seed:3},variants:{lit:{},pale:{pieceColor:(t,M)=>mix3(t.col,[230,230,200],.5)}},
     items:()=>[Fi(rect(0,0,SW,SH),'sky','bg',{ts:13,mode:'course',echo:2}),
                Fi(wave(-10,SW+10,700,30,.003,2).concat([[SW+10,SH+10],[-10,SH+10]]),'grass','bg',{ts:12,mode:'course',echo:1,tag:'grass'}),
                ...tree(900,720,480,{bend:.2,seed:1})]});
   defSet('fieldSand',{kind:'sand',opt:{sweep:.2},items:()=>[ /* the same items, with sd hints */ ]});
   ```

   Or describe it once in `scenes.js` with both kinds of hints and use it for both (as `SCENES.hillside` is).
5. Add shots in `buildShots()`, one per picture, in time order. Put changes on line starts (`L0(i)`, the start of line
   i) and hits on beats (`beatT(n)`, or `wordT(line, word)` for the time a word is sung).
6. Time a move to a word or beat inside a shot with `sstep(a, b, t)`, e.g. `sstep(wordT(6,4)-.2, wordT(6,4)+.2, t)`
   eases a tree's bow in over 0.4 s round the word "bow". `arrive(p, t, at, sweep, fade)` (shots.js) lays pieces in
   from left to right; `beatPulse(t)` jumps to 1 on every beat and decays.
7. Make something move: a figure or a prop as an `items` actor, a picture as a `raster` actor (paint it on a canvas
   the way `kitePicture` does), a group of laid pieces as `loose`, or a whole set's pieces through `pick` (variants,
   strength, `driftPick`). In sand, pour it each frame from `dyn`.
8. Run `node --check` on every file you changed, then check stills with `tools/still.py` (read the console errors it
   prints), then render.

Useful knobs:

- mosaic `opt`: `fig` (piece size for figures), `fineFace` (faces and hair), `bg` (backgrounds), `gap` (mortar
  width as a fraction of a piece), `echo` (outline rows before courses), `light` (direction), `mortar` (colour), `seed`.
- per item: `ts`, `mode`, `echo`, `courseDir`, `mat`, `outline`.
- shading (a set's `variants`): `groutGlow`, `pieceTint`, `pieceColor` (variants for flipping pieces).
- sand `opt`: `k` (how dark thick sand is), `lamp`, `lampEdge`, `front`, `frame`/`frameW` (the rim), `grainK`,
  `sweep`, `soft` (edge softness), `under`.
- per item: `sd`, `sg`, `sr`, `sand`, and `float` on dots.
- actors: `relay` (3 = laid again every third frame: it reads as laid stop motion; 1 is smooth and three times the
  cost); for a raster actor `opt.alphaCut`, `opt.levels` (colour steps a channel) and `opt.fig` (piece size).
- `driftPick`: `dx`, `dy` (the direction the bands travel), `speed` (bands a second), `band` (their spacing in px),
  `duty` (how much of each band shines), `low` (how much of a piece shows between bands).

### Re-laying another picture ("relay")

`relaySet(fromShot, atT, opt)` in sets.js makes a custom set from any shot's picture at a moment: it renders the
shot, blurs it a little, lays it with `mosaicFromRaster`, and shades it twice (mortar glowing where the picture was
bright, low and high) to breathe between. The `reveal` transition then brings it in behind a moving line of light. The
same works for a picture from anywhere: another style's frames, a painting, a photograph drawn to a canvas. (If the
shot it renders has a `prep`, give the relay shot a `prep` that waits for it, since the relay is laid the first time
it is drawn.) A moving picture is a raster actor: it is cropped to its opaque part, laid every few frames and set
into the floor with the floor's pieces under it lifted out. To turn a picture into sand instead, pour it:
`g.drawImage(picture, x, y)` in `dyn().pour` makes its opaque parts sand (`rho = max(rho, blurred alpha)`).

## Lab

Open http://localhost:8000/styles/mosaic-and-sand/lab/index.html and pick a scene and a look (or
`lab/index.html?s=washday&st=sand`). Render them all:

```
python tools/lab_stills.py styles/mosaic-and-sand/lab/index.html --all --out renders/lab --sheet
```

The lab draws `SCENES.hillside` (with two walkers) and `SCENES.washday` (washing on a line, a weathervane) from
`scenes.js`, scaled from set space to the 1920 x 960 picture, in both looks, with a line of the poem in the band.
Each takes under a second. What each renderer does with the same items:

- **Stone mosaic** keeps every colour, lays figures fine (`fig`, `fineFace`) and backgrounds coarse (`bg`), rings
  small shapes with rows, and turns glows into warmer stones and glowing mortar.
- **Sand on a lightbox** keeps only thickness: colour becomes how dark a shape is, glows clear the sand, fingertip
  lines and cleared shapes push it aside, and anything too close in thickness to its neighbour disappears (so put
  figures on light, or clear them out of dark).

## Performance

Measured on an M-series Mac in headless Chrome with the GPU on.

- Baking a set: a mosaic set at 2112 x 1056 takes 1-2 s (20,000-27,000 pieces, plus one shade per variant); a sand
  set about 0.4 s; the relay about 3 s. Two moving figures laid again every third frame add about 10-30 ms a frame;
  the kite, a raster actor, takes about 35 ms to lay, so about 12 ms a frame (the shot with it averaged 36 ms).
- A frame (these vary by 2x with what else the machine is doing): mosaic 15-50 ms with `pick` (the per-pixel pass);
  sand 100-230 ms (the wind warp, pouring, and shading 2.2 million pixels); transitions draw both shots, 230-470 ms
  (the sand sweep is the slowest: two sand frames).
- Memory: about 260 MB of baked sets by the engine's own count (`MEM`), about 310 MB of JavaScript heap with every
  set baked. `MEMCAP` (900 MB) drops the least recently used set past that.
- What makes it slow: sand (every pixel is shaded every frame), big sets, many variants, actors with `relay:1`.
- Render a slice: `python tools/render_mp4.py styles/mosaic-and-sand/index.html --fast --start 18 --end 27`. A slice
  is exact, because no frame depends on the one before.

## Lessons and gotchas

- **Lines laid first cut across what stands in front of them.** Drawn lines (wall joints, scaffolding, a clothesline) are
  regions in the id map, and their pieces are laid only where the line is still visible after later items.
- **Smiling faces read as cute.** Faces have a flat, short mouth and a longer face.
- **Check seated poses against the chair**: thighs forward, the floor at the feet, not at the seat.
- **A solid glow shape reads as an egg yolk.** In mosaic, light is warmed stones and glowing mortar (and gold
  pieces); a solid body of light suits the sand, where it is thinner sand for the lamp to come through.
- **Lettering laid by contour is too thin to read**, and a background's outline rows make a cartouche round every
  line. Lay letters along their centre line (`skel:true`) in bold capitals, and give the panel `echo:0`.
- **Unlaid pieces show bare mortar**, so letters and shapes not yet laid show faintly in the bed, like the design a
  mosaicist draws on the setting bed. Keep it; it makes the laying readable.
- **Big regions in `'echo'` mode fill with concentric "eyes"** where the rows close up. Use `'course'` with one to four
  outline rows for skies and fields; keep `'echo'` for figures and small shapes.
- **Grain everywhere made the first sand look like a filter**, and ruler-straight edges looked drawn by machine. The
  warp, fine grain and sparse drifts fixed it; palm sweeps turned up too high look like wood grain.
- **Don't marble the sand.** Warping the whole field with a displacement that changes quickly across the picture
  turns sand into marbled paper and mangles the drawing. Keep the warp small and smooth, and show wind with grains,
  wisps and shapes that bend.
- **Grains as uniform dashes look like Morse code**; vary their size, length and opacity. Wisps as lines read as
  cartoon speed lines; trails of scattered grains read as sand.
- **Dark figures on dark sand vanish.** Clear them out (`sand:'clear'`), which is also how sand is really drawn. A
  figure poured in front of something as thick (trees behind a walker) vanishes too: keep what stands behind a
  moving figure thinner and paler, or smaller.
- **A cleared line or doorway looked flat and digital**: sand pushed perfectly clear looks cut by a machine. Clearings
  keep a ridge of pushed sand at their edge, a few grains left behind and a faint film over their floor (the engine
  does this for every `scratch` and `clear`); give a cleared shape a wobbling edge (jitter its outline with `vn2`) and
  warm light under it.
- **Light under the glass doesn't come through thick sand.** A glow laid under dark ground barely shows; thin the
  sand where the light should come through (an `sr` ramp that is thin in the middle), then turn the light up.
- **Short straight fingertip marks read as rain**; small arcs read as leaves.
- **Long strokes read as tubes** (smoke especially). Overlapping puffs read as vapour.
- **Posterizing a one-colour picture by colour** splits its gradients into mottled patches. Blur it, and posterize by
  brightness (`lumOnly`).
- **`echo:0` was ignored** because `0 || 3` is 3; use `x != null ? x : default` for numeric options.
- **Pieces laid from text or rasters need their own direction and item**: a missing `dir` made `Math.cos(undefined)`
  NaN and silently dropped every course piece; centre-line letters with no `item` couldn't be found by tag.
- **Dots over a region cut holes in it**, and the region's rows ring each hole like a bubble (snow over a wall looked
  like foam). Mark them `float:1`: they are laid as single pieces among the region's own.
- **Moving figures stayed solid during a lift**, floating over the sand while the pieces round them flew off. They
  now come and go with the transition's front.
- **Lay an actor at its relay step's time, not the frame's**: laid from the time of whichever frame asked first, a
  still and a render could lay the same step differently.
- **A picture relayed as tesserae needs flat colours and thick strokes.** It is posterized into regions and laid with
  pieces of `fig` px; a line thinner than a piece and a half breaks into crumbs, and soft shading turns to confetti.
  Keep the picture small (the laying is cropped to its opaque part, and its cost grows with the crop): the demo's
  kite with its line and tail takes about 35 ms to lay, so re-laid every third frame it adds about 12 ms a frame.
- **A kite's tail that runs down from it reads as a second line.** Stream it downwind, nearly level, short, with bows.
- **`walking()` let its options overwrite the walk pose**, so a walker given an arm pose stopped walking. Options are
  merged into the pose now; keep that pattern (`const {pose, ...rest} = o`) in your own builders.
- **`wave()` drawn right to left returned nothing**, so a band made from two wavy edges (the second one reversed) came
  out as a thin line. It now works in either direction.
- **`-x**2` is a syntax error in JavaScript** (a minus directly before `**`), and one error silently stops the whole
  file, so every set in it vanishes. Write `-(x**2)`, and run `node --check` on each file before taking stills.
- **In a close-up, draw what a small figure gets away without**: a face in profile needs its chin clear of the neck,
  and a hand that hangs needs its fingers, or they read as lumps.
- **Hold the plate's rim still** when blowing sand (`edgeHold` in shots.js), or the dark rim smears inward.
- **Nothing should sit still for more than a beat or two**: a second of stillness reads as the player freezing. When
  an effect passes, let a weaker one trail it.
- **Keep the camera inside the set**: views are clamped, and a zoom below `OW/SW` would show past the edge.
- **A `*/` inside a comment** (a path like `frames/*/`) ends the comment early and silently breaks the page.
- **Read the console after every still**: one bad value in a canvas gradient blanks the whole frame.
- **Per-pixel callbacks must not allocate**: `glow`, `under` and `blow` run for up to two million pixels a frame.
  Return one reused array (`GB`, `UB` in shots.js), and look tags up once (`tagsOf`) rather than per piece per frame.



===== 完整公共规范：CLAUDE.md =====

# Instructions for Claude

This repository makes music videos in code: each style in `styles/` is an engine that draws every frame on an HTML
canvas (or WebGL / three.js) in a hand-made-looking medium, timed to a song, and `tools/` renders them to MP4. Read
`README.md` for the map, then the doc for whatever you're doing.

## When someone wants a video for their song

Follow [docs/workflow.md](docs/workflow.md). It's a conversation, not a build order to rush through:

1. **Get the inputs:** the song (mp3), the lyric sheet as sung, and ask whether they have stems and MIDI (Suno and
   stem splitters provide them) and any reference images.
2. **Ask the concept questions before building anything:** who is singing, who "you" is, whose voice the chorus is,
   what the key images (especially the ending) mean, how much the video may show, what stays out. Don't guess at
   these; an open question is better than a confident wrong answer. If the song belongs to a larger world, read
   whatever they give you about it, and keep a list of every detail the video invents, flagged as unconfirmed.
3. **Measure the song** ([docs/timing.md](docs/timing.md)): tempo, sections, stops and hits, and every word's time.
   Time to the audio, not to the lyric sheet's markings.
4. **Pitch three looks and recommend one:** the medium and why it suits this song, the organizing object, a small
   visual grammar and an arc, a section-by-section plan keyed to timestamps, and the open questions. The styles in
   `styles/` are the starting points (each README says what it's good at); a new medium is fine too
   ([docs/engine-patterns.md](docs/engine-patterns.md)).
5. **Style lab:** the same three or four moments drawn in each candidate look. Show the stills.
6. **Checkpoint:** build one section (20-90 s), render it (`--fast`), send it, get notes.
7. **Build the rest** section by section, then render the final MP4s. The MP4 is what gets shared.

Build a project in `projects/<song-slug>/`, copied from a style folder ([docs/your-own-video.md](docs/your-own-video.md)).
Don't change `styles/` for one person's video. Keep notes in `projects/<song-slug>/PLAN.md` as you go: their answers
and rulings, the measured sections and sync points, the shot list, the invented details, and their feedback on each
round. A later session should be able to pick up from that file alone.

## Working practices

- **Look at what you render.** Make stills and contact sheets (`tools/still.py ... --sheet`) and open the images.
  Check every frame on the sheet: edges, blank frames, the camera inside things, covered text, long freezes.
- **Read the console output** the tools print. A single bad canvas gradient value blanks a frame.
- **Preview slices with `--fast`**; render the full 1080p only at the end. Styles that carry state between frames
  must be rendered in order (the tools do this).
- **Keep it deterministic:** seeded randomness keyed to the frame, never `Math.random()` per frame.
- **Follow the page contract** in [docs/rendering.md](docs/rendering.md) (`window.__video`, `window.SONG`,
  `<canvas id="film">`, `#t<seconds>` stills) so the tools work.
- Apply the lessons in [docs/workflow.md](docs/workflow.md#what-the-notes-taught-true-for-every-style): busy
  enough, no long freezes, obvious changes, varied choruses, whole figures rather than close-up hands.
- The person's audio is git-ignored. If their lyrics or story are private, keep the project out of any public
  remote (add it to `.git/info/exclude`, or keep it outside the repo and pass `--root` to the tools).

## Setup

```bash
python3 -m venv .venv && .venv/bin/pip install -r requirements.txt -r requirements-audio.txt
```

Google Chrome must be installed (or `.venv/bin/python -m playwright install chromium`). To preview in the desktop
app's browser pane, create `.claude/launch.json` running `python3 tools/serve.py 8000` on port 8000 (git-ignored).
Use the server, never `file://`: module pages don't load from files and a plain server caches stale scripts.



===== 完整公共规范：docs/workflow.md =====

# How a video gets made

These videos were made in conversation: a person with a song and a clear sense of what it's about, and Claude
writing and rendering the code. The process below is what worked over a dozen songs. It suits working with Claude
Code (see [CLAUDE.md](../CLAUDE.md), which tells Claude to follow it), and it works just as well by hand.

The short version: **decide what the song is about, measure it, pitch three looks, test the look on a few scenes,
build one section, get notes, then build the rest.** Each step is cheap next to the one after it, so mistakes get
caught while they're still cheap.

## 1. Gather the inputs

- **The song** as an mp3 (or anything ffmpeg reads).
- **The lyric sheet** as plain text, one sung line per line, with `#section` markers (see
  [examples/poem/lyrics.txt](../examples/poem/lyrics.txt)). Write it the way it's sung: if the singer repeats a line
  that isn't on the sheet, add it.
- **Stems, if you have them.** An isolated vocal stem makes transcription far cleaner. Suno exports stems as audio
  and as MIDI per instrument; the MIDI's tempo map gives an exact beat grid, and the vocal MIDI gives note onsets to
  snap words to (see [timing.md](timing.md)).
- **Reference images, if any.** Mood boards and concept art are useful for content (what's in the world, what
  people wear, what the place looks like) even when the style will be different.

## 2. Decide what the song is about

Before any pictures, answer the questions that decide the concept. A video can't be good if these are guesses.

- **Who is singing,** and to whom? Who is "you"? It's often not who it seems, and it can change between verses.
- **Whose voice is the chorus?** The singer's, an imagined audience's, a crowd's, a custom's?
- **What do the key images mean?** Especially the closing one.
- **How much may the video show?** If the song belongs to a larger story, what would be a spoiler?
- **What stays out?** Eras, events, people, kinds of imagery.

If the song is part of a larger world (a novel, a game, a band's mythology), read up on it first, and **keep a list
of every detail the video invents**: a place's layout, what a prop says, who stands where. Show that list to
whoever owns the world, and treat nothing on it as settled until they say so.

## 3. Measure the song

Time the video to what the audio does, not to what the lyric sheet says. (AI song generators in particular ignore
markings like "quiet" or "almost unaccompanied".) With the tools in [timing.md](timing.md):

- tempo, and whether it changes;
- the sections and their loudness: which chorus is the big one, where it drops to almost nothing;
- **the stops and hits.** Musical stops, dropouts and the hit that ends a bridge make the best sync points: the
  place to freeze, cut, switch a light off, or change the whole picture;
- every word's time.

## 4. Pitch three looks

Offer three directions and recommend one. For each:

- **the medium** (paper cut, embroidery, marbled paper...) and why it suits this song. The strongest choices mean
  something: marbled paint for a song about water, where nothing stays put; a lantern lecture for a song sung by
  someone lecturing; a desk of files and stamps for a song about a record that doesn't add up;
- **the organizing object:** the one thing the whole video is, such as a desk under a lamp, a hanging read along
  its length, a printed sheet, a painted wagon's panels, a board of pasted-up photographs;
- **a small visual grammar:** a few rules that give the images meaning (stamps are the audience's verdicts, frost
  is the stillness, the camera's date flickers between years), and an **arc** over the song (clean to decayed,
  night to morning, empty to crowded);
- a **section-by-section plan** keyed to timestamps, giving each section one main image;
- the questions still open.

The [styles/](../styles) folder has eighteen engines to start from, and each one's README says what it's good at.
A new song can also want a new medium: the engines share their patterns ([engine-patterns.md](engine-patterns.md)),
so a new one is less work than it sounds.

## 5. Style lab

Draw the same three or four key moments in each candidate look, side by side, as stills (and a few seconds of motion
if the look depends on how it moves). Comparing like with like makes the choice easy, and it shows the problems
early: people who look like mannequins, faces that look ill, a palette that turns cute. Every family here with more
than one look has a lab page (`styles/<family>/lab/`) built this way.

Expect the first choice to be refined: "this look, but with the other one's colours", or "this, for the scenes in the
other world only". Mixing is fine.

## 6. Checkpoint

Build a real section before the whole song: 20-30 seconds of the section that carries the concept, or the first
90 seconds. Render it as an MP4 and get notes on the look, the pace, the figures, the text. This is where most of
the useful notes arrive, and they're cheap to act on now.

## 7. Build the whole song

Section by section. After each, render stills across it (`tools/still.py ... a:b:2 --sheet`) and look at every one:
frame edges, blank frames, things the camera cuts through, text that's unreadable or covered. Fix, then move on.
When it's all there, render the MP4, then scan it at one frame every two seconds.

## 8. Notes, and fixing a stretch

Notes on a full video are usually local: one stretch feels empty, one chorus repeats the last, a transition jerks.
Re-render only that slice and splice it in ([rendering.md](rendering.md#fixing-one-stretch)).

## 9. Deliver an MP4

Share the MP4, not the web page. A browser player's pause and scrub can feel unreliable, and people give up on it.
`tools/render_mp4.py` writes a 1080p file and a smaller 720p one for sending.

## 10. Revising a finished video

A second or third pass (new conventions, a list of fixes, a stretch that needs more going on) works best as: a short
written plan of every change; then before/after sheets, stills from the old render and the new build at the same song
times side by side; then the full render. The sheets let the notes land on exactly what changed. When picking stills
for review, catch short effects at their peak: a flash or a bolt that lasts half a second is easy to miss.

## What the notes taught (true for every style)

- **Busy enough.** Something new on nearly every beat, or at least every line. A stretch with nothing happening
  reads as a mistake, not a rest. When a stretch feels empty, fill it with callbacks (translucent overlays of earlier
  scenes) and background life (children, animals, people passing) rather than restaging it.
- **No long freezes.** A four-second still reads as the player stalling. Keep holds to a beat or two, or keep
  something drifting: a slow camera move, breathing light, smoke.
- **Make small changes obvious.** A face swapping for another face, a detail changing on a paper: if it matters,
  make it big and push the camera in on it. Subtle changes go unseen.
- **Too clean reads as dead.** A video that stays tidy all the way through can feel flat; give it an arc.
- **Vary the repeats.** The second chorus shouldn't replay the first. New scenes, with brief flashes back to the
  first chorus's pictures on key words, keep the echo without the repetition. A motif that does something different
  each chorus (ribbons that knot, then plait, then slip) works well.
- **Whole figures beat close-up hands.** Big silhouettes of hands and arms read as clubs, poles or chess pieces. A
  whole figure, even small and mostly still, carries a beat better.
- **Faces:** realistic halftone or heavy shading can make people look ill. Stylized faces (dot eyes, lowered lids
  when looking down) for close figures and blank faces for crowds read better.
- **What makes a look cute** (sometimes wanted, often not): flat candy fills, rounded sack-shaped figures with blob
  heads, even lighting, bobbing walks. For solemn songs, use weight, texture, uneven light and stillness instead.
- **Real texts make good props.** A period document, a real letter or hymn, an actual map give a scene weight even if nobody
  can read them.
- **Impossible places need ordinary things in them.** Floating or folded land only reads as land when it carries
  trees, lit windows, snow on its ground side, smoke going the "wrong" way.
- **Decide about text in the picture.** A lyric band under the picture is one choice; no readable text at all
  (squiggles for writing) is another; either way, be consistent. Captions that only repeat the lyric are redundant.
- **Fake text is worse than no text.** A card of invented glyphs that flickers reads as a screen of foreign writing.
  Use pictograms, squiggles, or nothing. Likewise on-screen read-outs (temperatures, timecodes) in a "technical"
  medium: keep them only if they mean something.
- **Show the medium working.** When a look risks feeling static (a photograph, a print, a drawing), let the viewer
  watch it being made: a plate exposing, inks printing in on the beats, stitches sewn in, a slide pushed into the
  lantern. It answers "static and unclear" without changing the look.
- **Vary what leads a scene.** In a medium with a life of its own (liquid light, marbling, sand), let some scenes be
  led by the pictures and some by the medium, rather than the same mix throughout.
- **Props must sit in hands.** A rope, a ring, a cloth or a cup that floats near a hand reads as broken. Anchor held
  things to the rig's hand points and check every one in stills.
- **Arms that move naturally:** pose them by where the hand and elbow should be, blend joint angles rather than
  positions, let the forearm trail the upper arm, and add breathing and small weight shifts. Arms that slide
  straight between poses look like a puppet's.
- **Bodies carry identity.** In silhouette, heat or other outline-first looks the outline is all a viewer gets: if
  someone is heavily built, or small and round, the shape must show it. Keep sizes consistent (an animal is as big in
  every shot).
- **Shapes read as other shapes.** A figure lying flat reads as a collapsed body (have them sit or doze upright unless
  a death is meant); a pyramid of sacks in a lit doorway reads as a hooded head; a fan of hair strands reads as a
  feathered headdress. Look at every silhouette as a stranger would.



===== 完整公共规范：docs/timing.md =====

# Timing a song

Everything in a video hangs off the song's clock: the lyric band lights each word as it's sung, pieces land on
beats, scenes change on line starts, the lamp goes out in a dropout. This page is how to get those times. The tools
are in [tools/audio/](../tools/audio); each prints its own help with `--help`.

Setup (once): `pip install -r requirements-audio.txt` (librosa, scipy, faster-whisper, mido). The Whisper model
downloads the first time it's used.

## The pipeline

```bash
# 1. the shape of the song: tempo, loudness, sections
python tools/audio/analyze.py song.mp3

# 2. words with timestamps, from the vocal stem if you have one
python tools/audio/transcribe.py vocals.mp3 --lyrics lyrics.txt --out whisper.json

# 3. your lyric sheet matched to Whisper's words
python tools/audio/align.py lyrics.txt whisper.json --out lines.json

# 4. snap each word to where the voice starts it (vocal MIDI and/or vocal audio)
python tools/audio/snap.py lines.json --midi vocals.mid --audio vocals.mp3 --out snapped.json

# 5. the page's data file
python tools/audio/to_js.py snapped.json --out projects/my-song/lyrics_data.js --title "My Song" \
    --audio song.mp3 --audio-file projects/my-song/song.mp3 --bpm 96 --beats-per-bar 4
```

Then open the video with the lyrics showing and listen through. Fix what's off by editing `lyrics_data.js`
directly: it's plain data.

## Step by step

### 1. The shape of the song

`analyze.py` prints the global tempo and the local tempo every 20 s, a table of loudness, brightness and rhythmic
busyness every few seconds, and guesses at section boundaries. Read it next to the lyric sheet. You're looking for:

- which sections are loud and which drop out: the video's big and quiet moments should follow them;
- tempo changes (a slow intro, a half-time bridge);
- **stops and hits.** `onsets.py song.mp3 --from 140 --to 155` zooms in on a stretch: the strongest onsets, the
  beats, and the loudness every quarter second, so a dropout shows as a run of low numbers. These are the best
  sync points a song offers: the place for everything to freeze, for a cut, for a light to go off.

`sections.py song.mp3 --lines lines.json` compares the sections' loudness, drums and tonal energy once you know
where they are.

### 2. Transcribe

`transcribe.py` runs faster-whisper with word timestamps. Give it the **vocal stem** if there is one; sung vocals
over a full mix transcribe much worse. The `small` model is usually enough and takes about a minute. `--lyrics`
passes the start of your lyric sheet as a prompt, so names and odd words come out spelled your way. `medium` can
rescue mumbled lines, but over a long song it can drift further than `small`.

Expect Whisper's times to run **early**, typically a few tenths of a second and sometimes by more than a second,
and to hear some words wrong, especially names and unusual words. Step 3 doesn't care about wrong words; steps 4 and
the listen-through fix the times.

### 3. Align

`align.py` lines your sheet up against Whisper's words (a sequence match, so misheard or missing words don't break
it; unmatched words get times interpolated from their neighbours). It prints each line with a match count like
`m7/9`. Low counts are where to listen first. Watch for:

- **numbers:** Whisper writes "1974" as one token for three sung words. The script spells out years and small
  numbers before matching, but check them;
- **hyphenated words** and contractions;
- **a misheard last line** ("Let it go" for "Letting go"): the end of a song, over a fade, is where Whisper guesses;
- **repeats and ad-libs** the singer added: put them on the sheet as sung, or they'll be squeezed between
  neighbours.

### 4. Snap to the voice

`snap.py` moves each word to the nearest sung-note onset within 0.32 s: note onsets from the **vocal MIDI** first
(if you have it), then onsets detected in the **vocal audio**. It first reports the median offset between the words
and the onsets; if Whisper ran early across the whole song, pass that back as `--shift` so everything moves before
snapping.

After snapping, some things still need a human ear:

- **line starts that land in silence** or on the tail of the previous word: move them to where the voice comes in;
- **choruses and held notes:** a melisma or a long held word confuses onsets;
- **MIDI quantization:** Suno's MIDI is quantized to sixteenth notes and can sit about 0.3 s off the voice.

For those, `onsets.py vocals.mp3 --from 25 --to 27 --pitch` prints the sung pitch and loudness every 50 ms: the
word starts where the pitch appears and the loudness jumps.

### 5. Write the page data

`to_js.py` writes `lyrics_data.js`, which sets `window.SONG`:

```js
window.SONG = {
  title: "My Song", credit: "", audio: "song.mp3", duration: 212.4,
  bpm: 96, beatsPerBar: 4, firstBeat: 0.35,
  sections: [["verse1", 12.3, 41.0], ...],
  beats: [0.35, 0.975, ...],            // only with --beats: exact beat times
  lines: [{section: "verse1", text: "Who has seen the wind?", t0: 12.3, t1: 14.9,
           words: [["Who", 12.3], ["has", 12.9], ...]}, ...],
};
SONG.beat(n)  // the time of beat n
```

Every style in this repo reads that shape (see [examples/poem/lyrics_data.js](../examples/poem/lyrics_data.js)).

## Beats

For a steady song, `--bpm` and `--first-beat` (the time of the first downbeat) are enough: `SONG.beat(n)` is
`firstBeat + n * 60 / bpm`. Find the first beat with `onsets.py` on the song's opening seconds.

If the tempo drifts or changes, use exact beat times instead:

- **from MIDI stems:** Suno writes a tempo event on every beat, so the tempo map is an exact beat grid.
  `midi.py drums.mid --beats-out beats.json` (any of the song's MIDI files will do);
- **from the audio:** `analyze.py song.mp3 --beats-out beats.json` (librosa's estimate; check it).

Pass the file to `to_js.py --beats beats.json`; `SONG.beat(n)` then reads from the list.

## Hits and loudness

Some styles pulse, flash or move with the music itself rather than the words: a lamp that breathes with the mix, a
ring on every drum hit, mouths that open with the voice. `pulses.py` measures those:

```bash
python tools/audio/pulses.py song.mp3 --percussion perc.mp3 --drums drums.mp3 --vocals vocals.mp3 --out projects/my-song/audio_data.js
```

It writes `window.AUDIO = {fps, ticks, kicks, env, venv, vdb}`: small hits (`ticks`) and big ones (`kicks`) as
`[time, strength]`, the mix's and the voice's loudness 24 times a second (`env`, `venv`, 0..1), and the voice's
loudness in decibels mapped to 0..1 (`vdb`, better for mouths). Stems give much cleaner hits than the mix; without
them everything comes from the mix. The liquid light show reads this file as it is; any style can read the arrays.

## Suno specifics

- The stem download gives an audio file and a MIDI file per instrument. The lead vocal stem transcribes cleanly.
- The MIDI files carry a key-signature event that the `mido` library can't decode (it raises
  `KeySignatureError`). `tools/audio/midi.py` patches mido to read it as C; import `load()` from it in your own
  scripts to get the fix.
- The MIDI tempo map has one event per beat: an exact beat grid, including tempo changes after an intro.
- Vocal MIDI notes are quantized and can sit up to ~0.3 s off the voice: good anchors for snapping, not ground truth.
- Suno ignores dynamics on the lyric sheet ("quiet", "spoken", "almost unaccompanied"). Measure.

## Checking by eye and ear

Open the page, play it with the sound on, and watch the lyric band. Words that light up early are the common
fault. For a close look, `#t25.3` on the page's URL shows the frame at 25.3 s with the band as it is then.



===== 完整公共规范：docs/rendering.md =====

# Previewing and rendering

Every video here is a web page that draws its frames on a canvas. You watch it in a browser while you work, and
when it's done a script steps through it frame by frame in headless Chrome and pipes the frames to ffmpeg. This
page covers the page contract the tools rely on, previewing, stills, MP4s, and fixing a stretch.

Setup (once): `pip install -r requirements.txt` (Playwright, imageio-ffmpeg, Pillow, numpy). The tools drive your
installed Google Chrome; if you don't have it, `python -m playwright install chromium` gets Playwright's own.
imageio-ffmpeg bundles an ffmpeg with x264 and AAC, so there's nothing else to install.

## The page contract

A video page (a style's `index.html`, or a copy of one for your song):

- draws into `<canvas id="film" width="1920" height="1080">`;
- loads its song data as `window.SONG` (see [timing.md](timing.md#5-write-the-page-data)) and plays `SONG.audio`
  in an `<audio>` element, falling back to a silent clock if the audio can't load;
- sets `window.__video`:
  - `ready`: true once everything is built;
  - `duration`: the song's length in seconds;
  - `step(t)`: draw song time `t` the way playback does. The MP4 renderer calls it at 24 fps, strictly in order;
  - `renderAt(t)`: draw a still of time `t` from a fresh state (catching up whatever the frames before it built);
  - either may return a Promise (a page that builds scenes asynchronously); the tools wait for it;
  - `error`: set this to the error text if building fails, and the tools stop and print it;
  - optionally `shots` and `probe(t)` for 3D pages (see `tools/probe.py`);
- shows a still when the URL ends in `#t<seconds>` (e.g. `index.html#t12.5`), with the page chrome hidden;
- draws only while playing: a paused player shouldn't keep redrawing its frame on every animation frame (the tools
  draw and read back each frame in one call, but a page that redraws on its own fights anything else that draws);
- is **deterministic**: all randomness comes from seeded generators keyed to the frame number, never
  `Math.random()` per frame, so a given moment always draws the same picture. An MP4 depends on it.

A style-lab page sets `window.__lab = { ready, scenes, styles, render(scene, style) }`, where `render` draws one
scene in one look and returns the canvas.

## Previewing

```bash
python tools/serve.py            # serves the repository at http://localhost:8000/ and lists the demo pages
```

Open a page from the list. Use this server rather than `python -m http.server` or opening the file directly:

- pages that use ES modules or load files **don't work from `file://`**;
- a plain server lets the browser **cache scripts**, so after an edit you can be looking at the old code. This
  server sends no-cache headers;
- audio and video only seek when the server answers **Range requests**; this one does.

**Stills in the browser:** add `#t<seconds>` to the URL. Changing only the `#` part doesn't reload the page, so
after editing code, reload with a new query (`index.html?r=2#t30`).

**Always check the console** after a load. One bad value in a canvas gradient (a NaN colour stop) throws, and the
whole frame goes blank.

**In Claude Code's desktop app**, the preview pane can run the server for you: create `.claude/launch.json` with
```json
{ "version": "0.0.1", "configurations": [
  { "name": "videos", "runtimeExecutable": "python3", "runtimeArgs": ["tools/serve.py", "8000"], "port": 8000 } ] }
```
(it's git-ignored).

## Stills and contact sheets

```bash
python tools/still.py styles/paper-cut/index.html 5 12.5 30          # three stills
python tools/still.py styles/paper-cut/index.html 0:37.5:2.5 --sheet # a frame every 2.5 s, tiled into one image
python tools/lab_stills.py styles/embroidery/lab/index.html --all --sheet
```

Output goes to `renders/` (git-ignored). The contact sheet is the fastest way to review a whole video: look at every
frame on it, not just the ones you changed. Things to look for: frame edges showing the end of the world, blank or
black frames, the camera inside an object, text covered or cut off, two scenes' seams, something frozen too long.

## MP4s

```bash
python tools/render_mp4.py styles/marbling/index.html                    # renders/marbling.mp4 and -720p.mp4
python tools/render_mp4.py projects/my-song/index.html --out "renders/My Song.mp4"
python tools/render_mp4.py projects/my-song/index.html --start 60 --end 90 --fast   # quick preview of a slice
```

- Two files: 1080p (x264 `slow`, CRF 23, AAC 192k: roughly 5 Mbps for a busy picture) and `-720p` (CRF 25: about
  1 Mbps, small enough to send).
- `--fast` writes only the 720p with the `veryfast` preset. Busy, grainy frames can take many times longer to
  encode with the slow preset than to draw, so use `--fast` for previews and the normal mode for the final.
- The audio comes from `SONG.audio` unless you pass `--audio`. A slice gets short audio fades.
- **Fonts:** the styles load their type from Google Fonts. If a font request fails (a flaky network), canvas text
  silently falls back to a default font, so `render_mp4.py` and `render_frames.py` check the page's fonts after it
  builds and stop if any failed. Run again, or pass `--allow-font-fallback` if you really mean it. The still tools
  print a warning instead.
- 24 fps. Frames are rendered **in order**: many styles draw each frame over the one before (frost that grows,
  ghosting, marbled paint that keeps its history), so a frame can't be drawn on its own.
- Speed depends on the style and on how much the machine is doing: from about 40 ms a frame (paper cut, painted
  enamel, archive desk) to 250 ms or more (sand, the pinscreen, screenprint's printing), including reading the frame
  back and encoding. Each style's README gives its numbers. A four-minute song is 5,760 frames: a few minutes for the
  fast styles, half an hour or more for the slow ones (see the next section for splitting a render across browsers).

## Long renders: frames on disk, resumable, in parallel

For a long song in a slow style, render the frames to a folder instead of straight into ffmpeg:

```bash
python tools/render_frames.py projects/my-song/index.html --dir renders/frames/my-song --jobs 3
python tools/encode.py renders/frames/my-song --out "renders/My Song.mp4"
```

- Frame `i` is `<dir>/<i:05d>.jpg` and shows song time `(i + 0.5) / 24`. Frames already on disk are skipped, so an
  interrupted render continues where it stopped when you run the same command again, and deleting a stretch's
  frames and re-running redoes just that stretch.
- `--jobs N` renders N runs of frames in N browsers at once. Each run starts with `renderAt()` at its first frame,
  which catches up styles whose frames depend on earlier ones, then steps in order. (Tested: a resumed run's frames
  match a straight-through render pixel for pixel.) GPU-heavy styles gain less, since the browsers share one GPU.
- `encode.py` takes the audio from the folder's `meta.json` (the page's `SONG.audio`), cuts it to the frames on
  disk, and writes the same 1080p and 720p files as `render_mp4.py`.
- **A render that sits before its first frame** is usually the machine, not the page: with other renders or heavy
  WebGL pages running, Chrome can take minutes to start or to build a page. `render_mp4.py` prints the page's URL when
  it's loaded and a progress line every 240 frames.
- **Heavy 3D pages:** building every set of a long WebGL video at once can hang the GPU. Render such a video in
  segments (`--start`/`--end` runs into the same frame folder, each run building only what its stretch needs), and
  on a machine that other renders are sharing, run one segment at a time.

## Fixing one stretch

A full render can take a while. To fix one stretch, render only that slice at full quality and splice it into the
finished file at whole frames:

```bash
python tools/render_mp4.py projects/my-song/index.html --start 120 --end 135 --out renders/fix.mp4
python tools/splice.py "renders/My Song.mp4" renders/fix.mp4 --at 120 --out "renders/My Song v2.mp4"
```

A slice opens with `renderAt(t)`, which catches up styles whose frames build on earlier ones, so its frames match the
full render's and the splice is seamless.

## Checking a 3D video's framing

`python tools/probe.py styles/diorama/index.html` asks the page, for the start, middle and end of every shot,
whether anything stands between the camera and its subject, or whether the camera is inside something. In a crowded
set it finds blocked views much faster than contact sheets.

## Sharing

Share the MP4. If you also want a review page (the video with notes around it), keep in mind that some hosts cap
file sizes: split a long 720p video into parts at scene changes and play them in sequence against the song, and
serve it from something that answers Range requests.



===== 完整公共规范：docs/your-own-video.md =====

# Making a video for your own song

The hands-on steps, from an mp3 to an MP4. For the creative side (what to decide before building, how to pick a
look) see [workflow.md](workflow.md). If you're working with Claude Code, you can just ask it to make a video for
your song: [CLAUDE.md](../CLAUDE.md) walks it through all of this.

## 1. Set up

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt            # rendering
pip install -r requirements-audio.txt      # timing a song (Whisper, librosa, MIDI)
```

You need Google Chrome installed (or run `python -m playwright install chromium`).

## 2. Start a project folder from a style

Pick a style from the [gallery](../README.md#the-styles) and copy its folder:

```bash
cp -r styles/paper-cut projects/my-song
cp ~/Music/my-song.mp3 projects/my-song/song.mp3
```

Audio files are git-ignored, so your song stays out of the repository.

In `projects/my-song/index.html`, change the lyrics script from the demo's
```html
<script src="../../examples/poem/lyrics_data.js"></script>
```
to your own
```html
<script src="lyrics_data.js"></script>
```
(Relative paths from `projects/my-song/` resolve just as they did from `styles/<style>/`, so anything else the
page loads from the repo keeps working.)

## 3. Time the lyrics

Write the lyric sheet (`projects/my-song/lyrics.txt`, one sung line per line, `#section` markers), then run the
pipeline in [timing.md](timing.md). It ends with `projects/my-song/lyrics_data.js`.

## 4. Look at it

```bash
python tools/serve.py
```

Open `http://localhost:8000/projects/my-song/index.html`. The demo's scenes now play under your lyrics for as long as
the demo lasts. That's the moment to decide the plan: which scene goes where, which line lands on which image.

## 5. Replace the demo's scenes with yours

Every style's README has a "Make your own video in this style" section that says which files are the demo (its
scenes, sets, shots or timeline) and which are the engine. Keep the engine; rewrite the demo files. Work a section
at a time:

```bash
python tools/still.py projects/my-song/index.html 30:60:2 --sheet   # stills every 2 s across 0:30-1:00
```

Look at every still on the sheet. Check the console output printed at the end.

## 6. Render

```bash
python tools/render_mp4.py projects/my-song/index.html --start 30 --end 60 --fast   # a quick 720p preview
python tools/render_mp4.py projects/my-song/index.html --out "renders/My Song.mp4"  # the final, 1080p + 720p
```

To fix one stretch later without re-rendering everything, see
[rendering.md](rendering.md#fixing-one-stretch).



===== 完整公共规范：docs/engine-patterns.md =====

# How the engines are built

The eighteen engines in [styles/](../styles) share no code at run time: each folder is self-contained, written for one
song in one medium (a few began as copies of another's files, such as the 3D pipeline or the ray-marched figure). But they
share a shape, and knowing it makes any of them easy to read and a new one quicker to write. This page is that
shape, plus the browser gotchas that cost the most time.

## Simulate the process, not the look

Each engine models how its medium is physically made, and the imperfections come out right on their own:

| medium | what the code does |
| --- | --- |
| screenprint | each ink is a stencil mask plus a halftone; inks are pulled one at a time and multiplied onto paper, each a little out of register, with squeegee streaks and pinholes |
| linocut | a block is a list of gouge cuts and inked areas; the key block prints black over watercolour washes |
| wool embroidery | wool is laid and couched from tiles, outlines are stem-stitched, light is couched gold thread |
| marbled paper | paint floats as closed outlines on a bath; drops, combs and swirls are exact maps applied to every point |
| magic lantern | slides are baked as tinted glass; a frame stacks glass by multiplying and throws it through a lens |
| painted enamel | two-colour bristle strokes with a highlight flick toward the light, then gold leaf |
| paper cut | cut shapes with a lit rim and a soft shadow, layered in depth and lit from behind |
| mosaic | tesserae are laid in rows along the outlines, then grouted |
| sand on a lightbox | sand thickness is a density field; the lamp shows through as `exp(-k * thickness)`; fingers clear lines |
| carved diorama | each piece is a signed-distance sculpture meshed in the browser; tool marks are a bump in the piece's own space |
| photomontage | photographs are painted in greys, then given a print's grain, halation and tone curve, and cut out with drifting scissors |
| pinscreen | a field of pins at different heights, lit from a low angle, each pin's shadow falling on the next |
| archive desk | every paper is pre-rendered with its shadow, grain, foxing and torn fibres; stamps are inked, then eroded |
| night poster | a shape's shadow is the band a shifted copy of it fails to cover; night mixes colours toward navy while lamps keep their brightness |
| batik | a real 3D set lit by two coloured lamps is rendered into buffers; wax resists where both lamps reach, each dye takes where only one does, and the wax cracks |
| long-exposure glass plate | each frame integrates many light drawings over the exposure, so whatever moved is a smear and whatever stood still is sharp; then halation, dust and the emulsion's edge |
| silverpoint | even hatching whose weight follows the tone; lines can't be erased, and tarnish from grey to brown with age |
| carved relief | the scene becomes a height field, shaded by a raking light with its own cast shadows |
| liquid light show | oil, water and dye in a dish on a projector: warped-noise dye bands, metaball oil drops with a meniscus, and drawn transparencies whose black ink really blocks the lamp |
| thermal camera | a scene rendered as temperatures and mapped through a camera palette, with a thin visible-light edge overlay, warm breath and fading heat prints |
| showboat stage | painted flats given brushwork by a sampled-stroke pass, lit by a light map in which the actors are lit through their own silhouettes |

A filter that makes a clean digital picture look like linocut never convinces for long. A few rules about how the
real thing is made go much further.

## One frame

Almost every engine's frame function looks like this:

```
renderFrame(t):
  shot = the shot covering t
  set  = shot.set, baked on first use           (the still layers: land, buildings, background)
  cam  = shot.cam(t)                            (keyframed, eased)
  draw the set's layers through the camera       (parallax: nearer layers move more)
  draw what moves at t                           (figures, props, light, weather)
  post: light (a multiplied lamp or light map), grain, vignette, the medium's texture
  if t is inside a transition: draw the next shot too and mix (dissolve, wipe, push)
  the lyric band / margin / caption for t
  fade in and out at the ends
```

The canvas is 1920x1080. Several styles keep the picture above a band for the lyrics (e.g. 1920x960 + 120).

## Sets, shots, cameras

- **Sets** (or scenes, worlds, plates) are places. Their still parts are drawn once into offscreen canvases the first
  time they're needed ("baked"), then only composited. Keep a memory budget: the whole song's sets rarely fit at
  once, so drop the least recently used. Bake at load what the first seconds need, so playback doesn't hitch.
- **Shots** are stretches of song time: `{t0, t1, set, cam, ...}` plus a function that poses what moves.
- **Camera keys** are `[time, x, y, zoom, ...]` with easing between them. Two useful rules:
  - push in with **lens zoom**, not by travelling into the layers: depth travel blows the nearest layer up (snow
    becomes moons);
  - **never let the camera see past the edge** of what's drawn. Check the frame corners on every new camera.
- **Transitions:** dissolves, drop wipes (a new picture spreading inside a drop), push and pull (from a room to the
  picture on its screen), panels (pull back to a page of panels, push into another), re-laying one medium as another
  past a moving line.

## Time: on twos, and in step with the song

- Hand-made animation moves **on twos**: pose changes at 12 fps inside 24 fps video. Several engines step motion at
  12 fps (`tm12 = Math.floor(t * 12) / 12`) while the camera moves at the full 24, which keeps the hand-made feel
  without a juddering camera. Texture "boil" (grain, ink noise) often changes at 8 fps.
- **Ease into fast moves**, or drive them with real time: a move that starts at full speed jumps at 12 fps.
- **Hits on beats, changes on lines.** `SONG.beat(n)` and each line's `t0` and word times are the anchors. A word
  lighting in the lyric band typically fades up over `[t - 0.04, t + 0.16]`.
- **Keep something moving.** A hold longer than a beat or two reads as the player freezing. A slow drift, a breathing
  light or drifting smoke keeps a still picture alive.

## Determinism and frame-to-frame state

- All randomness comes from seeded generators (`mulberry32(seed)`) and noise keyed to the frame number. Never call
  `Math.random()` while drawing a frame. The same `t` must give the same picture, or an MP4 won't match what you
  checked.
- Some styles **carry state from frame to frame**: frost that grows, ghosting of the previous frame, a charcoal
  drawing that's erased and redrawn, marbled paint whose outlines remember every comb. Those must be stepped in
  order. `renderAt(t)` then means "rebuild the state from the start of this scene up to t", and each engine's README
  says how it does that.
- When a view steps backwards in time (a camera effect that holds frames, a scrub), keep what's already baked rather
  than rebuilding it from scratch each step, or rendering crawls.

## Figures

- **Whole figures**, posed. Every engine has a rig: jointed silhouettes, contour-drawn people, ray-marched signed
  distance bodies, carved 3D pieces. Most use **two-bone IK** for arms (and often legs), so a hand can be put exactly
  on a rope, a cup or another hand. Each rig spells it its own way: `reachArm()` in paper cut, an arm given as
  `{t: [x, y]}` in embroidery or `{at: [x, y]}` in painted enamel; the style READMEs show how.
- Build **every figure of a kind from one model**, so its anatomy is the same in every shot; vary only pose,
  clothing and age.
- Things that make figures read wrong, all hit at least once: round heads read as teddy bears (give them a muzzle
  or a jaw); coats that hang along the body turn a crouching figure into a plank (hang them toward world-down);
  digitigrade legs with a long stride look like sitting on a stool; two figures leaving the same way merge into one
  blob; close-up arm silhouettes read as clubs or poles.

## Light

- A **lamp** is a radial gradient drawn with `multiply` (or a light map multiplied onto the whole picture). Its
  warmth and brightness carry most of a scene's mood.
- **Self-lit things** (flames, lit windows, glowing marks) go in their own layer drawn after the light map, plus a
  glow. A reflective shape in front should erase the self-lit layer behind it.
- On pale paper, `screen` adds almost nothing; `soft-light` plus a weaker `screen` shows coloured light.
- Glass only darkens: a moving piece has to pass over light glass, or it vanishes.

## Text in the picture

- Load fonts before drawing and wait for them (`document.fonts.load(...)` for each face and script you use), or text
  falls back to a default font. `document.fonts.load` resolves even when the font never arrived, so check the
  result (or `document.fonts.check(...)`) before building. Put `<meta charset="utf-8">` at the top of the page for
  any non-ASCII text.
- **Start building only when every script has loaded** (`DOMContentLoaded`, or put the start call at the end of the
  last script). A build started from a font promise plus a short timer can win the race against later scripts when
  the fonts come from cache, and the page fails to build only sometimes.
- Keep the lyrics readable: if the camera zooms, keep the text out of the zoom (a band or margin drawn in screen
  space).

## Browser gotchas that cost hours

- **One bad gradient value kills the frame.** `addColorStop` with a NaN or an out-of-range offset throws, and nothing
  after it draws. Check the console after every change.
- **`destination-out` uses the current fill's alpha.** A fill left translucent from the last wash only half-erases.
  Set `fillStyle = '#000'` before erasing.
- **`[hidden]` loses to `display: grid`.** Add `.gate[hidden] { display: none }` for overlay elements.
- **Globals collide.** Plain scripts share one global scope; a helper named like an existing function (`hand`,
  `line`) silently replaces it.
- **Tiling seams:** a texture tiled from a sampled corner shows seams on big pieces; downsample the whole texture.
- **WebGL:** GLSL has reserved words you'd never guess (`patch`); creating a texture while another is bound can
  overwrite a texture unit (create textures on a scratch unit such as TEXTURE15); a three.js `InstancedMesh` keeps the
  bounds of its first draw unless `frustumCulled = false`.
- **Headless loads:** wait for the page with `wait_until='commit'` and your own ready flag; a page that builds a lot
  at load can time out waiting for the load event.
- **Grain that changes every frame bloats the MP4.** Change it on twos.

## Starting a new engine

1. Copy the style closest to what you want. Keep its player (`index.html`, the playback and `window.__video` parts
   of its engine) and its lyric code.
2. Write the medium: the few functions that turn a shape into your medium's marks. Test them on stills first, on a
   page that just draws one scene (a lab page).
3. Draw the same key scenes in your medium and in one or two alternatives. Choose.
4. Then sets, shots and the song.



## 原作者媒介陷阱与经验摘录

## Lessons and gotchas

- **Lines laid first cut across what stands in front of them.** Drawn lines (wall joints, scaffolding, a clothesline) are
  regions in the id map, and their pieces are laid only where the line is still visible after later items.
- **Smiling faces read as cute.** Faces have a flat, short mouth and a longer face.
- **Check seated poses against the chair**: thighs forward, the floor at the feet, not at the seat.
- **A solid glow shape reads as an egg yolk.** In mosaic, light is warmed stones and glowing mortar (and gold
  pieces); a solid body of light suits the sand, where it is thinner sand for the lamp to come through.
- **Lettering laid by contour is too thin to read**, and a background's outline rows make a cartouche round every
  line. Lay letters along their centre line (`skel:true`) in bold capitals, and give the panel `echo:0`.
- **Unlaid pieces show bare mortar**, so letters and shapes not yet laid show faintly in the bed, like the design a
  mosaicist draws on the setting bed. Keep it; it makes the laying readable.
- **Big regions in `'echo'` mode fill with concentric "eyes"** where the rows close up. Use `'course'` with one to four
  outline rows for skies and fields; keep `'echo'` for figures and small shapes.
- **Grain everywhere made the first sand look like a filter**, and ruler-straight edges looked drawn by machine. The
  warp, fine grain and sparse drifts fixed it; palm sweeps turned up too high look like wood grain.
- **Don't marble the sand.** Warping the whole field with a displacement that changes quickly across the picture
  turns sand into marbled paper and mangles the drawing. Keep the warp small and smooth, and show wind with grains,
  wisps and shapes that bend.
- **Grains as uniform dashes look like Morse code**; vary their size, length and opacity. Wisps as lines read as
  cartoon speed lines; trails of scattered grains read as sand.
- **Dark figures on dark sand vanish.** Clear them out (`sand:'clear'`), which is also how sand is really drawn. A
  figure poured in front of something as thick (trees behind a walker) vanishes too: keep what stands behind a
  moving figure thinner and paler, or smaller.
- **A cleared line or doorway looked flat and digital**: sand pushed perfectly clear looks cut by a machine. Clearings
  keep a ridge of pushed sand at their edge, a few grains left behind and a faint film over their floor (the engine
  does this for every `scratch` and `clear`); give a cleared shape a wobbling edge (jitter its outline with `vn2`) and
  warm light under it.
- **Light under the glass doesn't come through thick sand.** A glow laid under dark ground barely shows; thin the
  sand where the light should come through (an `sr` ramp that is thin in the middle), then turn the light up.
- **Short straight fingertip marks read as rain**; small arcs read as leaves.
- **Long strokes read as tubes** (smoke especially). Overlapping puffs read as vapour.
- **Posterizing a one-colour picture by colour** splits its gradients into mottled patches. Blur it, and posterize by
  brightness (`lumOnly`).
- **`echo:0` was ignored** because `0 || 3` is 3; use `x != null ? x : default` for numeric options.
- **Pieces laid from text or rasters need their own direction and item**: a missing `dir` made `Math.cos(undefined)`
  NaN and silently dropped every course piece; centre-line letters with no `item` couldn't be found by tag.
- **Dots over a region cut holes in it**, and the region's rows ring each hole like a bubble (snow over a wall looked
  like foam). Mark them `float:1`: they are laid as single pieces among the region's own.
- **Moving figures stayed solid during a lift**, floating over the sand while the pieces round them flew off. They
  now come and go with the transition's front.
- **Lay an actor at its relay step's time, not the frame's**: laid from the time of whichever frame asked first, a
  still and a render could lay the same step differently.
- **A picture relayed as tesserae needs flat colours and thick strokes.** It is posterized into regions and laid with
  pieces of `fig` px; a line thinner than a piece and a half breaks into crumbs, and soft shading turns to confetti.
  Keep the picture small (the laying is cropped to its opaque part, and its cost grows with the crop): the demo's
  kite with its line and tail takes about 35 ms to lay, so re-laid every third frame it adds about 12 ms a frame.
- **A kite's tail that runs down from it reads as a second line.** Stream it downwind, nearly level, short, with bows.
- **`walking()` let its options overwrite the walk pose**, so a walker given an arm pose stopped walking. Options are
  merged into the pose now; keep that pattern (`const {pose, ...rest} = o`) in your own builders.
- **`wave()` drawn right to left returned nothing**, so a band made from two wavy edges (the second one reversed) came
  out as a thin line. It now works in either direction.
- **`-x**2` is a syntax error in JavaScript** (a minus directly before `**`), and one error silently stops the whole
  file, so every set in it vanishes. Write `-(x**2)`, and run `node --check` on each file before taking stills.
- **In a close-up, draw what a small figure gets away without**: a face in profile needs its chin clear of the neck,
  and a hand that hangs needs its fingers, or they read as lumps.
- **Hold the plate's rim still** when blowing sand (`edgeHold` in shots.js), or the dark rim smears inward.
- **Nothing should sit still for more than a beat or two**: a second of stillness reads as the player freezing. When
  an effect passes, let a weaker one trail it.
- **Keep the camera inside the set**: views are clamped, and a zoom below `OW/SW` would show past the edge.
- **A `*/` inside a comment** (a path like `frames/*/`) ends the comment early and silently breaks the page.
- **Read the console after every still**: one bad value in a canvas gradient blanks the whole frame.
- **Per-pixel callbacks must not allocate**: `glow`, `under` and `blow` run for up to two million pixels a frame.
  Return one reused array (`GB`, `UB` in shots.js), and look tags up once (`tagsOf`) rather than per piece per frame.


