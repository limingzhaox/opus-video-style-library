# Tinted linocut

A hand-coloured linocut, printed a few times a second. Each frame is a sheet of cream paper with a black key block
printed on it: the block is solid ink where nothing has been carved, and every light in the picture is a gouge cut
(tapered at both ends, the way a V-tool leaves it), so tone comes from how close and how wide the cuts are. Under the
block sit loose watercolour washes, laid as many faint, slightly different copies of each shape so they pool and
bloom and spill past the lines, the way old prints were tinted by hand. Every step gets fresh ink texture (specks
where the paper didn't take ink, soft patches where the roller ran thin), the motion steps at twelve drawings a
second, and the words are pencilled into the margin under the print, one word at a time, as a printmaker writes the
title and edition number under an impression.

![A row of poplars bowing in a gale on a ridge at dusk, a lit cottage, carved sky lines and shafts of light, the line of the poem pencilled underneath](img/hero.jpg)

## Looks in this family

The lab (`lab/`) draws the same two scenes in three looks, to compare them:

- **Tinted linocut**, the look of the demo: a carved black key block printed over hand-laid washes.
  ![](img/look-linocut.jpg)
- **Pen and wash**: sepia pen lines that restate their contours and boil a little from drawing to drawing, over
  watercolour washes that pool and bloom; light is lifted out of the paint.
  ![](img/look-penwash.jpg)
- **Charcoal**: one sheet drawn on, rubbed out and drawn again for every movement, so whatever moves leaves grey
  ghosts; light is made with the eraser.
  ![](img/look-charcoal.jpg)

## Run the demo

From the repository root:

```
python tools/serve.py
```

then open <http://localhost:8000/styles/linocut/index.html>. It builds its four prints in a second or two and plays
live, in step with the audio. Add `#t12.5` to the address for a still at 12.5 seconds (the page hides its controls
so the frame fills the window). Space plays and pauses; the bar scrubs.

Stills and a contact sheet:

```
python tools/still.py styles/linocut/index.html 2 6 12.5 0:37.5:2.5 --out renders/linocut --sheet
```

An MP4 with the song (`--fast` makes a 720p preview; leave it off for 1080p and 720p files):

```
python tools/render_mp4.py styles/linocut/index.html --out renders/linocut.mp4 --fast
```

The demo's frames took 5 to 25 ms each to draw here, and a `--fast` render of all 900 frames took about 45 seconds
(about 50 ms a frame, most of it spent reading frames back and encoding them; it took two minutes while the machine
was busy with other renders).

The demo is nine shots on four prints, one shot to a line of the poem, with a gust of wind on a word in every line:
the hill road at dusk, wide, with a woman climbing toward a lit cottage; the road close up beside her as she holds her
shawl closed and leans into the gusts; a branch of aspen whose leaves tremble and turn their pale sides out; the
cottage garden with its washing and chimney smoke; a cloud passing over the moon; the lamp in the window seen from inside,
with the hill printed into the panes; the poplars on the ridge bowing; the walker at the gate as the wind passes; and
the hill again as the wind drops. The second stanza answers the first line for line, so on "seen" and on "you" the
first stanza's print for the same line flickers back in over the new one, like the old block pulled again, and
lingers as a ghost. The walker's feet are planted as she walks: when a gust stops her, they stop.

![The opening wide: the road winding up the hill to the cottage and the poplars, with the title and credit pencilled underneath](img/hill-road.jpg)

![A branch of aspen close up against the dusk, its leaves trembling, some dark side out and some pale](img/leaves.jpg)

## How it works

### The files, in load order

| file | job |
| --- | --- |
| `../../examples/poem/lyrics_data.js` | `window.SONG`: title, credit, audio, duration, tempo, and each line's words with their times |
| `song.js` | turns `SONG` into what the engine reads: `DUR`, `LINES`, `BEATS`, `BEAT`, `BAR`, and `word(line, text)` |
| `lino.js` | the printmaking kit: print size, palette `WC`, maths, point lists, the key `Block`, gouge strokes, carved skies and ground, watercolour, the `World`, the camera, paper and ink textures, invented runes and pictograms |
| `figs.js` | people as silhouette templates (`FIG`), a walk with planted feet (`GAIT`), and `drawFig`, which prints one with a white halo, lit rims and carved folds |
| `scenery.js` | shared pieces: a night sky with a moon, lanterns and their pools of light, buildings with lit windows, pines, bunting, an oil lamp, tabletops, fur, and `drawWorldIn`, which prints one world inside another |
| `light.js` | light that moves: aurora curtains, beams carved as close horizontal cuts, and a wavering lens of light (a lamp flame) |
| `hands.js` | hands and forearms drawn light, for close-ups: cut to paper with a contour left standing, then creases and shade in ink |
| `papers.js` | letters, envelopes, wax seals, pins, handwriting too small to read, and text in a handwriting, print or typewriter font (the demo doesn't set any text, so add the fonts named in `FONT` to the page's Google Fonts link if you do) |
| `wind.js` | things the wind moves (the demo's own props, but reusable): gusts, bending trees, grass, leaves on the wind, clouds, smoke, washing on a line, a weathervane, trembling leaves on a branch, a curtain in a draught |
| `world-hill.js` | the demo's four prints: the hill (A), the road close up (B), a branch of aspen (C), the window from inside (D) |
| `shots.js` | the demo's shot list: which print, where the camera is, and what moves, second by second |
| `engine.js` | composes each frame, pencils the margin, runs the player, and sets `window.__video` for the render tools |

### The print and its layers

The output is 1920 x 1080. The print sits at `PX, PY` and is `PW x PH` (1808 x 886) pixels, leaving a margin
underneath for the pencil. Each frame (`renderFrame(t)` in `engine.js`) is:

1. the paper texture;
2. a ghost of the previous print, if the shot asks for one (see below);
3. the wash layer, clipped to a slightly ragged edge that spills past the block;
4. the key block, multiplied on top, clipped to the block's irregular edge, with a printed border;
5. the margin in pencil.

Two print-sized canvases are redrawn every frame: `K`, the key block (black where there is ink, transparent where it
is cut), and `WG`, the washes.

### Worlds: a key block and its washes

A print is a `World`, built once when the page loads:

```js
const w = new World(x, y, width, height, .5);   // world bounds; the wash canvas is half resolution
w.key.ink(polygon);                             // print black here
w.key.cut(polygon);                             // carve it away
w.key.cutAll(listOfPolygons);
wash(w.wg, polygon, WC.ochre, { seed: 3, layers: 12, alpha: .05 });   // lay a watercolour wash
```

`Block` keeps a list of ink and cut operations, merging runs of the same kind into one `Path2D`, and `draw(g)` fills
them in order (cuts with `destination-out`). Every polygon is wound the same way so that overlapping cuts add up.

The carving tools return polygons, so you collect them and add them in one go:

- `cutLine(points, width, sharp)`: a gouge stroke, tapering to a point at both ends (`sharp` shapes the taper);
  `inkLine(points, width)` is the inked equivalent with blunter ends.
- `skyCuts(x0, x1, y0, horizon, seed, density)`: a carved sky, sparse thin lines at the top and closer, wider ones
  toward the horizon, so the sky lightens as it goes down. `nightSky(world, x0, x1, y0, horizon, seed, { glow, moon })`
  inks the sky, lays its washes and returns these cuts.
- `groundCuts(region, seed, light(x, y), { sp0, sp1 })`: wavy rows across a region, wider where `light` is high.
- `hatchIn(poly, angle, spacing, width, seed)`, `rayCuts(...)`, `auroraCuts(...)`, `outline(points, width)`.

Watercolour: `wash(g, points, colour, options)` fills many deformed copies of the shape at low alpha (`layers`,
`alpha`, `v0` and `v` for how loose the edge is, `edge` for the darker pooled rim); `lift(g, points, amount, seed)`
takes pigment back out; `glowWash(g, x, y, r, colour, alpha)` is a soft pool of colour; `granulate(world)` knocks a
fine speckle out of the whole wash, as pigment settles into paper.

The camera is `[x, y, scale]`: the world point at the centre of the print and print pixels per world unit.
`camXf(g, cam)` puts that transform on a context. `toPrint(cam, [x, y])` tells you where a world point lands.

### Shots

`shots.js` defines `BUILDERS` (functions that build the worlds, run once at load) and `makeShots()`, which returns a
list of shots. A shot runs from its `t0` until the next shot's `t0`:

```js
{
  t0: 26.25,                     // song time it starts
  world: A.w,                    // the print it shows
  cam: (tm, t) => [x, y, scale], // where the camera is
  dyn(K, Wg, tm, cam, t, ks) {}, // draw everything that moves, into the key block and the wash
  ghost: .5,                     // show the previous print faintly, fading over this many seconds
  washA, printIn, washIn, fadeIn, still, fx, post,   // optional, see engine.js
}
```

`cam` and `dyn` get the 12 fps time `tm` first and the exact time `t` later, so ordinary motion steps like hand
animation but a fast move can use `t`. `ks` is the 8 fps ink step. Here is the demo's shot of the poplars bowing:

```js
S.push({
  t0: 26.25, world: A.w, ghost: .5,
  cam: t => kf([[26.25, [1930, 330, 1.28]], [30, [2010, 350, 1.32], 'sine']], t),
  dyn(K, Wg, t, cam) { hillLife(K, Wg, t, { cam }); },
});
```

`kf(keys, t)` interpolates `[time, value, easing]` keys (values may be arrays; easings are `inOut` by default,
`sine`, `out`, `in`, `lin`). `hillLife` draws everything that moves on the hill, back to front: clouds clipped to
the sky, the poplars (`windTree`), the chimney smoke, the weathervane, the washing, the broad tree, the walker
(`walker()` in `shots.js`, which puts `FIG.shawl` on the road with a lantern), grass and leaves.

The intro shows off the two layers: `washA` brings the washes up from the first frame, and `printIn` prints the key
block on the second bar in three quick steps, as if pulled.

### Flashes back to an earlier print

`flashBack(from, tw, te, T)` (engine.js) makes an earlier shot's print come back over the current scene round a word
sung at `tw`: the print of `from`, as it was at song time `T` and held still, is pulled once pale and a little off
register, the scene shows again for a step, the print is pulled darker, then held until `te`; one more pale pull on
the way out, and the scene comes back through the flash's ghost, which fades over `o.linger` seconds (default .7).
Each pull lasts one motion step (1/12 s). It registers the flash in `FLICKS`, which `shotAt(t)` checks before the
shot list, so call it inside `makeShots()` after the shots it borrows from exist. The demo's two:

```js
flashBack(S[0], word(4, 'seen'), word(4, 'seen') + .66, word(0, 'seen'));   // line 5 remembers line 1
flashBack(S[1], word(5, 'you'), word(5, 'you') + .66, word(1, 'you:'));     // line 6 remembers line 2
```

The pulls are the table `on` in `flashBack`: `[from, to, how much ink, off register x, off register y]`. Use it
where a line or a chorus comes back: the same words, the old picture.

### Moving light

A world can register light that moves in `fxOf(world)`: `beams` (shafts from a point, drawn as close horizontal cuts;
the demo's sunset rays are `skyBeams({ x, y, hz, n, a0, a1, clip })`), `auroras` (the hanging curtain of an aurora
ribbon, shimmering) and `flames` (a tall lens of light with bright strokes rising beside it and dark threads drifting
inside). The engine draws them every frame over the block and under the people. `fxFlame(K, Wg, flame, t)` can also be
called from a shot, as the window shot does, so the flame is drawn after the view is printed into the panes.

![Inside the cottage: an oil lamp on the sill with its flame and rings of light, a curtain stirring, and the hill road printed into the window panes](img/window.jpg)

### People

A figure template in `FIG` takes `(x, y, height, facing, walkPhase, options)` (`shawl` takes how far it has walked in
the options instead, as `stride`) and returns `{ parts, folds, lit, ... }`: polygons for the silhouette, lines carved as folds, and
edges that catch the light. It may also return `light` parts (pale things: a shawl, a face), each with a tint in
`lightCols`, and `over` parts, dark things that lie on top of the pale ones. `drawFig(K, figure, { halo, rimDx, scale,
seed, alpha, lightCol })` cuts a white margin round it all (so it reads against anything), fills the dark parts black,
cuts the light parts to paper with an ink outline and tints them in the wash, inks the `over` parts, and carves the lit
rim and the folds. The demo's walker is `FIG.shawl`: a woman in a headscarf knotted at the nape, her face lit in
profile, a long dark coat, and a pale shawl whose free end streams out behind her. Its options include `pose` (`stand`
or `walk`), `arm` (`shawl`, the near hand holding the shawl closed at her throat; `down`; `raise`), `carry` (a lantern
in the far hand), `lean` into a wind and `blow` (how hard the skirt, the shawl's end and the scarf's tails stream back).
There are others: a hooded traveller with a pack, a traveller in furs, a mother carrying a child, a robed figure in a
loose hood, a shepherd with a staff, a child, a townsperson in a coat or a dress, a rider, and more.

The walker's feet are planted. `GAIT.state(sig)` takes the distance walked in units of the figure's height and
returns the legs: each footfall is a fixed point on the ground, the foot rolls down about the heel and up about the
toe, and the shin is solved from the hip (two-bone IK); the body dips a little over each step. Because it runs on
distance, not time, a sole on the ground never slides, whatever the pace, and the feet stop when the walker stops.
`FIG.shawl` uses it when given `stride` (the demo passes `dist / h`; on a level road that is `x / h` plus a
constant, so a foot stays exactly where it landed). `GAIT.parts(state, place(x, y, h, f), h)` draws the lower legs
and the shoes, and leaves the thighs to a coat or a skirt: add it to another long-coated figure the same way (lower
the body by `state.dip * h`), and keep `legsWalk` for figures whose knees show.

![The walker on the road close up: a woman in a dark headscarf leaning into a gust, her red shawl blowing back and held closed at the throat, a lantern in her other hand, leaves streaming past](img/walker.jpg)

### The margin

The title and credit (`SONG.title`, `SONG.credit`) are pencilled in until the first sung line and come back after the
last. Each line is written word by word from its word times, each word wiped on left to right over about a sixth of a
second. The right-hand end of the margin shows `MARGIN_NOTES` from the shots file (`[[from time, text], ...]`); the demo
numbers its prints like an edition, `1/9` to `9/9`. The pencil is a Google font (Caveat) with a grain texture knocked
out of it, multiplied onto the paper.

### The ghost of the last print

When the shot changes and the new shot has `ghost: seconds`, the engine copies the last key block and prints it
faintly under the new one, fading out over that time, like a second pull from a block that still has ink on it.
A flash back to an earlier print leaves the same kind of ghost when it goes. The ghost is multiplied under the new
print, so it shows where the new print is pale and all but vanishes on a dark one. At the very end the print sinks
back into the paper, leaving only a ghost of itself and the pencilled title.

### Determinism and caching

Nothing uses `Math.random()`. `rnd(a, b)` is a hash and `RNG(seed)` a seeded stream, so every frame is a function of
the song time: `step(t)` and `renderAt(t)` give the same picture (`renderAt` first redraws a moment before the last
change of print, a shot starting or a flash coming or going, so a ghost is right in a still too). A walker's legs
come from the distance walked, not the frame before. The wind's running total (`windRun`) is computed once at 24 steps a
second and kept. Worlds (their key block paths and wash canvases) and the paper, ink and pencil textures are built
once at load.

## Make your own video in this style

1. **Copy the folder**: `cp -r styles/linocut projects/my-song` (leave out `lab/` and `img/` if you don't need them; see
   [docs/your-own-video.md](../../docs/your-own-video.md)).
2. **Your song's timing**: make a `lyrics_data.js` for your song with `tools/audio/to_js.py`, put it in your folder,
   and point the first `<script>` in `index.html` at it. `SONG.audio` is your audio file's path relative to the page.
   Change the page `<title>`, heading and the canvas's `aria-label`.
3. **Keep** `lino.js`, `figs.js`, `scenery.js`, `light.js`, `hands.js`, `papers.js`, `song.js` and `engine.js` as they
   are. Keep `wind.js` if your pictures have weather in them.
4. **Replace `world-hill.js`** with your own prints. A builder makes a `World`, lays its washes, inks and carves its
   key block, registers any moving light with `fxOf(w)`, and returns an object with `w` plus whatever your shots
   need to know (where a road runs, where a window is). Carve everything that never moves; leave what moves to the
   shots. Start from `buildBranch` (the smallest) or `buildHill` (a whole landscape).
5. **Replace `shots.js`**: list your builders in `BUILDERS`, set `MARGIN_NOTES` (or `[]`), and return your shots from
   `makeShots()`. Each shot is a world, a camera and a `dyn` function.
6. **Add a shot**: push `{ t0, world, cam, dyn }`. Give it `ghost: .5` if it follows a different print. Where a line
   or a chorus comes back, `flashBack(earlierShot, wordTime, wordTime + .66, timeInTheEarlierShot)` pulls the old
   print again round the word.
7. **Time a move to a word or a beat**: `word(2, 'trembling,')` is when that word is sung in the third line (lines
   count from 0); `BEATS[n]` is beat n; `BEAT` and `BAR` are their lengths. Put camera keys on those times with `kf`,
   and ease into anything fast (see below). In the demo every line has a gust peaking on one word:
   `WIND.gusts = [[word(6, 'heads,'), 1.5, .8], ...]` (peak time, strength, seconds to die away).
8. **Check it**: `#t` stills in the browser, then `tools/still.py` with `--sheet` across the whole song, looking at
   every shot's start, middle and end and at the frame edges. Then render.

Useful knobs:

- the print's place and size, `PX, PY, PW, PH`, and the colours `PAPER`, `INK` and the palette `WC` (`lino.js`);
- how worn the ink looks: the two `tile(...)` calls in `renderFrame` (specks at .42, soft patches at .14);
- the ghost's strength (.3 in `renderFrame`) and each shot's `ghost` duration;
- a flash's pulls (the `on` table in `flashBack`: timing, ink, how far off register) and how long it lingers
  (`o.linger`);
- a walk's step length and bob (`STEP`, `BOB` in `GAIT`), and the shin widths passed to `GAIT.parts`;
- the steps: motion at 12 a second (`tm`), ink at 8 (`ks`), both in `renderFrame`;
- the margin's font and sizes (`FONT_PENCIL`, and the sizes in `drawMargin`);
- a wash's looseness and weight: `layers`, `alpha`, `v0`, `v` in `wash()` calls;
- a tree's `flex`, `w`, `h` and `col`, and the `dense` and `cutW` options to `windTree` for how much it is carved.

## The lab

Open <http://localhost:8000/styles/linocut/lab/index.html>. Two buttons pick the scene (the hill road at dusk, or a
lighthouse on a headland at night in a gale); Play runs an eight-second loop, and only the looks on screen animate.
`#t2.5` shows a still at 2.5 seconds, `#scene=shore` picks the scene and `#only=charcoal` shows one look. To render all
six pictures:

```
python tools/lab_stills.py styles/linocut/lab/index.html --all --out renders/lab --sheet
```

`window.__lab.render(scene, look, t)` draws one (at five seconds unless you pass `t`).

The scenes are described once, in `lab-core.js`, as shapes with a role and a hue: a sky (with a glow, a moon or
stars), far ranges, fields (each with a texture: rows, stubble or furrows), hedges, a road, buildings with lit
windows, trees that bend, clouds, people, and for the shore the sea, its waves and the lighthouse's beam. Each look
reads the same description:

- `lab-lino.js` carves a key block from it (sky lines closer toward the horizon, each field carved its own way,
  hedges with a white line above them, buildings with a white margin) and prints it over the washes from
  `lab-wash.js`. What moves (clouds, the beam, the wave crests, trees, people, the lantern's rings of light, leaves or
  spray) is carved into a copy of the block every step, and the ink is worn with fresh texture.
- `lab-wash.js` lays the static washes once (sky passes, lifted moon and stars, fields with a bloom, the sea in
  streaks), then per drawing adds washes for what moves and restates every contour in pen, with a small wobble that
  changes each time, hatching on the side away from the light, and the paper's tooth multiplied over it all.
- `lab-charcoal.js` works on one sheet: rubs (blurred fills), strokes laid across a region, stick lines and the
  eraser. It draws the scene in over the first second, sky first, and then every other drawing rubs out what moved
  (not quite all of it) and draws it again, so movement leaves ghosts; light is erased out (the glow, the lamps, the
  beam, the crests of the waves). The photograph adds the paper's tooth, a little camera drift, a vignette and an
  unsteady exposure. Each drawing is made from the one before, so it replays from the start whenever it is asked to go
  backwards or switch scenes (about a tenth of a second for five seconds of drawing).

## Performance

- Drawing a frame took 5 to 25 ms here (the still tool prints it per frame). The static key blocks are a few big
  `Path2D` fills with thousands of cuts in them; most of the per-frame cost is what moves: carved trees, leaves,
  and the window shot, which prints the whole hill a second time inside the panes.
- Building the four prints takes a second or two; the paper texture is generated pixel by pixel once.
- Memory: each world keeps a half-resolution wash canvas (the hill's is 1850 x 880) and its paths; the engine keeps
  four print-sized canvases (key, wash, ghost, margin).
- A full `--fast` render of the demo took about 45 seconds; 1080p takes longer to encode. To redo one stretch,
  render a slice with `--start` and `--end` and put it back with `tools/splice.py`. Only the ghost after a cut or a
  flash depends on the frame before, so a slice that starts more than a second after one comes out identical to the
  full render.

## Lessons and gotchas

- **Clearing the wash**: a `destination-out` fill uses whatever fill colour was set last, often a translucent wash
  colour, so it only half clears. Set `fillStyle = '#000'` first.
- **Long holds read as a freeze.** A still held for four seconds looks as if the player has stalled. Keep holds to a
  beat, or keep something moving: a slow drift, the light breathing, smoke.
- **Fast moves jump at 12 fps** if they start at full speed. Ease into them, or drive them with the real time `t`.
- **Camera edges and gaps**: a camera that strays past a world's bounds shows blank paper, and so does any strip
  that no layer inks (a far range that stops above the hill in front of it). Extend back layers down behind the
  nearer ones, and check the frame edges on every new camera.
- **Ink on dark prints vanishes.** Draw objects cut to paper with an ink outline; carve texture into a dark shape
  that stands against a dark sky (a branch, a limb), or it reads only as its outline.
- **Light comes from cuts, so light things need their own layer order.** A cloud clipped to "the sky" will cross
  anything that stands up into the sky, like a cottage on the ridge; draw the skyline around such things.
- **`drawWorldIn` clears its window in the key block**, so a flame or anything else drawn there earlier disappears.
  Draw such things after printing the other world.
- **Rims on closed shapes**: when picking out the lit side of an outline, take the points in contiguous runs;
  filtering a closed polygon's points and joining them draws long straight cuts across the shape.
- **Gust timing**: measure a gust's lag from the middle of the view, so the gust arrives on its word where the
  camera is looking. Measured from the edge of a wide print, it arrives a second late.
- **Too much carving looks like straw.** A tree crown reads better as a mostly black mass with a thin white arc
  along the top of each clump than as a crown full of cuts.
- **A gesture made against the body vanishes in a silhouette.** An arm held across the chest merges with it. Leave a
  window of background around the gesture, or lay it over a pale part: the walker's hand is inked over her light shawl,
  and her face is a light part under a dark scarf, so both read even when she is small.
- **Legs swung on a clock slide.** Swinging legs driven by a phase only match the ground at one pace, so the soles
  skate whenever the walker speeds up, slows in a gust or stops. Plant each footfall and drive the walk by the distance
  walked (`GAIT`); on a level road pass `x / h`, so a planted foot is fixed to the ground exactly.
- **A stiff hood tail sticking out behind the head reads as an animal's ear** in silhouette. A loose hood that slumps
  behind the head and hangs down the back in a soft point reads as cloth.
- **Bring an old print back as a print, not a cut.** A flash that cuts to the old picture and back is just an edit;
  pulled in the way a print is (pale and a little off register, the scene again, darker, then held on the word, one
  more pale pull on the way out) it reads as the old block printed again, and its ghost ties it to the scene it
  interrupts. Hold it about two thirds of a second: a word's length.
- **Keep the player idle when paused.** If the page's animation loop keeps drawing the paused time, it draws over
  the frames the render tools ask for between their calls. The loop here only draws while playing.
- **Charcoal and the GPU**: clearing a canvas after a long run of blurred marks was not reliable; the charcoal look
  starts from a fresh canvas each time it replays.
- **Page basics**: put `<meta charset="utf-8">` first, and add `.gate[hidden]{display:none}`, because `display: grid`
  on the play overlay otherwise wins over the `hidden` attribute.

