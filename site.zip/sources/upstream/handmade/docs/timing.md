# Timing a song

Everything in a video hangs off the song's clock: the lyric band lights each word as it's sung, pieces land on
beats, scenes change on line starts, the lamp goes out in a dropout. This page is how to get those times. The tools
are in [tools/audio/](../tools/audio); each prints its own help with `--help`.

Setup (once): `pip install -r requirements-audio.txt` (librosa, scipy, faster-whisper, mido). The Whisper model
downloads the first time it's used.

## The pipeline

```bash
# 1. the shape of the song: tempo, loudness, sections
python tools/audio/analyze.py song.mp3

# 2. words with timestamps, from the vocal stem if you have one
python tools/audio/transcribe.py vocals.mp3 --lyrics lyrics.txt --out whisper.json

# 3. your lyric sheet matched to Whisper's words
python tools/audio/align.py lyrics.txt whisper.json --out lines.json

# 4. snap each word to where the voice starts it (vocal MIDI and/or vocal audio)
python tools/audio/snap.py lines.json --midi vocals.mid --audio vocals.mp3 --out snapped.json

# 5. the page's data file
python tools/audio/to_js.py snapped.json --out projects/my-song/lyrics_data.js --title "My Song" \
    --audio song.mp3 --audio-file projects/my-song/song.mp3 --bpm 96 --beats-per-bar 4
```

Then open the video with the lyrics showing and listen through. Fix what's off by editing `lyrics_data.js`
directly: it's plain data.

## Step by step

### 1. The shape of the song

`analyze.py` prints the global tempo and the local tempo every 20 s, a table of loudness, brightness and rhythmic
busyness every few seconds, and guesses at section boundaries. Read it next to the lyric sheet. You're looking for:

- which sections are loud and which drop out: the video's big and quiet moments should follow them;
- tempo changes (a slow intro, a half-time bridge);
- **stops and hits.** `onsets.py song.mp3 --from 140 --to 155` zooms in on a stretch: the strongest onsets, the
  beats, and the loudness every quarter second, so a dropout shows as a run of low numbers. These are the best
  sync points a song offers: the place for everything to freeze, for a cut, for a light to go off.

`sections.py song.mp3 --lines lines.json` compares the sections' loudness, drums and tonal energy once you know
where they are.

### 2. Transcribe

`transcribe.py` runs faster-whisper with word timestamps. Give it the **vocal stem** if there is one; sung vocals
over a full mix transcribe much worse. The `small` model is usually enough and takes about a minute. `--lyrics`
passes the start of your lyric sheet as a prompt, so names and odd words come out spelled your way. `medium` can
rescue mumbled lines, but over a long song it can drift further than `small`.

Expect Whisper's times to run **early**, typically a few tenths of a second and sometimes by more than a second,
and to hear some words wrong, especially names and unusual words. Step 3 doesn't care about wrong words; steps 4 and
the listen-through fix the times.

### 3. Align

`align.py` lines your sheet up against Whisper's words (a sequence match, so misheard or missing words don't break
it; unmatched words get times interpolated from their neighbours). It prints each line with a match count like
`m7/9`. Low counts are where to listen first. Watch for:

- **numbers:** Whisper writes "1974" as one token for three sung words. The script spells out years and small
  numbers before matching, but check them;
- **hyphenated words** and contractions;
- **a misheard last line** ("Let it go" for "Letting go"): the end of a song, over a fade, is where Whisper guesses;
- **repeats and ad-libs** the singer added: put them on the sheet as sung, or they'll be squeezed between
  neighbours.

### 4. Snap to the voice

`snap.py` moves each word to the nearest sung-note onset within 0.32 s: note onsets from the **vocal MIDI** first
(if you have it), then onsets detected in the **vocal audio**. It first reports the median offset between the words
and the onsets; if Whisper ran early across the whole song, pass that back as `--shift` so everything moves before
snapping.

After snapping, some things still need a human ear:

- **line starts that land in silence** or on the tail of the previous word: move them to where the voice comes in;
- **choruses and held notes:** a melisma or a long held word confuses onsets;
- **MIDI quantization:** Suno's MIDI is quantized to sixteenth notes and can sit about 0.3 s off the voice.

For those, `onsets.py vocals.mp3 --from 25 --to 27 --pitch` prints the sung pitch and loudness every 50 ms: the
word starts where the pitch appears and the loudness jumps.

### 5. Write the page data

`to_js.py` writes `lyrics_data.js`, which sets `window.SONG`:

```js
window.SONG = {
  title: "My Song", credit: "", audio: "song.mp3", duration: 212.4,
  bpm: 96, beatsPerBar: 4, firstBeat: 0.35,
  sections: [["verse1", 12.3, 41.0], ...],
  beats: [0.35, 0.975, ...],            // only with --beats: exact beat times
  lines: [{section: "verse1", text: "Who has seen the wind?", t0: 12.3, t1: 14.9,
           words: [["Who", 12.3], ["has", 12.9], ...]}, ...],
};
SONG.beat(n)  // the time of beat n
```

Every style in this repo reads that shape (see [examples/poem/lyrics_data.js](../examples/poem/lyrics_data.js)).

## Beats

For a steady song, `--bpm` and `--first-beat` (the time of the first downbeat) are enough: `SONG.beat(n)` is
`firstBeat + n * 60 / bpm`. Find the first beat with `onsets.py` on the song's opening seconds.

If the tempo drifts or changes, use exact beat times instead:

- **from MIDI stems:** Suno writes a tempo event on every beat, so the tempo map is an exact beat grid.
  `midi.py drums.mid --beats-out beats.json` (any of the song's MIDI files will do);
- **from the audio:** `analyze.py song.mp3 --beats-out beats.json` (librosa's estimate; check it).

Pass the file to `to_js.py --beats beats.json`; `SONG.beat(n)` then reads from the list.

## Hits and loudness

Some styles pulse, flash or move with the music itself rather than the words: a lamp that breathes with the mix, a
ring on every drum hit, mouths that open with the voice. `pulses.py` measures those:

```bash
python tools/audio/pulses.py song.mp3 --percussion perc.mp3 --drums drums.mp3 --vocals vocals.mp3 --out projects/my-song/audio_data.js
```

It writes `window.AUDIO = {fps, ticks, kicks, env, venv, vdb}`: small hits (`ticks`) and big ones (`kicks`) as
`[time, strength]`, the mix's and the voice's loudness 24 times a second (`env`, `venv`, 0..1), and the voice's
loudness in decibels mapped to 0..1 (`vdb`, better for mouths). Stems give much cleaner hits than the mix; without
them everything comes from the mix. The liquid light show reads this file as it is; any style can read the arrays.

## Suno specifics

- The stem download gives an audio file and a MIDI file per instrument. The lead vocal stem transcribes cleanly.
- The MIDI files carry a key-signature event that the `mido` library can't decode (it raises
  `KeySignatureError`). `tools/audio/midi.py` patches mido to read it as C; import `load()` from it in your own
  scripts to get the fix.
- The MIDI tempo map has one event per beat: an exact beat grid, including tempo changes after an intro.
- Vocal MIDI notes are quantized and can sit up to ~0.3 s off the voice: good anchors for snapping, not ground truth.
- Suno ignores dynamics on the lyric sheet ("quiet", "spoken", "almost unaccompanied"). Measure.

## Checking by eye and ear

Open the page, play it with the sound on, and watch the lyric band. Words that light up early are the common
fault. For a close look, `#t25.3` on the page's URL shows the frame at 25.3 s with the band as it is then.

