# Night poster

Flat-colour illustration in the manner of a mid-century travel poster: every shape is one flat fill cut by one
hard-edged shadow shape, with no gradients inside shapes. The shadow isn't painted on; it is the band that a copy of
the shape, shifted toward the light, fails to cover, so every form gets a clean shadow side for free. Nights are
indigo and ultramarine: ordinary colours are darkened and cooled by mixing toward navy (not by rotating the hue),
while lamps, lit windows and the moon keep their brightness, throw crisp-edged pools of light and put a warm rim on
whatever stands near them. The same painter has a daylight setting, so one scene can be drawn by night, at dawn, by
day and at dusk. People are drawn from contour points in feet, with two-bone arms and legs posed by where the hands
and feet (and, when it matters, the elbows) should be. Scenes sit on pages of panels with wavy seams, and one camera
moves over them: it pulls back until the frame is the page and pushes into another panel, slides across a seam to a
neighbour, or goes through a lit door in a warm flash. Pulled back far enough, a page's panels can turn out to be
the lit windows of a building.

*Good for:* everyday life, towns and streets, many moments in one frame, a place seen over years.

![A figure under a street lamp at night, a red umbrella blown inside out above them, the tree over the lamp lit gold](img/hero.jpg)

The demo sets Christina Rossetti's "Who Has Seen the Wind?" on a small-town street on a windy autumn evening. Stanza
one is the night: someone walking home under an umbrella that turns inside out on "wind?", the leaves by the lamp
trembling, a door opening. Then the page pulls back to the same street at four hours, a gust running through all
four at once, and pushes into the day for stanza two: washing on a line, a kite flyer on a hill opening on a seam of
its own in soft shapes for "Neither you nor I", the trees bowing on "bow", and a sheet torn off the line that blows
across a seam into the dusk panel and catches in a tree there. At the end the camera keeps pulling back past the
page, and the four hours turn into the four lit windows of a house on a hill at night, the wind still in its trees.

| | |
|---|---|
| ![The street at night, dawn, day and dusk in four panels with wavy seams](img/seams.jpg) | ![Washing blowing on a line by day, someone pegging it out](img/day.jpg) |
| ![A kite flyer on a hill in soft shapes, opened on a seam beside the day street](img/hill.jpg) | ![The four panels fading into the lit windows of a house on a hill at night](img/house.jpg) |

## Looks in this family

The [style lab](lab/index.html) draws the same scene descriptions with each look; only the Painter changes.

- **Night poster** (the demo): no outlines, darker and bluer, strong shadow shapes, lights kept bright. ![The street at night in the night poster look](img/look-night.jpg)
- **Night poster, by day**: the same painter with its daylight value at 1, warm mid-tones and cool violet shadows. ![The street by day](img/look-day.jpg)
- **Soft shapes**: no outlines, paler colour, a light band as well as a shadow band on every shape, more grain. The demo uses it for the hill. ![The street at night in soft shapes](img/look-soft.jpg)
- **Ink line**: heavy even outlines round every shape, flat fills, one flat shadow tone. ![The street at night in ink line](img/look-ink.jpg)

## Run the demo

```bash
python tools/serve.py
```

Then open `http://localhost:8000/styles/night-poster/index.html`. Play, or press Space; drag the bar to scrub.
Add `#t12.5` to the address for a still of 12.5 s with the page around it hidden (after editing code, reload with a
new query, `index.html?r=2#t12.5`, because changing only the `#` part doesn't reload).

```bash
python tools/still.py styles/night-poster/index.html 2 6 12.5 0:37.5:2.5 --sheet   # stills and a contact sheet
python tools/render_mp4.py styles/night-poster/index.html --fast                    # renders/night-poster-720p.mp4
python tools/render_mp4.py styles/night-poster/index.html                           # 1080p and 720p
```

It plays live, a little unevenly: close shots draw in 15-35 ms, but the four-panel page and the pull-back to the
house take 80-140 ms a frame and stutter. The MP4 is the smooth version: a `--fast` render of the 37.5 s takes about
a minute on an Apple-silicon Mac (about 67 ms a frame, encoding included), longer when other renders share the
machine.

## How it works

Plain scripts that share global names, loaded in this order by `index.html`:

| File | Job |
|---|---|
| `../../examples/poem/lyrics_data.js` | `window.SONG`: the lines, word times and beat grid |
| `core.js` | sizes (`W`, `H`), maths, seeded random `rng(seed)`, colour (`mix`, `hslAdj`, `rgba`), path builders, the pinhole camera, value noise |
| `paint.js` | the looks (`STYLES`) and the `Painter`, which draws every shape |
| `elements.js` | scenery: sky bands, stars, moon, clouds, mountains, pines, street lamps; the things wind shows up in: a tree that bows, loose leaves, chimney smoke, long grass, cloth on a line or snagged on a branch. Also aurora, snowbanks and falling snow |
| `fig.js` | figures: the frame and contour helpers, heads and hair, two-bone arms and legs, a walk, a figure in a coat (`figWalker`), one seen from behind (`figBack`), an umbrella, and the general figure `figPerson` (standing, walking, sitting, crouching, kneeling; side, back or front; tops, hair) |
| `props.js` | rooms and what's in them, as cheap flat faces: a box room, ceiling lights, a window onto the weather, a clock, paper in squiggles, binders, a phone, shelves, carts, cards, posters, a whiteboard, a hanging sign, a plant, furniture, stickers, and `revisit`. The lab loads it; the demo doesn't need it |
| `scene_street.js` | `SC_STREET`: the demo's street, one description drawn at four hours |
| `scene_hill.js` | `SC_HILL`: the hill in the soft inset |
| `scene_house.js` | `SC_HOUSE`: the house on the hill whose window grid sits under the page (by night, or `day`) |
| `scene_room.js` | `SC_ROOM`: a workroom that fills up by stage (the lab's; not loaded by the demo) |
| `engine.js` | scenes, pages and their seams, the camera's path, overlays (flash, opening seam of light), backdrops, half-size panel pictures, insets, loose things carried across a page, the lyric strip, the title card, `window.__video` |
| `shots.js` | this video: the wind, the figures' moves, the scenes, the page, the camera's path, the inset |
| `index.html` | the page and the player |

**The camera and scenes.** A scene is laid out in feet (x right, y up, z away from the viewer) and projected by a
pinhole camera, so it can be shot at any size:

```js
const cam = makeCam(1100, 960, 640, 5);  // focal length in px, screen x straight ahead, horizon y, eye height in feet
prj(cam, X, Y, Z)                        // -> [x, y] on the 1920x1080 scene: y = 640 - 1100 * (Y - 5) / Z
sAt(cam, Z)                              // pixels per foot at depth Z, for sizing figures and props
wquad(cam, [[X, Y, Z], ...])             // a flat shape given by its corners in feet
```

A scene function `SC_NAME(P, S)` draws a whole 1920x1080 frame through a Painter `P` from a state object `S` (all
optional, so `SC_STREET(P)` draws a sensible still) and returns anything the engine needs to know, here the lamp and
tree positions: `SC_STREET(P, { t, tod: 'night', wind: x => .6, walker: {...}, door: 1 })`. Rooms use a kit from
`props.js`: `const K = kit(makeCam(1080, 960, 470, 5.4))` gives `K.pr(X, Y, Z)`, `K.q(points)`, `K.s(Z)` and
`K.fAt(X, 0, Z, dir)` (a figure standing there).

**The Painter.** `new Painter(ctx, style, u)` with `style` one of `'night'`, `'poster'` (the night poster with the
daylight value `u`, 0 night to 1 day), `'soft'`, `'ink'`. It paints with the context's current transform, so a
zoomed camera stays crisp.

```js
P.part(paths, colour, { L: [-.6, -.8], sh: 10, hl: 0, rim: { L: [1, -.3], w: 3, c: '#ffcf86' }, em: false, flat: false })
P.flat(paths, colour, { a, em, raw })  // no shading, no outline: skies, light pools, glass, props (raw: colour already mapped)
P.stroke(path, width, colour, o)       // detail lines: ink in the ink look, a darker tone of the colour otherwise
P.glow(x, y, r, colour, alpha)         // a soft light (screen blend)
P.finish()                             // grain and vignette over the frame
P.col(colour, emissive), P.shade(colour, k), P.hi(colour, k)   // the look's colour, its shadow tone, its light tone
```

`paths` is a `Path2D` or a list of them, painted as one union. `L` points toward the light, `sh` is the shadow band's
width, `hl` a light band's, `rim` one or more coloured light bands (a lamp beside a figure), `em` marks something that
gives light and keeps its brightness at night. Path builders (`curve(points, closed, tension)` with `[x, y, 'c']` for a
corner, `poly`, `rect`, `ell`, `circ`, `capsule`) record the box they cover, so a shape only composites that part of
the frame. `alpha` multiplies with the context's own, so a whole scene can be drawn faded.

**Figures.** `frame(x, y, pxPerFoot, dir)` places a figure's feet on the screen; everything else is in feet from
there, facing +x (`dir: -1` mirrors it). Arms and legs are solved from a target, or posed exactly with an elbow:

```js
figWalker(P, frame(x, y, sAt(cam, Z)), {
  feet: walkFeet(phase),                  // or [[x, y, toe], [x, y, toe]] for a stance
  hands: [[.62, 3.72], [.3, 3.2]],        // near and far hand, in the body's own frame
  lean: .22, look: .5, flap: .8,          // lean into the wind, head tilted up, coat and scarf streaming
  prop: (P, f) => umbrella(P, f, [.62, 3.72], .38, { inv: 1 }),
});
figBack(P, frame(...), { hands: [[-.5, 6.9], [.55, 6.95]] })   // seen from behind, reaching up to a washing line
figPerson(P, K.fAt(5.6, 0, 10.6, -1), {                        // the general figure: sitting on a chair, reading
  pose: 'sit', view: 'side', top: { kind: 'sweater' }, hair: 'bun', head: { tilt: .25 },
  arms: { near: { h: [1.25, 3.05], e: [.85, 2.55] }, far: { h: [1.1, 3.1], e: [.68, 2.6] } },   // hands, and elbows
  hold: (P, f) => sheet(P, [f.T(1.05, 3.6), f.T(1.75, 3.45), f.T(1.62, 2.72), f.T(.95, 2.85)], { lines: 5 }),
});
```

`figPerson` takes `pose` ('stand', 'walk', 'sit', 'crouch', 'kneel'), `view` ('side', 'back', 'front'), `top.kind`
('tunic', 'sweater', 'coat', 'dress', 'robe', 'jacket', with `hem`, `sleeves`, `print`, `collar`, `belt`), `legs`
('pants', 'skirt', 'none'), `hair` ('bun', 'short', 'crop', 'pony', 'long', 'curls', 'hood', 'none'), `head.tilt`,
`scale` (0.6 for a child) and three drawing hooks: `under` (behind the whole figure: a chair back), `hold` (between
the arms) and `front` (over everything: a marker in the hand). It returns the shoulders, hips, head and each arm's
elbow and hand. `limbArm(P, fr, shoulder, hand, o)` and `limbLeg(P, fr, hip, foot, o)` draw one limb (`o.elbow` places
the elbow); `armBlend(shoulder, poseA, poseB, u)` moves an arm between two `{ h, e }` poses by turning each bone, so it
keeps its length; `walkFeet(phase, stride)` gives the ankles for a walk where each foot lands on phase 0 and 0.5, so
a stride timed to two beats puts a step on every beat. Moving the body at `stride / (0.6 * strideTime)` keeps the
planted foot from sliding. `bodyPt(K, fr, X, Y, Z)` turns a point of the room into the figure's own feet, for putting
a hand on a thing at another depth.

**Scenes, pages, the camera.** `engine.js` holds the machinery; `shots.js` fills it in. A scene is registered once and
can sit on any page:

```js
scene('night', { style: 'poster', u: 0, label: 'night',            // label: the caption while the camera is inside it
  draw: (P, t, cell) => SC_STREET(P, { t, tod: 'night', wind: windFor(cell, t), walker: walkerAt(t) }) });
scene('duskday', { style: 'poster', layers: t => [[.42, 1], [1, ramp(t, 7.5, 8.5)]],   // a dissolve, dusk into day
  draw: (P, t, cell, u) => SC_STREET(P, { t, tod: u > .5 ? 'day' : 'dusk' }) });
```

A page is a grid of scene ids, any number of rows and columns (1920x960 page units each, a wavy seam between
neighbours; each panel draws its whole scene at 1.04x so it covers where its seams bulge):

```js
page('street', [['night', 'dawn'], ['dusk', 'day']], { v: [[.0052, .6, 2]], h: [[.0031, 2.1, .4]],   // seam shapes
  backdrop: houseBackdrop, backdropScene: 'house', thumbBelow: .38,
  cellAlpha: (cam, t) => t < 33 ? 1 : clamp((cam.z * KP - .2) / (.36 - .2), 0, 1) });
```

The camera's path is a list of stretches, each on one page, each key `[time, view, ease]`:

```js
seg('street', [
  [0, V('night', 960, 520, 1.14)],             // scene point (960, 520) at the centre, 1.14 screen px per scene px
  [B(9), V('night', 840, 555, 1.62)],           // "wind?" (beat 9): closer on the walker as the gust hits
  [12.7, V('night', 1110, 350, 1.95)],          // up into the tree by the lamp
  [16.25, A(PW, PH, .5)],                        // page units: the whole page, four panels at half size
  [LINE(4), V('day', 740, 600, 1.72)],           // push into the day panel on line 5
  [34.2, A(PW - 19, PH + 86, .393), 'in'],       // the pull-back to the house, gathering speed...
  [35.4, A(PW - 4, PH + 370, .185), 'lin'],      // ...steady while the panels fade...
  [36.4, A(...housePt(960, 520), HOUSE_Z), 'out'],   // ...settling on the house
]);
```

Views: `V(sceneId, x, y, zoom, { free })` frames a panel in its own scene pixels (zoom 1 shows the scene's full
width); `A(x, y, z)` is in page units; `ALL(margin)` fits the page; `CELLS([ids], margin)` fits some panels. A close
`V` view is kept `SEAM_M` inside its panel on every side that has a neighbour, so the neighbour never peeks in at an
edge; `free` turns that off (the demo uses it where the hill's inset covers that edge). Eases: `'io'` (the default),
`'lin'`, `'in'` (gathering speed: into a door), `'out'` (settling); zoom interpolates in log. When one stretch ends
and the next begins, give both keys the same time and the same view of a panel both pages hold: the page change
doesn't show, and pulling back out of that panel finds it in new company.

The moves:
- **Pull back and push in:** a key on a panel, a key on `A(...)` or `ALL()` of its page, a key on another panel.
- **Slide:** a key on one panel, the next on its neighbour. Seam lines are drawn whenever they're on screen.
- **Through a lit door:** a key zooming into the lit opening with ease `'in'`, `flash(t0, peak, t1)` (the picture
  whites out to lamplight by `peak`), and the next stretch starting at `peak` on another page.
- **The building:** give the page a `backdrop` drawn in page units under the grid (the demo's draws `SC_HOUSE` scaled
  so its window grid, `HOUSE_WG`, lies exactly on the page) and a `cellAlpha` that fades the panels as the camera
  pulls back. Below `thumbBelow` panels are drawn from half-size pictures, which fade cleanly as whole pictures;
  `thumbT` draws those pictures once at a fixed time, for a quilt of dozens of panels.
- **The opening:** `seamOpen(t0, t1)` starts the picture as black with one line of warm light down the middle that
  widens like parting doors. The demo opens on a fade instead.

`overlay(t0, t1, fn)` is the general form: `fn(t, cam, page)` draws over the picture in screen pixels. An inset is a
second scene opening over the picture on a seam from the left: `SHOTS.insets = [{ style: 'soft', open: t => seamX,
view: t => [sceneX, sceneY, zoom], draw: (P, t) => ... }]`. `shots.js` ends with `const SHOTS = { ... }`, and
everything in it is optional: `over(P, t, cell, info)`
draws page-space things over each panel in that panel's light, `look(t, cam, page)` and `caption(t, cam, page)`
override the grain's look and the strip's caption, `build()` runs once at load, `poster` is the time shown on load.

**Moves inside a shot.** Most of a shot list is `tween(t, keys)`, a value eased between `[time, value]` keys
(numbers or arrays):

```js
inv: [[B(9) - .08, 0], [B(9) + .1, 1], [B(15) - .06, 1], [B(15) + .08, 0]],  // inside out on "wind?", back on "you"
```

**Wind.** `windAt(t, pageX, pageY)` in `shots.js` is a breeze that changes by section (`BREEZE`) plus gust fronts
(`GUSTS`) that sweep the page from right to left at `GUST_V`. Every scene gets `wind: x => ...` for its own screen x,
so a front crossing the page bends the trees panel after panel. Loose leaves live in page units and are stepped
through the wind once at load (`buildDrift`); `over()` draws them in every panel they cross, with that panel's
Painter, so a leaf changes its light as it crosses a seam. The torn sheet flies the same way along a fixed curve.

**Rooms that fill up.** `SC_ROOM(P, { stage })` is a workroom drawn at stage 0 (a desk, a chair, a clock, the window)
to 3 (shelves, cards, a whiteboard, a cart, a plant, posters, a hanging sign, stickers on everything, a second
person). Each prop checks the stage it arrives at. Props are flat faces (`wbox` draws a box as the faces turned to
the camera, shaded by the look), so a full room costs little more than a bare one. Coming back to a room later,
`revisit(P, t, a, b, (later, P) => SC_ROOM(P, { stage: later ? 3 : 1 }))` dissolves the old room into the fuller one
while the camera travels. The stickers (`sticker(P, x, y, r, 'star')`, `stickerQuad` for one lying on a wall or a page)
are plain stationery: star, heart, raindrop, leaf, snowflake, sun, and plain shapes; they mean whatever your video
needs.

**Lyrics.** The strip under the picture (120 px under a 1920x960 picture) shows one line at a time, each word fading
in as it's sung (`SONG.lines[i].words`), from the line's first word until the next line starts or 2.4 s after its
last word. Lines in a section whose name starts with `chorus` are set in amber italics. A caption at the right shows
the label of the panel the camera is in. `SONG.title` and `SONG.credit` are set in the sky until the first word is
sung.

**Determinism.** A frame is a pure function of `t`: every random choice comes from `rng(seed)` with a fixed seed (or a
seed keyed to the frame, like the drizzle's), and the leaves are integrated once at load, so `step(t)` and
`renderAt(t)` draw the same picture in any order. The caches are each Painter's colour table, the grain tile and,
with `thumbT`, the half-size panel pictures; the Painter's two offscreen buffers, the layer buffer and live panel
pictures are scratch space redrawn every frame.

## Make your own video in this style

1. Copy the folder and your song: `cp -r styles/night-poster projects/my-song`, `cp ~/Music/my-song.mp3
   projects/my-song/song.mp3` (see [docs/your-own-video.md](../../docs/your-own-video.md)).
2. Time your lyrics ([docs/timing.md](../../docs/timing.md)) so you end up with `projects/my-song/lyrics_data.js`
   (written by `tools/audio/to_js.py`), and in `index.html` change `../../examples/poem/lyrics_data.js` to
   `lyrics_data.js`. The page now plays the demo under your song.
3. Keep `core.js`, `paint.js`, `elements.js`, `fig.js`, `props.js`, `engine.js` and the player. Rewrite `shots.js` and
   write your own scenes; the street, the hill, the house and the room are there to borrow from.
4. **A scene:** a new file with `function SC_KITCHEN(P, S = {})`. Make a camera (or a `kit` for a room), lay things
   out in feet with `wquad`, `prj` and `sAt`, paint them with `P.part` and `P.flat` (and the props), and put people in
   with `figPerson`, `figWalker` or `figBack`. Give each thing its daylight colour and let the Painter's `u` make it
   night; for a scene seen at several hours, keep a small table of skies and tints like `STREET_TOD` and mix every
   colour toward the hour's tint (`C()` in the street and the house). Load the file in `index.html` before
   `engine.js`, and try it in the lab first (add it to `LAB_SCENES` in `lab/lab.js`).
5. **Register it and put it on a page:** `scene('kitchen', { style: 'poster', u: 1, label: 'morning', draw: (P, t,
   cell) => SC_KITCHEN(P, { t }) })`, then `page('p1', [['kitchen', 'street'], ...])`. The same scene function can
   sit behind several ids with different times or states (the kitchen at breakfast and at night).
6. **The camera:** one `seg` per page, keys `[t, view, ease]`. Keep a close view's zoom at about 1.12 or more; the
   clamp keeps it off its neighbours. To change page, end one stretch and start the next with the same key in a
   panel both pages hold; to leave through a door, zoom into it with `'in'` under a `flash`.
7. **Timing:** `B(n)` is beat n, `LINE(i)` is line i's start, `SONG.lines[i].words[k][1]` is word k's time. Put hits
   (an umbrella going, a sheet tearing) on beats and changes (a new shot, a push) on line starts. A gust that should
   land on a word needs its front to reach that spot a little early: set its time in `GUSTS` about 0.1 s before the
   word, at the page x of the thing it should hit.
8. **Knobs:** `BREEZE`, `GUSTS` and `GUST_V` (the wind); the tree's bend is `-(0.1 + 0.55w + 0.45w²)`, so a breeze
   leans and a gust bows; `KP`, `AMP`, `SEAM_M`, `SEAM_DARK`, `SEAM_LIGHT` (the pages); `thumbBelow`, `cellAlpha`
   (the building finale); `STREET_TOD` (each hour's sky, tint, lit windows, lamps); `Painter.nightT` and `dayT` (how
   the looks move colour); `grain` in `STYLES`; the strip's font and colours in `drawStrip`; the title's in
   `drawTitle`.

## Lab

Open `http://localhost:8000/styles/night-poster/lab/index.html` and pick a scene and a look;
`?scene=street&style=soft` opens on a pair. The scenes: the street, the hill, three hours of the street side by side
on seams, the house (by night, and by day in the day look), a lineup of the general figure, and the room filling up
(stages 0 to 3 on a page of panels). To render every pair:

```bash
python tools/lab_stills.py styles/night-poster/lab/index.html --all --sheet
```

| | |
|---|---|
| ![The general figure: standing, walking, sitting to read, from behind, from the front with hands on hips, crouching, kneeling, a child](img/lab-people.jpg) | ![One workroom at four stages on a page of panels: bare, a shelf and a first card, a whiteboard and a cart, then full](img/lab-room.jpg) |

What each look's Painter does to the same drawing:

- **Night poster** (`night`): each colour loses 12% saturation and 38% lightness, then goes 20% of the way to navy;
  shadow bands go 46% toward near-black blue; emissive colours keep their lightness; a strong vignette.
- **By day** (`poster`, u = 1): colours stay nearly true with 7% of a warm cream; shadow bands go toward blue-violet
  rather than black, light bands toward warm white; a lighter vignette. In between (dawn at 0.6, dusk at 0.42) it
  mixes the two, and the scene adds its own sky and tint for the hour.
- **Soft shapes** (`soft`): lightness lifted (up to 0.9) and saturation up 10%; every shape gets a light band half as
  wide as its shadow band; more grain, no vignette.
- **Ink line** (`ink`): each shape is stroked in dark ink at twice its line weight before its fill goes on, so a union
  of shapes gets one outer line; detail lines are ink; a violet shadow tone. Props drawn as flat faces get a thin
  ink outline per face.

## Performance

- Measured in headless Chrome on an Apple-silicon Mac: a close shot (one panel) draws in 15-35 ms, about 45 ms with
  the inset open; the four-panel page 80-140 ms (four whole scenes, around 900 shaded shapes); the pull-back to the
  house 60-140 ms (the house plus four half-size panels); the house alone about 8 ms. The mean over the demo is about
  42 ms.
- The cost is in `P.part`: a shape with a shadow, a light band or a rim is composited through two offscreen buffers,
  and the cost is proportional to the shape's box. Flat, unlit shapes are filled straight onto the frame. A path you
  build by hand (`new Path2D()` then `moveTo`...) has no box and composites the whole frame; start it with
  `emptyPath()` and add to it with the builders (or `leafPath`), or set `path.bb` yourself. For many small things
  (props in a room), use `P.flat` and `wbox`.
- Pages of many panels: below `thumbBelow` a panel is drawn from a 960x540 picture instead of in full, and with
  `thumbT` that picture is made once. A 7x7 quilt is then 49 image draws rather than 49 scenes.
- Memory: two 1920x1080 offscreen canvases shared by all painters (about 16 MB), a third for layer dissolves (8 MB,
  made when first needed), 2 MB per panel picture, and the leaf table (90 leaves x 1850 steps x 3 floats, about 2 MB).
- A whole `--fast` render takes about a minute for the 900 frames. Render a slice while you work on a stretch:
  `python tools/render_mp4.py styles/night-poster/index.html --start 15 --end 19 --fast`.
- Measure in a fresh page. After many `getImageData` readbacks Chrome may move a canvas to software rendering, which
  is several times slower and antialiases slightly differently.

## Lessons and gotchas

- **Night by mixing, not by hue.** Darkening by rotating hue toward blue turned cream walls red. Mix toward navy and
  lower the lightness instead, and mark lights as emissive so they keep their brightness.
- **Pale props shift hardest at night.** A pale blue blanket went royal blue under the night transform and a cream
  one went mustard; a cream house front came out ochre. Check pale things in the night look, pick them a little
  greyer, and give each night scene its own tint (the street and the house mix every colour toward the hour's tint
  before the Painter's night transform).
- **Day needs its own palette.** Mixing everything toward cream read as washed out and too close to soft shapes.
  Richer mid-tones and cool violet shadows fixed it, with the scene supplying its own colours for the hour (sky, a
  tint, which windows are lit) and the Painter doing the rest.
- **Keep the sky.** A tall building or big trees filling the top of the frame hid the sky, and in a poster the sky
  carries the hour. Three trees in the street, not five.
- **A tree that bends on a circular arc only slides its crown sideways.** To read as bowing, bend more toward the top
  (the angle at height s is `bend * s^1.9`), let the crown stream out downwind, and make the bend grow faster than
  the wind, so a breeze is a lean and a hard gust a bow.
- **Don't multiply time by a rate read from the wind.** Clouds drifting at `t * speed * wind(now)` raced across the
  sky as a gust arrived and ran backwards as it died down, and smoke, washing and a windmill driven the same way
  skipped. Anything that accumulates (a drift, a phase, an angle) needs a steady rate or the wind integrated over
  time (`buildDrift` does that for the leaves); the wind's strength can still set a bend, a lean or an amplitude.
- **Rim lights are in scene pixels.** A fixed width looks fat on a small figure and in a close-up; scale it to the
  figure (`w: fr.s * .1`). Aim it from the lamp to the figure, and it moves as they walk past.
- **Smoke puffs spaced wider than they are big look like beads.** Overlap them, and let the wind lay the plume over
  rather than stretch it.
- **Cloth is a flag.** A tumbling rounded rectangle read as a cushion. Draw it pinned along one edge with waves
  running out to the free end (`flag`).
- **Elbows.** Solving the elbow from the hand with a fixed side put a resting arm's elbow up in the air, and a
  resting figure's arms crossed in an X. `bend: 'down'` picks whichever elbow hangs lower, which suits a relaxed
  arm; for a pose that matters (resting on a table, hands on hips, arms hanging straight) give the elbow as well.
- **Blend arm poses by turning each bone**, not by blending positions: a straight blend shrinks the arm mid-move
  (`armBlend`). Targets solved by `limbArm` keep bone lengths anyway.
- **Two hands near the face read as someone holding their head.** When a figure holds something overhead, put the
  hands clear above the head.
- **Hair on a head lying down** read as a ball, then as leaves: draw it falling back from the forehead and spreading
  along the pillow.
- **A general figure's defaults must lose to the garment's own.** A shared hem default made every coat hip-length,
  and a sleeve default made sweaters short-sleeved; `figPerson` looks a garment's hem and sleeves up by its kind.
- **Figures are flat at their own depth.** A hand drawn at the figure's depth can't rest on a desk top nearer the
  camera; aim it at the thing with `bodyPt`, or slightly below the surface's height. Draw someone standing behind a
  desk before the desk, so it hides their legs.
- **Side walls barely show** from a camera looking down a room: posters there must sit near the back wall to be in
  shot. And props placed in front of the camera's near plane land huge or off the edge.
- **Capsules and arcs.** An arc drawn the long way round left circles at every elbow; `capsule()` draws both ends the
  short way.
- **Splitting points into several paths:** choose the path once per point and use it for both `moveTo` and `arc`, or
  snowflakes and flowers get joined into huge triangles.
- **A curve that must continue a path** (a panel outline made of two seams) needs `curve(..., path, true)`, which
  starts with a line instead of a new subpath.
- **Panels peek in.** Full-frame views showed the neighbouring panel at an edge where a seam bulges. Close views are
  now clamped inside their panel (`SEAM_M`); a view that does show a neighbour must show its seam line too (a
  neighbour without a seam line looks like a glitch), which is why seam lines are drawn whenever they're on screen,
  slides included.
- **Seams in one path.** Stroking each seam separately let the second seam's dark edge cut across the first one's
  light line where they cross; all of a page's seams are stroked as one path.
- **Page seams go under insets.** Drawn after the inset, a page seam crossed over the inset's picture.
- **Clip panels to the page.** A panel draws its whole scene larger than itself; at a page's outer edge nothing
  clipped it, and once the camera pulled back past the page (onto a backdrop) the scenes showed ragged edges.
- **Fading a scene.** A scene drawn at partial alpha shows its own shapes through each other (the sky through the
  houses). Fade whole pictures instead: a panel below `thumbBelow` is a picture, and a scene's later `layers` are
  drawn whole into a buffer and laid over. A shape's own `alpha` multiplies with the context's, or a dissolve drops
  the shapes that set one.
- **The building finale.** The panels came back in the windows whenever the camera passed that zoom again, until
  their fade was tied to time as well as zoom (`t < 33 ? 1 : ...`); and a backdrop that only drew when zoomed out
  blacked out a push back into it. The engine draws the backdrop whenever the view reaches past the page or the
  panels have faded. Keep the pull-back's speed even through the fade: an eased-in-and-out key on each side of it
  stops the camera there, so use `'in'`, `'lin'`, `'out'` with zooms chosen so the speed carries across the keys.
- **A scene drawn small inside its panel** (a wide view of somewhere) left hard edges where its hills stopped: run
  its ground and sky past the frame.
- **Compose an inset for the part its seam uncovers,** and don't time anything important under it: an early inset put
  its figures behind its seam, and an action landed while the inset still covered it.
- **A curve through too few points overshoots** (a line looping past where it should stop): add points.
- **Don't mutate what `tween` returns:** before the first key and after the last it hands back the key's own array.
- **One bad value in a gradient blanks the frame.** Check the console after every load; the still tool prints it.
- **Stale scripts:** serve with `tools/serve.py` (no caching), and reload with a new query after an edit.
- **Nothing still for long.** A hold of more than a beat or two reads as the player freezing; keep a camera drift,
  clouds, smoke or leaves moving through every held shot.

