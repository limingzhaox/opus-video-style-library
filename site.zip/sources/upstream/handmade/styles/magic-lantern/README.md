# Magic lantern

Engraved glass slides, coloured by hand, thrown onto a sheet by an oil-lit lantern in a darkened parlour. Every picture
is drawn in code as an engraving: each tone becomes parallel lines whose width follows the tone, laid at the surface's
own angle, with cross-lines in the darks and ink outlines on top. The engraving is then made into glass: its light is
the hand tint's transparent colour times one minus the ink. A slide is built the way real lantern slides were: a fixed
base glass with moving glasses (slipping and rackwork slides) in front of it, so light passes through both and a moving
piece can only darken what's behind it. The lantern throws that stack through a round, arched or cushion-shaped mask,
with the lamp's warm hot centre and falloff, a flicker, dust and a hair on the lens, a colour fringe toward the edges
and grain. Two stacks at once give the dissolving views and the carrier changes (one slide pushed out as the next comes
in). The camera can pull back into the room to see the picture on its sheet over the audience's heads, or follow the
picture wherever the lantern is turned, onto the people or onto fog. Under the picture runs the printed Reading, the
booklet a lantern lecture came with: the line being sung inks in word by word, with the slide number in the margin.

![A lantern evening: the weathercock slide on the sheet, the audience in silhouette, the lecturer pointing](img/hero.jpg)

## Looks in this family

The lab (below) draws the same scenes three ways, all from the same engraving pass:

- **Magic lantern**, the demo's look: the engraving on hand-tinted glass, projected.
  ![A ship in a gale as a lantern slide](img/look-lantern.jpg)
- **Wood engraving**: the engraving printed in an illustrated weekly, on newsprint, with its caption and leader column.
  ![The same scene as a newspaper wood engraving](img/look-engraving.jpg)
- **Crayon lithograph**: soft crayon on a litho stone, hatched by hand, with scraped whites, on a satirical paper's page.
  ![The same scene as a crayon lithograph](img/look-crayon.jpg)

## Run the demo

From the repository root:

```
python tools/serve.py
```

Then open http://localhost:8000/styles/magic-lantern/index.html. The page first bakes its slides ("Making the slides
n/46", 6-17 seconds), then Play (or Space) plays it with the song, and the slider scrubs. If the song can't load, it
plays on a silent clock. Add `#t12.5` to the address for a still of that moment, with the page's controls hidden.

It plays live: once the slides are baked a frame draws in 7-24 ms, well inside the 42 ms a 24 fps frame allows.

Stills, with a contact sheet:

```
python tools/still.py styles/magic-lantern/index.html 2 6 12.5 0:37.5:2.5 --sheet
```

An MP4 with the song:

```
python tools/render_mp4.py styles/magic-lantern/index.html          # 1080p, and a 720p copy
python tools/render_mp4.py styles/magic-lantern/index.html --fast   # 720p only, quicker
```

The whole 37.5 s demo (900 frames) took about 4 minutes with `--fast` on an Apple-silicon Mac that was busy with other
renders: about 0.27 s a frame, nearly all of it reading each frame back from the canvas and encoding it.

![The leaves dissolving into the chromatrope](img/dissolve.jpg)

## How it works

### The files, in load order

| file | its job |
| --- | --- |
| `../../examples/poem/lyrics_data.js` | `window.SONG`: title, credit, audio, duration, bpm, and every line with its word times |
| `core.js` | sizes, seeded random numbers, value noise, geometry (ellipses, Chaikin smoothing, a hand-drawn wobble, tapered bands, Béziers), the fonts |
| `figure.js` | whole figures, ray-marched in WebGL: face, hair, hat, hood, torso, jointed arms and hands, a long coat with folds and a lean, scarf, legs |
| `gbuf.js` | the scene painter `GB`: a picture is drawn once into a set of buffers; `putFigure` puts a rendered figure into them |
| `render.js` | the WebGL passes: `engrave` (buffers to engraved ink), and the three looks as stills: `onSlide`, `onPaper`, `crayon` |
| `people.js` | face types (`CAST`), `person()`, `placePerson()`, `fromBehind()`; curls, hair streaming in the wind, spectacles |
| `props.js` | the drawing vocabulary: the lantern, drapery, shelves, floorboards; skies, clouds, sea and swells, a ship, a lighthouse, trees that bend at joints, a thorn, grass, a wall, a windmill, a weathervane |
| `lantern.js` | the per-frame compositor, in its own WebGL2 context: stacking glass, the projector pass, and the room, scene and fog passes |
| `plates.js` | baking: `slide()`, `piece()` and `roomView()` register things to bake; `plate(name)` bakes one the first time it's needed |
| `reading.js` | the printed Reading under the picture |
| `room.js` | the parlour: the sheet, the audience, the lecturer at his lantern (`drawRoom`) |
| `slides.js` | the demo's slides and their moving glasses |
| `scenes.js` | the demo's room views, and the moor at night for the fog |
| `timeline.js` | the demo: `CUES`, `VIEWS`, `BRIGHT`, the wind, and how every moving glass moves |
| `engine.js` | one frame: the stacks, the transitions, the views, the band; `bakeAll()` |
| `index.html` | the page, the player and the `window.__video` hooks |

### Drawing a picture: the scene painter

A picture is drawn in design units, 1600 x 800 for a slide (the picture's 2:1; it fills 1920 x 960 above the 120-px
band, so `PX(v)` = `v * 1.2` turns design units into picture pixels) and 1600 x 900 for rooms and scenes (cropped top
and bottom). You draw into a `GB`, which holds several same-sized buffers: tone (`T`, 1 = white, 0 = black), light
(`Lt`, multiplies the tone), hatch (`Hh`: line angle, cross-line angle, line class), tint (`C`, the hand colouring),
outline ink (`O`), and scraped whites (`Wt`, used by the crayon look). The calls you use:

```js
S.shape(pts, { tone, hatch, tint, out, outA, over, rule })  // fill a polygon (or a list of them, or a Path2D)
S.line(pts, width, alpha); S.lines(list, width, alpha)     // ink lines, width in design units
S.text(str, x, y, font, { align })                          // ink letters (or buf: 'T', fill: '#fff' for clear ones)
S.ambient(v); S.glow(x, y, r, v); S.light(x, y, r, v0, v1); S.lightShape(pts, v)   // lighting, into Lt
S.pushClip(pts) ... S.popClip()                             // clip every buffer to a shape
```

- `tone` is a number or a gradient: `{ lin: [x0, y0, x1, y1], st: [[0, .9], [1, .4]] }` or `{ rad: [...], st }`.
  The engraving turns it into line width: .95 is a few hairlines, .5 solid lines, .15 cross-hatched near black.
- `hatch` is `[angle, crossAngle, class]` in degrees (0 = level lines, 90 = upright); the class is the spacing,
  `H_.fine`, `H_.mid`, `H_.norm`, `H_.coarse`, or 0 for flat (no lines at all: clear glass at tone 1, black at 0).
- `tint` is any CSS colour; its alpha is how strongly the wash colours the glass (`tintLin()` makes a gradient).
- An opaque shape hides the lines, tint and outlines of what's behind it, so draw from the back forward.
  `over: true` keeps them (for shading laid over something already drawn).
- A room reports what the passes need: `S.sheetQuad` (the sheet), `S.lensAt` (the lantern's lens), `S.targets`
  (named places a picture can be thrown, `{ name: [cx, cy, width] }`) and optionally `S.lights`.

Figures are rendered in 3D and dropped in: `sp(S, person('elder', { pose: { yaw }, body: { cloak: {...}, hat }, light,
rim }), 16)` makes a spec at 16 design px per head unit, and `placePerson(S, spec, x, y, extras, { tone, tint })` puts
its head at (x, y). `fromBehind()` is the common case of someone seen from behind. The `tone` overrides map each
material to a range, which is how the parlour's audience become silhouettes.

### Baking: slides, moving glasses, rooms

```js
slide('vane', S => { sky(S, -60, -60, 1660, 900, {...}); cupola(S, 800, 830, 1.0); });   // the base glass
piece('vane_cock', S => weathercock(S, 800, 270, 1.0));   // a moving glass, drawn where it rests, on clear glass
roomView('roomLit', S => drawRoom(S, { lecturer: 'lantern' }));   // a room print, at twice the picture's size
```

`plate(name)` bakes a registered thing the first time a frame asks for it: draw it into a painter at twice the
picture's size, engrave it, turn it into glass (`tint * (1 - .95 * ink)`), scale it down and keep it as a texture. A
piece is cropped to what it holds. A room is baked as a print (warm paper and ink, darker where its light is dim).
`bakeAll()` bakes everything ahead at load while it fits in three quarters of `BUDGET` (900 MB); past the budget the
least recently used plates are let go and baked again when needed, so a long song still fits.

### A frame

`drawFrame(t)` finds the cue on show and the one before it, draws each one's stack (its base plate, then each moving
glass at its place for time t, multiplied together), and then, depending on the view:

- `slide`: throws the stack full frame through the projector pass (mask, lamp falloff and flicker, dust, colour
  fringe, grain, an optional crack), with the cue's camera or a slow 4% creep over six seconds;
- `room`: lays the room print under the camera and adds the projected picture on its sheet, with the beam's haze and
  the lantern's glow;
- `push` / `pull`: moves between the room and the slide, the slide view drawn through the same camera while one gives
  way to the other;
- `scene`: an unlit print lit in the pass by the room's darkness, the lantern's glow and the picture wherever it lands;
- `fog`: a place at night with fog blowing across it and up to four glasses thrown onto the fog, showing only where
  there's fog and bent by its movement.

Then the Reading band, and a short fade from and to black at the very ends.

### The timeline

`timeline.js` holds three lists. `CUES` says what's in the lantern:

```js
{ t: 3.75, slide: 'vane', num: 1, trans: 'carrier', td: .45, mask: CIRC, pieces: [
  { plate: 'vane_cock', at: t => ({ sx: Math.cos(vaneHeading(t)), px: PX(800), py: PX(270) }) },   // turns on the spindle
  { plate: 'vane_clouds', at: t => ({ x: PX(integ(WIND, 3.75, t) * 34) }) },                         // drifts with the wind
] },
```

- `trans` is how it arrives: `'cut'`, `'dissolve'` (over `td` seconds, the two lanterns' light adding) or `'carrier'`
  (the old slide pushed out to the left as this one comes in from the right).
- `mask`: `['circle', radius]`, `['cushion', halfWidth, halfHeight]`, `['arch', halfWidth, halfHeight]` (picture px;
  `CIRC`, `CUSH` and `ARCH` are the demo's), or `null` for none. `slide: null` is the lantern with no slide in.
- `num` goes in the Reading's margin: a number prints `[Slide 3.]`, `'title'` prints `[Title.]`, any other string as is.
- Each piece's `at(t)` returns where its glass is: `x`, `y` (offset, picture px), `rot` (radians, clockwise), `s`,
  `sx`, `sy` (scale about the pivot), `px`, `py` (the pivot), `alpha`, `wipe` (0-1, reveals it along `dir`: 0 left to
  right, 1 top down, 2 and 3 the reverse). Returning `null` takes the glass out for that frame, which is how two
  glasses are swapped on the beat (the smoke in the trees slide runs three in turn).
- Optional: `cam: t => [zoom, panX, panY]`, and `crack: t => ({ x, y, ang, amt })` for glass cracked by the lamp's heat.

`VIEWS` says what the camera sees, `[kind, from, to, options]`; the options are mostly keyed values, `[[time, value...],
...]`, eased between keys:

```js
['slide', 3.55, 7.5, {}],
['pull', 7.5, 8.5, { room: 'roomPoint', cam: [[8.5, 1.1, -70, 24]] }],          // out of the slide into the parlour
['room', 8.5, 10.3, { room: 'roomPoint', cam: [[8.5, 1.1, -70, 24], [10.3, 1.16, -60, 34]] }],
['push', 10.3, 11.25, { room: 'roomPoint', cam: [[10.3, 1.16, -60, 34]] }],     // back in, landing on the next slide
['scene', 22.5, 26.25, { scene: 'roomAlb', proj: swing('roomAlb', 'sheet', 'audience', 22.55, 23.4), amb: [[0, .17]] }],
```

`cam` keys are `[time, zoom, panX, panY]`. A room view takes `dark`, `sheetGain`, `haze` and `glowK` keys; a scene
view `proj` (keys of `[cx, cy, width]`, a function of t, or a target's name), `amb`, `bounce` and `lights`; the fog
`imgs(t)` (a list of `{ plate, x, y, s, rot, a, soft }`), `rise`, `bank`, `wind` and `colour`.

`BRIGHT` is the lamp: `[[time, level], ...]`. The demo's lamp catches at the start and gutters out at the end.

The demo, line by line: the parlour in the dark, the lamp catching, the title slide coming in on the carrier and the
camera pushing in; the weathercock swinging round on "wind?"; a pull back to the audience and the lecturer on "Neither
I nor you" and a push back in; leaves trembling on their glasses, three tearing off on "trembling"; a dissolve into a
chromatrope spinning up on "passing through"; a ship rolling in a gale; the lantern swung round onto the audience;
trees bowing on "bow down their heads"; the pictures blown past on fog over a moor at night; Good Night on the sheet.

![The ship slide thrown across the audience](img/audience.jpg)

### The lyrics

`reading.js` makes `LINES` from `SONG.lines` and prints the Reading under the picture: before the first line, a title
page with `SONG.title` and `SONG.credit`; then each line in italic, each word inking in from pale to black at the time
it's sung, a new line rising as the old one lifts away, and a line fading a little when the next one is a long way
off. The running head at the right is the song's title; the margin shows the cue's `num`.

### Determinism and caching

Nothing uses `Math.random()` per frame. The lamp's flicker and the grain are keyed to the frame number, the rest is a
function of t and seeded random numbers, so a given moment always draws the same (checked: a frame drawn twice matches).
`step(t)` draws the 24 fps frame t falls in, the way playback does, and is what the MP4 tool calls; `renderAt(t)` draws
exactly t. No frame depends on the one before, so any frame can be drawn on its own, and a slice can be rendered alone.
Plates are baked once; figures are cached by their spec; shader programs and framebuffers are made once and reused.

## Make your own video in this style

1. Copy the folder: `cp -r styles/magic-lantern projects/my-song` (see [docs/your-own-video.md](../../docs/your-own-video.md)).
2. Make your song's timing file with `tools/audio/to_js.py` (it writes `lyrics_data.js` with the same `SONG` shape).
   Put it and your mp3 in your folder and change the first script tag in `index.html` to
   `<script src="lyrics_data.js"></script>`; `SONG.audio` is relative to the page. Change the page's title and heading.
3. Keep `core.js`, `figure.js`, `gbuf.js`, `render.js`, `people.js`, `props.js`, `lantern.js`, `plates.js`,
   `reading.js` and `engine.js` as they are, and `room.js` if a parlour suits you (it's plain to edit). Replace
   `slides.js` (your pictures), `scenes.js` (your room views and scene prints) and `timeline.js` (your cues, views and
   lamp). The demo's versions are the examples to copy from.
4. **A slide**: write a function that draws it in the 1600 x 800 design, back to front (the sky, the far things, the
   near things), thinking in tone (how much ink) and tint (the colour of the wash). `props.js` has skies, clouds, sea,
   ships, trees and more. Register it with `slide('name', draw)` and give it a cue.
5. **A moving glass**: draw it with `piece('name', draw)` where it rests. It must move over a light part of its slide:
   leave that part of the base pale or clear and put the darkness on the piece (the demo's whole sea is a sliding glass
   for that reason). Move it with a piece entry in the cue; pivots and offsets are picture px, so wrap design numbers in
   `PX()`. For a jointed thing (a tree bending at two joints), compose each part's offset from the part below it, as
   `treePieces` in `timeline.js` does.
6. **Timing to a word or a beat**: `SONG.lines[2].words[5][1]` is when "trembling," is sung (13.125 s); `SONG.beat(n)`
   is beat n (every 0.625 s at 96 bpm); a bar is `BAR`. Put slide changes on line starts (`SONG.lines[i].t0`) and hits
   on beats: a key in `BRIGHT`, a gust in `WIND`, a key in a piece's motion. `kv(keys, t)` eases between keys;
   `integ(keys, t0, t)` integrates a speed (for things that turn or drift at a changing rate).
7. **Views**: to show the room, register a room view and add `room`, `push` or `pull` entries around a slide; to throw
   the picture somewhere else, give the room's draw function `S.targets` and use a `scene` view with `proj`.
8. **The knobs**: masks and transitions per cue; the slide camera (`cam`, or the default creep in `renderPicture`);
   `BRIGHT`; the flicker's size (`lampAt` in `engine.js`); the lamp's colour (`[1, .9, .74]` in `lantern.js`); the
   colour fringe (`uCA`, .0025) and grain (`uGrain`) in `project()`; the engraving's line spacing (`period`, default 11)
   and wobble (`eng: { wob }` in a slide's options); how strongly the tint colours the glass (`tintA`, .9); the room
   pass's `dark`, `sheetGain`, `haze`; the fog's `rise`, `bank`, `wind`, `colour`; the memory `BUDGET`.
9. Check with `python tools/still.py projects/my-song/index.html 0:<length>:2.5 --sheet` and read its console output:
   a single bad value in a gradient can blank a frame.

![The trees bowing](img/trees.jpg)

## Lab

Open http://localhost:8000/styles/magic-lantern/lab/index.html and pick a scene and a look with the buttons, or go
straight to one with `?s=gale&st=crayon`. To render every scene in every look:

```
python tools/lab_stills.py styles/magic-lantern/lab/index.html --all --sheet
```

Each still takes 0.1-1.5 s. The page sets `window.__lab = { ready, scenes, styles, render(scene, look) }`. It loads the
style's own engine files from the folder above, plus `lab/scenes.js` (the two scenes, each a function of the painter
and the look, so the parlour can be lit by the lantern in one look and by its lamp in the others) and `lab/styles.js`
(what turns the buffers into each look and lays out the page). `inset()` draws one scene inside another: the printed
looks show the gale as a picture on the parlour's sheet. A look named `dbgT` (or `dbgHh`, `dbgC`, `dbgO`, `dbgLt`...)
shows one raw buffer, which is the quickest way to see why something engraves wrongly.

- **Magic lantern** (`onSlide`): the engraving becomes glass (its transmission times the tint), masked round or as a
  cushion, with the lamp's falloff, a colour fringe and a little softening toward the edge, dust and a hair, and the
  sheet's weave. A room is printed warm and dark (`roomPrint`) and the slide is laid over its sheet.
- **Wood engraving** (`onPaper`): the same ink printed black on newsprint, spreading a little, unevenly inked, with
  fibre and foxing, set on a weekly's page with a masthead, a caption and the verse in the leader column.
- **Crayon lithograph** (`crayon`): a soft tone rubbed onto the stone's grain, loose hatching along each surface that
  widens in the darks, outlines redrawn two or three times a little off (`jitterOutline`), scraped whites; on a paper's
  page with the type on the back of the sheet showing through.

## Performance

- **Loading**: 46 plates bake in 6-17 s (each is drawn into buffers at twice the picture size, engraved on the GPU,
  and read back; the figures are ray-marched once each). They take about 290 MB as textures.
- **Drawing**: 7-24 ms a frame. The fog is the slowest (full-screen noise); slides and rooms are 7-14 ms.
- **Rendering**: about 0.27 s a frame for an MP4, nearly all of it the readback and the encoder.
- **Slower**: more figures (each is a ray-march), bigger pieces (a piece is baked at full picture size before it's
  cropped), four glasses on the fog.
- **A slice**: `python tools/render_mp4.py styles/magic-lantern/index.html --start 18.75 --end 26.25 --fast`. Frames
  don't depend on earlier ones, so a slice matches the full render and `tools/splice.py` can put it back.

![The pictures blown past on fog](img/fog.jpg)

## Lessons and gotchas

- **Glass only darkens.** A moving piece has to move over light glass; a light piece over dark glass disappears (the
  sea's foam vanished until the whole sea went onto the moving glass and the base was left clear below the horizon).
- **Overlapping glass doubles the ink.** A tree cut into segments showed dark bands where the segments overlapped; they
  meet exactly at the joint instead, and the sliver a bend opens is too small to see.
- **A picture thrown at an open night sky shows nothing.** A scene's night sky prints near black, and the pictures
  appear only on fog or on things.
- **Push-ins first showed a double image.** Draw the slide view through the same camera as the room while they
  crossfade.
- **Textures created while others were bound overwrote them.** Create textures on a scratch unit (TEXTURE15).
- **The fog's own colours and overlapping pictures blew out to white** until toned down with a soft shoulder. A
  chromatrope's clear glass throws a white disc: make the glass round it black.
- **Phantasmagoria glasses are painted on black**, so only the subject throws light and floats on the fog; a whole
  slide thrown on fog is a bright rectangle.
- **Lines and tint from shapes behind showed through shapes in front** until every opaque shape cleared the outline,
  tint and scrape buffers under itself (`over: true` keeps them on purpose).
- **Figures behind furniture show their legs under it**: cover them (a hanging tablecloth) or cut the figure's window.
- **Lines laid round the body gave coats zebra chevrons.** Figures use straight lines at an angle per material.
- **The crayon's grain looked like digital speckle** until it became a soft rubbed tone with the grain as texture and
  the darks carried by hatching.
- **A beam drawn as light made a hard wedge on the wall**; the beam is a faint haze in the pass.
- **Fog first read as cartoon cumulus, then swallowed the scene**: low banks blowing in from one side read as fog.
- **The arched mask was a full semicircle** until made segmental.
- **Heads seen from behind looked like blank faces**: a hair cap leaves the nape bare, and skin can't go darker than
  its material's range. Pull the hairline down for backs of heads and pass tone overrides for silhouettes.
- **In a scene lit by the picture, a figure's baked shading fights the projected light**: bake figures for an unlit
  print with a plain frontal light.
- **Smoothing rounds everything.** Chaikin smoothing turned square sails into octagons: keep straight what's straight
  (a yard) and curve only what bellies.
- **Clouds with hard outlines look cut out of card**: shade them from the lit side, keep the outline faint, and make
  the sky around them darker than their lit tops.
- **The colour fringe grows with the square of the distance from the centre**: .004 was 15 px at the frame's edges.
- **A weathercock turning on its spindle is a squeeze, not a rotation**: scale the glass by the cosine of its heading.
- **Hold nothing still for long.** A frame that doesn't move for more than a beat or two reads as the player freezing;
  keep something drifting (the slow creep on every slide, a camera move in every room shot, the flicker).
- **Time to the measured audio**, and put the changes on musical events: a line's start, a beat, a gust in the wind.
- **Fonts must load before baking**: canvas text silently falls back to another face if the web font isn't ready.
- **A frame grabbed right after the page loads can catch the player's own opening frame**; the MP4 tool isn't affected.

