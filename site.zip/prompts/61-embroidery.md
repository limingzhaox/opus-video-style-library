# 61 · 羊毛刺绣 / Wool embroidery

来源类型：根据作者引擎说明整理的使用模板；并非作者原始创作提示词  
原作者：Miranda Dixon-Luinenburg  
上游原文：https://github.com/cyborggirl963/opus-5.5-music-video-art-styles/tree/main/styles/embroidery  
固定版本：801b3548c54765ecf932ce8b7f3cf4b29fb7a8bf  
抓取核对日期：2026-11-10  
本库改动：中文任务模板、中文摘要与编排；原文全文保留。

## 使用前先看

- 弯曲布片要共享网格边界，旋转小条会张开扇形裂缝。
- 重叠线团先合并轮廓，避免每团都描边而像乱麻；小字和面部先看实际尺寸。

- 这是代码渲染工作流；聊天文本本身不会自动产生 MP4，需有可执行的项目环境。
- 先看预览再做长片；不要把示例素材的许可自动套到自己的歌曲、照片、字体和品牌上。
- 下方复制区包含全部风格与公共规范，不要求 AI 另外从本机隐藏路径读取文件。

## 完整复制区

你是一位能写代码、检查画面并渲染成片的动画导演。请用“羊毛刺绣 / Wool embroidery”制作一个属于我的视频。

【我的需求；把花括号内容换成实际值】
主题与一句话故事：{{填写主题和结尾变化}}
用途与观众：{{例如面向普通观众的科普短片}}
内容依据或已有脚本：{{填写；没有则说明需要你写}}
音频、歌词、图片、数据、品牌素材路径：{{填写；没有写“无”}}
素材使用权限与需显示的署名：{{填写来源与许可；不清楚请列待确认项}}
目标时长：30 秒起步；MV 以实测歌曲时长为准
画幅与清晰度：默认横屏 16:9、1920×1080；帧率按本风格原文与引擎规范，未规定时24fps；竖屏须重新构图，不直接裁横屏
语言：简体中文；配音需求：{{有/无、声线与语速}}
必须出现的内容：{{填写}}
禁止出现的内容：{{填写}}
预算与速度：先做低成本验证，再渲染完整片
个人工程名：my-video（可改为英文短名）
确认方式：先给 3 张由真实渲染代码产出的样帧和 5–10 秒预览；我确认风格后再做完整成片

【本风格的核心实现】
用羊毛线迹、亚麻底布、沿形体的针向和长挂毯式移动镜头构图。
特别检查：
- 弯曲布片要共享网格边界，旋转小条会张开扇形裂缝。
- 重叠线团先合并轮廓，避免每团都描边而像乱麻；小字和面部先看实际尺寸。

【工程与流程】
1. 在工作区单独克隆 https://github.com/cyborggirl963/opus-5.5-music-video-art-styles ，检出 801b3548c54765ecf932ce8b7f3cf4b29fb7a8bf。将 styles/embroidery/ 复制到 projects/my-video/，保留引擎，按该风格 README 指定的文件替换示例场景。不要直接修改 styles/ 中的母版。
建立 Python 虚拟环境，阅读 requirements.txt 后安装渲染依赖；需分析音频时再安装 requirements-audio.txt。使用 Chrome 或项目支持的 Chromium。使用 python tools/serve.py 提供本地 HTTP，不用 file:// 打开渲染页面。
2. 先检查机器的 Python、Node/浏览器、FFmpeg、字体与 GPU 能力。Lemo 当前要求 FFmpeg 7+；先用 ffmpeg -version 核对。缺少工具或访问权限时明确报告缺什么，不能只描述完成、伪造文件或把截图称为已渲染视频。
3. 把我的需求写成 PLAN.md 或 TREATMENT.md：一句话故事、分镜、逐镜秒数、镜头运动、文字位置、音乐与声音 cue、所需素材、预计成本。涉及事实和数据时写 FACTS.md；没有来源的数字不填。
4. 如果是 MV，先取得音频与实际演唱歌词，测量段落、停顿、节拍与词时间；不得沿用 37.5 秒示例诗的时间轴。未提供音乐时不要假装已经完成歌词对齐，可先制作无歌词短预览。
5. 先完成 3 张代表开头、关键变化、结尾的样帧，逐张检查；再渲染 5–10 秒低清短段，检查字幕、运动、音画同步与控制台。复杂慢风格先计时，再估算整片。
6. 随机效果固定种子；有历史累积的媒介按顺序渲染。并行前先比较随机抽帧与连续渲染是否一致。
7. 正式导出使用项目文档中的工具与参数，不臆造命令。交付可播放 MP4、720p 预览、源代码、素材清单与许可、字幕（有台词时）、复现说明；保留最终片长、帧率、音频响度与实际渲染耗时。
8. 实际打开并检查成片开头、中间、转场、结尾及全片联系表，确认没有空帧、字体回退、遮挡、裁字、爆音或无意复制的作者片尾签名。交代尚未完成的检查。

下面是完整风格参考与公共制作规范。它们是上游参考资料，不代表我的主题或逐字台词；我的具体需求优先。风格中明确的声音、镜头和媒介限制优先于公共建议，例如无声电影不添加旁白或拟音。遇到 macOS/Linux 示例命令时按当前系统等价转换，不直接在 PowerShell 粘贴 bash 命令。相对资源路径以完整克隆的上游工程为准。


===== 完整风格原文：styles/embroidery/README.md =====

# Wool embroidery

A long embroidered hanging, wool on linen, that the camera travels along. Everything is drawn with the 2D canvas,
stitch by stitch, and what makes it read as needlework is how it's made, the way a real piece is worked. The linen
is a woven texture with slubs and faint foxing. Each patch of colour is wool *laid and couched*, as the Bayeux
Tapestry was worked: long parallel threads, each shaded along its twist with its highlit side turned to the light,
tied down by thinner threads in a staggered pattern, with loose fuzz on top and a soft shadow under the patch. Every
shape is outlined in *stem stitch*, one overlapping stitch at a time. Faces and hands are bare linen with an outline.
Leaves, fruit and flowers are *French knots*. Light and wind are *couched gold thread*: two metal plies held down by
small red ties. Because the outlines are separate stitches, a piece can be recorded and then *sewn in on screen*: the
outline runs round first, then the wool is laid row by row. Skies can be laid too: a mist of wool laid thin in bands,
with bands of light in couched gold drifting across it; and the far distance can hang from the top of the sky, its
houses upside down. The hanging hangs from a rod in a dim hall; whenever the camera stands back you see the hall, the
rod and the whole cloth.

The demo is Christina Rossetti's "Who Has Seen the Wind?", so it only shows wind through what it moves. A windmill
turns and smoke streams off a chimney while two people meet on the road, and a gust takes one's hat; overhead, a country
hangs upside down from the top of the sky, and the wind takes the smoke falling from its chimneys. Orchard trees are
sewn in, their knot leaves tremble, and washing lifts off the line. A kite is sewn into a child's hands and goes up
over a lake. Then, under a dusk sky of mist with bands of light hurrying across it, a row of trees on a ridge bows as
the gust goes along it. Gold wind lines are stitched in on the beat and unpicked as the wind passes.

![The hanging close up: a windmill on a hill, a thatched cottage with smoke streaming off the chimney, two people meeting on the road, one holding his hat on and one with a red cloak blown out behind, gold wind lines couched across the sky, and at the top right a country hanging upside down from the sky, its houses and trees pointing down](img/hero.jpg)

| | |
|---|---|
| ![Orchard trees being sewn in: one crown finished, one with its wool half laid, one only outlined](img/sewing-in.jpg) | ![Washing flying off the line in a gust, a woman holding a basket, French-knot leaves on the trees](img/washing.jpg) |
| ![A row of poplars and round trees bowing in turn as a gust passes under a lavender and gold sky of laid mist, bands of light slanting across it, a shepherd with a lantern leaning into the wind](img/ridge.jpg) | ![The whole hanging on the wall of a dim hall, with the poem's title in the band beneath](img/hall.jpg) |

## Looks in this family

The style lab draws the same three moments of the demo in three media, from the same scene code:

- **Wool on linen**, the look of the demo. ![The ridge in wool on linen](img/look-wool.jpg)
- **Paper theatre**: coloured papers cut and set in layers, lit from the front, each layer casting a soft shadow on
  the ones behind, gold tissue for light. ![The ridge as a paper theatre](img/look-paper.jpg)
- **Fresco**: earth pigments brushed onto lime plaster, distance paled into haze, then the wall's age on top: a red
  painted frame, cracks, patches where the paint has come away. ![The ridge as fresco](img/look-fresco.jpg)

## Run the demo

```bash
python tools/serve.py
```

Then open `http://localhost:8000/styles/embroidery/index.html`. It plays live in the browser (built and tested in
Chrome). The page takes two or three seconds to stitch the hanging ("Preparing"), then press Play. Space plays and
pauses, and the bar scrubs. If the audio can't load, it plays on a silent clock. Add `#t12.5` to the address for a
still of 12.5 seconds with the page furniture hidden. Changing only the hash redraws but doesn't reload, so after
editing a script reload with a new query, e.g. `?r=2#t12.5`.

Stills with a contact sheet, and an MP4 (from the repository root):

```bash
python tools/still.py styles/embroidery/index.html 2 7.7 12.2 16.7 0:37.5:2.5 --out renders/stills --sheet
python tools/render_mp4.py styles/embroidery/index.html --fast      # 720p preview
python tools/render_mp4.py styles/embroidery/index.html             # 1080p and 720p
```

A `--fast` render of the whole 37.5 s (900 frames) takes 40 to 50 seconds on a quiet Mac, 45 to 52 ms a frame, most
of it reading frames back and encoding; with other renders running on the same machine it took three minutes. The
full-quality encode is slower because of its slow encoder preset, not the drawing.

## How it works

### Files, in load order

| File | Job |
|---|---|
| `core.js` | Frame size (a 1920x960 picture over a 120 px lyric band), math and easing helpers, seeded random (`mulberry32`, `hashi`), value noise (`vn2`, `fbm2`), colour helpers, shapes (`shp`, `spline`, `resample`, `blob`, `archPts`, `wave`, `jitterRing`...), the bend geometry (`bendFrame`, `bentAt`, `bendPoint`) and fonts. |
| `../../examples/poem/lyrics_data.js` | The song: `window.SONG` (title, credit, audio, duration, bpm, lines with word times). |
| `figures.js` | Whole people from a pose: `figure(o)` in side view and `sitter(o)` seated behind a table, facing out. Both return a list of items. |
| `props.js` | `drawItems(S, items)`, and things drawn through a style object: land (`island`, `terraces`, `iceCliffs`, `tuftTree`, `cypress`, `fruitTree`), skies and the far distance (`mistSky`, `hangLand`, `curlLand`, `stormLid`), buildings (`roofTiles`, `arcade`, `windowLit`, `cottage`, `windmillTower`), furniture, `lantern`, clouds and storms, and the things the wind moves (`windmillSails`, `windTree`, `washing`, `kite`, `boat`, `weathervane`, `windPath`). |
| `stitch.js` | The renderer. The wool palette `WOOL`, the semantic map `SW`, outline wools `OUT`; the linen; laid-and-couched tiles; single stitches (`drawStitch`), knots (`drawKnot`, cached as stamps by `stampKnot`), couched gold (`drawGoldThread`, `drawGoldPath`); and `StitchStyle(g, opt)`, the style object. |
| `world.js` | The demo's hanging: its size (`WX0`, `WX1`), where each scene sits (`SPAN`), one painter per scene (`drawMill`, `drawOrchard`, `drawKite`, `drawRidge`), the cast (`CAST`, `POSE`, `WALK`), `buildSprites()` for everything that moves, and `buildWorld()`. |
| `shots.js` | The demo's choreography: the camera (`SHOTS`), the hall's light, the wind (`windAt`, `GUSTS`), the gold wind lines (`GOLD`) and what each scene draws when (`contentBack`, `contentFront`, `contentLights`). |
| `engine.js` | Everything generic: camera and dissolves, drawing baked cloth and sprites, bending sprites, sewing in, gold, lamps, weather, skies drawn live (`drawGoldBands`, `drawCurtains`, `drawTintMotes`, `drawBolt`), the hall and rod, the lyric band, `renderFrame`, playback and `window.__video`. |

### The style object

Scenes never draw directly. They call a style object `S`, which the lab can swap for paper or fresco:

```js
const S=StitchStyle(g,{rec,lamps,width,seed,noShadow});
S.layer(depth)                        // 0 far .. 1 near; under .2 the wool is laid sparse (open threads, linen between)
S.fill(shape,col,{dir,role,out,weave})// lay wool of colour col, threads running at angle dir, soft shadow, stem-stitch outline
S.line(pts,col,w,{role})              // w >= 5.5 a laid ribbon; w < 2.4 or role 'feature' a fine running line; else stem stitch
S.dot(x,y,r,col,{role})               // r <= 3.4 a French knot, bigger a satin-stitched round
S.glow(x,y,r,'lamp',a)                // a lamp: with opt.lamps it is recorded, and the engine lights it live
S.light(shape,{shaft})                // couched gold over an area
S.windLine(pts)                       // couched gold along a path
S.goldLine(pts)                       // couched gold thread point to point (the rim of a cloud bank)
S.run(pts,col,w,len,gap,off)          // running stitches len long with gaps between (wisps of mist)
S.borders(x0,x1,motifs)               // the bands along the top and bottom, with little motifs between slanting bars
```

A shape is `shp(rings)`: one or more closed rings of `[x, y]` points, with its bounding box and a cached `Path2D`.
Colours are semantic: a scene says `'roof'`, `'leaf'` or `'coatBlue'`, `SW` maps that to a wool in `WOOL`, and `OUT`
gives each wool the wool its outline is sewn in. `'skin'`, `'sky'` and `'road'` map to `'linen'`, bare cloth: the wool
is taken away and only an outline is sewn. `role` changes a few things (`'skin'` gets a finer outline, `'feature'`
lines are fine running stitch for eyes and brows). `out:false` lays wool without an outline, for shading inside
another shape.

### The hanging: baked cloth and sprites

The cloth is 960 world units tall; the demo's runs from x = 0 to 9600, four scenes of 2400 each (`SPAN`). At load,
`buildWorld()` paints each scene into its own canvas at `SC` (1.3) times its size, so shots up to about 1.3x zoom stay
sharp, then sews on its borders. `mipChunks()` keeps half and quarter copies for wide shots. The joins between scenes
are hidden by divider trees of the kind old hangings use, drawn as sprites standing on each join.

Anything that moves is a sprite: `makeSprite(bb, draw, {record, sc, pad, seed, depth}) -> {c, x0, y0, w, h, rec, sc}`,
a canvas plus where it sits in world units. `figSprite(o)` and `sitSprite(o)` wrap `figure` and `sitter`. With
`record:true` the outline stitches are kept in `s.rec` instead of drawn, which is what sewing in needs; at load every
recorded sprite also gets `s.full`, its finished look.

### Skies and the far distance

Laid in the cloth (props.js, drawn through `S`, so the lab's looks draw them too):

- `mistSky(S, x0, x1, y0, y1, seed, {bands, masses})`: a sky of mist. Broad bands laid thin, lavender above, rose and
  gold toward the land, with softer masses drifting in them and wisps of running stitch. It lays at depth .1, where the
  wool is sparse and the linen shows through: that reads as unfinished on one flat colour, and as mist in soft bands of
  close colours. The ridge's dusk sky.
- `hangLand(S, x0, x1, yEdge, depth, seed, {lobes, peaks, houses, houseW})`: country hanging from the top of the sky.
  Its ground faces down, so its fields are seen from below, its trees and a mountain or two point down and its houses
  stand upside down with their windows lit. It returns `{edge, chimneys}`: the demo draws the chimneys' smoke live,
  falling "up" for the houses (down for us) before the wind carries it off, in `millBack`.
- `curlLand(S, cx, cy, R, th, a0, a1, depth, seed, {house, houseW})`: fields curling up at the edge of the world like
  the inside of a bowl, trees and a house standing square to its inner face.
- `stormLid(S, x0, x1, y, depth, seed, {drop})`: a bank of cloud come down low like a lid, its underside billowed as old
  hangings carve a cloud bank and rimmed with couched gold; it returns the rim, for a live shimmer along it.
- `iceCliffs` are banded like a glacier's face.

Drawn live over the cloth (engine.js):

- `drawGoldBands(region, bands, clock, yT, yB, a)`: broad bands of light drifting across a sky and the land under it,
  clipped to a polygon: a thin laid gold the cloth shows through, a warm wash, a thread couched along each edge, a sheen
  running down each. Over the ridge they ride a wind clock, so they hurry in the gusts:
  ```js
  const RIDGE_LIGHT={region:[[7220,70],[9580,70],[9580,610],[7220,610]],bands:[{off:0,speed:44,w:180,ang:.34},{off:900,speed:36,w:130,ang:.4}]};
  RIDGE_C=windClock(8400,.3,1);                                   // .3 + the wind at x 8400, summed at load
  drawGoldBands(RIDGE_LIGHT.region,RIDGE_LIGHT.bands,RIDGE_C(t),70,610,.7);
  ```
- `drawCurtains(sky, t, {rows, a})`: an aurora hung in curtains of running stitch that ripple and brighten along
  their length, clipped to a night region `{poly, x0, x1, y0, y1}`.
- `drawTintMotes(x0, x1, y0, y1, n, t, seed, {strings, glow, k, drift, flow, a})`: points of light as tinted knots
  (teal, green, violet, pale gold) with a soft glow, drifting, never rayed, the first few strung in short lines.
- `drawBolt(x, yBase, yTop, t0, t, seed)`: lightning going up from the land into a storm, a jagged stitched bolt with
  a branch and a glow, for half a second after `t0` (a drum hit).
- `windClock(x, base, k)` (shots.js) sums `base + k * windAt(x, t)` once at load, for anything that should move faster
  in a gust without jumping: the sails' angle and the ridge's bands of light both ride one.

The demo uses the mist, the hanging country (with its live smoke) and the bands of light; the curtains, motes, bolts,
the cloud lid and the curling land are ready for a night or a storm.

### Figures

`figure({x, y, h, face, pose, dress, hairStyle, hat, ear, wind, props, anchors, child, wings})`
builds a whole person standing on `(x, y)`, `h` tall, facing `face` (1 right, -1 left). The pose is angles in degrees
(`lean`, `head`, `hipF`, `kneeF`, `hipB`, `kneeB`, `sit`) and two arms, each either `{a, e}` (shoulder and elbow
angles) or `{t:[x, y], bend}`, a hand target in units of `h` from the feet, reached by two-bone IK. The dress is a
garment type (`tunic`, `coat`, `robe`, `dress`) and semantic colours; `wind` pushes the hem downwind. Props:
`pack`, `basketBack`, `lantern`, `staff`, `books`, `tool`, `saw`, `breadBasket`, `mallet`, `washBasket` and `cloak`
(`{type:'cloak', lift, wind, flap}`: lift 0 hangs down the back, 1 streams out level). Pass an object as `anchors`
and it comes back with the world positions of the neck, head, hip and hands, to hang a lantern or tie a kite string to.
Walks are four poses (`WALK`) shown at 8 frames a second by `walkAt()`, which steps the position with them: it reads as
stitched frames, not smooth animation. `CAST` and `POSE` in `world.js` hold the demo's people, so the video and the lab
pose the same cast.

### Shots, the camera and dissolves

```js
// 'But when the leaves hang trembling': the orchard, close; then on through it to the washing
{t:10.95,fade:.6,keys:[[10.95,2960,600,1.42],[15.0,3300,600,1.42],[17.0,4200,520,1.18],[19.2,4330,520,1.14]]},
```

A shot starts at `t` and, with `fade`, dissolves in over the one before (here from 10.95 to 11.55, around the line's
start at 11.25). Its keys are `[time, x, y, zoom, ease power]`: the camera centre in world units and the zoom. Zoom 1
shows the cloth's full height; below 1 the hall shows round it; a close shot is clamped so it never shows past the
cloth's top or bottom. Between keys the camera eases (`easeIO`, bent by the optional fifth value) and the zoom moves in
log space. During a dissolve `renderFrame` draws both shots and mixes them.

### What happens when

After the baked cloth, the engine calls three functions from `shots.js`: `contentBack(t, ta)` (sky, sails, crowns,
washing, bent trees), `contentFront(t, ta)` (people, the kite, blown leaves, gold wind lines) and, after the hall's
dimming, `contentLights(t, ta)` (lamps, so they glow through dusk). The tools they use:

- `drawSpr(s, x, y, alpha, rot, pivot)`, `drawFig(s, x, y, alpha)`, and `poseSeq([[time, sprite], ...], t)` for
  cross-fading poses.
- `stitchIn(s, t0, dur, t, out)`: sews a recorded sprite in on screen, outline first, then the wool row by row;
  `out: [t, dur]` unpicks it again.
- `drawBent(s, ax, root, up, ang, alpha, rot, n)`: bends a sprite along its length. It cuts the sprite into `n`
  strips, each drawn as two textured triangles on a bent centre line (`bendFrame` in `core.js`). Trees grow up from
  their root; washing hangs down from the line. `ang(u)` is the bend at `u` along it; `rot` is how far the strips turn
  with it (1 bends like a stem, 0 only shears, like cloth blown out sideways).
- `drawGust({pts, t0, lay, hold, keep}, t)`: a gold wind line, laid from tail to head (a glint at the needle), then
  unpicked from the tail as the wind passes; `keep` leaves it sewn.
- `drawBlown`, `drawGrass`, `drawBird`, `runStitches` (moving running stitches: smoke, water, a kite string),
  `drawBand` (a band of couched gold with a sheen: the light on the lake), `drawAurora` (rows of stitches whose
  brightness travels: the ridge's wind streaks), `drawLamps`, `lampGlow`, `lampRays`, `sparkle`. Unused by the demo
  but ready: `drawRays` (gold shafts laid one by one), `drawSnow`, `drawBees`, `drawMotes`, `shadeRect`, and the live
  skies above (`drawCurtains`, `drawTintMotes`, `drawBolt`).

The wind is one function, `windAt(x, t)`: a base that follows the tune's own swell of wind noise (it rises and falls
every 7.5 s), plus the `GUSTS`, each a bump moving along the cloth. Trees bend by it, washing lifts, leaves tremble,
the sails turn (their angle is summed from the wind once at load), smoke streams and lamp flames gutter, so one gust
moves everything it passes in turn.

### Lyrics and title

`LYRICS` is built from `SONG.lines`: each line shows from 0.45 s before its first word until the next line comes in
(or 2.6 s after its last word, if that's sooner), and each word lights up as it's sung. The band is drawn in screen
space under the picture, so camera moves never touch it. The intro shows `SONG.title` and `SONG.credit` there as the title card (0.3 to 3.3 s).

### Determinism and caching

The song time `t` is the only input: no `Math.random()`, and every random choice comes from a seeded generator or a
hash of fixed numbers. Nothing carries from one frame to the next, so `step(t)` and `renderAt(t)` draw the same
picture and frames can be drawn in any order. Baked at load: the scenes and their smaller copies, all sprites and their
finished looks, the hall's wall, the lyric band's paper, and the sails' angle table. Built on first use, then kept: a
laid tile for each wool and mode (`TILE_CACHE`), a stamp for each knot colour and size (`KNOT_CACHE`), the glow of
the gold band, and the resampled gold paths.

## Make your own video in this style

1. Copy the folder and follow [your-own-video.md](../../docs/your-own-video.md) to time your song:
   `cp -r styles/embroidery projects/my-song`, then make `projects/my-song/lyrics_data.js` with the pipeline in
   [timing.md](../../docs/timing.md) (it ends with `tools/audio/to_js.py`) and point the page's lyrics script at it.
   Change the page title and heading in `index.html`.
2. Keep `core.js`, `stitch.js`, `figures.js`, `props.js` and `engine.js`. Replace `world.js` and `shots.js`: they
   are the demo. Delete `lab/` unless you want to try other looks.
3. Lay out the cloth in `world.js`: set `WX1` and `SPAN`, write a painter for each scene (`drawMill` is a readable
   model: back to front, with `S.layer()` before each depth), add it to `buildWorld()`, and put a tree in `DIVIDERS`
   on each join. Leave room at the ends of a scene you'll frame closely, or the next scene shows.
4. Add what moves in `buildSprites()`: people with `figSprite(cast(...))`, props with `makeSprite(bb, S=>...)`, and
   `record:true` for anything to be sewn in on screen.
5. Write `SHOTS`: one shot per line or two, dissolving on line starts (`fade` .5 to .6, starting .3 s before).
6. Draw the moving things in `contentBack` and `contentFront`, and time them to the song, not to seconds you typed:
   ```js
   const KITE_UP=word(4,4);                              // line 5, word 5 ('wind?'): the kite goes up
   const CROWN_T=[.05,.3,.55,.8].map(d=>lineAt(2)+d);    // crowns sewn in one after another as line 3 starts
   const GOLD=[[21,2540,470,1100,1], ...];               // a gold wind line laid from beat 21 (13.125 s), kept
   ```
   `word(line, w)`, `lineAt(line)` and `beat(n)` are at the top of `shots.js`. Put hits on beats and changes on line
   starts. (Until you rewrite `shots.js`, a line or word your song doesn't have falls back to its last one, so the
   demo still plays under your lyrics.)
7. Check stills often (`tools/still.py ... --sheet`), then render.

Useful knobs:

- `SC` (world.js): the bake scale. Raise it if you zoom past about 1.3, at the cost of memory.
- `WOOL`, `SW`, `OUT` (stitch.js): the palette. Keep it small; semantic names keep scenes readable.
- Depth: anything under `.2` is sparse laid work. Good for far hills; a big sparse area of one colour (a sky) looks
  unfinished, but laid in soft bands of close colours it reads as mist (`mistSky`, and its `bands`).
- `LIGHT` (stitch.js): the direction of the light; every laid thread turns its highlit side toward it.
- `windAt`, `GUSTS`, `swell` (shots.js): how hard it blows, where and when. `treeBend` and the washing's `lift`
  turn wind into bend.
- `drawBent`'s `n`: more strips bend more smoothly and cost more.
- `walkAt(..., fps)`: 8 gives the stitched-frames feel; 6 is a trudge.
- `hallLight` and `roomDim`: the hall's light, and dimming the whole picture for dusk.
- `RIDGE_LIGHT` and `windClock(x, base, k)` (shots.js): where bands of light drift, how wide, how fast, and how much
  a gust hurries them; `drawGoldBands`' last argument is their strength.

## Lab

Open `http://localhost:8000/styles/embroidery/lab/index.html` and pick a scene and a look with the buttons, or link
straight to one with `?scene=ridge&style=paper`. Render all nine stills and a sheet:

```bash
python tools/lab_stills.py styles/embroidery/lab/index.html --all --out renders/lab --sheet
```

The lab loads the video's own `core.js`, `figures.js`, `props.js`, `stitch.js` and `world.js`. `lab/scenes.js` draws
the video's scene painters through `warpStyle(S, f)`, which moves every point before it reaches the style:
`shiftTo(ox)` brings a window of the cloth into the frame, and `bentStyle(S, B, ox)` bends shapes through a
`bendFrame`, the same geometry the video uses to bend baked pictures. Then it adds, held still, what moves in the
video: sails turned, the people, lifted washing, bowing trees, wind lines. A scene is `{line, lit, draw(S)}`: `line` is
the poem line shown in the band and `lit` how many of its words are lit.

- **Wool** (`StitchStyle` from `stitch.js`): as in the video. The lab adds the soft folds and vignette the video
  draws live.
- **Paper** (`lab/style_paper.js`): every `S.layer()` depth becomes its own canvas. Pieces are filled with a tinted
  paper texture and their cut edges catch the light on one side. At the finish each layer drops a blurred shadow on
  the layers behind, offset by the depth gap between them, and a warm lamp gradient goes over everything. Lamps and
  light are yellow tissue on an overlay. `PAPERC` maps semantic colours to papers.
- **Fresco** (`lab/style_fresco.js`): each fill is painted into a scratch canvas as a pigment wash with brush strokes
  along its direction (leafy dabs for foliage) and ragged edges, then laid on a plaster ground; distance is paled toward
  the haze. The finish lets the plaster show through, then adds worn patches, the joins between days' work, losses,
  cracks, grime and the red frame. Colours come from `PAPERC` with pigment overrides (`FRESCO_OVR`).

## Performance

- **Build:** 2 to 3 seconds (four scenes and 68 sprites), up to 9 when the machine was busy.
- **Frames:** 25 to 40 ms for a close shot and 60 to 70 ms for the widest, measured with a GPU sync on a Mac running
  other renders. A dissolve draws two pictures. The MP4 tool adds reading each frame back and encoding it.
- **Memory:** about 82 MB of baked cloth (four scenes at 1.3x, with their half and quarter copies), 46 MB of sprites
  and 22 MB of working canvases.
- **What costs:** bent sprites (each is `2n` clipped triangles; the ridge alone is 7 trees of 26 strips), hundreds of
  knot leaves a frame (stamped from the cache), wide shots with every scene in view, and dissolves. The skies cost
  little: the mist and the hanging country are baked into the cloth, and three bands of light are a few fills a frame.
- **The latest whole `--fast` render:** 900 frames in 70 s (about 78 ms each, with other renders running).
- **A slice:** `python tools/render_mp4.py styles/embroidery/index.html --start 26 --end 34 --fast`, or stills of
  just that stretch (`still.py ... 26:34:.5 --sheet`).

## Lessons and gotchas

- **Bending by rotating strips leaves a fan of gaps.** Rotated strips pull apart at their outer ends. Draw each strip
  as two textured triangles that share their corners with the next strip (`drawBent` does), clipped a hair wide so
  neighbours meet.
- **Overlapping masses with an outline each look tangled.** Outline one silhouette, and lay the darker and lighter wool
  inside it without outlines (`out:false`). A lobed edge reads as foliage.
- **Knot leaves vanish green-on-green.** Use lighter and yellower greens than the crown under them, and a few flowers.
- **Sparse laid work looks unfinished on big areas.** Anything under depth .2 is sewn sparse; keep that for distance,
  or for mist: laid in soft bands of close colours, with a few wisps of running stitch, the same thinness reads as a
  sky of mist.
- **Joins between baked scenes** show as hairlines and jumps in the landscape. Stand a divider tree on each join, as a
  sprite so it isn't cut in two, and fill a flat linen colour under the whole cloth first.
- **A close shot near the end of a scene shows the next scene.** Keep what you'll frame closely well inside its span,
  or widen the scene.
- **Draw order is depth.** A sprite drawn in `contentBack` goes behind anything drawn after it; if something must stand
  in front, draw it later or in `contentFront`. A chimney drawn before its roof has to rise above the ridge to show.
- **Poses read bluntly in wool.** A tool raised over another figure's head reads as a threat whatever you meant; keep
  tools low or reaching away from people. Small changes need to be obvious: move the camera in when one matters.
- **Dusk on one scene leaves a hard edge where the next begins.** Dim the whole picture (`roomDim`) instead.
- **Things that drift must stay on the cloth.** Clouds drifting past the ends of the hanging hang in the hall; clip
  moving sky to the cloth.
- **Long straight gold rays in open land read as poles or ladders.** Keep rays for light through an opening; show open
  light as a band on water or a field. Broad bands of light across a sky work when they're mostly the cloth seen
  through thin gold, with their couched edges faint and the whole band drifting; at full strength their edge threads
  read as panes or straps.
- **Never fade to a blank frame.** The end dims the hall but stops short of black.
- **Holds read as a frozen player.** Keep something moving in every shot: a slow camera drift, flickering lamps,
  folds in the cloth, clouds, the wind.
- **Test exact event times.** The MP4 tool samples mid-frame, so a bug at the exact start of an event (a gold line
  whose needle has no path yet) can hide until someone asks for a still at `#t13.125`.
- **`imageSmoothingQuality = 'high'` on sprites drawn from canvases** made wide shots eight times slower in Chrome.
  Leave it at the default; the baked cloth has its own smaller copies for wide shots.
- **Build everything at load.** A cache built on first use makes a hitch the first time a scene is seen; that's fine
  for knot stamps, not for whole scenes.
- **One bad value in a canvas gradient kills the whole frame.** Check the console after every change (`still.py`
  prints it).
- **`[hidden]` loses to `display: grid`.** The play overlay needs `.cover[hidden]{display:none}`.
- **A plain `python -m http.server` lets the browser run stale scripts.** Use `tools/serve.py`.
- **Everything baked into the sky sits behind every cloud.** The clouds are sprites drawn over the cloth, so far land
  laid into the sky (the hanging country) is hidden whenever a cloud drifts over it. Plan the clouds' paths clear of it.
- **On land that hangs upside down, everything obeys its own ground.** Its trees and a mountain point down, its houses
  stand on their heads with their roofs below them, and their smoke falls "up" for them, which is down for us, before
  the wind carries it off.
- **Points of light with rays read as stars.** Tinted knots with no rays, drifting slowly, a few strung in short
  lines, read as something stranger. And white knots of snow high on a dark sky read as stars too: keep the snow low
  when the sky is dark.
- **The lab's looks must know every call the painters make.** When a scene painter starts using a new `S` method (the
  mist's running stitches, `S.run`), add it to `warpStyle` in `lab/scenes.js`, or the lab draws it unshifted, off the
  frame, and give the paper and fresco styles their own version of it.
- **Live sky goes under what stands in front of it.** Bands of light, curtains and motes drawn over the cloth are drawn
  in `contentBack` before the divider trees and the figures, so they don't lay themselves over trees that stand in
  front of the sky.



===== 完整公共规范：CLAUDE.md =====

# Instructions for Claude

This repository makes music videos in code: each style in `styles/` is an engine that draws every frame on an HTML
canvas (or WebGL / three.js) in a hand-made-looking medium, timed to a song, and `tools/` renders them to MP4. Read
`README.md` for the map, then the doc for whatever you're doing.

## When someone wants a video for their song

Follow [docs/workflow.md](docs/workflow.md). It's a conversation, not a build order to rush through:

1. **Get the inputs:** the song (mp3), the lyric sheet as sung, and ask whether they have stems and MIDI (Suno and
   stem splitters provide them) and any reference images.
2. **Ask the concept questions before building anything:** who is singing, who "you" is, whose voice the chorus is,
   what the key images (especially the ending) mean, how much the video may show, what stays out. Don't guess at
   these; an open question is better than a confident wrong answer. If the song belongs to a larger world, read
   whatever they give you about it, and keep a list of every detail the video invents, flagged as unconfirmed.
3. **Measure the song** ([docs/timing.md](docs/timing.md)): tempo, sections, stops and hits, and every word's time.
   Time to the audio, not to the lyric sheet's markings.
4. **Pitch three looks and recommend one:** the medium and why it suits this song, the organizing object, a small
   visual grammar and an arc, a section-by-section plan keyed to timestamps, and the open questions. The styles in
   `styles/` are the starting points (each README says what it's good at); a new medium is fine too
   ([docs/engine-patterns.md](docs/engine-patterns.md)).
5. **Style lab:** the same three or four moments drawn in each candidate look. Show the stills.
6. **Checkpoint:** build one section (20-90 s), render it (`--fast`), send it, get notes.
7. **Build the rest** section by section, then render the final MP4s. The MP4 is what gets shared.

Build a project in `projects/<song-slug>/`, copied from a style folder ([docs/your-own-video.md](docs/your-own-video.md)).
Don't change `styles/` for one person's video. Keep notes in `projects/<song-slug>/PLAN.md` as you go: their answers
and rulings, the measured sections and sync points, the shot list, the invented details, and their feedback on each
round. A later session should be able to pick up from that file alone.

## Working practices

- **Look at what you render.** Make stills and contact sheets (`tools/still.py ... --sheet`) and open the images.
  Check every frame on the sheet: edges, blank frames, the camera inside things, covered text, long freezes.
- **Read the console output** the tools print. A single bad canvas gradient value blanks a frame.
- **Preview slices with `--fast`**; render the full 1080p only at the end. Styles that carry state between frames
  must be rendered in order (the tools do this).
- **Keep it deterministic:** seeded randomness keyed to the frame, never `Math.random()` per frame.
- **Follow the page contract** in [docs/rendering.md](docs/rendering.md) (`window.__video`, `window.SONG`,
  `<canvas id="film">`, `#t<seconds>` stills) so the tools work.
- Apply the lessons in [docs/workflow.md](docs/workflow.md#what-the-notes-taught-true-for-every-style): busy
  enough, no long freezes, obvious changes, varied choruses, whole figures rather than close-up hands.
- The person's audio is git-ignored. If their lyrics or story are private, keep the project out of any public
  remote (add it to `.git/info/exclude`, or keep it outside the repo and pass `--root` to the tools).

## Setup

```bash
python3 -m venv .venv && .venv/bin/pip install -r requirements.txt -r requirements-audio.txt
```

Google Chrome must be installed (or `.venv/bin/python -m playwright install chromium`). To preview in the desktop
app's browser pane, create `.claude/launch.json` running `python3 tools/serve.py 8000` on port 8000 (git-ignored).
Use the server, never `file://`: module pages don't load from files and a plain server caches stale scripts.



===== 完整公共规范：docs/workflow.md =====

# How a video gets made

These videos were made in conversation: a person with a song and a clear sense of what it's about, and Claude
writing and rendering the code. The process below is what worked over a dozen songs. It suits working with Claude
Code (see [CLAUDE.md](../CLAUDE.md), which tells Claude to follow it), and it works just as well by hand.

The short version: **decide what the song is about, measure it, pitch three looks, test the look on a few scenes,
build one section, get notes, then build the rest.** Each step is cheap next to the one after it, so mistakes get
caught while they're still cheap.

## 1. Gather the inputs

- **The song** as an mp3 (or anything ffmpeg reads).
- **The lyric sheet** as plain text, one sung line per line, with `#section` markers (see
  [examples/poem/lyrics.txt](../examples/poem/lyrics.txt)). Write it the way it's sung: if the singer repeats a line
  that isn't on the sheet, add it.
- **Stems, if you have them.** An isolated vocal stem makes transcription far cleaner. Suno exports stems as audio
  and as MIDI per instrument; the MIDI's tempo map gives an exact beat grid, and the vocal MIDI gives note onsets to
  snap words to (see [timing.md](timing.md)).
- **Reference images, if any.** Mood boards and concept art are useful for content (what's in the world, what
  people wear, what the place looks like) even when the style will be different.

## 2. Decide what the song is about

Before any pictures, answer the questions that decide the concept. A video can't be good if these are guesses.

- **Who is singing,** and to whom? Who is "you"? It's often not who it seems, and it can change between verses.
- **Whose voice is the chorus?** The singer's, an imagined audience's, a crowd's, a custom's?
- **What do the key images mean?** Especially the closing one.
- **How much may the video show?** If the song belongs to a larger story, what would be a spoiler?
- **What stays out?** Eras, events, people, kinds of imagery.

If the song is part of a larger world (a novel, a game, a band's mythology), read up on it first, and **keep a list
of every detail the video invents**: a place's layout, what a prop says, who stands where. Show that list to
whoever owns the world, and treat nothing on it as settled until they say so.

## 3. Measure the song

Time the video to what the audio does, not to what the lyric sheet says. (AI song generators in particular ignore
markings like "quiet" or "almost unaccompanied".) With the tools in [timing.md](timing.md):

- tempo, and whether it changes;
- the sections and their loudness: which chorus is the big one, where it drops to almost nothing;
- **the stops and hits.** Musical stops, dropouts and the hit that ends a bridge make the best sync points: the
  place to freeze, cut, switch a light off, or change the whole picture;
- every word's time.

## 4. Pitch three looks

Offer three directions and recommend one. For each:

- **the medium** (paper cut, embroidery, marbled paper...) and why it suits this song. The strongest choices mean
  something: marbled paint for a song about water, where nothing stays put; a lantern lecture for a song sung by
  someone lecturing; a desk of files and stamps for a song about a record that doesn't add up;
- **the organizing object:** the one thing the whole video is, such as a desk under a lamp, a hanging read along
  its length, a printed sheet, a painted wagon's panels, a board of pasted-up photographs;
- **a small visual grammar:** a few rules that give the images meaning (stamps are the audience's verdicts, frost
  is the stillness, the camera's date flickers between years), and an **arc** over the song (clean to decayed,
  night to morning, empty to crowded);
- a **section-by-section plan** keyed to timestamps, giving each section one main image;
- the questions still open.

The [styles/](../styles) folder has eighteen engines to start from, and each one's README says what it's good at.
A new song can also want a new medium: the engines share their patterns ([engine-patterns.md](engine-patterns.md)),
so a new one is less work than it sounds.

## 5. Style lab

Draw the same three or four key moments in each candidate look, side by side, as stills (and a few seconds of motion
if the look depends on how it moves). Comparing like with like makes the choice easy, and it shows the problems
early: people who look like mannequins, faces that look ill, a palette that turns cute. Every family here with more
than one look has a lab page (`styles/<family>/lab/`) built this way.

Expect the first choice to be refined: "this look, but with the other one's colours", or "this, for the scenes in the
other world only". Mixing is fine.

## 6. Checkpoint

Build a real section before the whole song: 20-30 seconds of the section that carries the concept, or the first
90 seconds. Render it as an MP4 and get notes on the look, the pace, the figures, the text. This is where most of
the useful notes arrive, and they're cheap to act on now.

## 7. Build the whole song

Section by section. After each, render stills across it (`tools/still.py ... a:b:2 --sheet`) and look at every one:
frame edges, blank frames, things the camera cuts through, text that's unreadable or covered. Fix, then move on.
When it's all there, render the MP4, then scan it at one frame every two seconds.

## 8. Notes, and fixing a stretch

Notes on a full video are usually local: one stretch feels empty, one chorus repeats the last, a transition jerks.
Re-render only that slice and splice it in ([rendering.md](rendering.md#fixing-one-stretch)).

## 9. Deliver an MP4

Share the MP4, not the web page. A browser player's pause and scrub can feel unreliable, and people give up on it.
`tools/render_mp4.py` writes a 1080p file and a smaller 720p one for sending.

## 10. Revising a finished video

A second or third pass (new conventions, a list of fixes, a stretch that needs more going on) works best as: a short
written plan of every change; then before/after sheets, stills from the old render and the new build at the same song
times side by side; then the full render. The sheets let the notes land on exactly what changed. When picking stills
for review, catch short effects at their peak: a flash or a bolt that lasts half a second is easy to miss.

## What the notes taught (true for every style)

- **Busy enough.** Something new on nearly every beat, or at least every line. A stretch with nothing happening
  reads as a mistake, not a rest. When a stretch feels empty, fill it with callbacks (translucent overlays of earlier
  scenes) and background life (children, animals, people passing) rather than restaging it.
- **No long freezes.** A four-second still reads as the player stalling. Keep holds to a beat or two, or keep
  something drifting: a slow camera move, breathing light, smoke.
- **Make small changes obvious.** A face swapping for another face, a detail changing on a paper: if it matters,
  make it big and push the camera in on it. Subtle changes go unseen.
- **Too clean reads as dead.** A video that stays tidy all the way through can feel flat; give it an arc.
- **Vary the repeats.** The second chorus shouldn't replay the first. New scenes, with brief flashes back to the
  first chorus's pictures on key words, keep the echo without the repetition. A motif that does something different
  each chorus (ribbons that knot, then plait, then slip) works well.
- **Whole figures beat close-up hands.** Big silhouettes of hands and arms read as clubs, poles or chess pieces. A
  whole figure, even small and mostly still, carries a beat better.
- **Faces:** realistic halftone or heavy shading can make people look ill. Stylized faces (dot eyes, lowered lids
  when looking down) for close figures and blank faces for crowds read better.
- **What makes a look cute** (sometimes wanted, often not): flat candy fills, rounded sack-shaped figures with blob
  heads, even lighting, bobbing walks. For solemn songs, use weight, texture, uneven light and stillness instead.
- **Real texts make good props.** A period document, a real letter or hymn, an actual map give a scene weight even if nobody
  can read them.
- **Impossible places need ordinary things in them.** Floating or folded land only reads as land when it carries
  trees, lit windows, snow on its ground side, smoke going the "wrong" way.
- **Decide about text in the picture.** A lyric band under the picture is one choice; no readable text at all
  (squiggles for writing) is another; either way, be consistent. Captions that only repeat the lyric are redundant.
- **Fake text is worse than no text.** A card of invented glyphs that flickers reads as a screen of foreign writing.
  Use pictograms, squiggles, or nothing. Likewise on-screen read-outs (temperatures, timecodes) in a "technical"
  medium: keep them only if they mean something.
- **Show the medium working.** When a look risks feeling static (a photograph, a print, a drawing), let the viewer
  watch it being made: a plate exposing, inks printing in on the beats, stitches sewn in, a slide pushed into the
  lantern. It answers "static and unclear" without changing the look.
- **Vary what leads a scene.** In a medium with a life of its own (liquid light, marbling, sand), let some scenes be
  led by the pictures and some by the medium, rather than the same mix throughout.
- **Props must sit in hands.** A rope, a ring, a cloth or a cup that floats near a hand reads as broken. Anchor held
  things to the rig's hand points and check every one in stills.
- **Arms that move naturally:** pose them by where the hand and elbow should be, blend joint angles rather than
  positions, let the forearm trail the upper arm, and add breathing and small weight shifts. Arms that slide
  straight between poses look like a puppet's.
- **Bodies carry identity.** In silhouette, heat or other outline-first looks the outline is all a viewer gets: if
  someone is heavily built, or small and round, the shape must show it. Keep sizes consistent (an animal is as big in
  every shot).
- **Shapes read as other shapes.** A figure lying flat reads as a collapsed body (have them sit or doze upright unless
  a death is meant); a pyramid of sacks in a lit doorway reads as a hooded head; a fan of hair strands reads as a
  feathered headdress. Look at every silhouette as a stranger would.



===== 完整公共规范：docs/timing.md =====

# Timing a song

Everything in a video hangs off the song's clock: the lyric band lights each word as it's sung, pieces land on
beats, scenes change on line starts, the lamp goes out in a dropout. This page is how to get those times. The tools
are in [tools/audio/](../tools/audio); each prints its own help with `--help`.

Setup (once): `pip install -r requirements-audio.txt` (librosa, scipy, faster-whisper, mido). The Whisper model
downloads the first time it's used.

## The pipeline

```bash
# 1. the shape of the song: tempo, loudness, sections
python tools/audio/analyze.py song.mp3

# 2. words with timestamps, from the vocal stem if you have one
python tools/audio/transcribe.py vocals.mp3 --lyrics lyrics.txt --out whisper.json

# 3. your lyric sheet matched to Whisper's words
python tools/audio/align.py lyrics.txt whisper.json --out lines.json

# 4. snap each word to where the voice starts it (vocal MIDI and/or vocal audio)
python tools/audio/snap.py lines.json --midi vocals.mid --audio vocals.mp3 --out snapped.json

# 5. the page's data file
python tools/audio/to_js.py snapped.json --out projects/my-song/lyrics_data.js --title "My Song" \
    --audio song.mp3 --audio-file projects/my-song/song.mp3 --bpm 96 --beats-per-bar 4
```

Then open the video with the lyrics showing and listen through. Fix what's off by editing `lyrics_data.js`
directly: it's plain data.

## Step by step

### 1. The shape of the song

`analyze.py` prints the global tempo and the local tempo every 20 s, a table of loudness, brightness and rhythmic
busyness every few seconds, and guesses at section boundaries. Read it next to the lyric sheet. You're looking for:

- which sections are loud and which drop out: the video's big and quiet moments should follow them;
- tempo changes (a slow intro, a half-time bridge);
- **stops and hits.** `onsets.py song.mp3 --from 140 --to 155` zooms in on a stretch: the strongest onsets, the
  beats, and the loudness every quarter second, so a dropout shows as a run of low numbers. These are the best
  sync points a song offers: the place for everything to freeze, for a cut, for a light to go off.

`sections.py song.mp3 --lines lines.json` compares the sections' loudness, drums and tonal energy once you know
where they are.

### 2. Transcribe

`transcribe.py` runs faster-whisper with word timestamps. Give it the **vocal stem** if there is one; sung vocals
over a full mix transcribe much worse. The `small` model is usually enough and takes about a minute. `--lyrics`
passes the start of your lyric sheet as a prompt, so names and odd words come out spelled your way. `medium` can
rescue mumbled lines, but over a long song it can drift further than `small`.

Expect Whisper's times to run **early**, typically a few tenths of a second and sometimes by more than a second,
and to hear some words wrong, especially names and unusual words. Step 3 doesn't care about wrong words; steps 4 and
the listen-through fix the times.

### 3. Align

`align.py` lines your sheet up against Whisper's words (a sequence match, so misheard or missing words don't break
it; unmatched words get times interpolated from their neighbours). It prints each line with a match count like
`m7/9`. Low counts are where to listen first. Watch for:

- **numbers:** Whisper writes "1974" as one token for three sung words. The script spells out years and small
  numbers before matching, but check them;
- **hyphenated words** and contractions;
- **a misheard last line** ("Let it go" for "Letting go"): the end of a song, over a fade, is where Whisper guesses;
- **repeats and ad-libs** the singer added: put them on the sheet as sung, or they'll be squeezed between
  neighbours.

### 4. Snap to the voice

`snap.py` moves each word to the nearest sung-note onset within 0.32 s: note onsets from the **vocal MIDI** first
(if you have it), then onsets detected in the **vocal audio**. It first reports the median offset between the words
and the onsets; if Whisper ran early across the whole song, pass that back as `--shift` so everything moves before
snapping.

After snapping, some things still need a human ear:

- **line starts that land in silence** or on the tail of the previous word: move them to where the voice comes in;
- **choruses and held notes:** a melisma or a long held word confuses onsets;
- **MIDI quantization:** Suno's MIDI is quantized to sixteenth notes and can sit about 0.3 s off the voice.

For those, `onsets.py vocals.mp3 --from 25 --to 27 --pitch` prints the sung pitch and loudness every 50 ms: the
word starts where the pitch appears and the loudness jumps.

### 5. Write the page data

`to_js.py` writes `lyrics_data.js`, which sets `window.SONG`:

```js
window.SONG = {
  title: "My Song", credit: "", audio: "song.mp3", duration: 212.4,
  bpm: 96, beatsPerBar: 4, firstBeat: 0.35,
  sections: [["verse1", 12.3, 41.0], ...],
  beats: [0.35, 0.975, ...],            // only with --beats: exact beat times
  lines: [{section: "verse1", text: "Who has seen the wind?", t0: 12.3, t1: 14.9,
           words: [["Who", 12.3], ["has", 12.9], ...]}, ...],
};
SONG.beat(n)  // the time of beat n
```

Every style in this repo reads that shape (see [examples/poem/lyrics_data.js](../examples/poem/lyrics_data.js)).

## Beats

For a steady song, `--bpm` and `--first-beat` (the time of the first downbeat) are enough: `SONG.beat(n)` is
`firstBeat + n * 60 / bpm`. Find the first beat with `onsets.py` on the song's opening seconds.

If the tempo drifts or changes, use exact beat times instead:

- **from MIDI stems:** Suno writes a tempo event on every beat, so the tempo map is an exact beat grid.
  `midi.py drums.mid --beats-out beats.json` (any of the song's MIDI files will do);
- **from the audio:** `analyze.py song.mp3 --beats-out beats.json` (librosa's estimate; check it).

Pass the file to `to_js.py --beats beats.json`; `SONG.beat(n)` then reads from the list.

## Hits and loudness

Some styles pulse, flash or move with the music itself rather than the words: a lamp that breathes with the mix, a
ring on every drum hit, mouths that open with the voice. `pulses.py` measures those:

```bash
python tools/audio/pulses.py song.mp3 --percussion perc.mp3 --drums drums.mp3 --vocals vocals.mp3 --out projects/my-song/audio_data.js
```

It writes `window.AUDIO = {fps, ticks, kicks, env, venv, vdb}`: small hits (`ticks`) and big ones (`kicks`) as
`[time, strength]`, the mix's and the voice's loudness 24 times a second (`env`, `venv`, 0..1), and the voice's
loudness in decibels mapped to 0..1 (`vdb`, better for mouths). Stems give much cleaner hits than the mix; without
them everything comes from the mix. The liquid light show reads this file as it is; any style can read the arrays.

## Suno specifics

- The stem download gives an audio file and a MIDI file per instrument. The lead vocal stem transcribes cleanly.
- The MIDI files carry a key-signature event that the `mido` library can't decode (it raises
  `KeySignatureError`). `tools/audio/midi.py` patches mido to read it as C; import `load()` from it in your own
  scripts to get the fix.
- The MIDI tempo map has one event per beat: an exact beat grid, including tempo changes after an intro.
- Vocal MIDI notes are quantized and can sit up to ~0.3 s off the voice: good anchors for snapping, not ground truth.
- Suno ignores dynamics on the lyric sheet ("quiet", "spoken", "almost unaccompanied"). Measure.

## Checking by eye and ear

Open the page, play it with the sound on, and watch the lyric band. Words that light up early are the common
fault. For a close look, `#t25.3` on the page's URL shows the frame at 25.3 s with the band as it is then.



===== 完整公共规范：docs/rendering.md =====

# Previewing and rendering

Every video here is a web page that draws its frames on a canvas. You watch it in a browser while you work, and
when it's done a script steps through it frame by frame in headless Chrome and pipes the frames to ffmpeg. This
page covers the page contract the tools rely on, previewing, stills, MP4s, and fixing a stretch.

Setup (once): `pip install -r requirements.txt` (Playwright, imageio-ffmpeg, Pillow, numpy). The tools drive your
installed Google Chrome; if you don't have it, `python -m playwright install chromium` gets Playwright's own.
imageio-ffmpeg bundles an ffmpeg with x264 and AAC, so there's nothing else to install.

## The page contract

A video page (a style's `index.html`, or a copy of one for your song):

- draws into `<canvas id="film" width="1920" height="1080">`;
- loads its song data as `window.SONG` (see [timing.md](timing.md#5-write-the-page-data)) and plays `SONG.audio`
  in an `<audio>` element, falling back to a silent clock if the audio can't load;
- sets `window.__video`:
  - `ready`: true once everything is built;
  - `duration`: the song's length in seconds;
  - `step(t)`: draw song time `t` the way playback does. The MP4 renderer calls it at 24 fps, strictly in order;
  - `renderAt(t)`: draw a still of time `t` from a fresh state (catching up whatever the frames before it built);
  - either may return a Promise (a page that builds scenes asynchronously); the tools wait for it;
  - `error`: set this to the error text if building fails, and the tools stop and print it;
  - optionally `shots` and `probe(t)` for 3D pages (see `tools/probe.py`);
- shows a still when the URL ends in `#t<seconds>` (e.g. `index.html#t12.5`), with the page chrome hidden;
- draws only while playing: a paused player shouldn't keep redrawing its frame on every animation frame (the tools
  draw and read back each frame in one call, but a page that redraws on its own fights anything else that draws);
- is **deterministic**: all randomness comes from seeded generators keyed to the frame number, never
  `Math.random()` per frame, so a given moment always draws the same picture. An MP4 depends on it.

A style-lab page sets `window.__lab = { ready, scenes, styles, render(scene, style) }`, where `render` draws one
scene in one look and returns the canvas.

## Previewing

```bash
python tools/serve.py            # serves the repository at http://localhost:8000/ and lists the demo pages
```

Open a page from the list. Use this server rather than `python -m http.server` or opening the file directly:

- pages that use ES modules or load files **don't work from `file://`**;
- a plain server lets the browser **cache scripts**, so after an edit you can be looking at the old code. This
  server sends no-cache headers;
- audio and video only seek when the server answers **Range requests**; this one does.

**Stills in the browser:** add `#t<seconds>` to the URL. Changing only the `#` part doesn't reload the page, so
after editing code, reload with a new query (`index.html?r=2#t30`).

**Always check the console** after a load. One bad value in a canvas gradient (a NaN colour stop) throws, and the
whole frame goes blank.

**In Claude Code's desktop app**, the preview pane can run the server for you: create `.claude/launch.json` with
```json
{ "version": "0.0.1", "configurations": [
  { "name": "videos", "runtimeExecutable": "python3", "runtimeArgs": ["tools/serve.py", "8000"], "port": 8000 } ] }
```
(it's git-ignored).

## Stills and contact sheets

```bash
python tools/still.py styles/paper-cut/index.html 5 12.5 30          # three stills
python tools/still.py styles/paper-cut/index.html 0:37.5:2.5 --sheet # a frame every 2.5 s, tiled into one image
python tools/lab_stills.py styles/embroidery/lab/index.html --all --sheet
```

Output goes to `renders/` (git-ignored). The contact sheet is the fastest way to review a whole video: look at every
frame on it, not just the ones you changed. Things to look for: frame edges showing the end of the world, blank or
black frames, the camera inside an object, text covered or cut off, two scenes' seams, something frozen too long.

## MP4s

```bash
python tools/render_mp4.py styles/marbling/index.html                    # renders/marbling.mp4 and -720p.mp4
python tools/render_mp4.py projects/my-song/index.html --out "renders/My Song.mp4"
python tools/render_mp4.py projects/my-song/index.html --start 60 --end 90 --fast   # quick preview of a slice
```

- Two files: 1080p (x264 `slow`, CRF 23, AAC 192k: roughly 5 Mbps for a busy picture) and `-720p` (CRF 25: about
  1 Mbps, small enough to send).
- `--fast` writes only the 720p with the `veryfast` preset. Busy, grainy frames can take many times longer to
  encode with the slow preset than to draw, so use `--fast` for previews and the normal mode for the final.
- The audio comes from `SONG.audio` unless you pass `--audio`. A slice gets short audio fades.
- **Fonts:** the styles load their type from Google Fonts. If a font request fails (a flaky network), canvas text
  silently falls back to a default font, so `render_mp4.py` and `render_frames.py` check the page's fonts after it
  builds and stop if any failed. Run again, or pass `--allow-font-fallback` if you really mean it. The still tools
  print a warning instead.
- 24 fps. Frames are rendered **in order**: many styles draw each frame over the one before (frost that grows,
  ghosting, marbled paint that keeps its history), so a frame can't be drawn on its own.
- Speed depends on the style and on how much the machine is doing: from about 40 ms a frame (paper cut, painted
  enamel, archive desk) to 250 ms or more (sand, the pinscreen, screenprint's printing), including reading the frame
  back and encoding. Each style's README gives its numbers. A four-minute song is 5,760 frames: a few minutes for the
  fast styles, half an hour or more for the slow ones (see the next section for splitting a render across browsers).

## Long renders: frames on disk, resumable, in parallel

For a long song in a slow style, render the frames to a folder instead of straight into ffmpeg:

```bash
python tools/render_frames.py projects/my-song/index.html --dir renders/frames/my-song --jobs 3
python tools/encode.py renders/frames/my-song --out "renders/My Song.mp4"
```

- Frame `i` is `<dir>/<i:05d>.jpg` and shows song time `(i + 0.5) / 24`. Frames already on disk are skipped, so an
  interrupted render continues where it stopped when you run the same command again, and deleting a stretch's
  frames and re-running redoes just that stretch.
- `--jobs N` renders N runs of frames in N browsers at once. Each run starts with `renderAt()` at its first frame,
  which catches up styles whose frames depend on earlier ones, then steps in order. (Tested: a resumed run's frames
  match a straight-through render pixel for pixel.) GPU-heavy styles gain less, since the browsers share one GPU.
- `encode.py` takes the audio from the folder's `meta.json` (the page's `SONG.audio`), cuts it to the frames on
  disk, and writes the same 1080p and 720p files as `render_mp4.py`.
- **A render that sits before its first frame** is usually the machine, not the page: with other renders or heavy
  WebGL pages running, Chrome can take minutes to start or to build a page. `render_mp4.py` prints the page's URL when
  it's loaded and a progress line every 240 frames.
- **Heavy 3D pages:** building every set of a long WebGL video at once can hang the GPU. Render such a video in
  segments (`--start`/`--end` runs into the same frame folder, each run building only what its stretch needs), and
  on a machine that other renders are sharing, run one segment at a time.

## Fixing one stretch

A full render can take a while. To fix one stretch, render only that slice at full quality and splice it into the
finished file at whole frames:

```bash
python tools/render_mp4.py projects/my-song/index.html --start 120 --end 135 --out renders/fix.mp4
python tools/splice.py "renders/My Song.mp4" renders/fix.mp4 --at 120 --out "renders/My Song v2.mp4"
```

A slice opens with `renderAt(t)`, which catches up styles whose frames build on earlier ones, so its frames match the
full render's and the splice is seamless.

## Checking a 3D video's framing

`python tools/probe.py styles/diorama/index.html` asks the page, for the start, middle and end of every shot,
whether anything stands between the camera and its subject, or whether the camera is inside something. In a crowded
set it finds blocked views much faster than contact sheets.

## Sharing

Share the MP4. If you also want a review page (the video with notes around it), keep in mind that some hosts cap
file sizes: split a long 720p video into parts at scene changes and play them in sequence against the song, and
serve it from something that answers Range requests.



===== 完整公共规范：docs/your-own-video.md =====

# Making a video for your own song

The hands-on steps, from an mp3 to an MP4. For the creative side (what to decide before building, how to pick a
look) see [workflow.md](workflow.md). If you're working with Claude Code, you can just ask it to make a video for
your song: [CLAUDE.md](../CLAUDE.md) walks it through all of this.

## 1. Set up

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt            # rendering
pip install -r requirements-audio.txt      # timing a song (Whisper, librosa, MIDI)
```

You need Google Chrome installed (or run `python -m playwright install chromium`).

## 2. Start a project folder from a style

Pick a style from the [gallery](../README.md#the-styles) and copy its folder:

```bash
cp -r styles/paper-cut projects/my-song
cp ~/Music/my-song.mp3 projects/my-song/song.mp3
```

Audio files are git-ignored, so your song stays out of the repository.

In `projects/my-song/index.html`, change the lyrics script from the demo's
```html
<script src="../../examples/poem/lyrics_data.js"></script>
```
to your own
```html
<script src="lyrics_data.js"></script>
```
(Relative paths from `projects/my-song/` resolve just as they did from `styles/<style>/`, so anything else the
page loads from the repo keeps working.)

## 3. Time the lyrics

Write the lyric sheet (`projects/my-song/lyrics.txt`, one sung line per line, `#section` markers), then run the
pipeline in [timing.md](timing.md). It ends with `projects/my-song/lyrics_data.js`.

## 4. Look at it

```bash
python tools/serve.py
```

Open `http://localhost:8000/projects/my-song/index.html`. The demo's scenes now play under your lyrics for as long as
the demo lasts. That's the moment to decide the plan: which scene goes where, which line lands on which image.

## 5. Replace the demo's scenes with yours

Every style's README has a "Make your own video in this style" section that says which files are the demo (its
scenes, sets, shots or timeline) and which are the engine. Keep the engine; rewrite the demo files. Work a section
at a time:

```bash
python tools/still.py projects/my-song/index.html 30:60:2 --sheet   # stills every 2 s across 0:30-1:00
```

Look at every still on the sheet. Check the console output printed at the end.

## 6. Render

```bash
python tools/render_mp4.py projects/my-song/index.html --start 30 --end 60 --fast   # a quick 720p preview
python tools/render_mp4.py projects/my-song/index.html --out "renders/My Song.mp4"  # the final, 1080p + 720p
```

To fix one stretch later without re-rendering everything, see
[rendering.md](rendering.md#fixing-one-stretch).



===== 完整公共规范：docs/engine-patterns.md =====

# How the engines are built

The eighteen engines in [styles/](../styles) share no code at run time: each folder is self-contained, written for one
song in one medium (a few began as copies of another's files, such as the 3D pipeline or the ray-marched figure). But they
share a shape, and knowing it makes any of them easy to read and a new one quicker to write. This page is that
shape, plus the browser gotchas that cost the most time.

## Simulate the process, not the look

Each engine models how its medium is physically made, and the imperfections come out right on their own:

| medium | what the code does |
| --- | --- |
| screenprint | each ink is a stencil mask plus a halftone; inks are pulled one at a time and multiplied onto paper, each a little out of register, with squeegee streaks and pinholes |
| linocut | a block is a list of gouge cuts and inked areas; the key block prints black over watercolour washes |
| wool embroidery | wool is laid and couched from tiles, outlines are stem-stitched, light is couched gold thread |
| marbled paper | paint floats as closed outlines on a bath; drops, combs and swirls are exact maps applied to every point |
| magic lantern | slides are baked as tinted glass; a frame stacks glass by multiplying and throws it through a lens |
| painted enamel | two-colour bristle strokes with a highlight flick toward the light, then gold leaf |
| paper cut | cut shapes with a lit rim and a soft shadow, layered in depth and lit from behind |
| mosaic | tesserae are laid in rows along the outlines, then grouted |
| sand on a lightbox | sand thickness is a density field; the lamp shows through as `exp(-k * thickness)`; fingers clear lines |
| carved diorama | each piece is a signed-distance sculpture meshed in the browser; tool marks are a bump in the piece's own space |
| photomontage | photographs are painted in greys, then given a print's grain, halation and tone curve, and cut out with drifting scissors |
| pinscreen | a field of pins at different heights, lit from a low angle, each pin's shadow falling on the next |
| archive desk | every paper is pre-rendered with its shadow, grain, foxing and torn fibres; stamps are inked, then eroded |
| night poster | a shape's shadow is the band a shifted copy of it fails to cover; night mixes colours toward navy while lamps keep their brightness |
| batik | a real 3D set lit by two coloured lamps is rendered into buffers; wax resists where both lamps reach, each dye takes where only one does, and the wax cracks |
| long-exposure glass plate | each frame integrates many light drawings over the exposure, so whatever moved is a smear and whatever stood still is sharp; then halation, dust and the emulsion's edge |
| silverpoint | even hatching whose weight follows the tone; lines can't be erased, and tarnish from grey to brown with age |
| carved relief | the scene becomes a height field, shaded by a raking light with its own cast shadows |
| liquid light show | oil, water and dye in a dish on a projector: warped-noise dye bands, metaball oil drops with a meniscus, and drawn transparencies whose black ink really blocks the lamp |
| thermal camera | a scene rendered as temperatures and mapped through a camera palette, with a thin visible-light edge overlay, warm breath and fading heat prints |
| showboat stage | painted flats given brushwork by a sampled-stroke pass, lit by a light map in which the actors are lit through their own silhouettes |

A filter that makes a clean digital picture look like linocut never convinces for long. A few rules about how the
real thing is made go much further.

## One frame

Almost every engine's frame function looks like this:

```
renderFrame(t):
  shot = the shot covering t
  set  = shot.set, baked on first use           (the still layers: land, buildings, background)
  cam  = shot.cam(t)                            (keyframed, eased)
  draw the set's layers through the camera       (parallax: nearer layers move more)
  draw what moves at t                           (figures, props, light, weather)
  post: light (a multiplied lamp or light map), grain, vignette, the medium's texture
  if t is inside a transition: draw the next shot too and mix (dissolve, wipe, push)
  the lyric band / margin / caption for t
  fade in and out at the ends
```

The canvas is 1920x1080. Several styles keep the picture above a band for the lyrics (e.g. 1920x960 + 120).

## Sets, shots, cameras

- **Sets** (or scenes, worlds, plates) are places. Their still parts are drawn once into offscreen canvases the first
  time they're needed ("baked"), then only composited. Keep a memory budget: the whole song's sets rarely fit at
  once, so drop the least recently used. Bake at load what the first seconds need, so playback doesn't hitch.
- **Shots** are stretches of song time: `{t0, t1, set, cam, ...}` plus a function that poses what moves.
- **Camera keys** are `[time, x, y, zoom, ...]` with easing between them. Two useful rules:
  - push in with **lens zoom**, not by travelling into the layers: depth travel blows the nearest layer up (snow
    becomes moons);
  - **never let the camera see past the edge** of what's drawn. Check the frame corners on every new camera.
- **Transitions:** dissolves, drop wipes (a new picture spreading inside a drop), push and pull (from a room to the
  picture on its screen), panels (pull back to a page of panels, push into another), re-laying one medium as another
  past a moving line.

## Time: on twos, and in step with the song

- Hand-made animation moves **on twos**: pose changes at 12 fps inside 24 fps video. Several engines step motion at
  12 fps (`tm12 = Math.floor(t * 12) / 12`) while the camera moves at the full 24, which keeps the hand-made feel
  without a juddering camera. Texture "boil" (grain, ink noise) often changes at 8 fps.
- **Ease into fast moves**, or drive them with real time: a move that starts at full speed jumps at 12 fps.
- **Hits on beats, changes on lines.** `SONG.beat(n)` and each line's `t0` and word times are the anchors. A word
  lighting in the lyric band typically fades up over `[t - 0.04, t + 0.16]`.
- **Keep something moving.** A hold longer than a beat or two reads as the player freezing. A slow drift, a breathing
  light or drifting smoke keeps a still picture alive.

## Determinism and frame-to-frame state

- All randomness comes from seeded generators (`mulberry32(seed)`) and noise keyed to the frame number. Never call
  `Math.random()` while drawing a frame. The same `t` must give the same picture, or an MP4 won't match what you
  checked.
- Some styles **carry state from frame to frame**: frost that grows, ghosting of the previous frame, a charcoal
  drawing that's erased and redrawn, marbled paint whose outlines remember every comb. Those must be stepped in
  order. `renderAt(t)` then means "rebuild the state from the start of this scene up to t", and each engine's README
  says how it does that.
- When a view steps backwards in time (a camera effect that holds frames, a scrub), keep what's already baked rather
  than rebuilding it from scratch each step, or rendering crawls.

## Figures

- **Whole figures**, posed. Every engine has a rig: jointed silhouettes, contour-drawn people, ray-marched signed
  distance bodies, carved 3D pieces. Most use **two-bone IK** for arms (and often legs), so a hand can be put exactly
  on a rope, a cup or another hand. Each rig spells it its own way: `reachArm()` in paper cut, an arm given as
  `{t: [x, y]}` in embroidery or `{at: [x, y]}` in painted enamel; the style READMEs show how.
- Build **every figure of a kind from one model**, so its anatomy is the same in every shot; vary only pose,
  clothing and age.
- Things that make figures read wrong, all hit at least once: round heads read as teddy bears (give them a muzzle
  or a jaw); coats that hang along the body turn a crouching figure into a plank (hang them toward world-down);
  digitigrade legs with a long stride look like sitting on a stool; two figures leaving the same way merge into one
  blob; close-up arm silhouettes read as clubs or poles.

## Light

- A **lamp** is a radial gradient drawn with `multiply` (or a light map multiplied onto the whole picture). Its
  warmth and brightness carry most of a scene's mood.
- **Self-lit things** (flames, lit windows, glowing marks) go in their own layer drawn after the light map, plus a
  glow. A reflective shape in front should erase the self-lit layer behind it.
- On pale paper, `screen` adds almost nothing; `soft-light` plus a weaker `screen` shows coloured light.
- Glass only darkens: a moving piece has to pass over light glass, or it vanishes.

## Text in the picture

- Load fonts before drawing and wait for them (`document.fonts.load(...)` for each face and script you use), or text
  falls back to a default font. `document.fonts.load` resolves even when the font never arrived, so check the
  result (or `document.fonts.check(...)`) before building. Put `<meta charset="utf-8">` at the top of the page for
  any non-ASCII text.
- **Start building only when every script has loaded** (`DOMContentLoaded`, or put the start call at the end of the
  last script). A build started from a font promise plus a short timer can win the race against later scripts when
  the fonts come from cache, and the page fails to build only sometimes.
- Keep the lyrics readable: if the camera zooms, keep the text out of the zoom (a band or margin drawn in screen
  space).

## Browser gotchas that cost hours

- **One bad gradient value kills the frame.** `addColorStop` with a NaN or an out-of-range offset throws, and nothing
  after it draws. Check the console after every change.
- **`destination-out` uses the current fill's alpha.** A fill left translucent from the last wash only half-erases.
  Set `fillStyle = '#000'` before erasing.
- **`[hidden]` loses to `display: grid`.** Add `.gate[hidden] { display: none }` for overlay elements.
- **Globals collide.** Plain scripts share one global scope; a helper named like an existing function (`hand`,
  `line`) silently replaces it.
- **Tiling seams:** a texture tiled from a sampled corner shows seams on big pieces; downsample the whole texture.
- **WebGL:** GLSL has reserved words you'd never guess (`patch`); creating a texture while another is bound can
  overwrite a texture unit (create textures on a scratch unit such as TEXTURE15); a three.js `InstancedMesh` keeps the
  bounds of its first draw unless `frustumCulled = false`.
- **Headless loads:** wait for the page with `wait_until='commit'` and your own ready flag; a page that builds a lot
  at load can time out waiting for the load event.
- **Grain that changes every frame bloats the MP4.** Change it on twos.

## Starting a new engine

1. Copy the style closest to what you want. Keep its player (`index.html`, the playback and `window.__video` parts
   of its engine) and its lyric code.
2. Write the medium: the few functions that turn a shape into your medium's marks. Test them on stills first, on a
   page that just draws one scene (a lab page).
3. Draw the same key scenes in your medium and in one or two alternatives. Choose.
4. Then sets, shots and the song.



## 原作者媒介陷阱与经验摘录

## Lessons and gotchas

- **Bending by rotating strips leaves a fan of gaps.** Rotated strips pull apart at their outer ends. Draw each strip
  as two textured triangles that share their corners with the next strip (`drawBent` does), clipped a hair wide so
  neighbours meet.
- **Overlapping masses with an outline each look tangled.** Outline one silhouette, and lay the darker and lighter wool
  inside it without outlines (`out:false`). A lobed edge reads as foliage.
- **Knot leaves vanish green-on-green.** Use lighter and yellower greens than the crown under them, and a few flowers.
- **Sparse laid work looks unfinished on big areas.** Anything under depth .2 is sewn sparse; keep that for distance,
  or for mist: laid in soft bands of close colours, with a few wisps of running stitch, the same thinness reads as a
  sky of mist.
- **Joins between baked scenes** show as hairlines and jumps in the landscape. Stand a divider tree on each join, as a
  sprite so it isn't cut in two, and fill a flat linen colour under the whole cloth first.
- **A close shot near the end of a scene shows the next scene.** Keep what you'll frame closely well inside its span,
  or widen the scene.
- **Draw order is depth.** A sprite drawn in `contentBack` goes behind anything drawn after it; if something must stand
  in front, draw it later or in `contentFront`. A chimney drawn before its roof has to rise above the ridge to show.
- **Poses read bluntly in wool.** A tool raised over another figure's head reads as a threat whatever you meant; keep
  tools low or reaching away from people. Small changes need to be obvious: move the camera in when one matters.
- **Dusk on one scene leaves a hard edge where the next begins.** Dim the whole picture (`roomDim`) instead.
- **Things that drift must stay on the cloth.** Clouds drifting past the ends of the hanging hang in the hall; clip
  moving sky to the cloth.
- **Long straight gold rays in open land read as poles or ladders.** Keep rays for light through an opening; show open
  light as a band on water or a field. Broad bands of light across a sky work when they're mostly the cloth seen
  through thin gold, with their couched edges faint and the whole band drifting; at full strength their edge threads
  read as panes or straps.
- **Never fade to a blank frame.** The end dims the hall but stops short of black.
- **Holds read as a frozen player.** Keep something moving in every shot: a slow camera drift, flickering lamps,
  folds in the cloth, clouds, the wind.
- **Test exact event times.** The MP4 tool samples mid-frame, so a bug at the exact start of an event (a gold line
  whose needle has no path yet) can hide until someone asks for a still at `#t13.125`.
- **`imageSmoothingQuality = 'high'` on sprites drawn from canvases** made wide shots eight times slower in Chrome.
  Leave it at the default; the baked cloth has its own smaller copies for wide shots.
- **Build everything at load.** A cache built on first use makes a hitch the first time a scene is seen; that's fine
  for knot stamps, not for whole scenes.
- **One bad value in a canvas gradient kills the whole frame.** Check the console after every change (`still.py`
  prints it).
- **`[hidden]` loses to `display: grid`.** The play overlay needs `.cover[hidden]{display:none}`.
- **A plain `python -m http.server` lets the browser run stale scripts.** Use `tools/serve.py`.
- **Everything baked into the sky sits behind every cloud.** The clouds are sprites drawn over the cloth, so far land
  laid into the sky (the hanging country) is hidden whenever a cloud drifts over it. Plan the clouds' paths clear of it.
- **On land that hangs upside down, everything obeys its own ground.** Its trees and a mountain point down, its houses
  stand on their heads with their roofs below them, and their smoke falls "up" for them, which is down for us, before
  the wind carries it off.
- **Points of light with rays read as stars.** Tinted knots with no rays, drifting slowly, a few strung in short
  lines, read as something stranger. And white knots of snow high on a dark sky read as stars too: keep the snow low
  when the sky is dark.
- **The lab's looks must know every call the painters make.** When a scene painter starts using a new `S` method (the
  mist's running stitches, `S.run`), add it to `warpStyle` in `lab/scenes.js`, or the lab draws it unshifted, off the
  frame, and give the paper and fresco styles their own version of it.
- **Live sky goes under what stands in front of it.** Bands of light, curtains and motes drawn over the cloth are drawn
  in `contentBack` before the divider trees and the figures, so they don't lay themselves over trees that stand in
  front of the sky.


