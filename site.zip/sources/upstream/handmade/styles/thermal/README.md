# Thermal camera

The picture a heat camera makes: every surface drawn by the warmth it gives off rather than the light it
reflects, mapped through a false-colour palette. It's real 3D (three.js), built from signed-distance models meshed
in the browser, but every vertex carries a temperature, an emissivity and a visible brightness instead of a colour.
A heat pass renders apparent temperature at a sensor's low resolution: emissivity falls at grazing angles, so bodies
cool toward their outlines; glass and bare metal reflect the cold sky; hollows such as the corners of the eyes read
warmer. A visible pass supplies only thin white outlines, laid over the heat the way real cameras blend in their
visible image. The final pass is the camera itself: detail enhancement with its dark halos, a noisy sensor with a
fixed column pattern, vignetting, a little bloom on hot sources, and the palette. Breath, smoke and exhaust are warm
gas; footprints and handprints are heat marks that fade; everything moves twelve times a second. The demo is a
farmyard on a windy autumn night. The camera can't see the wind either, only what it does to warm things.

*Good for:* songs set at night or in the cold; bodies, breath and touch; distance, watching and being watched;
anything where warmth means something.

![A woman reaches over a field gate to lift the latch, her breath blown sideways; a child and a dog wait beside her, a warm truck behind](img/hero.jpg)

| | |
|---|---|
| ![The farmhouse at night: lit windows, the chimney's smoke streaming flat, trees and clouds](img/yard.jpg) | ![From above: warm paw prints and boot prints fading on the gravel, breath trailing downwind](img/prints.jpg) |
| ![A lit window with the leaves of a branch hanging dark against it](img/window.jpg) | ![The second stanza in the arctic palette: washing streaming from the line like flags](img/washing.jpg) |

## Looks in this family

The [style lab](lab/index.html) draws three moments of the demo through each of the camera's settings. The
temperatures never change; only the way the camera turns them into a picture does.

| | | |
|---|---|---|
| ![Ironbow](img/look-ironbow.jpg)<br>**Ironbow** (the demo's first stanza): black through violet, red and orange to white. | ![White-hot](img/look-white-hot.jpg)<br>**White-hot**: plain grey, hotter is whiter. | ![Black-hot](img/look-black-hot.jpg)<br>**Black-hot**: inverted grey, the way surveillance cameras often show it. |
| ![Rainbow](img/look-rainbow.jpg)<br>**Rainbow**: every few degrees a new colour; loud, but small differences jump out. | ![Amber](img/look-amber.jpg)<br>**Amber**: one warm hue, black to cream; reads as older footage. | ![Arctic](img/look-arctic.jpg)<br>**Arctic** (the second stanza): a blue world where only warm things turn gold. |
| ![Embossed edges](img/look-emboss.jpg)<br>**Embossed edges**: the visible image's edges lighten the dark parts and darken the bright. | ![No edges](img/look-no-edges.jpg)<br>**No edge overlay**: heat alone; things at the air's temperature disappear. | ![Read-outs](img/look-readouts.jpg)<br>**Camera read-outs**: the scale bar with its span, and a spot meter reading the heat buffer. |

## Run the demo

```bash
python tools/serve.py
```

Then open http://localhost:8000/styles/thermal/index.html and press Play (or Space); drag the bar to scrub. The page
has to be served: ES modules and module workers don't run from `file://`, and `tools/serve.py` stops the browser
caching old scripts. Add `#t12.5` to the address for a still of 12.5 s with the page around it hidden (after
editing code, reload with a new query, `index.html?r=2#t12.5`, since changing only the `#` part doesn't reload).

```bash
python tools/still.py styles/thermal/index.html 2 6 12.5 0:37.5:2.5 --sheet   # stills and a contact sheet
python tools/render_mp4.py styles/thermal/index.html --fast                    # renders/thermal-720p.mp4
python tools/render_mp4.py styles/thermal/index.html                           # 1080p and 720p
```

It plays live, unevenly. Drawing a frame takes a few milliseconds; what's slow is the figures, whose poses are
meshed afresh twelve times a second (0.1-0.4 s of worker time each). So the player shows about 10 frames a second
while people are on screen, dropping frames to keep time with the audio, and the full 24 in the shots without them.
The MP4 is the smooth version, since the renderer waits for every pose: a `--fast` render draws the demo's 900 frames
in under a minute here. The page loads in about 6 s while eight workers mesh the set.

## How it works

`index.html` loads Archivo Narrow from Google Fonts, an import map for three.js 0.170 from jsDelivr, the song timing
(`../../examples/poem/lyrics_data.js`, which sets `window.SONG`) and then `film.js` as a module; everything else is
imported from there. Nothing is loaded at run time but the font and three.js: every model is meshed from code.

| File | Job |
|---|---|
| `film.js` | Builds the sets, draws the frame for song time t (figures, props, breath, wind, camera, gas, decals, render), the lyric band, the camera's read-outs, the player, and `window.__video`. |
| `thermal.js` | The renderer: palettes, the heat and visible materials (with the wind's bending in their vertex shader), gas, heat decals, the wind uniforms, and `ThermalRenderer` with its passes. |
| `kit.js` | Building a set: `Stage` (pieces, flat shapes, sky, emitters), `Actor` (a figure meshed per pose), `Walkers` (a crowd), `beamSet`, pose blending (`blend`, `keyed`), `setOff`. |
| `pieces.js` | `needOne()`: sends mesh requests to a pool of module workers and caches the geometries; `peekOne()`, `assign()`. |
| `tmesher.js` | The module worker: builds one model and meshes it. |
| `tmodels.js` | Every model as a signed-distance function with thermal "colours": the person, the dog, trees, grass, the house's neighbours, props. No three.js here, so the workers can import it. |
| `sdf.js` | Signed-distance modelling and the mesher (block-sparse surface nets), shared with the carved diorama style. |
| `common.js` | The demo's shared vocabulary: the air temperature, looks, people, the wind, time and pose helpers, cameras, handprints and footprints. |
| `sets.js` | The demo's one set, the farmyard (`setYard`). |
| `shots.js` | The demo's shot list and its choreography. |

`sdf.js` is the diorama style's modeller with one change for heat: the cavity factor (how closed in a surface is)
comes out separately instead of darkening the colour, because a heat camera sees hollows warmer, not darker. See
[the diorama's README](../diorama/README.md#modelling-and-meshing) for the primitives and operations. The per-pose
figure meshing (`Actor`, the pose cache in `pieces.js`) is the same idea the diorama uses for its moving pieces.

### Heat instead of colour

Every model op carries `th(T, e, alb)` instead of an RGB colour: `T` the temperature in C, `e` the emissivity, and
`alb` the brightness a visible camera would see, which is used for the edge overlay and nothing else. A 4th channel is
a material code that picks the fine texture the heat shader adds:

| code | material | | code | material |
|---|---|---|---|---|
| 0 | skin | | 5 | wood, paper |
| 1 | metal | | 6 | leather, rubber |
| 2 | hot source (no texture, and gusts don't cool it) | | 7 | stone, glass, ice, snow |
| 3 | cloth | | 8 | leaves and grass (the only parts of a meshed piece that flutter) |
| 4 | hair, fur | | | |

```js
const M = new Model();
M.add(P.cyl([0, 0.2, 0], 0.15, 0.2, 0.02), { col: th(55, 0.95, 0.8), mat: 5 });   // a mug of hot tea: 55 C, matt
M.sub(P.cyl([0, 0.36, 0], 0.12, 0.06, 0.01), { k: 0.01, col: th(68, 0.97, 0.1) }); // the tea, hotter still
return { model: M, bounds: autoBounds(M, 0.08) };
```

The heat shader writes an apparent temperature, not a colour: `ea * T + (1 - ea) * Tr`, where `ea` is the emissivity
reduced at grazing angles and `Tr` is what the surface reflects (`look.trefl`, the sky's cold outdoors, the room's
warmth indoors). So polished metal and glass show their surroundings, not themselves, and a body's outline is cooler
than its middle. The palette only happens at the end, in the final pass, which is why the lab can re-map any frame.

Some temperatures that read right for a cold night (air at 4 C; the demo's values):

| | C | | C |
|---|---|---|---|
| clear sky, horizon to overhead | -22 to -40 | a person's face (nose to cheek) | 29-34 |
| clouds | up to 22 above the clear sky | a parka, a knit hat | 13-15 |
| a roof losing heat to the sky | 1-2 | trousers, boots | 12-19 |
| grass, trees, a fence (at the air) | 3-4 | a dog's coat, its eyes and mouth | 16, 37 |
| house walls, lit windows | 7-8, 13-18 | breath as it leaves the mouth | 31 |
| a truck's hood, tyres, exhaust pipe | 34, 11, 70 | chimney top, smoke, sparks | 44, 58, 260 |

`humanTemps(p)` and `dogTemps(p)` work these out from a core temperature and the air: skin a little under the core,
clothes and hair a fraction of the way from the air up to the skin, cold hands and noses when `cold` is set. Set a
person's `room: true` and the whole figure reads as the air (a statue).

### The renderer

`new ThermalRenderer(canvas, 1920, 1080, [1280, 640], 120)` draws into the page's canvas: the picture fills 1920x960
and the bottom 120 px are the lyric band. `R.render(scene, camera, look, frameNumber)` runs:

1. **Heat**: every mesh with its heat material, plus the gas, into a half-float target at the sensor's size (1280x640
   by default; `look.sensor: [960, 480]` gives a softer, older-looking camera). Heat decals and the gust cooling are
   applied per pixel here.
2. **Blur**: the heat image at a quarter size, blurred, for detail enhancement.
3. **Visible**: brightness, normals and depth at full size, only for the edges.
4. **Final**: a slight optical softening; detail enhancement (`T + dde * (T - blurred)`, capped at `ddeMax`
   degrees); span to 0..1; sensor noise that changes every frame and a column pattern that doesn't; vignette; the
   palette; the edge overlay; bloom on anything hotter than the span; a flash and a fade; the overlay canvas.

`look` is a plain object; the demo keeps a few in `common.js` (`OUT`, `COLD`, `NEAR`) and each shot can adjust one:

| key | what it does |
|---|---|
| `palette`, `span: [cold, hot]` | the lookup (`ironbow`, `rainbow`, `amber`, `arctic`, `white` for white-hot, `black` for black-hot; add your own to `STOPS`) and the temperatures at its two ends |
| `trefl` | the temperature low-emissivity surfaces reflect (the sky, outdoors) |
| `msx`, `edge`, `line`, `edgeW` | edge overlay strength (0 turns it off), `'line'` (thin white lines, the default) or `'emboss'`, how white the lines are, their width in pixels |
| `dde`, `ddeMax` | detail enhancement and its cap in degrees |
| `noise`, `fpn`, `vig`, `gamma`, `texAmp` | sensor noise, column pattern, vignette, contrast curve, the materials' fine texture |
| `flash`, `fade` | a white flash (0..1) and a fade to black (1 = full picture) |
| `palette2`, `span2`, `wipe: [front, softness, slant, wobble]` | a change of palette sweeping across the picture: behind the front (0..1 across) the new palette and span |
| `osd`, `spot: [x, y, z]` | (film.js) the camera's read-outs: a scale bar with the span and a spot meter at a point in the scene, reading the temperature the sensor actually saw there |

Palettes are `STOPS[name]`, lists of `[position, '#rrggbb']`, turned into 256-entry lookups by `makeLUT`.

**Gas** (`Gas` in `thermal.js`) is deterministic: each particle is born at `i / rate` and its position, temperature
and opacity are worked out from its age, so any frame can be drawn on its own. An emitter is a plain object:
`{p` or `path(t), dir, rate, life, T, amb, size: [at birth, at death], spread, speed, rise, drift: [x, y, z] (ft/s),
alpha, cool, puff (breaths a second), flutter: [amp, rate], hard (hard-edged flecks: blown leaves, sparks), t0, t1,
seed, off}`. Particles fade to the air's temperature (`amb`) as they age, which is what makes breath and smoke look
right. `path(t)` returns where the emitter was when a particle was born, so a plume from a walking person trails
behind them rather than following their head.

**Heat decals** (`setDecals(list)`, at most 48 a frame): `{p: [x, y, z], r, T, k}` sets any surface within `r` of
`p` toward `T` by `k`. They're spheres in world space, so a mark on something that moves must be moved with it (the
demo works out the gate's and the door's handprints from their hinges every frame). `handprint(centre, up, right, T)`
and `prints(t, pos, t0, t1, step, dT, fade, options)` in `common.js` build a hand and a trail of footprints.

### The wind

The whole set shares one wind field: a steady breeze along `WIND_DIR` plus up to four gust fronts that travel
downwind at 36 ft/s, each rising sharply at its front and dying away behind it. `setWind(state)` (called every frame
with the shot's `wind(t)`) hands it to the shaders, and `windAt(x, z, t)` in `common.js` is the same field in
JavaScript. Everything reads it:

- **Bending**, in the vertex shader. A piece placed with `sway: {k, len, pivot, mode}` bends downwind by `k` feet per
  unit of wind at the far end of its `len`, growing with the square of the distance from the pivot: `mode` 0 bends
  upward (trees, grass), `'hang'` hangs down from the pivot (washing), `'x'` reaches out along +x (a branch).
  `flutter: [amount, fineness]` adds a shake of its own (fineness is 1 / the size of the parts that move together).
  On a meshed piece only material 8 (leaves, grass) flutters fully.
- **Cooling**, in the heat shader: a band just behind each gust front strips warmth from anything warmer than the
  air (`cool`, `coolMax` in the wind state), so lit windows dim one after another as a gust crosses a house.
- **Gas**: shots set emitters' `drift` from `driftAt(x, z, t)`, so smoke lies down in a gust and breath streams off.
- **People and animals**: the shots turn the wind into a scarf's and a ponytail's direction (`windLocal`), a lean,
  a dog's ears.
- **The sky**: clouds (warmer than the clear sky between them) drift by the wind's `scroll`.

`GUSTS` in `common.js` is the demo's list: `{tc, w, str}` puts a front across s = 0 at time `tc`; `tcAt(t, x, z)`
works out the `tc` that brings a gust to a place at a given time, which is how the gusts land on words.

### Figures

`humanModel` (in `tmodels.js`, meshed as type `'human'`) is one parametric person: build (`H` height in feet, `bw`
breadth, `mus`, `gut`, `fem`, `child`), clothing (`top`: `'tshirt'`, `'shirt'`, `'jacket'`, `'parka'`, `'coat'` or
`'bare'`; `drape`, `legsWear`, `feetWear`, `hair`, `beard`, `hat: 'knit'`, `scarf`), the wind (`hairTail`,
`scarfTail`, `scarfWave`, `hem`) and pose: `legs` as `'stand'` with a `stride`, one of several seated and crouching
set-ups, or `'free'` with `pelvisY` and `footL`/`footR` targets so any two poses blend; `lean`, `twist`, `side`, the
head's `headYaw`, `headPitch`, `headRoll`; arms as angles `{fwd, out, bend}` or IK targets `{t: [x, y, z], pole}`;
things held (`holdL`/`holdR` of `'plate'`, `'jug'`, `'paper'`, `'bucket'`, `'bag'`; `cup`; `bundle`). It faces +z
with its feet at y = 0; `mouthAt(p)` says where its mouth is, for breath.

`dogModel` (`'dog'`) is a dog or a wolf: `pose` `'stand'`, `'pant'`, `'run'` (with `phase` 0-3), `'walk'` (with a
continuous `phase`), `'crouch'`, `'lie'`, `'sniff'`; `size`, `headYaw`, `headPitch`, `ears` (0 up, 1 flat), `tail`.

An `Actor` (`kit.js`) is a figure on stage. Each frame `film.js` calls `actor.set(params, h)` with that frame's pose:
if the pose has been meshed before it shows at once, otherwise it's meshed in a worker first (and `set` returns a
Promise, which `step()` hands back to the render tool to wait for). `h` is the mesh's cell size in feet, the main cost
knob: 0.022-0.028 for a close shot, 0.032-0.05 for a wide one. While a frame shows, `film.js` asks the workers for the
next half-second of poses (`prefetch`). The cache (`MAX` in `pieces.js`) keeps 72 meshes nobody is showing and drops
the oldest. Poses blend with `keyed(t, [[t0, pose0], [t1, pose1], ...])` and `blend(a, b, u)`; `walkP(t, rate, amp)`
in `common.js` is a walk.

### Sets

A set is a function that builds a `Stage` and returns it. From the demo's yard, in brief:

```js
export function setYard() {
  const s = new Stage(), amb = AMB; s.amb = amb; s.em = {};
  s.sky(amb - 26, 18, { amp: 22, lo: -0.12, hi: 0.42, scale: 1.4 });                  // horizon, zenith drop, clouds
  s.box([7000, 0.4, 7000], { p: [0, -0.2, 0] }, { T: amb - 1.2, alb: 0.3, mat: 8, noise: 0.9, noiseScale: 0.22 });
  s.box([3, 11, 3], { p: [11, 23.5, -23] }, { T: amb + 9, alb: 0.4, mat: 7, grad: [2.4, 18, 0.6] }, 'chimney');
  s.em.smoke = s.emit({ p: [11, 29.6, -23], dir: [0, 1, 0], rate: 26, life: 5.5, T: 58, amb, size: [1.3, 10], alpha: 0.13, cool: 1.6, seed: 11 });
  for (const [x, z, h, seed] of TREES)                                                  // a tree that bows and shakes
    s.piece('tree', { T: amb, h, seed }, 0.09, { p: [x, 0, z], sway: { k: 0.085 * h, len: h }, flutter: [0.2, 0.7] });
  new Actor(s, 'human', 0.024, {}, 'woman');                                            // posed by the shots
  return s;
}
```

- `s.piece(type, params, h, tf, name)` meshes a model from `tmodels.js` in a worker; `tf` places it (`p`, `r` or
  `ry`, `s`) and gives it a `sway` and `flutter`.
- `s.box`, `s.plane`, `s.cyl`, `s.sphere` and `s.flat(geometry, ...)` are plain three.js shapes with a flat thermal
  material: `{T, e, alb, mat, noise, noiseScale, grad: [C per ft of height, from height, lumpiness], stripe: [axis,
  spacing, dT]}` (the stripes are boards and siding). `s.plane(w, h, tf, o, name, [xSegs, ySegs])` subdivides a sheet
  so it can bend. The demo's house is built this way: crisp edges and cheap.
- `s.sign(w, h, canvas, ...)` is a board whose painted words show in the visible pass only: paint and bare board
  are the same temperature, so a heat camera can read a sign only through its edges.
- `s.sky(T, zenith, clouds)`, `s.void(T)` (the dark beyond an indoor set) and `s.emit(emitter)`.
- Named things (`s.named`) are what shots move: the demo's truck, gate and door, and props called `prop_*`, which
  start hidden and show only where a shot's `props(t)` puts them.

`film.js` builds every set a shot names, from the functions called `set<Name>` that `sets.js` exports
(`setYard` is the set `'yard'`). `?sets=yard` builds only those.

### Shots and the camera

A shot is a plain object covering a stretch of song time. From the demo (the prints seen from above):

```js
shot({ t0: 7.5, t1: 11.25, look: () => ({ ...OUT, span: [-10, 30] }),
  cam: (t) => ({ pos: [lerp(-8.4, -10, sm(7.5, 11.25, t)), 17, lerp(20.2, 19.4, sm(7.5, 11.25, t))],
                 look: [lerp(-4.6, -6.2, sm(7.5, 11.25, t)), 0, 10.4], fov: 42 }),
  cast: (t) => detail(0.032, { woman: W(t), child: C(t), dog: D(t) }),
  breath: (t) => breathOf({ w: W(t), c: C(t), d: D(t) }, t), fx, decals: marks,
});
```

- `look`: an object or a function of t.
- `cam(t)`: `{pos, look, fov, roll}` in feet and degrees. `aim(target, dir, dist, fov)` in `common.js` places a
  camera at a distance and direction from what it looks at.
- `cast(t)`: `{actorName: {p, ry, params, h, flare} | null}`. Everything else about a figure is in `params`. `flare`
  raises the whole figure's temperature (a heat flare); `setOff(mesh, degrees)` does the same for any piece.
- `props(t)`: `{prop_name: {p, rx, ry, rz}}` for the props this shot shows.
- `fx(t, stage)`: anything else, after the cast: the demo moves the truck, the gate and the door here, and steers
  the emitters (smoke drift, exhaust on and off, leaves torn off in a gust, chimney flares on the beats).
- `breath(t)`: a list of breaths `{p, dir, drift, T, puff, alpha}`, one per breathing figure (keep each figure's
  place in the list with a null when it isn't there). Past puffs ask `breath(t)` again for when they were breathed.
- `decals(t)`: the heat marks for this frame. `wind(t)`: the wind state (the demo gives every shot `windState`).

`film.js` picks the shot whose `t0` is the last at or before t (so shots must cover the song), steps t down to a
twelfth of a second, and cuts. Everything, the camera included, moves on twos; only the sensor noise changes every
frame. There are no dissolves: a heat camera cuts. The demo's stanza change is a palette wipe instead (`wipe` above),
with a short flash, and the door opening pumps the camera's automatic gain (the span jumps up as the hot hall comes
into view, then settles).

### The lyric band

The bottom 120 px. During the intro it shows `SONG.title` in italics over `SONG.credit` in spaced capitals; then each
line of `SONG.lines` fades in 0.2 s before its start and out as the next begins, in Archivo Narrow, drawn on a canvas
(`R.bandCanvas`) that the renderer lays under the picture. Change `drawBand` in `film.js` for another layout; a
`caption` in the look replaces the line (the lab labels its looks that way).

### Determinism and caching

Every frame is a function of its time: poses, the wind, the camera and the gas are all computed from t, the noise is
keyed to the frame number, and nothing calls `Math.random()`. So `step(t)` and `renderAt(t)` are the same function,
any slice renders exactly, and a still at 12.5 s matches frame 300 of the MP4. The only state is the mesh cache, which
changes how long a frame takes, never what it shows. `step(t)` returns a Promise while a pose is being meshed (the
tools wait for it) and nothing once everything is cached. `window.__video` also has `frame(t, lookOverrides)` (used by
the lab), `shots`, `stages` and `R`, the renderer.

## Make your own video in this style

1. **Copy the folder**: `cp -r styles/thermal projects/my-song`, and put your mp3 in it as `song.mp3` (see
   [docs/your-own-video.md](../../docs/your-own-video.md) for the whole process). Paths work the same from
   `projects/my-song/`, and the tools serve it at http://localhost:8000/projects/my-song/index.html.
2. **Your song**: make its `lyrics_data.js` with the timing pipeline in [docs/timing.md](../../docs/timing.md) (it
   ends with `tools/audio/to_js.py`, which writes the same `window.SONG` shape), then point the page at it: in
   `index.html`, change `../../examples/poem/lyrics_data.js` to `lyrics_data.js`. `SONG.audio` is the mp3's path
   relative to the page. Change the page's title and heading. The lab page loads the timing from
   `../../../examples/poem/lyrics_data.js`; point it at `../lyrics_data.js` too if you use it.
3. **Keep** `film.js`, `thermal.js`, `kit.js`, `pieces.js`, `tmesher.js`, `tmodels.js` and `sdf.js`. **Replace**
   `sets.js` with your places, `shots.js` with your shot list, and in `common.js` the air temperature, looks, people
   and `GUSTS` (keep its helpers). The demo's gust times fall back to fixed times if your song has fewer lines, so the
   demo keeps playing under your lyrics while you work.
4. **Decide the temperatures first.** Pick the air, then everything relative to it (the table above), and a span for
   each kind of shot: the span, not the palette, decides what reads. Things within a degree or two of their
   background vanish unless the edge overlay outlines them.
5. **Add a set**: export `function setMine()` from `sets.js` returning a `Stage`, and name `'mine'` in your shots.
   `?sets=mine` builds only that set while you work. Name the things your shots move.
6. **Add a model**: a function in `tmodels.js` returning `{model, bounds}` with thermal colours, added to `MODELS`.
   Try it in a set with `s.piece('mine', {...}, 0.04, {p: [...]})` and look at a still; halve `h` only if you
   must (mesh time grows with 1/h²).
7. **Add a shot**: an object like the one above. Cut on line starts (`SONG.lines[i].t0`), put hits on beats. Give
   the figures an `h` that suits their size in frame. Make sure something moves: breath, smoke, a sway.
8. **Time a move to a word or beat**: `word(i, k, fallback)` in `common.js` is when word k of line i is sung (both
   counted from 0) and `beat(n)` is beat n. The demo opens its door on "you": `const YOU = word(5, 1, 23.125)` and
   `doorA = (t) => 1.35 * sm(YOU - 0.18, YOU + 0.32, t)`. To send a gust to a place on a word, add
   `{ tc: tcAt(word(i, k, fallback), x, z), w: 34, str: 1 }` to `GUSTS`.
9. **Useful knobs**: the looks' `span` and `palette`; `trefl`; `dde`; the edge overlay's `msx` and `line`; `GUSTS`
   and `baseAt` (the wind); each piece's `sway` and `flutter`; `cool` in `windState`; a figure's `h`; `sensor`.

## Lab

Open http://localhost:8000/styles/thermal/lab/index.html (with `tools/serve.py` running) and pick a scene and a look;
`?scene=gate&style=amber` opens on a pair. The lab loads the demo's own `film.js`, meshes the figures for its three
moments (the yard at 2.6 s, the window at 13.4 s, the gate at 17.3 s) once, and then draws any moment in any look
immediately with `window.__video.frame(t, lookOverrides)`.

```bash
python tools/lab_stills.py styles/thermal/lab/index.html --all --sheet    # every scene in every look
python tools/lab_stills.py styles/thermal/lab/index.html gate:readouts    # one
```

What each look changes (see `LOOKS` in `lab/lab.js`):

- **Ironbow**, **white-hot**, **black-hot**, **rainbow**, **amber**: only `palette`; the span is the shot's own.
- **Arctic**: `palette: 'arctic'` with a lower span, so that walls and trees sit in the blues and only lit windows,
  engines and people reach the gold end.
- **Embossed edges**: `edge: 'emboss'`, the heavier overlay many cameras use: edges from the visible image's
  brightness, depth and normals, lightening dark areas and darkening bright ones, 1.25 px wide.
- **No edge overlay**: `msx: 0`, heat alone. Compare it with ironbow to see how much of the picture's legibility is
  the overlay: the fence, the gate and the grass are at the air's temperature and nearly vanish.
- **Camera read-outs**: `osd: true` and a `spot` point. `film.js` renders once, reads the heat buffer back at the
  spot (`R.readT(u, v)`), draws a scale bar and a crosshair with the reading on the overlay canvas, and renders again.

## Performance

On an Apple M4 shared with other sessions' renders (the tools run headless Chrome with the GPU on):

- **Load**: about 6 s: 18 set meshes in eight workers, most of the time the five broadleaf trees (`h` 0.09). The set
  is 99 distinct geometries and about 1.7 million vertices; the sixteen spruces share three meshes.
- **Frames**: drawing takes 1-16 ms when every pose is cached. Meshing takes, in worker time on an idle machine, 0.37 s
  for a person at `h` 0.024 (41,000 vertices), 0.2 s at 0.034 (20,000) and 0.13 s at 0.045 (12,000), and 0.18 s for
  the dog at 0.024; about twice that when other renders share the machine. Stepped in order, stretches with people
  cost 70-140 ms a frame and the rest about 6 ms. A full `--fast` render drew its 900 frames in 51 s (57 ms a frame,
  including reading the canvas back); the whole command, with loading and encoding, took from one to six minutes here,
  depending on what else the machine was doing.
- **Memory**: the JS heap is about 210 MB, most of it cached pose meshes; lower `MAX` in `pieces.js` (72) if memory
  is tight.
- **What makes it slow**: small `h` on figures (vertices grow with 1/h²), several figures at once, and poses that
  never repeat. Wide shots don't need fine figures: the demo meshes people at `h` 0.045 in its widest shot. A figure
  that holds still costs nothing after its first frame.
- **A slice**: `python tools/render_mp4.py styles/thermal/index.html --start 15 --end 19 --fast`. Every frame depends
  only on its time, so a slice matches the full render and can be spliced into it with `tools/splice.py`.

## Lessons and gotchas

- **Traces are the style's best tool.** Breath, smoke, exhaust, footprints, handprints, the warm patch where someone
  sat: a heat camera shows what just happened, and that's what tells a story in it. Seen from above, breath trailing
  downwind was the clearest picture of the wind in the demo.
- **Anything at the air's temperature disappears.** A fence, a gate, grass, a sign: without the edge overlay they're
  gone. Keep the overlay on, as thin white lines at half strength (0.8 px); the heavier embossed overlay muddies warm
  bodies.
- **Faces read in profile and at a distance, not straight on.** Close up and face-on a warm face is a smooth
  mannequin; keep faces to profiles and medium shots, and let hats, hair and breath carry them.
- **Glass is opaque to a heat camera.** A lit window shows its own warmth, never the room behind it, and a glazed door
  hides the face behind it; a barred opening doesn't.
- **Two warm bodies touching merge into one blob**, and so do figures of the same temperature overlapping in depth.
  Keep a layer of cooler clothing, or a gap, between them.
- **Text is invisible in heat.** Paint is the same temperature as the board; `s.sign()` puts it in the visible pass,
  where only the overlay can show it.
- **The span decides what reads, more than the palette.** A palette wipe needs each palette's own span (`span2`): a
  shared span flashed the incoming palette to its hot end. Cool palettes such as arctic need a lower span so warm
  things reach their warm end.
- **Detail enhancement lies about thin cool things against a very cold sky**: branches and blown leaves came out with
  hot rims. The enhancement is capped (`ddeMax`, 6 degrees).
- **Edges from depth must ignore slopes.** First differences of depth fire on distant ground seen at a grazing angle
  and drew a grey band along the horizon; the second difference of inverse depth is flat on any plane and jumps only
  at outlines.
- **Material codes must not blend across a seam.** Blended, skin beside cloth passed through 2 (a hot source) and
  leaves beside bark missed 8. The modeller takes the winning op's code, and the shaders read it as a flat varying.
- **Keep the sky cold below the horizon, and the ground big.** A sky sphere whose temperature follows height warms
  below the horizon, and it shows through past the edge of a small ground plane.
- **Flutter only small things, at their own scale.** A noise shake fine enough for leaves melted whole trees; give each
  piece a fineness, and let only leaves and grass shake fully on a meshed piece.
- **Washing on a line running downwind** streams out like flags, face-on to a camera beside it; on a line across the
  wind it billows toward or away from the camera and reads as a shapeless blanket.
- **A gust's cooling is limited by physics**: it can only take away a surface's warmth above the air, so it barely
  shows on walls a few degrees above it. It shows on lit windows and on people; let the windows dim one by one.
- **Hot things dominate the frame.** A truck's hood right after a drive is the brightest thing in any shot it's in;
  park it out of the shots that are about something else, or keep it small.
- **Handprints are small**: a palm is a few pixels beyond 15 ft. Bring the mark toward the camera (the demo's gate
  swings toward it) or go close.
- **Past breath must leave from where the mouth was.** Using the current mouth made a walking person's plume follow
  their head like a rigid tail; `breath(t)` is asked again for each puff's own time.
- **Figures cost their mesh, not their drawing.** Give every shot a figure detail to suit its framing, and don't
  animate a far-off figure every frame when nobody can see it (the demo's dog in the truck turns its head every
  two beats).
- **A heat camera cuts; it doesn't dissolve.** For a change of section, change the palette (the demo sweeps it across
  with the wind), pump the gain or flash briefly; the last two are what a real camera does.
- **Move on twos.** Twelve drawings a second reads as a real, slightly cheap camera rather than a render, and the
  sensor noise, which still changes every frame, keeps a held shot alive.
- **Don't start or end on pure black.** The demo fades up from 20% and fades down to about 30%.
- **`step()` may return a Promise**, and the render tools wait for it; a page that meshes on demand must still never
  draw a frame before its poses are ready.

