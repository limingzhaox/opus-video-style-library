// Embedded in the standalone gallery at build time; no network is needed to copy.
const PUBLIC_BASE='https://limingzhaox.github.io/opus-video-style-library/';
function taskSection(title,description,text,label){
  const section=document.createElement('section');section.className='ai-task';
  const h=document.createElement('h3');h.textContent=title;
  const p=document.createElement('p');p.textContent=description;
  const area=document.createElement('textarea');area.className='prompt-text';area.value=text;area.setAttribute('aria-label',label);
  const tools=document.createElement('div');tools.className='prompt-tools';
  const copy=document.createElement('button');copy.className='copy-prompt';copy.textContent='复制'+title;
  const status=document.createElement('span');status.className='ai-status';status.setAttribute('role','status');
  copy.onclick=async()=>{try{await navigator.clipboard.writeText(area.value);status.textContent='已复制，可粘贴给其他 AI';}catch{area.focus();area.select();try{status.textContent=document.execCommand('copy')?'已复制，可粘贴给其他 AI':'请按 Ctrl+C 复制';}catch{status.textContent='请按 Ctrl+C 复制';}}};
  tools.append(copy,status);section.append(h,p,area,tools);media.append(section);
}
function openHandoff(key){
  const d=key?data[key]:null;media.classList.add('prompt-view');media.replaceChildren();links.replaceChildren();
  document.getElementById('dialogtitle').textContent=d?key+' · '+d.cn+' · 交给其他 AI':'让其他 AI 找风格、读提示词、制作视频';
  const intro=document.createElement('p');intro.className='ai-intro';intro.textContent='把下面的指令粘贴到另一个 AI，并修改主题等需求。网址可免登录读取；AI 需要联网权限。不能联网时，使用对应的完整 Markdown 或 TXT 附件。文本框可直接编辑后再复制。';media.append(intro);
  const needs='我的需求：主题={{填写主题}}；片长=30 秒；画幅=16:9；语言=中文；音频=无配音，音乐仅使用我有权使用的素材。可修改这些参数；其余非关键缺项先给出合理默认并说明。';
  const selected=d?`已选择 ${d.cn} / ${d.en}（${d.id}）。完整提示词：${PUBLIC_BASE+d.promptFile} 。请实际读取该文件，保留风格核心，先用中文解释它的注意事项。`:`请实际读取 ${PUBLIC_BASE}llms.txt 和 ${PUBLIC_BASE}styles.json ，按我的主题推荐 3 个风格。每个给编号、中文名、选择理由、案例图片/原作者视频和完整 promptFile 网址，并说明各自取舍。等我选定后再读取对应完整 Markdown，不必一次读取全部 prompts.json。`;
  taskSection(d?'联网 AI 使用指令':'联网 AI 选风格指令','适合能浏览网页的聊天 AI：看案例、做选择、填写提示词。',selected+'\n\n'+needs+'\n\n先整理推荐或模板，不要声称已生成视频。读取 '+PUBLIC_BASE+'ATTRIBUTION.md ，区分作者原始 STYLE.md 与本库整理模板；若网页读取失败，请说明并向我索取单项文件，不要凭空编造原文。','联网 AI 指令');
  const production=d?`使用 ${d.cn}（${d.id}），先读取完整模板 ${PUBLIC_BASE+d.promptFile} 。`:`先读取 ${PUBLIC_BASE}llms.txt 和 ${PUBLIC_BASE}styles.json ，提出 3 个适合主题的候选，等我选定一种后读取其完整 promptFile。`;
  taskSection('编程 AI 制作指令','适合能读写文件、运行终端和浏览器的 AI。实际渲染需要完整上游工程。',production+'\n\n'+needs+'\n\n先说明当前工具能否读取文件、克隆项目、运行依赖、预览浏览器和导出 MP4。读取该风格全部规范、注意事项与 '+PUBLIC_BASE+'ATTRIBUTION.md ，按模板中指定的上游仓库及固定提交，在新工程目录制作，保留母版及我已有文件；不要把这份静态资料当作完整渲染引擎。填好需求，替换演示故事、文字与音频。先交付分镜、3 张真实渲染样帧和 5–10 秒预览，等我确认后再导出完整视频，保留源工程和素材署名。检查文字、音画同步、空白帧与日志，只报告实际执行过的结果。涉及真实数据时给出来源，艺术模拟须标明。','编程 AI 指令');
  const offline=document.createElement('p');offline.className='ai-intro';offline.textContent=d?'不能联网：关闭此窗口，点本风格“完整提示词 · 注意事项”，复制全文或下载 TXT，作为消息或附件发给另一个 AI。要保留来源与指南，可发送完整分享 ZIP。':'不能联网：先选一个风格，在“完整提示词 · 注意事项”里复制全文或下载 TXT；也可把完整分享 ZIP 上传给支持附件的 AI，要求它先读 README、styles.json，再按项读 prompts/。本机路径不能给外部 AI 直接访问。';media.append(offline);
  addLink('AI使用说明.md','阅读完整 AI 使用说明');addLink(PUBLIC_BASE+'llms.txt','公开 AI 文本入口 ↗');
  if(d)addLink(PUBLIC_BASE+d.promptFile,'此风格的公开完整提示词 ↗');
  viewer.showModal();
}
document.getElementById('ai-help').addEventListener('click',()=>openHandoff(null));
document.querySelector('.grid').addEventListener('click',e=>{const b=e.target.closest('[data-handoff]');if(b)openHandoff(b.dataset.handoff);});
