"""Package only an explicit allowlist; user material and original PDF are excluded."""
from pathlib import Path
import base64, json, shutil, zipfile
ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'可发布资料'
def put(dest,source=None,text=None):
    dest.parent.mkdir(parents=True,exist_ok=True)
    if source is not None:
        if not dest.exists() or dest.read_bytes()!=source.read_bytes():shutil.copyfile(source,dest)
    else:dest.write_text(text,encoding='utf-8')
lib=json.loads((ROOT/'prompts.json').read_text(encoding='utf-8'))
assert all(not x['reviewFlags'] for x in lib['styles']),'Review new/changed source text before packaging.'
files={}
fixed=['README.md','使用指南.md','ATTRIBUTION.md','分享与外部访问.md','更新说明.md','更新日志.md','案例索引.md','完整提示词总册.md','llms.txt','styles.json','prompts.json','先看这12种.jpg']
for name in fixed:files[name]=ROOT/name
for pattern in ['prompts/*.md','images/*.jpg','总览-*.jpg','sources/upstream/lemo/**/*.md','sources/upstream/handmade/**/*.md','sources/upstream/*/LICENSE','sources/upstream/*/requirements*.txt','sources/upstream/lemo/styleboard/catalog.json','sources/*.py','sources/style-notes.txt']:
    for p in ROOT.glob(pattern):files[p.relative_to(ROOT).as_posix()]=p
for name in ['styles.json','manifest.json','source-files.json','source-inventory.json','upstreams.json','auxiliary-repos.json']:
    files['sources/'+name]=ROOT/'sources'/name
files['index.html']=ROOT/'图册.html'
OUT.mkdir(exist_ok=True)
assert OUT.resolve().is_relative_to(ROOT.resolve()) and OUT.name=='可发布资料'
manifest=OUT/'.package-manifest.json'
previous=set(json.loads(manifest.read_text(encoding='utf-8'))) if manifest.exists() else set()
existing={p.relative_to(OUT).as_posix() for p in OUT.rglob('*') if p.is_file()}-{'.package-manifest.json'}
unknown=existing-previous
if unknown:raise SystemExit('Preserve unexpected files before rebuilding publish folder: '+str(sorted(unknown)))
for rel,source in files.items():
    if rel=='index.html':
        text=source.read_text(encoding='utf-8')
        for item in lib['styles']:
            image=ROOT/'images'/(item['source']+'-'+item['slug']+'.jpg')
            embedded='data:image/jpeg;base64,'+base64.b64encode(image.read_bytes()).decode()
            text=text.replace(embedded,'images/'+image.name)
        text=text.replace('从你文件夹中的《Opus 5.5.pdf》找到','从《Opus 5.5.pdf》资料中找到')
        put(OUT/rel,text=text)
    elif source.suffix=='.md':
        text=source.read_text(encoding='utf-8').replace('(图册.html)','(index.html)')
        put(OUT/rel,text=text)
    else:put(OUT/rel,source=source)
# Remove only exact obsolete paths from our previous allowlist.
for rel in previous-set(files):
    p=(OUT/rel).resolve()
    assert p.is_relative_to(OUT.resolve())
    if p.is_file():p.unlink()
names=sorted(files)
put(manifest,text=json.dumps(names,ensure_ascii=False,indent=2)+'\n')
zipdest=ROOT/'Opus风格分享包.zip'
with zipfile.ZipFile(zipdest,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for rel in names:z.write(OUT/rel,rel)
print(json.dumps({'files':len(names),'zip':zipdest.name,'bytes':zipdest.stat().st_size,'publishedToInternet':False},ensure_ascii=False))

