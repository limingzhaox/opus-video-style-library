# Batik

A waxed and dyed cloth, worked out from a real 3D set (three.js). The set is built like a theatre model: white card,
dowel, and pieces meshed in the browser from signed-distance models, lit by just two lamps, a gold one and a blue one.
The batik comes from that light, the way dye takes on waxed cloth: where only the gold lamp reaches, the cloth is
dyed soga (a gold-brown); where only the blue reaches, indigo; where both reach, it's left cream; where neither
does, near black. Every silhouette and crease is a line of wax that resists the dye (cream on dyed ground, dark on
light), and the wax cracks, letting fine veins of indigo into the light parts. For busier scenes there's a full
palette: each thing is dyed its own colour, snapped to the nearest of nine dyes and then overdyed by the lamp that
reaches it, so its shadows still lean soga or indigo. Things carry batik patterns in their own space (parang, kawung,
dots, stripes, grass ticks), so a pattern stays on a skirt as it blows. A dye front sweeps one palette into the next
across the cloth; the cloth has a border of tumpal triangles and a band along the bottom where the lyrics are
written in, each word brightening as it's sung.

![A woman in a patterned indigo skirt and a man in a green coat meet on a dotted path by a big tree, in the full palette](img/hero.jpg)

*Good for:* songs with two voices or two sides (the two lamps are two dyes), day and night, weather, folk songs, and
songs that swing between busy verses and stark choruses (the full palette for the verses, two dyes for the high
points).

The demo sets Christina Rossetti's "Who Has Seen the Wind?" on a windy afternoon in open country, where the wind is
only seen through what it moves. The title comes up on the cloth in two dyes; on the first word a dye front carries
the full palette across the cloth with the wind. Two people meet on a path by a big tree, her skirt blown ahead of her,
his coat blown back; the tree's leaves, drawn as little shapes of wax, tremble and blow off; a gust runs along the
washing on the line. The second verse sweeps in an evening colourway while the camera climbs a kite string from a
child on a knoll to the kite; the two stand looking up; a row of trees on the ridge bows as a gust runs along it on
"bow down their heads". "The wind is passing by" is two dyes again, the whole field from the east with the lamps
swinging overhead, and in the last bars two round windows open in the cloth on the beats, onto two other looks of
the same set.

| | |
|---|---|
| ![The field in two dyes, soga and indigo fields in the sky, the title in the caption band](img/twodye.jpg) | ![A dye front sweeping the full palette across the cloth from the left](img/wipe.jpg) |
| ![A row of trees bowing on a ridge in the evening colourway, teal ground and a rose sky](img/trees.jpg) | ![Two round windows in the cloth, the left showing the lit card model and the right gold line on indigo](img/window.jpg) |

## Looks in this family

The [style lab](lab/index.html) draws the demo's set from three of its cameras in each look. All four are made from the
same lit set; only the last step changes.

- **Batik** (the demo): wax lines and dyes worked out from the two lamps' light, crackle, patterns, a tumpal border.
  ![The washing on the line in batik, the sheets patterned in kawung and parang](img/look-batik.jpg)
- **Two-lamp model box**: the set itself, white card under a gold lamp and a blue lamp, every object throwing two
  coloured shadows, on a curved backdrop, with ambient occlusion, a shallow lens and faint haze in the beams.
  ![The washing as a white card model lit gold and blue](img/look-box.jpg)
- **Gold line on indigo**: edges drawn in gold and silver on indigo paper, each in the metal of the lamp that lights
  it; where one lamp is blocked, the shadow is hatched in the other lamp's metal.
  ![The washing in gold and silver line on indigo](img/look-goldline.jpg)
- **Shop-window glass**: the scene painted on a shop window at night: people gilded in gold leaf, trunks and sheep
  etched, the land and the washing in stained glass, the lights of the shop blurred behind the sky, frost in the
  corners, a sign-writer's gilt border. It is the weakest of the four: over a whole scene it can read as a 3D render
  put through a filter. It holds up best with a few gilded figures and plenty of dark glass around them.
  ![The washing as a stained-glass window with bokeh behind](img/look-glass.jpg)

## Run the demo

```
python tools/serve.py
```

Then open http://localhost:8000/styles/batik/index.html and press Play (or Space). The page has to be served (ES
modules and module workers don't run from `file://`). It plays live, but not at full speed: a frame takes 60-110 ms
to draw on an Apple M4, so the player shows 9-16 frames a second, picking frames by the audio clock (it drops frames
rather than drifting). Render an MP4 to share it. The first load takes about 5 s while a pool of workers meshes the
pieces; the label in the corner says what it is building.

- `index.html#t12.5` shows a still at 12.5 s (the page around it is hidden).
- `index.html?look=box` (or `goldline`, `glass`) plays the whole demo in another look of the family (without the
  caption band).
- `index.html?buf=col` (or `id`, `nd`, `depth`, `gold`, `blue`) shows one of the buffers the looks are drawn from:
  the quickest way to see why something came out the wrong dye.
- `index.html?sets=field` builds only the named sets (this demo has one).

Stills, MP4 and the framing check (from the repository root):

```
python tools/still.py styles/batik/index.html 2 6 12.5 0:37.5:2.5 --sheet
python tools/render_mp4.py styles/batik/index.html --fast
python tools/probe.py styles/batik/index.html
```

A `--fast` 720p render of the 37.5-second demo takes about 80 s on a quiet Apple M4: a 5 s load, then 900 frames at
about 85 ms each, including reading the canvas back and encoding (3 minutes with other renders sharing the machine).
`probe.py` lists shots where something stands between the camera and its subject.

## How it works

`index.html` loads Alegreya (Google Fonts), an import map for three.js 0.170 from jsDelivr, the song timing
(`../../examples/poem/lyrics_data.js`, which sets `window.SONG`), and then `film.js` as a module; everything else is
imported from there. Units are feet throughout: a person stands about 5.6.

| File | Job |
|---|---|
| `film.js` | The player: builds the sets, draws song time t (sets up the shot, renders it, writes the caption band), playback on the audio clock, `window.__video`, `probe(t)` and `view(t, pos, look, fov)`. |
| `styles.js` | The four looks: `makeStyles(renderer)`, the buffer passes, and the composite shaders (batik, gold line, glass; the model box is three.js post-processing). The colourways (`WAYS`). |
| `stagekit.js` | The lamp rig: `stage()`, `lamp()`, `addLamp()`, haze cones, the tide (each colour's lamps faded over time), a bokeh backdrop for the glass. |
| `mats.js` | The card and figure materials, glowing bulbs, and the per-pass materials every mesh gets (`prepPasses`, `usePass`). |
| `props.js` | Card and dowel pieces: boxes, dowels, threads, sagging lines, cut shapes, leaves, flowers, plant clumps, a card house, a lantern, a cut cloud, the curved backdrop, card cut-out people for crowds. |
| `models.js` | Signed-distance models (no three.js, so the workers can import it): a person, and the countryside (trunk, crown, leaf, grass tuft, washing, line post, fence, kite, bow, smoke puff, cottage, sheep). The colour table. |
| `figures.js` | `makeFigures()`: meshed models as groups, and where a person's hands are (`handOf`). |
| `sdf.js`, `mesher.js`, `pieces.js` | Signed-distance modelling and meshing in a pool of module workers (`need()`). |
| `core.js` | Frame size, seeded random, canvas helpers, the GLSL noise, and the textures (paper fibre, gold leaf, frost). |
| `common.js` | Helpers for sets: dye tints `T`, `show`, `ground`, easing, `polyline`, props in hands, pose flips on twos, merging static meshes. |
| `shotkit.js` | Helpers for shots: `pal()`, `orbit()`, `word()`, `line()`, `beat()`. |
| `sets.js` | The sets a shot can name: `{ field }`. |
| `set_field.js` | The demo's set: the land, the wind (`GUSTS`, `wind()`), every piece, and `update(t)`. |
| `shots.js` | The shot list, `shotAt(t)`, `camAt(shot, t)`, and the windows of the outro. |

`sdf.js`, `mesher.js` and `pieces.js` are the diorama style's ([styles/diorama](../diorama)), with one change: the
mesher leaves out the diorama's darkening of hollows (see the lessons below). A point takes its material code from
whichever operation wins there rather than a blend of them, in both styles. `pieces.js` also has `needOne()` and
`assign()`, for figures re-meshed in a new pose on every step (the diorama's `Actor`); this demo doesn't use them. The
countryside models in `models.js` are the diorama's too, rescaled and recoloured to land on the dyes.

### A set and its lamps

A set is an async function that returns an object; `stage()` starts one with a scene, a camera and the two lamps:

```js
import { V, stage, applyTide } from './stagekit.js';
import { T, ground } from './common.js';
import * as PR from './props.js';
import { makeFigures } from './figures.js';

export async function yard(renderer) {
  const S = stage(renderer, { goldPos: V(-40, 44, 36), goldAim: V(0, 0, -4), bluePos: V(40, 44, 36), blueAim: V(0, 0, -4),
    goldO: { i: 1.3, angle: 0.6, far: 160 }, blueO: { i: 1.2, angle: 0.6, far: 160 } });
  S.scene.add(ground(200, 200, { tint: T.soga, pat: 5, patScale: 1.5 }));          // dotted soga ground
  const house = PR.tag(PR.house(8, 7, 6.5), { tint: T.cream }); house.position.set(0, 0, -12); S.scene.add(house);
  const F = await makeFigures({ reader: { pose: { dress: 'indigo', skirt: 'rose', skirtMat: 13, hair: 'bun' } } });
  F.reader.position.set(3, 0, -4); S.scene.add(F.reader);
  S.P = { reader: F.reader };                   // named parts a shot can show or hide
  S.tide = () => ({ g: 1, b: 1 });
  S.lref = 0.3; S.nearFar = [12, 60];
  S.update = (t) => { applyTide(S, t); F.reader.rotation.y = 0.3 * Math.sin(t); };
  return S;
}
```

Add it to `SETS` in `sets.js`. What the looks read from a set:

- `goldLights` and `blueLights` (from `stage()`, plus any `addLamp(S, warm, pos, aim, o)`), and `extraLights`
  (point lights with `userData.warm` true or false, counted as gold or blue).
- `lref`: the light level the dyes are measured against. A surface counts as lit when its light is over 15% of it.
  `?buf=gold` and `?buf=blue` show each lamp's light with `lref` as mid-grey.
- `tide(t)`: `{g, b}`, multipliers on the gold and blue lamps; `tideAt(t, [[time, gold, blue], ...])` eases between
  keys. Turning one colour down turns the cloth toward the other dye.
- `nearFar`: the depths (ft) over which lines thin out with distance; `crackle(t)`: how much the wax cracks.
- For the model box: `focus` (`{dist, aperture, maxblur}`; `film.js` sets `dist` from each shot's subject), `bloom`,
  `exposure`, `vignette`, `hazes`. For the glass: `glass` (`{bg, frost, frostT, growth(t), amount}`).
- For `film.js`: `update(t)` (pose everything for song time t), `P` (named parts, for `show`), `named` (for `probe`).

Lamp options (`goldO`, `blueO`, or `lamp(colour, pos, aim, o)`): `i` intensity, `angle`, `pen` penumbra, `map`
shadow-map size, `near`/`far` (keep the shadow camera tight round the set), `nb` normal bias, `soft`.

### Pieces

Card pieces are ordinary three.js meshes; signed-distance pieces are meshed in workers. Either way a mesh's `userData`
tells the looks how to treat it (`PR.tag(object, {...})` sets it on every mesh under an object):

| key | meaning |
|---|---|
| `tint` | the thing's own colour (card pieces; a meshed model multiplies it into its own colours). The full palette dyes it the nearest dye. `T` in `common.js` has a tint next to each dye. |
| `mat` | the material code, for meshes without one of their own: 0 plain, 1 metal, 2 glow, 3 cloth, 4 hair, 5 red dye (keeps its red in the two-dye picture), 6 leather, 7 lamp, 9 ground, 10 sky, 13 patterned cloth, 14 a glow that keeps its own dye, 15 wax resist (left cream in any palette). |
| `patKind`, `patScale` | a batik pattern drawn in the object's own space: 3 parang, 4 kawung, 5 dots, 6 stripes, 7 stone courses, 8 grass ticks, 9 water, 10 cross-hatch, 11 fine cracks; `patScale` in the object's units (feet). On a card piece it covers the whole piece; on a meshed model only its mat-13 parts (parang unless `patKind` says otherwise). |
| `side` | 0 neutral, 1 warm, 2 cool, 3 both: the gold line draws warm things in gold and cool ones in silver (neutral things take the metal of the lamp that lights them). |
| `finish` | the glass look: 1 gilt, 2 etched, 3 stained, 4 clear, 5 light, 6 faint etch, 7 painted dark. |
| `noPass`, `litOnly`, `passOnly`, `alphaCut`, `passAlpha` | no buffer materials (haze cones); only in the lit or only in the buffer passes; a cut-out's alpha. |

Meshed models are signed-distance models from `models.js`, requested by name, parameters and cell size:

```js
const G = await need({ tree: ['crown', { seed: 2, r: 5.4 }, 0.1], leaf: ['leafChip', { mat: 15 }, 0.012] });
const F = await makeFigures({
  her: { pose: { hgt: 5.4, dress: 'red', skirt: 'indigo', skirtMat: 13, hood: 'yellow', stride: 0.36, wind: [0, 0.75] }, patScale: 0.3 },
});
```

A model is an ordered list of operations on primitives (see [styles/diorama](../diorama) for `P.sphere`, `P.cone`,
`P.box`, `P.fn` and the rest) with a colour and a material code. The person (`personModel`) takes `hgt`, `build`,
`dress`, `skirt`, `skirtMat`, `hem` (0.55 a long skirt, about 2.3 a coat to the knee over trousers), `legs`, `hood`
(a colour for a headscarf), `hair` ('short', 'bun', 'long'), `cap`, `scarf`, `apron`, `bag`, `pack`, arms `armL` /
`armR` `{fwd, out, bend}`, `headYaw`, `headPitch`, `lean`, `stride`, `kneel`, `sit`, `face: 'full'`, and `wind: [x, z]`,
how far (ft, in the figure's own frame) the wind blows the hem, long hair, the scarf's end and a headscarf's knot, with
`flap` shifting the ripples round the hem. A walk is four meshes (stride +, 0, -, 0) swapped on twos. `handOf(req, 'L')`
gives a hand's position for putting something in it (`hold()` in `common.js`).

### The buffers and the batik

For the buffer looks, `styles.js` draws the set five times into buffers at twice the frame size (3840 x 2160): normal
and depth; ids (which object, its side and finish, its material code, its pattern); its local colour; the lit set with
only the gold lamps on; and with only the blue. The shadow maps are drawn once, in the gold pass. Then one full-screen
shader draws the look and the result is filtered down to 1920 x 1080. The batik shader, for each pixel:

1. Wobbles where it samples a little (the lines "boil" on twos), and reads the buffers there.
2. Measures each lamp's light by the luminance of the lamp's own colour, so the two balance: `lit` if the total is
   over 15% of `lref`, `onlyG` if the gold's share is over 0.7, `onlyB` if under 0.3.
3. Two dyes: cream where both lamps reach, soga or indigo where one does, near black where neither. The sky is a soga
   field on the gold lamp's side of the cloth, indigo on the blue's, cream between, each bounded by a line of wax.
4. Full palette: the local colour snapped to the nearest of nine dyes (cream, soga, indigo, near black, red, green,
   yellow, pale blue, rose) as the colourway dyes them, then overdyed: toward soga where only the gold reaches, toward
   indigo where only the blue does, toward black where neither. The sky is mega mendung, cloud bands in steps with wax
   between them, in the colourway's sky dyes.
5. Mixes the two by the palette, along the dye front.
6. Red dye (5) stays red in two dyes; lamps are bright wax; wax resist (15) is cream.
7. Patterns: the id buffer's pattern drawn as wax against the dye (dark on light, cream on dark).
8. Fillers in the two-dye picture: dots on the indigo, fine lines in the dark.
9. Wax lines along silhouettes (an id change or a jump in depth) and creases (a turn in the normal), found at one,
   two and (up close) three pixels; cream on dyed ground, dark where the ground was left light.
10. Crackle: two scales of Voronoi cracks, patchy, only where the wax is (the light parts).
11. The weave and uneven dye, the windows (below), the fade to bare cloth, a split screen's divider, the tumpal border
    and the caption band.

**The palette** is a function of song time returning an object; `pal()` in `shotkit.js` makes the usual ones:

```js
pal(a, b = a, w0 = 0, w1 = 0, dir = [1, 0], wayA = 'day', wayB = wayA, extra = {})
// a, b: how much of the full palette shows before and after the dye front (0 two dyes, 1 full)
// w0, w1: when the front starts and finishes its sweep across the cloth; dir: its direction on screen
// wayA, wayB: the colourway before and after it (WAYS in styles.js: 'day', 'dusk', 'sogan')
// extra: slip [x, y] (jolt the picture, as fractions of the frame), rain (streaks of wax, 0..2), cap (the caption
//   band's height in pixels, 0 for none), skyTop / skyBot (override the colourway's sky), and the windows (win, winR,
//   win2, looks)
```

A colourway is the same design dyed another way, the way one waxed cloth is dyed in several colourways: `WAYS` maps each
of the nine dyes to what it comes out as, and gives the sky's two dyes. The demo's second verse sweeps from `day` (the
dyes as they are) to `dusk` (greens to dark teal, yellows to orange, a rose sky); `sogan` is browns and indigo only.

**Windows** (the outro): two round windows in the cloth that show the same set in other looks, drawn from the same
buffers: 1 the lit model box, 2 gold line on indigo, and cruder takes on 3 wool embroidery, 4 a varnished painted
panel, 5 a halftone print, 6 backlit paper cut, 7 linocut, 8 an engraving thrown by a lantern. Each has a rim of wax,
and round them the dye can marble (two eddies turning opposite ways, one round each window). `win: [x, y, distance
between the centres, rim strength]` (pixels of a 1080-high frame, y up), `winR: [left radius, right radius]` (0 is
shut: grow them to open a window, on a beat), `win2: [height / width, turn, marbling, how far the windows show]`,
`looks: [left, right]`. See `windows()` in `shots.js`.

**Split screen**: a shot with `split: [panelA, panelB]` (each a `{set, cam}` like a shot) and `band: (t) => width`
draws two panels side by side, each into its half of the buffers (so both may use the same set), with an indigo
divider edged in tumpal; each panel's sky is its own lamp's dye.

### Shots and the camera

A shot is a plain object. From the demo:

```js
// the title, the cloth in two dyes; then "Who has seen the wind?": the colour comes in across the cloth with the
// wind, and the camera comes down over the field
{ t0: 0, t1: line(1), set: 'field', palette: pal(0, 1, line(0) - 0.05, line(0) + 1.3, [1, 0], DAY), breath: 0.8,
  cam: [[0, [36, 52, 176], [2, 6, -34], 36], [line(1), [26, 30, 118], [4, 8, -28], 36]] },
// "The wind is passing through.": the washing, the gust passing along the line
{ t0: line(3), t1: line(4), set: 'field', palette: pal(1, 1, 0, 0, [1, 0], DAY), breath: 0.3,
  cam: [[line(3), [-27, 7.5, 3], [-57, 4.8, -22], 36], [line(4), [-29, 7, 0], [-57, 4.8, -22], 36]] },
```

- `cam`: keys `[time, position, look-at, fov, roll?]`, eased between; or `camFn(S, t)` returning one key (the kite
  shot follows the kite this way). `breath` (ft) adds a slow drift so no shot sits dead still.
- `palette(t)`: above. `show`: the names of `S.P` parts to show (every other named part is hidden).
- `apply(S, t)`: anything the set's `update(t)` doesn't already do; `focus`: the subject, a point or a function of t
  (for `probe` and the model box's lens; default the look-at point).
- `shotAt(t)` takes the first shot whose `t0..t1` contains t, so keep them in order and covering the song.

The wind is one field in `set_field.js`: a breeze that changes by section, plus gust fronts, each `[time it passes
the origin, strength, width, direction [x, z], speed]`, timed with `word(i, k)`. Everything that moves reads it where
it stands: trees bow at the trunk's foot and again at the crown (the crown more), the leaves tremble harder and are
released in the gusts on flights worked out at load, grass leans, smoke lays over, the washing lifts and swaps between
three billow meshes, the kite climbs, and the walkers' hems blow. The gust along the washing travels north-east, from
the line's near end to its far end, so it fills the sheets one after another rather than all at once.

### The caption band

The batik shader leaves a band 112 px tall along the bottom of the cloth (indigo, small tumpal triangles on the outer
edge, a soga line on top), and `drawCaption` in `film.js` writes into it: during the intro `SONG.title` in italics and
`SONG.credit` in spaced capitals; then each line of `SONG.lines`, from just before it starts until the next begins (or
a second after it ends), each word going from dim to full as it's sung. A line with `voice: 'a'` or `'b'` is set in
that voice's colour (for duets). The font is Alegreya, from Google Fonts.

### Determinism and caching

Every frame is a function of the song time alone: pieces move on twos (`twos(t) = floor(12 t) / 12`), the lines boil
on twos, random numbers come from fixed seeds, and anything with a history (the leaves' flights) is worked out at load.
So `step(t)` and `renderAt(t)` are the same function and any slice of the film renders exactly. Meshes are made once
at load and shared between identical requests.

## Make your own video in this style

1. **Copy the folder**: `cp -r styles/batik projects/my-song`, and put your mp3 in it as `song.mp3` (the whole process
   is in [docs/your-own-video.md](../../docs/your-own-video.md)). The tools serve it at
   http://localhost:8000/projects/my-song/index.html.
2. **Your song**: time it with the pipeline in [docs/timing.md](../../docs/timing.md), which ends with
   `tools/audio/to_js.py` writing `lyrics_data.js`, then in `index.html` change `../../examples/poem/lyrics_data.js`
   to `lyrics_data.js`, and the title and heading. `SONG.audio` is the mp3's path relative to the page.
3. **Keep** `film.js`, `styles.js`, `stagekit.js`, `mats.js`, `props.js`, `figures.js`, `models.js`, `sdf.js`,
   `mesher.js`, `pieces.js`, `core.js`, `common.js` and `shotkit.js`. **Replace** `set_field.js` with your sets (the
   field is there to borrow from), `sets.js`, and the shots in `shots.js` (keep `shotAt` and `camAt`).
4. **A set**: a file exporting `async function mySet(renderer)` like the one above, added to `SETS`. Place the lamps as
   you would place dyes: the side of a thing that faces only the gold lamp comes out soga. Check with `?buf=gold` and
   `?buf=blue`, and keep the edges of the lamps' cones out of frame.
5. **A model**: a function in `models.js` returning `{model, bounds}`, added to `MODELS`; give each part a colour close
   to the dye you want and a material code. For something that changes shape (a walk, a sheet billowing), mesh a few
   poses and show one at a time, on twos.
6. **A shot**: an object in `SHOTS`. Cut on line starts (`line(i)`), put hits on beats (`beat(n)`) and words
   (`word(i, k)`). Keep a whole person 20 ft or more from the camera. Two dyes for the high points, the full palette
   for the busy verses; move between them with a dye front on a line start.
7. **Time a move to a word**: for a gust, set its time a little before the word so the front reaches the thing on the
   word; for a pose, `poseAt(S.P, [[word(2, 3), 'wave']], t)`; for a front, `pal(1, 0, word(7, 0), word(7, 0) + 1.2)`.
8. **Knobs**: the lamps (position, intensity, the tide), `lref` (how much light counts as lit), the palette and its
   colourway, `WAYS` (new colourways), `crackle`, `patScale` on each thing, the `GUSTS`, `breath` on each shot, and
   the dye thresholds in `BATIK_FS` (0.15 for lit, 0.3 and 0.7 for one lamp's share).

For a long song, render in stretches (see Performance).

## Lab

Open http://localhost:8000/styles/batik/lab/index.html and pick a scene (the meeting on the path, the washing, the
trees on the ridge) and a look; `?scene=washing&style=glass` opens on a pair. The lab builds the demo's set and draws it
from three of the demo's cameras, so a look is always compared on the same picture. To render every pair:

```
python tools/lab_stills.py styles/batik/lab/index.html --all --sheet
```

What each look's renderer does with the same set:

- **Batik** (`batik`): the buffers and the batik shader above. In the lab the meeting and the washing are in the full
  palette, the ridge in two dyes.
- **Two-lamp model box** (`box`): the lit set as it is, through three.js post-processing: GTAO ambient occlusion, a
  bokeh depth of field (the haze cones hidden from its depth, or everything behind them blurs), bloom and a grade.
  The set's curved backdrop and the two lamps' haze make it read as a model on a stage.
- **Gold line on indigo** (`goldline`): the same buffers, but only lines and hatching on indigo paper: silhouettes
  firm and creases lighter, both thinner with distance; lines in gold where the gold lamp lights a thing and silver
  where the blue does; shadows hatched in the other lamp's metal (crosshatched where neither reaches); patterns as fine
  metal; a gold rule and a silver rule round the frame.
- **Shop-window glass** (`glass`): the buffers plus a bokeh canvas behind (`S.glass.bg`, from `bokehCanvas()`), gold
  leaf and frost textures. Gilt is flat crinkled leaf reflecting a room we never see (bright bands that move); etched
  glass is frosted in three steps by the light; stained glass is the thing's colour lit from behind by the bokeh's
  brightness; clear glass shows the lights behind; lines are scratched through. Frost grows in from chosen edges.

## Performance

On an Apple M4 (the tools run headless Chrome with the GPU on):

- **Load**: about 5 s: 49 meshes, 1.4 million vertices, meshed in up to 8 workers; the big tree's crown and the
  cottage are the slowest.
- **Frames**: 60-110 ms to draw a frame (the first frame longer, compiling shaders); in an MP4 render about 85 ms a
  frame including reading the canvas back and encoding. A `--fast` render of the demo takes about 80 s, or 3 minutes
  when other renders share the GPU.
- **Memory**: about 100 MB of JavaScript heap; about 0.6 GB on the GPU, most of it the five buffers at 3840 x 2160
  (three in half-float) and their depth buffers, plus the two lamps' 4096-square shadow maps.
- **What makes it slow**: the buffers' size (`SS = 2` in `makeStyles`; 1 is four times cheaper and the lines get
  coarser), draw calls times five passes (merging static meshes with `mergeStatic` and drawing the shadow maps once
  took a set of thousands of small meshes from 3.3 s a frame to 0.2 s), shadow-map size, and the batik shader's edge
  search.
- **A slice**: `python tools/render_mp4.py styles/batik/index.html --start 15 --end 19 --fast`. Every frame depends
  only on its time, so a slice can be spliced into a full render with `tools/splice.py`.
- **A long song**: build only the sets a stretch needs, and render the song in stretches into one folder of frames,
  which picks up where it stopped if interrupted:
  ```
  python tools/render_frames.py projects/my-song/index.html --dir renders/frames/my-song --end 62 --query sets=street
  python tools/render_frames.py projects/my-song/index.html --dir renders/frames/my-song --start 62 --query sets=yard
  python tools/encode.py renders/frames/my-song --out "renders/My Song.mp4"
  ```
  Loading every set of a long video at once can exhaust the GPU and hang the render after a frame or two. Frames are
  numbered by song time, so the stretches meet exactly and the song goes on once, with no joins.

## Lessons and gotchas

- **Weigh each lamp by its own colour.** At the same intensity blue light has half the luminance of gold, so measured
  by luminance the gold's share of an evenly lit surface sits at about 0.67, just under the 0.7 threshold: whole slopes
  flipped between cream and soga. The shaders divide each light by the luminance of its lamp's colour.
- **Dye edges come from the light, so keep the lamps' own edges out of frame.** A spot's cone edge across the set made
  a soft soga blotch that no batik has. Put the lamps far enough off that both reach everything in view, with little
  penumbra; then the dyes follow what faces which lamp and what shadows what.
- **Material codes must not blend.** Blended where two materials meet, their codes passed through a third (a glow)
  and every such join lit up. `sdf.js` takes the winning operation's code, and the passes carry it as a `flat` varying.
- **Colours near a dye boundary flip dyes.** A bark brown landed on green; a pale skin went rose where it was darker.
  Choose each colour close to the dye you want (the table in `models.js` is checked against the nine), and don't
  darken hollows: the diorama's carved-wood patina changed the dye in every crease, so `mesher.js` turns it off.
- **No noise on the dye thresholds.** A noise meant to make dye edges wander, fixed to the screen, read as static
  wherever a surface's light sat near a threshold. The edges wander with the sampling wobble instead, which moves with
  the cloth.
- **Coplanar surfaces flicker in blocks**, and the edge finder outlines every block. Keep surfaces apart (a few inches
  at the set's scale).
- **Shadow acne** shows as dye speckle; a normal bias of 0.1 ft cures it at this scale.
- **Draw the shadow maps once.** Five passes each redrawing every lamp's shadow map cost more than everything else; the
  gold pass draws them and the blue reuses them.
- **Thousands of small meshes** (flowers, needles, bulbs) cost a draw call each in every pass. Merge the static ones
  (`mergeStatic`), and make any mesh that appears mid-shot at build time, only swapping its geometry, or it has no pass
  materials.
- **Instanced meshes need instancing in the pass shaders** (the grass and leaves here); `mats.js` applies
  `instanceMatrix` and `instanceColor`.
- **Things thinner than a few pixels become all wax line.** Grass blades come out as cream strokes: batik-like, but
  keep them sparse near the camera or they fill the frame.
- **Object-space patterns are sized in the object's units.** A pattern that reads in a close-up vanishes in a wide
  shot; give big things (the ground) bigger patterns.
- **The ambient light counts in both lamps' passes.** With one lamp turned off, faces away from the other still came
  out cream; turn the fill down with the lamp. Likewise a dark backing behind a lit cut-out must take no light at all,
  or both lamps dye it cream.
- **Faces in two dyes take the dye of their lamp, like everything else**, so a face can go soga or indigo; use the
  full palette for close-ups where a face should stay pale.
- **A box's back face mirrors its texture.** A board with shapes cut through it showed the wrong holes from behind;
  build a cut-out from a front face and a back face with the holes lined up.
- **Things held in hands float** unless they're children of the figure at the palm: `handOf()` repeats the model's arm
  maths.
- **A coat blown sideways, seen from the front, read as a kicked leg.** Check a figure's wind from the camera it's
  seen from, and ease it for the front view.
- **The camera's breath needs a start time.** A split screen's panels had none, the drift came out NaN and the panels
  rendered empty.
- **`show()` hides every named part not listed.** Keep pieces that are always there out of `S.P`, or list them in
  every shot.
- **Build only what a stretch needs.** With every set of a long video loaded at once, a render hung after one frame;
  `?sets=` builds only some, and a frame whose set isn't built is skipped at load rather than failing.
- **Nothing may sit still**: a hold longer than a beat or two reads as the player freezing. Keep the camera breathing,
  the lamps swinging and something in the wind.
- **Don't start or end on a blank frame.** The cloth fades in from half-dyed and back toward bare cloth, never all the
  way.
- **Judge colour at full size.** Thin lines and crackle average out in contact-sheet thumbnails.
- **three.js's ambient occlusion isn't repeatable on its own**: `GTAOPass` makes its denoising noise with
  `Math.random()`, so the model box came out a few levels different on every load (which matters when frames are
  rendered in several browsers, or a slice is spliced in). `styles.js` seeds `Math.random` while it builds the pass.
- **Load the page without waiting for `load`**: the tools wait with `wait_until='commit'` and poll `__video.ready`.

