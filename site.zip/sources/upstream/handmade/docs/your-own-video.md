# Making a video for your own song

The hands-on steps, from an mp3 to an MP4. For the creative side (what to decide before building, how to pick a
look) see [workflow.md](workflow.md). If you're working with Claude Code, you can just ask it to make a video for
your song: [CLAUDE.md](../CLAUDE.md) walks it through all of this.

## 1. Set up

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt            # rendering
pip install -r requirements-audio.txt      # timing a song (Whisper, librosa, MIDI)
```

You need Google Chrome installed (or run `python -m playwright install chromium`).

## 2. Start a project folder from a style

Pick a style from the [gallery](../README.md#the-styles) and copy its folder:

```bash
cp -r styles/paper-cut projects/my-song
cp ~/Music/my-song.mp3 projects/my-song/song.mp3
```

Audio files are git-ignored, so your song stays out of the repository.

In `projects/my-song/index.html`, change the lyrics script from the demo's
```html
<script src="../../examples/poem/lyrics_data.js"></script>
```
to your own
```html
<script src="lyrics_data.js"></script>
```
(Relative paths from `projects/my-song/` resolve just as they did from `styles/<style>/`, so anything else the
page loads from the repo keeps working.)

## 3. Time the lyrics

Write the lyric sheet (`projects/my-song/lyrics.txt`, one sung line per line, `#section` markers), then run the
pipeline in [timing.md](timing.md). It ends with `projects/my-song/lyrics_data.js`.

## 4. Look at it

```bash
python tools/serve.py
```

Open `http://localhost:8000/projects/my-song/index.html`. The demo's scenes now play under your lyrics for as long as
the demo lasts. That's the moment to decide the plan: which scene goes where, which line lands on which image.

## 5. Replace the demo's scenes with yours

Every style's README has a "Make your own video in this style" section that says which files are the demo (its
scenes, sets, shots or timeline) and which are the engine. Keep the engine; rewrite the demo files. Work a section
at a time:

```bash
python tools/still.py projects/my-song/index.html 30:60:2 --sheet   # stills every 2 s across 0:30-1:00
```

Look at every still on the sheet. Check the console output printed at the end.

## 6. Render

```bash
python tools/render_mp4.py projects/my-song/index.html --start 30 --end 60 --fast   # a quick 720p preview
python tools/render_mp4.py projects/my-song/index.html --out "renders/My Song.mp4"  # the final, 1080p + 720p
```

To fix one stretch later without re-rendering everything, see
[rendering.md](rendering.md#fixing-one-stretch).

