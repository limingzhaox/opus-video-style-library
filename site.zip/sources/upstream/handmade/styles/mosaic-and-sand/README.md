# Stone mosaic and sand

Two hand-made media drawn from one scene description. **Stone mosaic**: every picture is cut into small stone,
glass and gold tesserae and set in a mortar bed. The pieces are laid the way a mosaicist lays them, in rows that
follow each shape's outline (the rows ripple round a figure like a halo), with plain straight courses for the
background and small cut pieces in the gaps. Each piece is shaded as a little bevelled block that catches one light,
glass and gold glint, the mortar has its own grain and shadow, and light is shown the old way, as warmer stones
and glowing mortar round a lamp or the sun. Lettering is laid as one row of pieces along the centre line of each
letter, as in Roman inscriptions. **Sand on a lightbox**: every picture is sand on lit glass, as in hand-made sand
animation. Thick sand is dark and thin sand lets the lamp through; edges wobble like a hand pushed them; thin sand
breaks into grains; rubbed areas carry palm sweeps; a fingertip clears lines with a small ridge of pushed sand
beside them; coloured light can be laid under the glass. Figures are drawn by pouring sand, or by pushing it away.

![The hillside laid in stone, the wind in the sky as curling courses](img/hero.jpg)

## Looks in this family

- **Stone mosaic** (`mosaic.js`): tesserae laid along outlines in a mortar bed. ![Stone mosaic](img/look-mosaic.jpg)
- **Sand on a lightbox** (`sand.js`): sand thickness as darkness, pushed and cleared by hand, lit from below. ![Sand on a lightbox](img/look-sand.jpg)

The demo uses both: the first stanza is laid in stone, the second pushed about in sand, and at the end the sand is
re-laid as stone. On the way: the title laid a word to a beat, with a warm pulse running out through the mortar
when it is done; two walkers laid again every third frame as they come down the path; leaves cut loose to tremble;
a kite painted flat on a canvas and re-laid as tesserae every third frame, jumping when the gust reaches it; seeds
on the wind that seem to drift because they shine in travelling bands; figures swept clear of the sand with a
fingertip; trees poured into the sand as they bow.

![The leaves hang trembling: each leaf a loose group of tesserae](img/leaves.jpg)
![A kite painted on a canvas and re-laid as tesserae every third frame, seeds drifting in the sky around it](img/kite.jpg)
![The trees bow down their heads, in sand](img/trees.jpg)
![The sand re-laid as mosaic behind a moving line of light](img/relay.jpg)

## Run the demo

```
python tools/serve.py
```

then open http://localhost:8000/styles/mosaic-and-sand/index.html. Space or the button plays and pauses, the slider
moves through the song, and `index.html#t12.5` opens on a still of 12.5 seconds. If the song can't load, it plays on a silent clock.

It plays live, but not smoothly everywhere: mosaic frames draw in about 15-50 ms, sand frames in 100-230 ms (so the
sand half runs at 4-10 frames a second), and a transition draws both pictures. The first frame of each
new set lays its floor (1-3 s); the player does this in the background after it opens, so wait a few seconds before
pressing Play. For a smooth copy, render it:

```
python tools/still.py styles/mosaic-and-sand/index.html 2 6 12.5 0:37.5:2.5 --out renders/mosaic-and-sand --sheet
python tools/render_mp4.py styles/mosaic-and-sand/index.html --fast
```

The whole 37.5 s demo (900 frames) rendered in about 1 minute 50 seconds with `--fast` on an M-series Mac shared
with other work: about 120 ms a frame on average, including building the page, the one-off bakes, reading each frame
back as a JPEG and encoding it. (On a busier day it took 3.5 minutes.)

## How it works

Plain canvas 2D, no libraries; fonts from Google Fonts (EB Garamond for the lyric band, Cinzel for inscriptions).
Scripts load in this order (`index.html`):

| File | Job |
|---|---|
| `../../examples/poem/lyrics_data.js` | `window.SONG`: title, credit, audio, duration, bpm, sections, lines with word times |
| `core.js` | sizes (`W,H` frame, `PW,PH` picture, `SW,SH` set), maths, seeded random (`mulberry32`, `hashi`), value noise (`vn2`, `fbm2`), colour helpers, shapes (`shp`, `spline`, `resample`, `ell`, `blob`, `wave`, `ribbon`), fonts |
| `figures.js` | whole people from a pose: `figure(o)` side view, `sitter(o)` behind a table, `stander(o)` facing us; props (cape and scarf that stream in the wind, lantern, basket, bundle...); `walkPose(ph)` |
| `items.js` | the scene description: item constructors `Fi` `Li` `Gl` `Do` `Tx`, `figItems`, `scaleItems`, `wrapText`; the header lists every hint both renderers read |
| `mosaic.js` | the mosaic renderer: `MPAL` palette, `makeMosaic`, `shadeMosaic`, `mosaicFromRaster` |
| `sand.js` | the sand renderer: `sandDensity`, `sandShade`, `renderSand` |
| `figs.js` | the film's builders: extra colours, `tree` and `pine` that bend and bow, `leaf`, `swirl`, `gustLine`, `walking`, `standing`, and `kitePicture` (a flat painting for a raster actor) |
| `scenes.js` | scenes described once for both looks (`SCENES.hillside`, `SCENES.washday`), plus `cloud`, `smokePuffs`, `windCourse` |
| `engine.js` | the film engine: sets and baking, moving figures and moving pictures (actors), loose pieces, mosaic and sand frames, cameras, transitions, the timeline `step(t)`, the lyric band, timing and pick helpers (`tagsOf`, `driftPick`), the player |
| `sets.js` | the demo's sets (and `windSeeds`, the seeds in the hill's sky) |
| `shots.js` | the demo's shots, and `buildShots()` |

### A scene is a list of items

```js
Fi(points, colour, role, hints)   // a filled shape      {k:'fill', s, col, role, ...}
Li(points, colour, width, role, hints)   // a stroke     {k:'line', pts, col, w, ...}
Do(x, y, r, colour, hints)        // a spot
Gl(x, y, r, colour, alpha, hints) // light
Tx(x, y, text, font, colour, hints)
```

Later items cover earlier ones. `colour` is a name in `MPAL` (mosaic.js, extended in figs.js) or `[r,g,b,material]`
with material 0 stone, 1 glass, 2 gold. Each renderer reads its own hints and ignores the other's:

- mosaic: `ts` piece size in px; `mode:'echo'` (rows follow the outline all the way in) or `'course'` (`echo` outline
  rows, then straight courses at `courseDir`); `mat`; `skel:true` on text for centre-line lettering; `float:1` on a
  dot (one piece set among the pieces of whatever is under it, without cutting a hole there: snow, seeds on the
  wind); `mos:'skip'`.
- sand: `sd` thickness 0-1 (by default from the role and how dark the colour is); `sg`/`sr` linear or radial ramps of
  thickness; on lines `sand:'draw'` (a line of sand) or `'scratch'` (a fingertip line cleared through it); on fills
  `sand:'clear'` (push the sand away inside the shape); `mos:'only'` keeps an item out of the sand.

Anything else rides along. `tag` is the useful one: shots find the pieces an item was laid as by its tag.

### The mosaic renderer

`makeMosaic(items, opt)` returns `M = {w, h, T, owner, regs, RID, opt}`:

1. The items are drawn flat into a colour picture and a region-id map (one id per item).
2. Edges between regions go through an exact distance transform. Marching squares trace iso-lines of distance /
   piece size, and pieces are laid along them, outline row first (`row: 0`), level by level inward. A piece is
   a quad; it is laid only where it overlaps less than 6% of what is already laid, and shrinks to fit if needed.
3. Regions in `'course'` mode get straight staggered courses after their outline rows. Lines and dots get one
   row of pieces along the stroke (laid before the rows, so they keep their place); `skel` text is thinned
   (Zhang-Suen) and laid along the skeleton. A `float` dot never enters the region map: it is laid first, as one
   piece, and the rows of the region under it simply pass round it.
4. Leftover gaps get small cut pieces (`fill: 1`).

Each piece in `M.T` is `{cx, cy, tx, ty, hl, hw, col, mat, reg, q, tilt, sd, row?, line?, fill?, item?}`: centre,
direction, half-length and half-width, colour, material, region, its quad, a random tilt, a seed, and how it was laid.
`M.owner[i]` is the piece covering pixel `i` (or -1 for mortar).

`shadeMosaic(M, ctx, opt)` shades per pixel: mortar with grain and occlusion near pieces; each piece as a bevelled
block lit from the laying's `light` direction, with stone texture, a glass highlight, or gold's hot glint. Options: `groutGlow(x,y)` ->
`[r,g,b,a]` makes the mortar glow; `pieceTint(t,x,y)` multiplies a piece's colour; `pieceColor(t,M)` replaces it
(this is how the film's variants are made); `alphaOf(i)` for transparent cut-outs.

`mosaicFromRaster(rgba, w, h, opt)` lays any picture: colours posterized into regions (`levels`, or `lumOnly` for a
one-colour picture), tidied by a majority filter; regions bigger than `courseArea` px get `courseEcho` outline rows
and straight courses. Blur the picture a little first, or its texture turns into confetti.

### The sand renderer

`sandDensity(items, opt)` returns `{rho, w, h, opt}`: each item paints its thickness into a density field, fingertip
lines and cleared shapes go into a second field, glows into a third. The field is warped a few pixels by noise so
edges wobble, softened, given fine grain and broad palm sweeps (`opt.sweep` is their angle), and rubbed-thin areas
break into drifts of grains. The plate's rim is darkened (`frame`, `frameW`). `sandShade(rho, w, h, opt)` turns
thickness into light: `exp(-k * rho)` of a lamp with a warm hot spot (`lamp`, `lampEdge`), over the colour of lit sand
(`front`), with `opt.under(x,y)` -> `[r,g,b,amount,gain]` laying coloured light under the glass.

### Sets, shots and the timeline

`defSet(name, spec)` registers a set; `bake(name)` builds it the first time it's needed (least recently used sets are
dropped past `MEMCAP`).

- `kind:'mosaic'`: `items()` laid once at 2112 x 1056 (10% bigger than the picture, so the camera can move), shaded
  into each of `variants` (`{name: shadeMosaic options}`), plus the bare bed with no pieces.
- `kind:'sand'`: `items()` baked to a density field; `opt` for `sandDensity`; `under(x,y,u,t)` for light under glass.
- `kind:'custom'`: `bake()` and `frame(g, B, shot, u, t)` draw it themselves (`relaySet` in sets.js is one).

A shot, from `shots.js` (u is time since the shot began, t is song time):

```js
{id:'hill2', t0:L0(3), set:'hill',                         // line 4 starts
 cam:[[0,1180,560,1.08],[2.4,SW/2,SH/2,OW/SW]],             // [u, x, y, zoom]; smoothstep between keys
 pick:(p,u,t,i,B)=>{ ... return {v:'pale'} or {a:0.5} or null; }}   // per piece, per frame: which variant, how laid
```

More shot fields: `tr:{type, dur, dir}` how it comes in from the shot before (`cut`, `dissolve`, `wipe`, `lift`
(mosaic pieces rise off to show the next picture), `settle`, `sweep` (sand pushed into the next picture), `reveal`,
`flash`); `actors` (below); `loose:{match(item), move(group,u,t) -> [dx,dy,rot,variant]}` groups of laid pieces
cut out as sprites that swing over their empty beds; `glow(x,y,u,t)` light in the mortar (called for every mortar
pixel, so return one reused array, as `titleGlow` in shots.js does); `over(g,u,t)` and `post(g,u,t)` draw on top;
`prep(t)` returns a Promise for anything the shot must load before it can be drawn. Sand shots add `dyn(u,t)`
returning `{blow(x,y,o), items, pour(g,u,t), scratch, clear(g,u,t)}`: blow the whole field along a wind (o gets the
displacement), pour moving shapes and grains, fingertip lines, cleared shapes; and `under` and `light` for the lamp.
`pour` can draw any picture (`g.drawImage(canvas, x, y)`): its opaque parts become sand.

The wipe, lift and settle fronts run across the set they are laid in (`tr.w`, `tr.h` override that), and moving
figures come and go with the front, like the pieces round them.

#### Actors: moving figures and moving pictures

`actors:[{id, items(u,t) | raster(u,t), relay, on(u,t), opt}]` are laid again every `relay` frames (3 reads as laid
stop motion; 1 is smooth and three times the cost), in a small crop, and set into the floor: the floor's pieces under
them are lifted out and the bare mortar shows round their edges. `u` and `t` are the time of the relay step, not of
the frame, so a laying is the same whichever frame asks for it first. `opt` goes to the laying (`fig`, `fineFace`,
`seed`, ...); the set's `mortar` and `light` are used unless it says otherwise.

- `items(u,t)` returns scene items (a figure from `figItems`, a leaf, anything), laid with `makeMosaic`.
- `raster(u,t)` returns `{img, x, y}`: any canvas or image drawn at set scale, and where its top left sits in the set.
  Its opaque part (alpha over `opt.alphaCut`, default 190) is cropped and laid with `mosaicFromRaster`, keeping its
  own colours, posterized into `opt.levels` (default 5) steps a channel. The picture can come from anywhere: a flat
  painting in code (`kitePicture` in figs.js, the demo's kite), a frame of another style's video drawn to a canvas,
  a photograph. Paint it in flat colours with strokes at least as wide as a piece and a half: thinner lines break
  up into crumbs.

```js
actors:[{id:'kite', relay:3, raster:kiteRaster, opt:{fig:5, levels:5, seed:5}}]
// kiteRaster(u,t) -> kitePicture(x, y, tilt, lineEnd, tailPhase, tailWave, size) -> {img, x, y}
```

To relay frames of another video (rendered to PNGs), load them in the shot's `prep(t)` (`await` an `Image`'s load)
and draw the one for `t` in `raster`: `step()` waits for `prep` before it draws.

#### Picks

`pick(p,u,t,i,B)` runs for every piece in every frame, so keep it cheap: `tagsOf(B)[i]` is piece i's tag, looked up
once per baked set. `driftPick(p,i,B,t,tag,{dx,dy,speed,band,low})` makes the pieces of one tag shine in bands that
travel along (dx, dy), which reads as movement: `float` dots become falling snow (`dy:1`) or, in the demo, seeds
blown downwind and up (`{dx:1, dy:-.35, speed:1.3}`).

`step(t)` finds the shot, waits for its `prep` (and the previous shot's, during a transition), draws it (and the one
before, during a transition) into the 1920 x 960 picture, then the lyric band. It returns a Promise; the render
tools wait for it, and the player draws one frame at a time. `renderAt(t)` is the same (nothing depends on the frame
before). The page sets `window.__video = {ready, duration, step, renderAt}`.

### Lyrics

`engine.js` turns `SONG.lines` into `[section, text, t0, t1]` and shows one line at a time in the band under the
picture, in italic EB Garamond, fading in 0.15 s before the line and out 0.3 s after. During the intro the band shows
`SONG.title` in Cinzel capitals and `SONG.credit` under it. The band's colours follow the medium (`BANDCOL`), blending
through a transition. The title set lays `SONG.title` itself as a mosaic inscription, one word to a beat.

### Determinism and caching

All randomness is seeded (`mulberry32`, `hashi`, fixed noise tables); nothing calls `Math.random()`. Moving figures
and pictures are laid again every `relay` frames, keyed by the step number and drawn at the step's own time, so any
frame can be drawn in any order and comes out the same. Caches (`BAKED` sets, `ACT` actor layings, per-set tags,
loose-piece sprites, reused buffers) only save time.

## Make your own video in this style

1. Copy the folder: `cp -r styles/mosaic-and-sand projects/my-song`, and put your mp3 in it (see
   [docs/your-own-video.md](../../docs/your-own-video.md)).
2. Make your song's timing file with `tools/audio/to_js.py` and point `index.html` at it instead of
   `../../examples/poem/lyrics_data.js`. `SONG.audio` should be the path to your mp3 relative to `index.html`.
3. Keep `core.js`, `figures.js`, `items.js`, `mosaic.js`, `sand.js`, `figs.js` and `engine.js`. Replace `scenes.js`,
   `sets.js` and `shots.js` with your own (the title set reads `SONG.title` and `SONG.credit`, so it works as is).
4. Add a set. Coordinates are set space, 2112 x 1056:

   ```js
   defSet('field',{opt:{fig:7,fineFace:5,bg:13,seed:3},variants:{lit:{},pale:{pieceColor:(t,M)=>mix3(t.col,[230,230,200],.5)}},
     items:()=>[Fi(rect(0,0,SW,SH),'sky','bg',{ts:13,mode:'course',echo:2}),
                Fi(wave(-10,SW+10,700,30,.003,2).concat([[SW+10,SH+10],[-10,SH+10]]),'grass','bg',{ts:12,mode:'course',echo:1,tag:'grass'}),
                ...tree(900,720,480,{bend:.2,seed:1})]});
   defSet('fieldSand',{kind:'sand',opt:{sweep:.2},items:()=>[ /* the same items, with sd hints */ ]});
   ```

   Or describe it once in `scenes.js` with both kinds of hints and use it for both (as `SCENES.hillside` is).
5. Add shots in `buildShots()`, one per picture, in time order. Put changes on line starts (`L0(i)`, the start of line
   i) and hits on beats (`beatT(n)`, or `wordT(line, word)` for the time a word is sung).
6. Time a move to a word or beat inside a shot with `sstep(a, b, t)`, e.g. `sstep(wordT(6,4)-.2, wordT(6,4)+.2, t)`
   eases a tree's bow in over 0.4 s round the word "bow". `arrive(p, t, at, sweep, fade)` (shots.js) lays pieces in
   from left to right; `beatPulse(t)` jumps to 1 on every beat and decays.
7. Make something move: a figure or a prop as an `items` actor, a picture as a `raster` actor (paint it on a canvas
   the way `kitePicture` does), a group of laid pieces as `loose`, or a whole set's pieces through `pick` (variants,
   strength, `driftPick`). In sand, pour it each frame from `dyn`.
8. Run `node --check` on every file you changed, then check stills with `tools/still.py` (read the console errors it
   prints), then render.

Useful knobs:

- mosaic `opt`: `fig` (piece size for figures), `fineFace` (faces and hair), `bg` (backgrounds), `gap` (mortar
  width as a fraction of a piece), `echo` (outline rows before courses), `light` (direction), `mortar` (colour), `seed`.
- per item: `ts`, `mode`, `echo`, `courseDir`, `mat`, `outline`.
- shading (a set's `variants`): `groutGlow`, `pieceTint`, `pieceColor` (variants for flipping pieces).
- sand `opt`: `k` (how dark thick sand is), `lamp`, `lampEdge`, `front`, `frame`/`frameW` (the rim), `grainK`,
  `sweep`, `soft` (edge softness), `under`.
- per item: `sd`, `sg`, `sr`, `sand`, and `float` on dots.
- actors: `relay` (3 = laid again every third frame: it reads as laid stop motion; 1 is smooth and three times the
  cost); for a raster actor `opt.alphaCut`, `opt.levels` (colour steps a channel) and `opt.fig` (piece size).
- `driftPick`: `dx`, `dy` (the direction the bands travel), `speed` (bands a second), `band` (their spacing in px),
  `duty` (how much of each band shines), `low` (how much of a piece shows between bands).

### Re-laying another picture ("relay")

`relaySet(fromShot, atT, opt)` in sets.js makes a custom set from any shot's picture at a moment: it renders the
shot, blurs it a little, lays it with `mosaicFromRaster`, and shades it twice (mortar glowing where the picture was
bright, low and high) to breathe between. The `reveal` transition then brings it in behind a moving line of light. The
same works for a picture from anywhere: another style's frames, a painting, a photograph drawn to a canvas. (If the
shot it renders has a `prep`, give the relay shot a `prep` that waits for it, since the relay is laid the first time
it is drawn.) A moving picture is a raster actor: it is cropped to its opaque part, laid every few frames and set
into the floor with the floor's pieces under it lifted out. To turn a picture into sand instead, pour it:
`g.drawImage(picture, x, y)` in `dyn().pour` makes its opaque parts sand (`rho = max(rho, blurred alpha)`).

## Lab

Open http://localhost:8000/styles/mosaic-and-sand/lab/index.html and pick a scene and a look (or
`lab/index.html?s=washday&st=sand`). Render them all:

```
python tools/lab_stills.py styles/mosaic-and-sand/lab/index.html --all --out renders/lab --sheet
```

The lab draws `SCENES.hillside` (with two walkers) and `SCENES.washday` (washing on a line, a weathervane) from
`scenes.js`, scaled from set space to the 1920 x 960 picture, in both looks, with a line of the poem in the band.
Each takes under a second. What each renderer does with the same items:

- **Stone mosaic** keeps every colour, lays figures fine (`fig`, `fineFace`) and backgrounds coarse (`bg`), rings
  small shapes with rows, and turns glows into warmer stones and glowing mortar.
- **Sand on a lightbox** keeps only thickness: colour becomes how dark a shape is, glows clear the sand, fingertip
  lines and cleared shapes push it aside, and anything too close in thickness to its neighbour disappears (so put
  figures on light, or clear them out of dark).

## Performance

Measured on an M-series Mac in headless Chrome with the GPU on.

- Baking a set: a mosaic set at 2112 x 1056 takes 1-2 s (20,000-27,000 pieces, plus one shade per variant); a sand
  set about 0.4 s; the relay about 3 s. Two moving figures laid again every third frame add about 10-30 ms a frame;
  the kite, a raster actor, takes about 35 ms to lay, so about 12 ms a frame (the shot with it averaged 36 ms).
- A frame (these vary by 2x with what else the machine is doing): mosaic 15-50 ms with `pick` (the per-pixel pass);
  sand 100-230 ms (the wind warp, pouring, and shading 2.2 million pixels); transitions draw both shots, 230-470 ms
  (the sand sweep is the slowest: two sand frames).
- Memory: about 260 MB of baked sets by the engine's own count (`MEM`), about 310 MB of JavaScript heap with every
  set baked. `MEMCAP` (900 MB) drops the least recently used set past that.
- What makes it slow: sand (every pixel is shaded every frame), big sets, many variants, actors with `relay:1`.
- Render a slice: `python tools/render_mp4.py styles/mosaic-and-sand/index.html --fast --start 18 --end 27`. A slice
  is exact, because no frame depends on the one before.

## Lessons and gotchas

- **Lines laid first cut across what stands in front of them.** Drawn lines (wall joints, scaffolding, a clothesline) are
  regions in the id map, and their pieces are laid only where the line is still visible after later items.
- **Smiling faces read as cute.** Faces have a flat, short mouth and a longer face.
- **Check seated poses against the chair**: thighs forward, the floor at the feet, not at the seat.
- **A solid glow shape reads as an egg yolk.** In mosaic, light is warmed stones and glowing mortar (and gold
  pieces); a solid body of light suits the sand, where it is thinner sand for the lamp to come through.
- **Lettering laid by contour is too thin to read**, and a background's outline rows make a cartouche round every
  line. Lay letters along their centre line (`skel:true`) in bold capitals, and give the panel `echo:0`.
- **Unlaid pieces show bare mortar**, so letters and shapes not yet laid show faintly in the bed, like the design a
  mosaicist draws on the setting bed. Keep it; it makes the laying readable.
- **Big regions in `'echo'` mode fill with concentric "eyes"** where the rows close up. Use `'course'` with one to four
  outline rows for skies and fields; keep `'echo'` for figures and small shapes.
- **Grain everywhere made the first sand look like a filter**, and ruler-straight edges looked drawn by machine. The
  warp, fine grain and sparse drifts fixed it; palm sweeps turned up too high look like wood grain.
- **Don't marble the sand.** Warping the whole field with a displacement that changes quickly across the picture
  turns sand into marbled paper and mangles the drawing. Keep the warp small and smooth, and show wind with grains,
  wisps and shapes that bend.
- **Grains as uniform dashes look like Morse code**; vary their size, length and opacity. Wisps as lines read as
  cartoon speed lines; trails of scattered grains read as sand.
- **Dark figures on dark sand vanish.** Clear them out (`sand:'clear'`), which is also how sand is really drawn. A
  figure poured in front of something as thick (trees behind a walker) vanishes too: keep what stands behind a
  moving figure thinner and paler, or smaller.
- **A cleared line or doorway looked flat and digital**: sand pushed perfectly clear looks cut by a machine. Clearings
  keep a ridge of pushed sand at their edge, a few grains left behind and a faint film over their floor (the engine
  does this for every `scratch` and `clear`); give a cleared shape a wobbling edge (jitter its outline with `vn2`) and
  warm light under it.
- **Light under the glass doesn't come through thick sand.** A glow laid under dark ground barely shows; thin the
  sand where the light should come through (an `sr` ramp that is thin in the middle), then turn the light up.
- **Short straight fingertip marks read as rain**; small arcs read as leaves.
- **Long strokes read as tubes** (smoke especially). Overlapping puffs read as vapour.
- **Posterizing a one-colour picture by colour** splits its gradients into mottled patches. Blur it, and posterize by
  brightness (`lumOnly`).
- **`echo:0` was ignored** because `0 || 3` is 3; use `x != null ? x : default` for numeric options.
- **Pieces laid from text or rasters need their own direction and item**: a missing `dir` made `Math.cos(undefined)`
  NaN and silently dropped every course piece; centre-line letters with no `item` couldn't be found by tag.
- **Dots over a region cut holes in it**, and the region's rows ring each hole like a bubble (snow over a wall looked
  like foam). Mark them `float:1`: they are laid as single pieces among the region's own.
- **Moving figures stayed solid during a lift**, floating over the sand while the pieces round them flew off. They
  now come and go with the transition's front.
- **Lay an actor at its relay step's time, not the frame's**: laid from the time of whichever frame asked first, a
  still and a render could lay the same step differently.
- **A picture relayed as tesserae needs flat colours and thick strokes.** It is posterized into regions and laid with
  pieces of `fig` px; a line thinner than a piece and a half breaks into crumbs, and soft shading turns to confetti.
  Keep the picture small (the laying is cropped to its opaque part, and its cost grows with the crop): the demo's
  kite with its line and tail takes about 35 ms to lay, so re-laid every third frame it adds about 12 ms a frame.
- **A kite's tail that runs down from it reads as a second line.** Stream it downwind, nearly level, short, with bows.
- **`walking()` let its options overwrite the walk pose**, so a walker given an arm pose stopped walking. Options are
  merged into the pose now; keep that pattern (`const {pose, ...rest} = o`) in your own builders.
- **`wave()` drawn right to left returned nothing**, so a band made from two wavy edges (the second one reversed) came
  out as a thin line. It now works in either direction.
- **`-x**2` is a syntax error in JavaScript** (a minus directly before `**`), and one error silently stops the whole
  file, so every set in it vanishes. Write `-(x**2)`, and run `node --check` on each file before taking stills.
- **In a close-up, draw what a small figure gets away without**: a face in profile needs its chin clear of the neck,
  and a hand that hangs needs its fingers, or they read as lumps.
- **Hold the plate's rim still** when blowing sand (`edgeHold` in shots.js), or the dark rim smears inward.
- **Nothing should sit still for more than a beat or two**: a second of stillness reads as the player freezing. When
  an effect passes, let a weaker one trail it.
- **Keep the camera inside the set**: views are clamped, and a zoom below `OW/SW` would show past the edge.
- **A `*/` inside a comment** (a path like `frames/*/`) ends the comment early and silently breaks the page.
- **Read the console after every still**: one bad value in a canvas gradient blanks the whole frame.
- **Per-pixel callbacks must not allocate**: `glow`, `under` and `blow` run for up to two million pixels a frame.
  Return one reused array (`GB`, `UB` in shots.js), and look tags up once (`tagsOf`) rather than per piece per frame.

