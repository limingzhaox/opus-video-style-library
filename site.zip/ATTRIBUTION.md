# 来源、署名与再发布

本资料库整理 117 个条目（Lemo 99 项、手作 MV 18 项）。这是免费、非商业的资料索引。中文模板、摘要、注意事项、翻译与编排为本库整理，作者原文完整保留；不是原作者逐字对话。图片有缩放、JPEG 压缩与拼版。本库不另行分发示例影片或原音轨。

## Lemo-Opuscar by Lemomo (LemoLab)

来源：[原仓库](https://github.com/lemomo-ai/lemo-opuscar)，固定提交 `8ca0dd805e214bcc1d30714cd5b9d21cc02a454b`。自 2026-11-23 起版权主体为 SecondFirst Pty Ltd（trading as LemoLab，ACN 701 727 237），创作者 Lemomo。完整条款以 [固定 LICENSE](https://github.com/lemomo-ai/lemo-opuscar/blob/8ca0dd805e214bcc1d30714cd5b9d21cc02a454b/LICENSE)、[本地 LICENSE](sources/upstream/lemo/LICENSE)、[REUSE.toml](sources/upstream/lemo/REUSE.toml) 和 [协议全文目录](https://github.com/lemomo-ai/lemo-opuscar/blob/8ca0dd805e214bcc1d30714cd5b9d21cc02a454b/LICENSES) 为准。

- **文档及改编文档**：全部 Markdown（STYLE.md、DIRECTOR.md、TECHNIQUE.md 等）与生图提示词为 [CC BY-NC 4.0](https://creativecommons.org/licenses/by-nc/4.0/)。可署名非商业转载、改编；保留项目名、作者、仓库及许可链接，并说明改动。本库含这些文档及中文改编，不能把整个资料库称作 MIT 可商用。
- **自己的影片有额外许可**：上游允许你、员工、外包、客户为自己的影片（包括商用及客户影片）读取、照做、复制、改编文档，并随该片项目文件交付。该许可为全球、免版税、非独占、不可撤销；不包括在上述人员与交付之外共享或出售文档。其他商业产品、服务或文档再发行，不论收费与否，需另获商用授权，联系 lemomo.studio@gmail.com。自己制作的影片归自己，无须为库署名，影片中第三方资产仍须遵守各自条件。
- **代码**：MIT，仅适用于 LICENSE 指定代码范围，不能延伸到文档或第三方资产。本库只归档上游文本，没有完整执行引擎。
- **作者示例画面**：仅有权授权的部分为 [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/)，须署名 “Lemo-Opuscar by Lemomo (LemoLab)”、链接原仓库和许可并说明改动。图片、影像、地图、字体、采样、角色、界面等第三方权利仍归原来源。逐项文件级许可与权利人列于下表，完整资产清单见相应 CREDITS。CC0 / 公共领域也按原清单保留来源。
- **贡献者**：孟菲斯微缩景观须同时署名 “Memphis Diorama by EianLu, in Lemo-Opuscar by Lemomo (LemoLab)”（[EianLu](https://x.com/EianLu)）；蜡笔立体世界须同时署名 “Crayon World 3D by 2nd1st, in Lemo-Opuscar by Lemomo (LemoLab)”（[2nd1st](https://github.com/2nd1st)）。上游说明贡献者已书面同意相同条款。
- **六项旁白例外**：chalkboard、circuit-board、desktop-flythrough、isometric-picture-book、printed-long-take 的 Microsoft Edge TTS 与 news-package 的 Doubao TTS 不在 CC BY 4.0 内。抽取、改编及带这些声音的整片复用，均须按服务条款或另获许可；自己影片重新生成有权使用的声音。历史副本按其固定提交核对，不能用新版条款反推旧音轨已获授权。
- **Clawd / 第三方界面**：Clawd 的设计与名称归 Anthropic，第三方产品界面、名称、logo 也未获本项目授权，整片、海报和静帧均同样受限。吉祥物录屏的本地图片改为本库文字查看入口，不复制该样帧；保留作者原图、视频和说明链接供自行查看。制作时使用原创或已获授权角色与界面。
- **IBTrACS / CMA 数据**：流场风线的部分图像含 CMA 最佳路径记录，经 NOAA IBTrACS v04r01 分发，Lemomo 不为这些记录授予许可。适用原数据条款（含其商业使用条件）并按 [LicenseRef-IBTrACS](sources/upstream/lemo/LICENSES/LicenseRef-IBTrACS.txt) 引用。该项本地改为文字查看入口；作者案例仍可从链接查看。
- **旧版许可**：上游说明 2.0.0 之前已经发布的版本和 fork 保持原许可，已授出的 CC/MIT 权利不撤回。本次包使用上述固定新版；不得把旧版许可套到新版文档。

## Lemo 案例图逐项署名

下表对应 styles/<slug>/poster.jpg。本库收齐 99 份 demo/CREDITS，并保存全部对应许可证文本；若自行复用，仍须核对原始素材页、用途和版本。含 LicenseRef 的两项不打包作者图，localImage 为明确标注“非风格样帧”的本库查看入口。

|风格|文件级许可|权利人 / 来源署名|完整资产清单|本库图片|
|---|---|---|---|---|
|字幕新闻 / caption-news|CC-BY-4.0 AND CC-BY-3.0 AND CC-BY-2.0 AND LicenseRef-PublicDomain|2026 Lemomo (LemoLab)；Altena TV (A-TV)；Phonon.b；Martin J. Calabrese；Midsummer Bees；vastateparksstaff (Virginia State Parks)|[CREDITS](sources/upstream/lemo/styles/caption-news/demo/CREDITS)|作者画面经缩放压缩|
|1920s 新闻影片 / newsreel|CC-BY-4.0 AND LicenseRef-PublicDomain|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/newsreel/demo/CREDITS)|作者画面经缩放压缩|
|实时倒计时分屏 / countdown|CC-BY-4.0 AND LicenseRef-PublicDomain|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/countdown/demo/CREDITS)|作者画面经缩放压缩|
|城市交响曲 / city-symphony|CC-BY-4.0 AND CC-BY-3.0 AND CC-BY-2.0 AND LicenseRef-PublicDomain|2026 Lemomo (LemoLab)；Scott Herder；David Schwab；Longfellow Films；Joe Cavallini；350.org；Branded Cities；Steven Kelley；Jason Eppink；Sunny Ripert|[CREDITS](sources/upstream/lemo/styles/city-symphony/demo/CREDITS)|作者画面经缩放压缩|
|视觉调查 / visual-investigation|CC-BY-4.0 AND LicenseRef-PublicDomain|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/visual-investigation/demo/CREDITS)|作者画面经缩放压缩|
|构成主义蒙太奇 / kino-montage|CC-BY-4.0 AND LicenseRef-PublicDomain AND CC0-1.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/kino-montage/demo/CREDITS)|作者画面经缩放压缩|
|体育战术板 / telestrator|CC-BY-4.0 AND CC-BY-3.0 AND CC-BY-2.0 AND CC0-1.0|2026 Lemomo (LemoLab)；beIN SPORTS Türkiye；Thomas Rodenbücher|[CREDITS](sources/upstream/lemo/styles/telestrator/demo/CREDITS)|作者画面经缩放压缩|
|电视新闻包装 / news-package|CC-BY-4.0 AND LicenseRef-PublicDomain|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/news-package/demo/CREDITS)|作者画面经缩放压缩|
|卫星简报 / satellite-briefing|CC-BY-4.0 AND LicenseRef-PublicDomain|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/satellite-briefing/demo/CREDITS)|作者画面经缩放压缩|
|工程简报板 / briefing-board|CC-BY-4.0 AND CC-BY-2.0 AND CC0-1.0 AND LicenseRef-PublicDomain|2026 Lemomo (LemoLab)；BAW – Bundesanstalt für Wasserbau；Russ ("Bear mountain bridge west II")|[CREDITS](sources/upstream/lemo/styles/briefing-board/demo/CREDITS)|作者画面经缩放压缩|
|点云测绘 / lidar-survey|CC-BY-4.0 AND LicenseRef-PublicDomain|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/lidar-survey/demo/CREDITS)|作者画面经缩放压缩|
|白模投影 / white-model|CC-BY-4.0 AND CC0-1.0|2026 Lemomo (LemoLab)；3DGI and the 3D geoinformation research group, TU Delft (3DBAG)|[CREDITS](sources/upstream/lemo/styles/white-model/demo/CREDITS)|作者画面经缩放压缩|
|数据实物化 / data-physical|CC-BY-4.0 AND CC0-1.0|2026 Lemomo (LemoLab)；IRENA (2026), processed by Our World in Data|[CREDITS](sources/upstream/lemo/styles/data-physical/demo/CREDITS)|作者画面经缩放压缩|
|产品拆解 / teardown|CC-BY-4.0|2026 Lemomo (LemoLab)；foostan (Corne keyboard, github.com/foostan/crkbd)|[CREDITS](sources/upstream/lemo/styles/teardown/demo/CREDITS)|作者画面经缩放压缩|
|显微镜下 / microscope|CC-BY-4.0 AND CC0-1.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/microscope/demo/CREDITS)|作者画面经缩放压缩|
|档案看片台 / archive-lighttable|CC-BY-4.0 AND LicenseRef-PublicDomain|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/archive-lighttable/demo/CREDITS)|作者画面经缩放压缩|
|蜡笔儿童绘本 / crayon-book|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/crayon-book/demo/CREDITS)|作者画面经缩放压缩|
|水彩笔刷 / watercolor|CC-BY-4.0 AND LicenseRef-PublicDomain|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/watercolor/demo/CREDITS)|作者画面经缩放压缩|
|中国水墨 / ink-wash|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/ink-wash/demo/CREDITS)|作者画面经缩放压缩|
|油画厚涂 / impasto|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/impasto/demo/CREDITS)|作者画面经缩放压缩|
|一笔画 / one-line|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/one-line/demo/CREDITS)|作者画面经缩放压缩|
|白板讲解 / whiteboard|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/whiteboard/demo/CREDITS)|作者画面经缩放压缩|
|钢笔淡彩 / urban-sketch|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/urban-sketch/demo/CREDITS)|作者画面经缩放压缩|
|皮影戏 / shadow-puppet|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/shadow-puppet/demo/CREDITS)|作者画面经缩放压缩|
|浮世绘 / ukiyoe|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/ukiyoe/demo/CREDITS)|作者画面经缩放压缩|
|红色窗花剪纸 / papercut-red|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/papercut-red/demo/CREDITS)|作者画面经缩放压缩|
|纸雕灯影 / paper-lantern|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/paper-lantern/demo/CREDITS)|作者画面经缩放压缩|
|孔版印刷 / risograph|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/risograph/demo/CREDITS)|作者画面经缩放压缩|
|网点档案 / halftone-dossier|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/halftone-dossier/demo/CREDITS)|作者画面经缩放压缩|
|木刻版画 / woodcut|CC-BY-4.0 AND CC0-1.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/woodcut/demo/CREDITS)|作者画面经缩放压缩|
|铜版画 / engraving|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/engraving/demo/CREDITS)|作者画面经缩放压缩|
|丝印旅行海报 / silkscreen-poster|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/silkscreen-poster/demo/CREDITS)|作者画面经缩放压缩|
|瑞士动态排版 / swiss-motion|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/swiss-motion/demo/CREDITS)|作者画面经缩放压缩|
|60s 间谍片头 / spy-titles|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/spy-titles/demo/CREDITS)|作者画面经缩放压缩|
|装饰艺术 / art-deco|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/art-deco/demo/CREDITS)|作者画面经缩放压缩|
|工程蓝图 / blueprint|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/blueprint/demo/CREDITS)|作者画面经缩放压缩|
|彩色玻璃窗 / stained-glass|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/stained-glass/demo/CREDITS)|作者画面经缩放压缩|
|象形运动图形 / pictogram-motion|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/pictogram-motion/demo/CREDITS)|作者画面经缩放压缩|
|CRT 字符终端 / ascii-crt|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/ascii-crt/demo/CREDITS)|作者画面经缩放压缩|
|数据叙事 / dataviz|CC-BY-4.0 AND LicenseRef-PublicDomain|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/dataviz/demo/CREDITS)|作者画面经缩放压缩|
|等距信息图 / iso-infographic|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/iso-infographic/demo/CREDITS)|作者画面经缩放压缩|
|暗色科技发布 / dark-keynote|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/dark-keynote/demo/CREDITS)|作者画面经缩放压缩|
|像素小人录屏 / living-screencast|CC-BY-4.0 AND LicenseRef-Clawd AND LicenseRef-ThirdPartyMarks|2026 Lemomo (LemoLab)；Anthropic (Clawd; the Claude app interface, Claude and Claude Code)|[CREDITS](sources/upstream/lemo/styles/living-screencast/demo/CREDITS)|查看入口，非样帧|
|科幻全息界面 / hologram-hud|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/hologram-hud/demo/CREDITS)|作者画面经缩放压缩|
|1930s 橡皮管卡通 / rubber-hose|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/rubber-hose/demo/CREDITS)|作者画面经缩放压缩|
|80 年代赛璐璐动画 / cel-anime-80s|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/cel-anime-80s/demo/CREDITS)|作者画面经缩放压缩|
|科幻情景喜剧卡通 / scifi-toon|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/scifi-toon/demo/CREDITS)|作者画面经缩放压缩|
|50s 扁平卡通 / midcentury-toon|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/midcentury-toon/demo/CREDITS)|作者画面经缩放压缩|
|16-bit 像素 RPG / pixel-rpg|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/pixel-rpg/demo/CREDITS)|作者画面经缩放压缩|
|2.5D 像素 / hd-2d|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/hd-2d/demo/CREDITS)|作者画面经缩放压缩|
|微游戏快闪 / microgame|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/microgame/demo/CREDITS)|作者画面经缩放压缩|
|节奏综艺 / game-show|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/game-show/demo/CREDITS)|作者画面经缩放压缩|
|1920s 默片 / silent-film|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/silent-film/demo/CREDITS)|作者画面经缩放压缩|
|后室录像带 / backrooms|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/backrooms/demo/CREDITS)|作者画面经缩放压缩|
|积木玩具 / brick-toy|CC-BY-4.0 AND CC0-1.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/brick-toy/demo/CREDITS)|作者画面经缩放压缩|
|纸片立体书 / paper-popup|CC-BY-4.0 AND CC0-1.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/paper-popup/demo/CREDITS)|作者画面经缩放压缩|
|移轴微缩 / tilt-shift|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/tilt-shift/demo/CREDITS)|作者画面经缩放压缩|
|低多边形等距 / lowpoly-island|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/lowpoly-island/demo/CREDITS)|作者画面经缩放压缩|
|玻璃质感产品 / glass-product|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/glass-product/demo/CREDITS)|作者画面经缩放压缩|
|黑板粉笔 / chalkboard|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/chalkboard/demo/CREDITS)|作者画面经缩放压缩|
|刮版画长镜头 / printed-long-take|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/printed-long-take/demo/CREDITS)|作者画面经缩放压缩|
|地铁线路图 / transit-map|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/transit-map/demo/CREDITS)|作者画面经缩放压缩|
|等距小人场景 / isometric-picture-book|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/isometric-picture-book/demo/CREDITS)|作者画面经缩放压缩|
|电路板 / circuit-board|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/circuit-board/demo/CREDITS)|作者画面经缩放压缩|
|孟菲斯微缩景观 / memphis-diorama|CC-BY-4.0|2026 EianLu；2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/memphis-diorama/demo/CREDITS)|作者画面经缩放压缩|
|桌面卡片穿梭 / desktop-flythrough|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/desktop-flythrough/demo/CREDITS)|作者画面经缩放压缩|
|彩铅科普插画 / colored-pencil|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/colored-pencil/demo/CREDITS)|作者画面经缩放压缩|
|视觉笔记 / sketchnote|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/sketchnote/demo/CREDITS)|作者画面经缩放压缩|
|火柴人讲解 / stick-explainer|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/stick-explainer/demo/CREDITS)|作者画面经缩放压缩|
|平板速写讲解 / ipad-sketch|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/ipad-sketch/demo/CREDITS)|作者画面经缩放压缩|
|马克笔白纸速写 / marker-paper|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/marker-paper/demo/CREDITS)|作者画面经缩放压缩|
|金箔彩绘 / gilded-illumination|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/gilded-illumination/demo/CREDITS)|作者画面经缩放压缩|
|波普艺术 / pop-art|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/pop-art/demo/CREDITS)|作者画面经缩放压缩|
|复古版画拼贴 / vintage-collage|CC-BY-4.0 AND LicenseRef-PublicDomain|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/vintage-collage/demo/CREDITS)|作者画面经缩放压缩|
|包豪斯几何 / bauhaus-shapes|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/bauhaus-shapes/demo/CREDITS)|作者画面经缩放压缩|
|扁平尺度漫游 / flat-space-explainer|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/flat-space-explainer/demo/CREDITS)|作者画面经缩放压缩|
|文字闪切 / text-flash-cuts|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/text-flash-cuts/demo/CREDITS)|作者画面经缩放压缩|
|剪影律动 / silhouette-rhythm|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/silhouette-rhythm/demo/CREDITS)|作者画面经缩放压缩|
|线稿剖面图解 / hardcore-info|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/hardcore-info/demo/CREDITS)|作者画面经缩放压缩|
|分色机械图解 / precise-mechanism|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/precise-mechanism/demo/CREDITS)|作者画面经缩放压缩|
|说明书插画 / instruction-manual|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/instruction-manual/demo/CREDITS)|作者画面经缩放压缩|
|笔式绘图仪 / pen-plotter|CC-BY-4.0 AND CC0-1.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/pen-plotter/demo/CREDITS)|作者画面经缩放压缩|
|流水线图解 / assembly-line-diagram|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/assembly-line-diagram/demo/CREDITS)|作者画面经缩放压缩|
|搞笑历史卡通 / comic-history|CC-BY-4.0 AND LicenseRef-PublicDomain|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/comic-history/demo/CREDITS)|作者画面经缩放压缩|
|黑白漫画分格 / manga-panels|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/manga-panels/demo/CREDITS)|作者画面经缩放压缩|
|胶片直刻 / scratch-film|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/scratch-film/demo/CREDITS)|作者画面经缩放压缩|
|双重曝光 / double-exposure|CC-BY-4.0 AND LicenseRef-PublicDomain AND CC0-1.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/double-exposure/demo/CREDITS)|作者画面经缩放压缩|
|表格动画 / spreadsheet|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/spreadsheet/demo/CREDITS)|作者画面经缩放压缩|
|1-bit 点阵 / one-bit-dither|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/one-bit-dither/demo/CREDITS)|作者画面经缩放压缩|
|萤火光点 / firefly-pointillism|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/firefly-pointillism/demo/CREDITS)|作者画面经缩放压缩|
|流场风线 / flow-field|CC-BY-4.0 AND LicenseRef-IBTrACS AND LicenseRef-PublicDomain AND CC0-1.0|2026 Lemomo (LemoLab)；China Meteorological Administration (best track), distributed by NOAA NCEI in IBTrACS v04r01|[CREDITS](sources/upstream/lemo/styles/flow-field/demo/CREDITS)|查看入口，非样帧|
|示波器数学 / oscilloscope-math|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/oscilloscope-math/demo/CREDITS)|作者画面经缩放压缩|
|霓虹灯管 / neon-tubes|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/neon-tubes/demo/CREDITS)|作者画面经缩放压缩|
|蜡笔立体世界 / crayon-world|CC-BY-4.0|2026 2nd1st；2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/crayon-world/demo/CREDITS)|作者画面经缩放压缩|
|安检 X 光 / security-xray|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/security-xray/demo/CREDITS)|作者画面经缩放压缩|
|雷达扫描纪录片 / dark-documentary|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/dark-documentary/demo/CREDITS)|作者画面经缩放压缩|
|热成像 / thermal-camera|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/thermal-camera/demo/CREDITS)|作者画面经缩放压缩|
|立体地图解说 / map-explainer|CC-BY-4.0 AND LicenseRef-PublicDomain|2026 Lemomo (LemoLab)；EOX IT Services GmbH (Sentinel-2 cloudless 2016, https://s2maps.eu)；Contains modified Copernicus Sentinel data (2016, 2017)；OpenStreetMap contributors (shipping lanes)；Mapzen / Tilezen terrain tiles (AWS Open Data)|[CREDITS](sources/upstream/lemo/styles/map-explainer/demo/CREDITS)|作者画面经缩放压缩|
|小人模拟实验 / pip-simulation|CC-BY-4.0|2026 Lemomo (LemoLab)|[CREDITS](sources/upstream/lemo/styles/pip-simulation/demo/CREDITS)|作者画面经缩放压缩|

## Miranda Dixon-Luinenburg

来源：https://github.com/cyborggirl963/opus-5.5-music-video-art-styles 。仓库根 LICENSE 为 MIT，Copyright (c) 2026 Miranda Dixon-Luinenburg。保留 [原 LICENSE](sources/upstream/handmade/LICENSE) 与 18 份风格 README；案例图来自 styles/<slug>/img/hero.jpg，已缩放与编排。歌曲、诗、外部字体与引用素材仍各按来源条件处理。中文使用模板根据引擎说明整理，没有声称是作者原始对话。

## 其余参考项目

仅作链接与元数据索引，不重发其完整媒体或五份 README：

- https://github.com/yihui-dev/awesome-opus5-5-videos
- https://github.com/joeseesun/opus-video-prompts
- https://github.com/JohnHeibel/PDoomVideo
- https://github.com/JohnHeibel/ClaudeAnimationBase
- https://github.com/mexicat/pdoom-video

引用或复用前阅读各项目许可。原始 PDF、个人素材和机器配置不在公开包中。
