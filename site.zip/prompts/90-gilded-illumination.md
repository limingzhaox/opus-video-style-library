# 90 · 金箔彩绘 / Gilded Illumination

来源类型：官方风格原文 + 本库中文执行模板  
原作者：Lemo-Opuscar by Lemomo (LemoLab)  
上游原文：https://github.com/lemomo-ai/lemo-opuscar/blob/8ca0dd805e214bcc1d30714cd5b9d21cc02a454b/styles/gilded-illumination/STYLE.md  
固定版本：8ca0dd805e214bcc1d30714cd5b9d21cc02a454b  
抓取核对日期：2026-11-24  
本库改动：中文任务模板、中文摘要与编排；原文全文保留。

## 使用前先看

- 金色来自金箔内部移动光斑，暗处仍是金属而非整片提亮；不能把金色推成纯白或泛光。
- 30fps，讲述卷轴的位置与宽度稳定并留足阅读时间；原创人物构图，不复制现存手抄本画面。
- Lemo-Opuscar by Lemomo (LemoLab), https://github.com/lemomo-ai/lemo-opuscar 。风格原文、公共规范及其改编文档按 CC BY-NC 4.0（https://creativecommons.org/licenses/by-nc/4.0/）署名非商业共享；本库新增中文模板与编排。上游另允许为自己的影片（含商业及客户影片）读取、复制、改编文档并随该片项目交付，超出该范围的商业产品、服务或文档再发行需另获授权。代码 MIT、示例画面 CC BY 4.0 仅覆盖可授权部分，第三方素材、六项示例旁白和 Clawd 等另有例外。详见 ATTRIBUTION.md 与 sources/upstream/lemo/LICENSE。
- 案例图许可：CC-BY-4.0；署名与第三方资产详见 sources/upstream/lemo/styles/gilded-illumination/demo/CREDITS。六项示例配音的限制也适用于整段原影片，不能只凭画面许可转发音轨。

- 这是代码渲染工作流；聊天文本本身不会自动产生 MP4，需有可执行的项目环境。
- 先看预览再做长片；不要把示例素材的许可自动套到自己的歌曲、照片、字体和品牌上。
- 下方复制区包含全部风格与公共规范，不要求 AI 另外从本机隐藏路径读取文件。

## 完整复制区

【来源与许可】
Lemo-Opuscar by Lemomo (LemoLab), https://github.com/lemomo-ai/lemo-opuscar 。风格原文、公共规范及其改编文档按 CC BY-NC 4.0（https://creativecommons.org/licenses/by-nc/4.0/）署名非商业共享；本库新增中文模板与编排。上游另允许为自己的影片（含商业及客户影片）读取、复制、改编文档并随该片项目交付，超出该范围的商业产品、服务或文档再发行需另获授权。代码 MIT、示例画面 CC BY 4.0 仅覆盖可授权部分，第三方素材、六项示例旁白和 Clawd 等另有例外。详见 ATTRIBUTION.md 与 sources/upstream/lemo/LICENSE。

你是一位能写代码、检查画面并渲染成片的动画导演。请用“金箔彩绘 / Gilded Illumination”制作一个属于我的视频。

【我的需求；把花括号内容换成实际值】
主题与一句话故事：{{填写主题和结尾变化}}
用途与观众：{{例如面向普通观众的科普短片}}
内容依据或已有脚本：{{填写；没有则说明需要你写}}
音频、歌词、图片、数据、品牌素材路径：{{填写；没有写“无”}}
素材使用权限与需显示的署名：{{填写来源与许可；不清楚请列待确认项}}
目标时长：30 秒起步；MV 以实测歌曲时长为准
画幅与清晰度：默认横屏 16:9、1920×1080；帧率按本风格原文与引擎规范，未规定时24fps；竖屏须重新构图，不直接裁横屏
语言：简体中文；配音需求：{{有/无、声线与语速}}
必须出现的内容：{{填写}}
禁止出现的内容：{{填写}}
预算与速度：先做低成本验证，再渲染完整片
个人工程名：my-video（可改为英文短名）
确认方式：先给 3 张由真实渲染代码产出的样帧和 5–10 秒预览；我确认风格后再做完整成片

【本风格的核心实现】
用中世纪彩绘的平面颜料、坚实墨线和铅白小点，在深群青天空前表现会受光的方块金箔。
特别检查：
- 金色来自金箔内部移动光斑，暗处仍是金属而非整片提亮；不能把金色推成纯白或泛光。
- 30fps，讲述卷轴的位置与宽度稳定并留足阅读时间；原创人物构图，不复制现存手抄本画面。

【工程与流程】
1. 在工作区单独克隆 https://github.com/lemomo-ai/lemo-opuscar ，检出 8ca0dd805e214bcc1d30714cd5b9d21cc02a454b，保留上游原目录供渲染工具和相对路径使用。图册只归档提示词文档，没有打包全部视频源代码。
在独立个人工程目录实现，参考 styles/gilded-illumination/STYLE.md；不得把示例电影的故事、角色、文案、音轨当成我的需求。先读风格规范与 DIRECTOR.md、TECHNIQUE.md。Windows 的 sh 命令在 Git Bash 或 WSL 执行。window.TEXTS(t) 的 pass: true 只用于无需完整阅读的路过文字，不能用于观众必须读懂的信息；字幕另按 SRT 检查。
2. 先检查机器的 Python、Node/浏览器、FFmpeg、字体与 GPU 能力。Lemo 当前要求 FFmpeg 7+；先用 ffmpeg -version 核对。缺少工具或访问权限时明确报告缺什么，不能只描述完成、伪造文件或把截图称为已渲染视频。
3. 把我的需求写成 PLAN.md 或 TREATMENT.md：一句话故事、分镜、逐镜秒数、镜头运动、文字位置、音乐与声音 cue、所需素材、预计成本。涉及事实和数据时写 FACTS.md；没有来源的数字不填。
4. 按主题写旁白并实测音频时长；无需旁白时用画面和声音讲清楚。
5. 先完成 3 张代表开头、关键变化、结尾的样帧，逐张检查；再渲染 5–10 秒低清短段，检查字幕、运动、音画同步与控制台。复杂慢风格先计时，再估算整片。
6. 随机效果固定种子；有历史累积的媒介按顺序渲染。并行前先比较随机抽帧与连续渲染是否一致。
7. 正式导出使用项目文档中的工具与参数，不臆造命令。交付可播放 MP4、720p 预览、源代码、素材清单与许可、字幕（有台词时）、复现说明；保留最终片长、帧率、音频响度与实际渲染耗时。
8. 实际打开并检查成片开头、中间、转场、结尾及全片联系表，确认没有空帧、字体回退、遮挡、裁字、爆音或无意复制的作者片尾签名。交代尚未完成的检查。

下面是完整风格参考与公共制作规范。它们是上游参考资料，不代表我的主题或逐字台词；我的具体需求优先。风格中明确的声音、镜头和媒介限制优先于公共建议，例如无声电影不添加旁白或拟音。遇到 macOS/Linux 示例命令时按当前系统等价转换，不直接在 PowerShell 粘贴 bash 命令。相对资源路径以完整克隆的上游工程为准。


===== 完整风格原文：styles/gilded-illumination/STYLE.md =====

# Gilded Illumination — Style Prompt

> The whole frame is one gilded miniature painting, and the story happens inside it: flat mineral pigments inside firm ink outlines, white-lead highlights and dots, and real gold leaf (laid in squares, with seams, burnished) that only shines when a light inside the picture moves across it. No book, no page, no desk: the picture fills the screen edge to edge, and at the end it can be revealed as one whole painting inside its own border.
> References (picture grammar only): Gothic and late-medieval miniatures (blue grounds with gold stars, gold grounds with punched diapers, foliate and quatrefoil frames, stepped leaning rock spires, scalloped clouds, continuous narration with one figure shown several times). Copy no specific painting, figure, layout or border; never name a manuscript or painter in the film.

Rules below are what make the style; everything marked *Reference* is one good way to do it, free to change per film.

## 1. Essence, and what it is not

- **Flat pigment, firm line.** Every shape is one flat colour, a darker band just inside the outline, a **firm ink outline** (never hairline: at least ~2.5 px on screen in a wide shot, thicker in close-ups) and white-lead strokes on the edges that face the light. No gradients that model form, no soft shading.
- **Gold is a material, not a colour.** Gold leaf is laid in squares: you can see the leaf blocks, their seams and overlaps, a little red bole where the leaf broke, punched dots. It lies dark and warm until a light crosses it; then the squares flash one by one (each one tilted a little differently) while the pigment beside it stays matte. That contrast is the style's signature. Anything yellow on screen is either real leaf with that texture or a pale pigment that cannot be mistaken for it; never a flat yellow standing in for gold.
- **White lead in strokes and dots.** Besides the edge strokes, white lead is laid as dots: triads on foliage and rock, a row of pearls along a hem, a band of pearls on a vermilion ring. They are what makes a flat shape read as painted, not as a vector illustration.
- **The picture is the place.** The camera lives inside one painted world. Text, when there is any, lives inside the picture too: a speech scroll, a plaque in the border, an inscription.
- **The world is painted too.** Mountains, trees, buildings, figures, water and sky use the same palette and the same outline-and-highlight rule. Nothing switches to photographic or 3D-shaded rendering.
- **Night is deep ultramarine.** The dark of the picture is the blue ground sinking toward a deep lapis, never black and never grey. When light returns, the sky stays a deep blue: the world gets brighter because its gold lights up, not because the blue turns pale or the whole frame is lifted.
- **Medieval pictorial logic.** Mountains are clusters of stepped, leaning spires; skies are blue grounds with gold stars and scalloped clouds; distance is shown by size, overlap and paler pigment, not by atmosphere.

Not Stained Glass (no lead cames, no transmitted light), not Art Deco (no streamlined geometry, no metallic gradients as decoration), not Ukiyo-e (no woodblock bleed, no bokashi), not Paper-cut Lightbox, not a fantasy game map, not a flat vector illustration with yellow circles.

## 2. Materials & rendering

- **Pigment shapes**: `fill` + `rimShade` (the same path stroked inside its own clip in a darker tone) + ink `stroke` + white-lead `hiLine` + white-lead dots. This recipe is the whole look; keep line widths tied to the camera so they never thin out to a hairline in wide shots.
- **Gold leaf**: a tileable texture laid in leaf squares (each square its own tone, a thin dark seam with a bright overlap ridge, a few cracks, specks of red bole), filled through a pattern into any path, then a burnish, a speck layer, an inner rim and an ink outline. Punched decoration is rows of tiny dark dots with a light fleck. Raised (gesso) gold gets a small cast shadow.
- **Light only on gold**: every gold path is also written into a screen-space mask; light from the picture's own sources is added only inside that mask, per leaf square (each square has its own tilt, so the light moves across the squares unevenly), with star-shaped flashes where it is brightest. Pigment never receives specular light.
- **Lit gold stays gold**: light pulls the leaf toward a warm gold with a cap on each colour channel (ours stops at 82% of the way), so the brightest leaf still shows its squares and seams and never burns to white or flat yellow. A soft bloom, if any, belongs only to the most strongly lit leaf and stays small; never a wash over the frame.
- **Ground pigment (ultramarine and friends)**: a granular pattern (coarse grains, not noise) mapped between a dark and a light tone of the hue.
- *Reference:* vellum (procedural sheet with grain and stains) is kept for the parts that are written on: speech scrolls and the end plaque.
- *Reference:* static and live layers: anything that does not move can be pre-rendered under the camera; anything that grows, flashes or is lit is vector, every frame (ours draws everything every frame at ~50 ms).
- **Light comes from inside the picture**: a lamp, the sun, a band of light crossing the painting. Night is the pigments sinking toward blue; lit gold rises above it.
- *Reference:* infinite zoom: textures that must survive a big push (the leaf in a macro shot) are generated again at higher resolution for that region and cross-faded by log zoom.

## 3. Colour logic

- The ground is ultramarine (sky) or gold (gold-ground panels and frames). Everything else is a short list of medieval pigments: lapis/ultramarine blue, vermilion, verdigris green, rose, azure, lilac-grey, white lead, iron-gall brown ink, gold, rarely silver. Ochre only in small, clearly matte places (hair, a roof), never on large areas next to gold.
- Each pigment comes in three values only: body, darker rim, white-lead highlight.
- Blue and gold are the pair the eye goes to; keep the biggest blue field and the brightest gold for the moment that matters. Vermilion is for the hero, frames and marks of importance.
- *Reference palette:* ultramarine `#22379a`, vermilion `#c8321f`, verdigris `#3f8f7a`, rose `#d97a8a`, ink `#2a1a10`, gold leaf (texture, mid tone `#c99a3e`); vellum `#efe2c4` only for scrolls and the plaque.
- Brightness is carried by gold, not by the whole frame: from the darkest night to the brightest ending, the average brightness of the picture moves little; what changes is how much gold is lit and how brightly.
- Never: neon, pastel gradients, photographic skies, flat yellow used as gold, black outlines thicker than the shapes they hold, a pale or washed-out sky after the light returns, a global brightness or saturation boost to show "day".

## 4. Type & subtitles

- *Reference:* titles and inscriptions in Uncial Antiqua (display capitals) or Grenze Gotisch (lowercase Gothic); explanatory words and subtitles in IM Fell English (roman and italic) for English and Noto Serif SC for Chinese, in brown ink, written on scrolls and plaques. One language per line.
- **Sizes**: text meant to be read ≥ 40 px at 1080p for titles, ≥ 32 px for English subtitles, ≥ 34 px for Chinese.
- **Reading time**: hold ≥ CJK ÷ 4.5 + other ÷ 15 + 1.5 s, and ≥ 1.8 s, from the first frame the block is complete. Text is revealed by a pen wipe, never typed letter by letter.
- **Subtitles are a speech scroll, fixed in one place**: a vellum banderole at the bottom centre of the frame (Chinese line, English line) that unrolls when a line is spoken. It is part of the style. It never moves sideways and never changes size: one width for the whole film (set by the longest line, shorter lines centred inside it), one height, one type size. Between two close lines the scroll stays open: the old words fade, then the new ones are pen-wiped on; two lines are never seen on top of each other.
- **Compose for the scroll**: the hero is kept out of the lower-centre band while a line is up (higher in frame, to one side, or the camera lowered), rather than moving the scroll.

## 5. Motion quality

- 30 fps, smooth (on ones). Things appear the way they are made: shapes pop up with a small spring, strokes are laid along their path, writing is wiped on, gold is laid then shines, a figure is painted in layers (gold, colour, ink and white lead).
- Easing is calm (ease-in-out, ease-out); springs only on small things appearing.
- What never moves: the painted picture and the gold already laid. Only the light, the hero and the camera move across them.
- Paint and gold build up; they never fade in as a whole.

## 6. Camera grammar

A virtual camera over a flat painted world (centre, log zoom, roll).

| Move | What it expresses | Can serve |
|---|---|---|
| exponential pull out of the leaf | from the material to the picture | an opening; a reveal of scale |
| push through a quatrefoil / foliate frame | entering the picture, changing chapter | a hero introduced in a roundel, then the world |
| follow along the path of a continuous narration | a journey, time passing | a climb, a pilgrimage, a delivery |
| foreground spire or cloud wiping across | an elided stretch of time without a cut | the middle of a long walk |
| locked frame while light rakes | revelation, value | the finished work, gold, a seal |
| a band of light sweeping the whole picture | the world changes | a sunrise, a verdict, a return |
| a ring of gold light spreading from a touch | ignition, a decision, a turning point | a key turning in a lock, a seal pressed |
| hard cuts on circles, centre to centre | match, repetition | a wheel to a halo, a coin to a seal |
| the big pull back to the whole painting | the story was one picture | endings: every scene seen at once |

Framing: the painted world fills the frame edge to edge; a patterned border can be the camera's frame and, at the end, grow into the whole painting's frame. Allowed transitions: continuous zoom, push through a frame, foreground wipes, match cuts on shapes, hard cuts on the beat. Forbidden: page-turn wipes, slide transitions, cross-dissolves between unrelated scenes.

## 7. Sound palette

- *Reference band:* bowed fiddle (a solo violin played plainly stands in), harp, portative organ (a soft organ register), frame drum, recorder; bells (tubular, glockenspiel, hand chimes) for gold.
- Modes: dorian, mixolydian, aeolian; a Picardy third for arrival. No piano, no modern string section, no synth pads.
- *Reference foley:* the painted world's own sounds: wind, running water, footsteps on stone, a door, a far bell. Workshop sounds (quill, brush, mortar) are optional, for a film about making.
- Silence is a tool: drop the band to one held note when the picture asks a question.
- Gold gets a bell when it lights; the brightest moment of gold gets the fullest bar of music. Mix: voice on top, music under it, −14 LUFS.

## 8. Native moves

- **The touch.** A small light (a flame, a spark) touches a large piece of leaf; two thin rings of gold light spread from the point of contact and the leaf squares light one after another as they pass, while rays around it light in turn. Restrained: no white flash, no full-frame bloom; the climax is gold lighting up, not the screen going bright. *Fits content like:* a launch; a first sale; the moment a thing starts working.
- **Gold laid, then lit.** Gold appears dark and warm; later a light crosses it and each leaf square flashes in turn while pigment stays matte. *Fits content like:* revealing a finished seal; an inventory of treasures; a medal list.
- **Lit by a lamp.** A light moves through the picture and the gold brightens only near it, then sinks back after it passes. *Fits content like:* a guide, a teacher, a product that changes what it touches.
- **Into the material.** Pull out of a macro of leaf (squares, seams, punches) into the picture. *Fits content like:* where a thing comes from; an opening that starts from texture.
- **Continuous narration.** The same figure appears several times in one painting, each at a later moment of the story; the final pull back shows them all. *Fits content like:* a journey; a process with stations; a life.
- **Through the frame.** A quatrefoil or foliate frame holds a close-up; the camera pushes through it into the big picture. *Fits content like:* introducing a hero; a chapter change.
- **Painted in layers.** A figure or a title appears in the order it is made: bole, gold and its flash, then colour, inner rim, ink and white lead. *Fits content like:* a reveal; a signature; a product being made.
- **Holy card.** One object centred in a painted frame on a gold ground, with its name on a scroll. *Fits content like:* a herb; a tool; a coin.
- **Brush fill.** A blank area is filled stroke by stroke in ground pigment, from the centre out. *Fits content like:* a design completed; a sky; a filled map region.

Our demo opens *into the material*, out of a macro of dark leaf, uses *the touch* as its climax and ends on the pull back to the whole painting, its border growing from the corners. A new film opens and ends another way: a gold ground with nothing on it yet and the first stroke of colour, a *holy card* whose gold is *laid, then lit*, a *brush fill* of the first blank area, or an ending on a locked frame while light rakes across one finished object.

## 9. Pitfalls of the medium

- **Shading creeps in.** Soft gradients make objects look plastic; model with the rim band and white-lead strokes only.
- **Flat-illustration drift.** Thin lines, no white dots, gold as plain yellow discs: the picture turns into a modern vector illustration. Keep the ink firm, add white-lead dots, show the leaf squares.
- **Gold everywhere, lit all the time.** If gold shines all the time, the light has nothing to reveal. Keep gold dark until its moment.
- **The white-out climax.** Pushing the lit leaf's brightness up (or adding a big glow) turns the brightest moment into a yellow-white blur and erases the leaf squares. Light the climax with more gold, not with more white: rings, squares lighting in turn, a capped gold tone.
- **Day by brightening.** Raising the whole frame's brightness or saturation, or turning the night sky light blue, to show that the light came back looks like a colour-correction slip and kills the deep ultramarine. The sky stays deep; the gold does the work.
- **Wandering subtitles.** A scroll that jumps between left, centre and right, or changes width with each line, reads as an error. Fix its place and size; move the camera or the hero instead.
- **Picket-fence mountains.** A row of spires of the same height reads as a fence. Group spires in clusters (one tall, smaller ones leaning off it), vary the gaps, and stack two or three ranges, paler and smaller behind.
- **Stacked-box mountains.** Rectangular ledges read as buildings; spires must lean and taper, with small stair-steps on both flanks.
- **The hero as a nun.** A hood over the face makes a small figure read as a nun or monk; keep the face and hair visible.
- **Blackletter legibility.** Grenze capitals are hard to read; set display capitals in Uncial and keep Gothic for lowercase words. Never set Chinese or long English in blackletter.
- **Fake Latin.** Use real public-domain Latin sentences or none.
- **Infinite zoom seams.** A single texture stretched over a big push turns to mush; regenerate the leaf at the zoomed region's resolution.
- **Render state.** Canvas state and cached patterns leak between frames; reset the context every frame and clear offscreen buffers.

## 10. Engine

- `lib.js`: math and easing, `monotone`/`track`, the pigment palette, the leaf-square gold texture (`makeGold`, `leafAt`), `gold()` / `goldStroke()` with the glint mask (`MK`), `shape`, `rimShade`, `hiLine`, `dots`/`pearls` (white lead), `tubePath`, `spirePts`, `camMatrix`, `reg()` for `window.TEXTS`.
- `world.js`: the demo's one painted world (its subjects are the demo's; your film paints its own): `leaf()` with its dark (`dim`) state, layered rock clusters (`makeRange`, `drawSpire`), the sun (`drawSun`, dark or lit, rays lighting in turn), trees with gold fruit, the chapel with a gold-ground arch, the hero (`drawGirl`, painted in layers), the lantern, the border that grows from its corners (`drawBorder`), the end plaque.
- `film.js`: one timeline in film seconds; `glintPass` (radial lights and light bands, computed per leaf square from the mask), the quatrefoil frame, the macro leaf for the opening, the speech-scroll subtitles, `window.EV` for the sound.
- Minimal example, a gilded coin with a punched rim on ultramarine:
  ```js
  const c = P2(q => q.arc(0, 0, 60, 0, TAU));
  g.fillStyle = ULTRA; g.fillRect(-200, -150, 400, 300);
  gold(g, c, [-60, -60, 120, 120], { lw: 4, rimW: 6 });
  for (let a = 0; a < TAU; a += .2) { g.fillStyle = 'rgba(110,60,5,.55)'; g.beginPath(); g.arc(Math.cos(a) * 50, Math.sin(a) * 50, 2, 0, TAU); g.fill(); }
  pearls(g, 0, 0, 72, 24, 3);   // white-lead pearls around it
  ```

## 11. Variation space

The agent decides the painted world (a mountain, a city, a garden, a sea), the hero, where the light comes from and what it touches, the story's stations, the palette within the pigment list, and the music within the band.

- *Reference structures:* one journey told as continuous narration in one picture; a bestiary of framed holy cards lit one by one; a single object followed from its material to its place in the picture.
- *Reference openings:* a pull out of a macro of dark leaf; a single lit lamp in a quatrefoil; a gold ground with nothing on it yet, and the first stroke of colour.
- *Reference endings:* the pull back to the whole painting, its border growing from the corners; a plaque in the border lettered in bole, then gilded; one last band of light crossing every piece of gold.

---

How our demo was made (story, shots, score, end card, build): [DEMO.md](DEMO.md). Read it after your treatment exists.


===== 完整公共规范：DIRECTOR.md =====

# Directing a Lemo-Opuscar film

The directing method behind every film in this library. Pair it with one `styles/<slug>/STYLE.md` (the style) and [`TECHNIQUE.md`](TECHNIQUE.md) (how to build).

You are the director, not a tech demo. A film is judged in this order: **sound, rhythm, camera, directing** (performance, staging, emotional arc). Good-looking frames are only the starting point.

---

## 1. Take the brief

The user gives a style and a topic, sometimes more (length, language, voice, must-have shots, brand rules). Everything else is your decision. Ask once, in a single message (AGENTS.md, Workflow), then no more questions. Defaults:

- Length **30–60 s**; shorter and tight beats padded. Beyond two or three minutes multiplies time and token cost: tell the user.
- 1920×1080 at 24 fps by default; an output frame rate set in the style's `STYLE.md` (30 or 60 fps, for example) wins, and is what you pass to `--fps` and `mux.sh`; other sizes (vertical 1080×1920, for example) with `--size WxH` on the render tools.
- Voice and subtitles in the language the user writes in. Subtitles burned in and exported as `.srt`.
- **The language on screen is the film's, not the demo's.** Many `STYLE.md` files set a Chinese line above an English line (subtitles, titles, labels): those are the two languages of our demos. A film in one language sets that line alone, in the upper line's place and size. A film in two keeps the stack, its main language on top. For another script, choose an openly licensed face of the same kind (weight, serif or sans, written or printed). The rest of the style's type stays: sizes, placement, how the text arrives.
- Loudness −14 LUFS.

Say it in the questions when it matters: a good Chinese voice uses Microsoft's online service (edge-tts) and needs a connection; offline, Kokoro reads Chinese but sounds plain (TECHNIQUE.md §4).

Requests that only change the plan:

- **No voice, or no subtitles.** Drop those steps and say so in the treatment.
- **Their own voice recording.** Use it as it is; transcribe it with faster-whisper for word timings.
- **Their own material**: logos, photos, footage, and for a style built from real data or scans (its `STYLE.md` says so) their own data, scans, imagery or CAD. Ask whether they have any; what they give comes first, and the sources in the `STYLE.md` are the fallback. Before you download from those sources, tell the user what you will fetch, from where and under which licence. Rights: section 12.

## 2. Find a benchmark first

Before writing anything, pick one or two reference works (films, title sequences, games, ads) that set the bar for this style **and this topic**. They are your choice, made for the user's film; don't borrow the demo's. Write down:

- **What to learn**: composition, pacing, camera grammar, colour logic, score structure.
- **What not to take**: characters, designs, melodies, specific shots, logos, fonts.

The benchmark lifts quality more than any rule below.

## 3. Shape the story

- **One subject, one goal, one turn.** A character (or a single object, product or idea) wants something, something changes, it ends differently from how it began.
- **Hook in the first 3 seconds.** No slow logo reveal before anything happens.
- **An ending that echoes.** Bookend the opening, reveal the scale, or let the character do the thing right the second time.
- **One native move**: a moment only this medium can do (a fold that becomes a transition, ink that blooms into the next scene, a type grid that snaps into the logo). Put it at the emotional peak. `STYLE.md` lists the medium's native moves; pick or invent the one your story needs.
- **Cut the extras.** One gag the audience reads at thumbnail size beats three they can't. If a beat needs explaining, remove it.

## 4. Write the treatment

Write `TREATMENT.md` before drawing anything, and before you open the style's `DEMO.md` or demo code (an Edit & Documentary style gathers its material first: AGENTS.md, "Treatment first"):

1. **Three candidate structures**, a few lines each (for example: a single journey, a before/after, a countdown, a list that turns), then the one you chose and why. Choose the opening image, the ending and the shape of the score from the topic too; the first idea that comes to mind for a style is usually its cliché.
2. **Logline and arc**: one sentence, then setup → turn → ending.
3. **Benchmark**: learn / don't learn (section 2).
4. **Shot list**: for every shot, the framing (wide / full / medium / close / insert), angle, camera move (push, pull, pan, track, crane, zoom), duration, and **why** it is shot that way.
5. **Beat sheet**, second by second.
6. **Cue map**: tempo, bar grid, instrumentation per section, and on which beat every cut, key action and subtitle lands.
7. **Sound design table**: for each section, the ambience bed, the main foley and the music state.
8. **Subtitle and title design**: the type is part of the style.

## 5. Prove the look

- **With characters**: draw a model sheet (turnaround, 3–4 expressions, 2–3 key poses, palette) plus two style frames.
- **Without characters**: three style frames from the film, one of them the signature shot.

Render them with the real drawing code, not a mock-up, and check them yourself against the `STYLE.md` before going on.

### The storyboard (only if the user asked for one)

Render 6–9 key shots with the real drawing code, tiled into one sheet (`core/render/sheet.py`) with shot number, framing, duration and line under each. Send it with the logline and what you are least sure about, and **wait for approval**. If the user didn't ask for one, don't stop.

## 6. Sound is half the film

- **Every visible action has a sound**: landings, page turns, cuts, drips, clicks, cloth. Match the material (paper, wood, metal, ink and glass all sound different).
- **Three layers**: ambience (room, wind, rain, city), foley (tied to actions) and music. Duck the music under dialogue and key foley.
- **At least two real silences**, or near-silences, before the turn or the emotional peak. The first sound after the silence should be one of the most important sounds in the film.
- **Use sound as a transition** at least twice: bring the next scene's sound in early (J-cut) or let the last scene's sound run over the cut (L-cut).
- **Avoid generic "piano and strings".** Score in the instruments of the style's sound palette.

## 7. Rhythm: the music grid comes first

- Write the cue map before animating. The picture locks to the grid, and a script checks every cue (TECHNIQUE.md §3).
- **Vary the pace**: alternate fast and slow, include one clear acceleration or deceleration, and give the audience one breath (a long take or a held pause). A film at one even speed has failed.
- One action, one sound, one cut, but don't cut on every beat. Leave time to see.
- **Pace for the viewer, not the clock**:
  - Hold every subtitle at least 1.8 s, and never shorter than the spoken line + 0.6 s.
  - After text finishes animating in, hold it for roughly (letters ÷ 15 + 1.5) s in English, (characters ÷ 4.5 + 1.5) s in Chinese; `readcheck.mjs` checks this for you.
  - Hold a title card at least 4 s.
  - Give failures and gags enough time to be understood.
  - Fast is fine; make it fast with fewer words per screen, not by cutting before people finish reading.

## 8. Camera: every shot needs a reason

- Use at least **four different camera moves** and real changes of framing. 2D has a camera too: push, pull, parallax, focus pulls, frames within frames.
- **One signature shot** people remember: a oner, a scale reveal, a transition made from the medium itself.
- **Design transitions inside the medium** (a page turn, a carved line growing, ink spreading), as one consistent grammar. Avoid default fades and hard cuts.
- At key moments the subject fills at least a third of the frame height, with clear staging and a readable silhouette.

## 9. Performance

- **Anticipation, action, follow-through** on every meaningful move. Characters change emotion. They do not just slide across the screen.
- **Motion continuity**, especially for characters built from code rigs:
  - Blend every pose with keyframes and easing; never switch poses inside an `if`. The only exception is a deliberate one-frame comic pop.
  - Check shoulders and arms on a large action test sheet (reach, raise, run, kneel) before shooting (TECHNIQUE.md §10).
  - Held props sit **between the palms**, at a depth between the two arms. A hand-over interpolates from one palm to the other. A rolling object turns by distance ÷ radius.
  - Step through key actions at 0.2 s intervals, enlarged.
- Check every expression at final size, especially eyebrow direction: "worried" and "angry" are one flip apart.

## 10. The failures we saw most

- Subject too small, too far away, or pushed against the frame edge.
- Too dark to read, or a colour laid on the same colour (red on red).
- Subtitles covering the subject.
- A gag or failure too fast to understand.
- Blank frames in transitions.
- A timed effect (iris, zoom, follow cam) that doesn't track the subject after the camera moves (one world → screen function, TECHNIQUE.md §2).

## 11. Before you deliver

- Run the review loop (TECHNIQUE.md §8): contact sheets, 0.2 s strips of key actions, one full-speed viewing with sound.
- **One fix round.** Fix everything the review and the checks below find in one round, then check once more. Small fixes that second check turns up (a level, a frame) belong to the same round; anything bigger, tell the user in one line when you deliver. The user's notes after delivery are new rounds: change only what they ask.
- **Not the demo again.** After the treatment, read `DEMO.md` and compare: structure, opening, signature shot, camera path, score shape, ending. At least four of the six must differ; rethink the ones that match. Before delivery, put your contact sheet next to the demo poster (`styles/<slug>/poster.jpg`) as a last check.
- Voice: every line transcribes back correctly (speech-to-text check). For Chinese, one misheard character in a short line is normal: listen, and if it is right, let the check expect what the model heard (TECHNIQUE.md §4).
- Loudness about −14 LUFS; no black frames, no NaN frames; subtitles in sync and not covering key action.
- Every row of the sound design table is actually in the mix.
- Every map, globe or satellite view passes section 13, checked enlarged.
- No LemoLab sign-off: `grep -rniE "lemo ?lab|opus 5\.5" <project folder>` finds nothing outside `LICENSE`, `CREDITS` and the library's path in `LIB=` lines, and you have watched the last seconds of the film (text drawn into an image can't be grepped).

**Deliver**, in the project folder (the complete list):

- `<name>.mp4` (24 fps unless `STYLE.md` sets another rate, about −14 LUFS) and `poster.jpg`;
- `<name>.srt`, when the film has narration, dialogue or subtitles; when the subtitles are burned into the picture, `subtitles_<lang>.srt` instead (desktop players load a `.srt` named like the video on top of the picture, so every line would show twice);
- `TREATMENT.md`;
- `CREDITS`: every third-party asset in the film (sample libraries, music, fonts, images, the voice engine) with its source and licence (TECHNIQUE.md §11);
- the source, with a one-command `build.sh` (TECHNIQUE.md §2).

**Tell the user**, in their language: where the project folder and the film are; that `CREDITS` lists the third-party assets in the film and their licences; and that they are responsible for the materials they use in it.

## 12. Copyright red lines

- References teach grammar only. Don't copy characters, designs, melodies, shots, logos or type designs.
- No existing works, games, brands or events appear in the film unless the user owns them or has the right to use them. That includes the logos, photos and footage the user hands you: use them when they say they have the right, otherwise draw fictional stand-ins.
- Some of our demos are unofficial fan films of real events or characters. Keep the style, and never carry those names, marks or characters into a user's film.

## 13. Maps

These apply to every frame that shows a map, a globe or satellite imagery, in every style.

- **No borders unless the film is about them.** Draw coastlines, terrain, imagery or streets, without national or provincial borders. Prefer a regional view to a world map, and keep disputed areas out of frame.
- **When China is in frame, draw all of it.** Taiwan, Hainan, the South China Sea islands with the dashed line (in frame, or in an inset), and the Diaoyu Islands with Chiwei Yu. Taiwan and the mainland are one country, in the same colour and the same treatment. Zangnan and Aksai Chin are drawn as on China's standard map.
- **Default border data doesn't meet this.** The default boundaries of Natural Earth, world-atlas and OpenStreetMap can't be used to draw China. When the film needs borders, use China-view data (such as Natural Earth's `admin_0_countries_chn` layers, checked against the standard map) or China's standard map service (bzdt.ch.mnr.gov.cn).
- **Words follow the same map.** Taiwan, Hong Kong and Macao are never listed as countries: not in labels, legends, subtitles, the voice-over or data tables. A list that includes them is "countries and regions". Clean a dataset's country field before you chart it.
- **Other disputed areas**: the same; frame them out, or leave their borders undrawn.
- **Check and credit.** Before delivery, enlarge every map shot and check it against these rules. `CREDITS` names the map data, its source and its view (for example "Natural Earth 1:50m, China view").


===== 完整公共规范：TECHNIQUE.md =====

# Technique: how the films are built

Every film here is made from code: no video generation, no stock footage. This page explains the pipeline, to reproduce with our tools in `core/` or in your own stack. Pair it with [`DIRECTOR.md`](DIRECTOR.md) and one `styles/<slug>/STYLE.md`. Every command and flag is in [`core/README.md`](core/README.md).

```
timeline (single source of truth)
   ├─► picture:  web page with render(t) ──► headless Chrome, frame by frame ──► video.mp4
   ├─► voice:    TTS per line ──► speech-to-text check ──► word timings
   ├─► music:    score from the same timeline (samples + synthesis) ──► stems
   ├─► sound:    procedural foley at event times
   └─► subtitles: .srt + burned-in captions
mix (duck, compress, balance) ──► mux with ffmpeg, two-pass loudnorm −14 LUFS ──► film.mp4
```

## 1. Requirements and install

System tools, which the user installs: **Node 20+**, **ffmpeg 7+** (6.x under-reports audio length through `loudnorm`, and `mux.sh` then rejects the file as cut off), and **Python 3.11+** or [uv](https://docs.astral.sh/uv/). Developed on macOS (Apple silicon); Linux should work. On Windows, Git Bash (part of Git for Windows) works: run the same `sh` commands there; WSL also works. 3D and shader-heavy styles want a GPU.

Everything else installs in tiers, from the library root (`$LIB` in skill mode). Install a tier only when the film needs it:

| Command | Adds | Size |
|---|---|---|
| `sh plugin/skills/lemo-opuscar/scripts/setup.sh deps` | core: npm packages, headless browser, Python `.venv` (numpy, scipy, soundfile, soxr, pillow): render, synthesize sound, mux | ~350 MB |
| `… setup.sh deps voice` | Kokoro + model (English, offline), edge-tts (Chinese, online), faster-whisper (voice check) | ~0.55 GB + a Whisper model on first check (~145 MB for English, ~480 MB for Chinese) |
| `… setup.sh deps music` | numba, for plucked strings (`pluck.py`); the sampler itself needs only the core | ~140 MB |
| `sh tools/fetch.sh instruments <lib>` | a sample library: `freepats`, `karoryfer`, `salamander`, `vcsl`, `vsco2ce` or `all` | 70–400 MB each |
| `sh tools/fetch.sh hdri` | HDRIs for 3D styles | 12 MB |

Some styles need packages of their own (a LiDAR reader, a slide-scan decoder, a CAD importer); the style's `STYLE.md` lists them. They are packages, not system tools: install them yourself into a private venv or `node_modules` in the project folder, never into `$LIB/.venv`.

The styles marked ✦ also draw with an image generator, which the library doesn't include and you don't install: the user's own Codex CLI, signed in (`core/image/gen_image.py`), or another image tool they have. Their prompts go to that service (core/README.md, "Image generation").

A synthesized score needs no big download. A sampled one needs the libraries its instruments live in: `sampler.py` downloads the missing ones itself, all at once, when the score is rendered (`LEMO_FETCH=0` turns that off and prints the `fetch.sh` commands instead). Put `"$LIB/.venv/bin/python" core/audio/sampler.py --need <your mix.py>` at the top of a `build.sh`, so they arrive before the long picture render, not after it. A pack needs about twice its size free while it unpacks. Downloads come from npm, PyPI, GitHub Releases and Hugging Face (`HF_ENDPOINT` sets a mirror).

## 2. The picture is a function of time

Each film is a folder with an `index.html` (`<demo>` in the commands) that exposes:

```js
window.DUR = 54.2;                 // seconds
window.render = (t) => { ... };    // draw the frame at time t, deterministic
window.READY = true;               // set once fonts and images are loaded
window.EV = [{t, type, ...}];      // optional: sound / cue events for the mixer
window.TEXTS = (t) => [{id, text, x0, y0, x1, y1}];   // optional: every text visible at t, for readcheck (pass: true = not meant to be read in full: a sign passed by, fine-print credits)
```

**Paths:** pages reach library files with absolute URLs (`/core/lib.js`, `/node_modules/three/build/three.module.js`); scripts and `build.sh` use `$LIB`. Never `../..`.

A `build.sh` that works in both modes (in skill mode, put `LIB=<path setup.sh printed>` at the top):

```sh
#!/bin/sh
set -e
HERE=$(cd "$(dirname "$0")" && pwd)
LIB=${LIB:-$(cd "$HERE/../.." && pwd)}          # clone mode: <repo>/films/<name>/
export LIB
[ -f "$LIB/core/render/video.mjs" ] || { echo "set LIB to the library folder"; exit 1; }
cd "$LIB"
node core/render/events.mjs "$HERE"
node core/render/video.mjs "$HERE" --fps 24 --out "$HERE/out/video.mp4"
"$LIB/.venv/bin/python" "$HERE/mix.py"                               # score, foley, voice → out/mix.wav
sh core/render/mux.sh "$HERE/out/video.mp4" "$HERE/out/mix.wav" "$HERE/<name>.mp4" 24
```

Rules that keep it reliable:

- **Deterministic.** No `Date.now()`, no `Math.random()` without a seed (`core/lib.js` has `mulberry` and `hash`), no state carried from the previous frame. Any frame can be rendered alone, in any order, by any worker.
- **Canvas 2D** for most 2D styles; **three.js** for 3D (§9); **WebGL2** shaders for post passes (film damage, CRT, ink redraw).
- **Animate on twos where the style wants it** (12 fps stepping for stop-motion, pixel or cel looks), but keep the camera and light smooth every frame. A stepped camera reads as lag.
- **One world → screen function.** Any effect that follows a subject (iris, zoom, spotlight) goes through it. Never hand-type screen coordinates.
- **Draw for the frame you render.** The default is 1920×1080; for another size pass `--size WxH` (e.g. `1080x1920`) to every render tool and lay the page out from `innerWidth` × `innerHeight`.

Capture (`core/render/`):

```sh
node core/render/still.mjs <demo> 1.5 12 --range 0:50:2   # review stills; exits on page errors
node core/render/video.mjs <demo> --fps 24 --workers 3     # all frames → <demo>/out/video.mp4
node core/render/events.mjs <demo>                         # export DUR + EV → events.json
node core/render/readcheck.mjs <demo>                      # every on-screen text stays long enough to read
```

To render a second version with other content, pass it to the page and give it its own output: `--q 'content=content_alt.json' --out …/alt.mp4` (the same for `events.mjs`).

Capture is fast because of **JPEG screenshots**, **one browser per worker** and **grain added in ffmpeg**: grain drawn in the page makes every frame incompressible and slow.

## 3. One timeline drives everything

Keep sections, tempo, beats and hit points in one file (`timeline.js`). Export it to JSON and let the score, the mixer, the subtitles and the checks read the same numbers:

```js
export const SECS = [{ id: 'chase', t: 12.0, bpm: 144, beats: 12 }, ...];
export const HIT  = { pratfall: ['chase', 6], ... };   // section + beat
```

A small script (`cuecheck.py`, in `styles/<slug>/demo/tools/` of several demos) compares every visual hit with the music cue it should land on. Aim for 0 ms.

## 4. Voice

- **TTS is only the default.** If the user brings a recording or names a voice, use that. Otherwise:
  - **English**: [Kokoro](https://github.com/thewh1teagle/kokoro-onnx), local, many voices (an unknown `voice` name makes `tts.py` print the full list; `af_` / `am_` are American, `bf_` / `bm_` British; cast the narrator for this film, not the demo's). `core/tts/tts.py lines.json out/` writes one WAV per line and a durations file. Its Chinese voices (`"lang": "cmn"`) work offline but sound plain.
  - **Chinese**: `core/tts/tts_zh.py lines.json out/` uses [edge-tts](https://github.com/rany2/edge-tts) with Microsoft's neural voices (`zh-CN-XiaoxiaoNeural`, `zh-CN-YunxiNeural`…), with the same outputs as `tts.py`, a rate per line and the silence trimmed. **It needs a network connection.**
- Spell numbers out in the TTS text and write them as digits in the subtitles.
- **Check every line**: `core/tts/asr_check.py` transcribes each WAV with faster-whisper and compares it with the script (`--lang zh`: numbers by value, so 十九 matches 19, and the rest character by character); re-generate until it exits 0. A misheard character in a short Chinese line is normal: listen, and if it is right, put what the model heard in the line's `asr` field. It also writes word timestamps for placing lines and subtitles.
- **Before mixing**: TTS has a high peak-to-average ratio. Compress the voice first, then balance by RMS: voice about 10 dB above the music.

## 5. Music

Write an original score from the cue map, in the instruments of the style's sound palette; no generic piano and strings.

- **Samples**: `core/audio/sampler.py` plays real instruments from free libraries (VSCO 2 CE, VCSL, FreePats, Karoryfer, Salamander Grand Piano; list and licences in `core/audio/INSTRUMENTS.md`). Write the score as events `(time, instrument, pitch, duration, velocity, pan)`. Long notes are extended seamlessly, and round-robins avoid the machine-gun effect.
- **Plucked and folk strings** (guqin, pipa, shamisen, banjo…): `core/audio/pluck.py`, physical modelling (Karplus–Strong) with bends and vibrato.
- **Synthesis** with numpy for chip tunes, drones and effects; no download needed.
- **Balance the low end.** Synthetic scores get bass-heavy quickly. Measure energy per band after mixing; keep 20–120 Hz around −3 dB relative to the rest, skip pad notes below MIDI 48, and give the bass some 2nd and 3rd harmonics so it speaks on small speakers.

## 6. Sound effects and mix

- `core/audio/sfx.py` synthesises foley procedurally (click, whoosh, thump, ding, paper, noise beds…) with filters, envelopes and `add(buffer, sound, at, gain, pan)`. Drive it from `window.EV`, so every sound sits exactly on its frame.
- **Master**: `sh core/render/mux.sh video.mp4 mix.wav out.mp4 24 [grain]` muxes, runs a two-pass loudnorm to −14 LUFS with a true-peak limit, adds grain in ffmpeg and prints the measured loudness; it exits non-zero on any failure. On light backgrounds use less grain; for pixel and vector styles, none.
- Films with grain baked into the picture compress badly; re-encode with `-tune grain` and a higher CRF.

## 7. Subtitles

- Export `.srt` with `core/render/srt.py cues.json out.srt` (cues = `[{t0, t1, text}]`), and burn styled captions into the page itself: the caption design is part of the style.
- Timing rules are in DIRECTOR.md §7.

## 8. Review loop

1. Contact sheets: a frame every 1–2 s with `still.mjs --range`, tiled with `core/render/sheet.py`. At least two full passes.
2. Frame strips at 0.2 s for every key action: hand-overs, falls, hits.
3. On the final file: `ffmpeg -af ebur128` (loudness), `blackdetect` (blank frames), whisper again on the final mix if it has voice.
4. Watch it once, at full speed, with sound.

## 9. 3D notes

- three.js r170 rendered headless through WebGL2 on the GPU; physical depth of field and GTAO from `core/three/post.js`, rendered at 2× and downsampled.
- Lighting: soft area lights plus a Poly Haven HDRI at low intensity reads more "real" than bright ambient light.
- `core/three/post.js` is written for a perspective camera. For an orthographic camera swap `perspectiveDepthToViewZ` for `orthographicDepthToViewZ` in its depth pass, or the depth of field silently breaks.

## 10. Characters drawn in code

- A 2.5D rig (torso, head, limbs solved per frame) is enough for pantomime.
- Order the shoulder rotation as abduction, then flexion; the reverse order crosses raised arms into an X.
- Let the shoulder girdle rise and move forward as the arm lifts, and don't outline the part of the arm that overlaps the torso: that line is what makes a joint look like a puppet seam.

## 11. Assets, credits and fonts

Only CC0, CC BY or OFL material, each listed in the film's `CREDITS` with its source and licence; `core/audio/sampler.py credits(names)` writes the lines for the instruments you used. Public-domain works count as CC0; "no known restrictions" does not. Data or images under other open licences (ODbL, CC BY-SA, open-hardware licences) only after you have named the licence and its terms (attribution, share-alike) to the user and they agree. The user's own material is fine as it is. Images from an image generator (the ✦ styles) are listed too: which tool and model made them, that they are generated, and where the prompts are kept; drawings the user made are credited to them.

A film that states facts (a style built from real data or scans: its `STYLE.md` says so) keeps a `FACTS.md` in the project folder: each claim with its source URL and the quoted wording, or the measurement that produced it.

Fonts: Google Fonts (OFL), self-hosted in the project. The typefaces a `STYLE.md` names are not in the library; download them (`https://github.com/google/fonts/tree/main/ofl/<family>`) into the project's `fonts/`. `core/fonts/` holds a few Latin display fonts and a Chinese display font with only about 200 glyphs, not enough for running Chinese text. For Chinese, subset a CJK font to the characters you use: the Google Fonts CSS API with `&text=` returns just those glyphs (`https://fonts.googleapis.com/css2?family=Noto+Sans+SC:wght@700&text=<URL-encoded characters>`). Download the font file it points to into the project's `fonts/` and load it with `@font-face`; don't link Google Fonts at render time.

## 12. Where to look in our demos

| If you need… | Look at |
|---|---|
| 2D character animation and lip sync | `styles/scifi-toon/`, `styles/cel-anime-80s/` |
| a timeline-driven score with cue checking | `styles/microgame/`, `styles/silent-film/` |
| an image-to-ink redraw and film-damage post pass | `styles/silent-film/demo/engine/` |
| a brush or stroke engine | `styles/watercolor/`, `styles/ink-wash/`, `styles/impasto/` |
| 3D with depth of field and real materials | `styles/brick-toy/`, `styles/paper-popup/` |
| a CRT or VHS look | `core/post/crt.js`, `styles/ascii-crt/`, `styles/backrooms/` |

Each style's `DEMO.md` says how its demo was built. Open it and the code only after your treatment exists, to learn a technique, never to rebuild our film (an Edit & Documentary style's material tools in `demo/tools/` come first: AGENTS.md, "Treatment first"). In skill mode, get the source with `sh <skill folder>/scripts/setup.sh demo <slug>`. Copied demo code often reaches the library with `../..`: replace that with `$LIB` or absolute URLs.


## 原作者媒介陷阱与经验摘录

## 9. Pitfalls of the medium

- **Shading creeps in.** Soft gradients make objects look plastic; model with the rim band and white-lead strokes only.
- **Flat-illustration drift.** Thin lines, no white dots, gold as plain yellow discs: the picture turns into a modern vector illustration. Keep the ink firm, add white-lead dots, show the leaf squares.
- **Gold everywhere, lit all the time.** If gold shines all the time, the light has nothing to reveal. Keep gold dark until its moment.
- **The white-out climax.** Pushing the lit leaf's brightness up (or adding a big glow) turns the brightest moment into a yellow-white blur and erases the leaf squares. Light the climax with more gold, not with more white: rings, squares lighting in turn, a capped gold tone.
- **Day by brightening.** Raising the whole frame's brightness or saturation, or turning the night sky light blue, to show that the light came back looks like a colour-correction slip and kills the deep ultramarine. The sky stays deep; the gold does the work.
- **Wandering subtitles.** A scroll that jumps between left, centre and right, or changes width with each line, reads as an error. Fix its place and size; move the camera or the hero instead.
- **Picket-fence mountains.** A row of spires of the same height reads as a fence. Group spires in clusters (one tall, smaller ones leaning off it), vary the gaps, and stack two or three ranges, paler and smaller behind.
- **Stacked-box mountains.** Rectangular ledges read as buildings; spires must lean and taper, with small stair-steps on both flanks.
- **The hero as a nun.** A hood over the face makes a small figure read as a nun or monk; keep the face and hair visible.
- **Blackletter legibility.** Grenze capitals are hard to read; set display capitals in Uncial and keep Gothic for lowercase words. Never set Chinese or long English in blackletter.
- **Fake Latin.** Use real public-domain Latin sentences or none.
- **Infinite zoom seams.** A single texture stretched over a big push turns to mush; regenerate the leaf at the zoomed region's resolution.
- **Render state.** Canvas state and cached patterns leak between frames; reset the context every frame and clear offscreen buffers.


