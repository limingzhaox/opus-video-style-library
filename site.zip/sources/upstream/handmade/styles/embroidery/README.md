# Wool embroidery

A long embroidered hanging, wool on linen, that the camera travels along. Everything is drawn with the 2D canvas,
stitch by stitch, and what makes it read as needlework is how it's made, the way a real piece is worked. The linen
is a woven texture with slubs and faint foxing. Each patch of colour is wool *laid and couched*, as the Bayeux
Tapestry was worked: long parallel threads, each shaded along its twist with its highlit side turned to the light,
tied down by thinner threads in a staggered pattern, with loose fuzz on top and a soft shadow under the patch. Every
shape is outlined in *stem stitch*, one overlapping stitch at a time. Faces and hands are bare linen with an outline.
Leaves, fruit and flowers are *French knots*. Light and wind are *couched gold thread*: two metal plies held down by
small red ties. Because the outlines are separate stitches, a piece can be recorded and then *sewn in on screen*: the
outline runs round first, then the wool is laid row by row. Skies can be laid too: a mist of wool laid thin in bands,
with bands of light in couched gold drifting across it; and the far distance can hang from the top of the sky, its
houses upside down. The hanging hangs from a rod in a dim hall; whenever the camera stands back you see the hall, the
rod and the whole cloth.

The demo is Christina Rossetti's "Who Has Seen the Wind?", so it only shows wind through what it moves. A windmill
turns and smoke streams off a chimney while two people meet on the road, and a gust takes one's hat; overhead, a country
hangs upside down from the top of the sky, and the wind takes the smoke falling from its chimneys. Orchard trees are
sewn in, their knot leaves tremble, and washing lifts off the line. A kite is sewn into a child's hands and goes up
over a lake. Then, under a dusk sky of mist with bands of light hurrying across it, a row of trees on a ridge bows as
the gust goes along it. Gold wind lines are stitched in on the beat and unpicked as the wind passes.

![The hanging close up: a windmill on a hill, a thatched cottage with smoke streaming off the chimney, two people meeting on the road, one holding his hat on and one with a red cloak blown out behind, gold wind lines couched across the sky, and at the top right a country hanging upside down from the sky, its houses and trees pointing down](img/hero.jpg)

| | |
|---|---|
| ![Orchard trees being sewn in: one crown finished, one with its wool half laid, one only outlined](img/sewing-in.jpg) | ![Washing flying off the line in a gust, a woman holding a basket, French-knot leaves on the trees](img/washing.jpg) |
| ![A row of poplars and round trees bowing in turn as a gust passes under a lavender and gold sky of laid mist, bands of light slanting across it, a shepherd with a lantern leaning into the wind](img/ridge.jpg) | ![The whole hanging on the wall of a dim hall, with the poem's title in the band beneath](img/hall.jpg) |

## Looks in this family

The style lab draws the same three moments of the demo in three media, from the same scene code:

- **Wool on linen**, the look of the demo. ![The ridge in wool on linen](img/look-wool.jpg)
- **Paper theatre**: coloured papers cut and set in layers, lit from the front, each layer casting a soft shadow on
  the ones behind, gold tissue for light. ![The ridge as a paper theatre](img/look-paper.jpg)
- **Fresco**: earth pigments brushed onto lime plaster, distance paled into haze, then the wall's age on top: a red
  painted frame, cracks, patches where the paint has come away. ![The ridge as fresco](img/look-fresco.jpg)

## Run the demo

```bash
python tools/serve.py
```

Then open `http://localhost:8000/styles/embroidery/index.html`. It plays live in the browser (built and tested in
Chrome). The page takes two or three seconds to stitch the hanging ("Preparing"), then press Play. Space plays and
pauses, and the bar scrubs. If the audio can't load, it plays on a silent clock. Add `#t12.5` to the address for a
still of 12.5 seconds with the page furniture hidden. Changing only the hash redraws but doesn't reload, so after
editing a script reload with a new query, e.g. `?r=2#t12.5`.

Stills with a contact sheet, and an MP4 (from the repository root):

```bash
python tools/still.py styles/embroidery/index.html 2 7.7 12.2 16.7 0:37.5:2.5 --out renders/stills --sheet
python tools/render_mp4.py styles/embroidery/index.html --fast      # 720p preview
python tools/render_mp4.py styles/embroidery/index.html             # 1080p and 720p
```

A `--fast` render of the whole 37.5 s (900 frames) takes 40 to 50 seconds on a quiet Mac, 45 to 52 ms a frame, most
of it reading frames back and encoding; with other renders running on the same machine it took three minutes. The
full-quality encode is slower because of its slow encoder preset, not the drawing.

## How it works

### Files, in load order

| File | Job |
|---|---|
| `core.js` | Frame size (a 1920x960 picture over a 120 px lyric band), math and easing helpers, seeded random (`mulberry32`, `hashi`), value noise (`vn2`, `fbm2`), colour helpers, shapes (`shp`, `spline`, `resample`, `blob`, `archPts`, `wave`, `jitterRing`...), the bend geometry (`bendFrame`, `bentAt`, `bendPoint`) and fonts. |
| `../../examples/poem/lyrics_data.js` | The song: `window.SONG` (title, credit, audio, duration, bpm, lines with word times). |
| `figures.js` | Whole people from a pose: `figure(o)` in side view and `sitter(o)` seated behind a table, facing out. Both return a list of items. |
| `props.js` | `drawItems(S, items)`, and things drawn through a style object: land (`island`, `terraces`, `iceCliffs`, `tuftTree`, `cypress`, `fruitTree`), skies and the far distance (`mistSky`, `hangLand`, `curlLand`, `stormLid`), buildings (`roofTiles`, `arcade`, `windowLit`, `cottage`, `windmillTower`), furniture, `lantern`, clouds and storms, and the things the wind moves (`windmillSails`, `windTree`, `washing`, `kite`, `boat`, `weathervane`, `windPath`). |
| `stitch.js` | The renderer. The wool palette `WOOL`, the semantic map `SW`, outline wools `OUT`; the linen; laid-and-couched tiles; single stitches (`drawStitch`), knots (`drawKnot`, cached as stamps by `stampKnot`), couched gold (`drawGoldThread`, `drawGoldPath`); and `StitchStyle(g, opt)`, the style object. |
| `world.js` | The demo's hanging: its size (`WX0`, `WX1`), where each scene sits (`SPAN`), one painter per scene (`drawMill`, `drawOrchard`, `drawKite`, `drawRidge`), the cast (`CAST`, `POSE`, `WALK`), `buildSprites()` for everything that moves, and `buildWorld()`. |
| `shots.js` | The demo's choreography: the camera (`SHOTS`), the hall's light, the wind (`windAt`, `GUSTS`), the gold wind lines (`GOLD`) and what each scene draws when (`contentBack`, `contentFront`, `contentLights`). |
| `engine.js` | Everything generic: camera and dissolves, drawing baked cloth and sprites, bending sprites, sewing in, gold, lamps, weather, skies drawn live (`drawGoldBands`, `drawCurtains`, `drawTintMotes`, `drawBolt`), the hall and rod, the lyric band, `renderFrame`, playback and `window.__video`. |

### The style object

Scenes never draw directly. They call a style object `S`, which the lab can swap for paper or fresco:

```js
const S=StitchStyle(g,{rec,lamps,width,seed,noShadow});
S.layer(depth)                        // 0 far .. 1 near; under .2 the wool is laid sparse (open threads, linen between)
S.fill(shape,col,{dir,role,out,weave})// lay wool of colour col, threads running at angle dir, soft shadow, stem-stitch outline
S.line(pts,col,w,{role})              // w >= 5.5 a laid ribbon; w < 2.4 or role 'feature' a fine running line; else stem stitch
S.dot(x,y,r,col,{role})               // r <= 3.4 a French knot, bigger a satin-stitched round
S.glow(x,y,r,'lamp',a)                // a lamp: with opt.lamps it is recorded, and the engine lights it live
S.light(shape,{shaft})                // couched gold over an area
S.windLine(pts)                       // couched gold along a path
S.goldLine(pts)                       // couched gold thread point to point (the rim of a cloud bank)
S.run(pts,col,w,len,gap,off)          // running stitches len long with gaps between (wisps of mist)
S.borders(x0,x1,motifs)               // the bands along the top and bottom, with little motifs between slanting bars
```

A shape is `shp(rings)`: one or more closed rings of `[x, y]` points, with its bounding box and a cached `Path2D`.
Colours are semantic: a scene says `'roof'`, `'leaf'` or `'coatBlue'`, `SW` maps that to a wool in `WOOL`, and `OUT`
gives each wool the wool its outline is sewn in. `'skin'`, `'sky'` and `'road'` map to `'linen'`, bare cloth: the wool
is taken away and only an outline is sewn. `role` changes a few things (`'skin'` gets a finer outline, `'feature'`
lines are fine running stitch for eyes and brows). `out:false` lays wool without an outline, for shading inside
another shape.

### The hanging: baked cloth and sprites

The cloth is 960 world units tall; the demo's runs from x = 0 to 9600, four scenes of 2400 each (`SPAN`). At load,
`buildWorld()` paints each scene into its own canvas at `SC` (1.3) times its size, so shots up to about 1.3x zoom stay
sharp, then sews on its borders. `mipChunks()` keeps half and quarter copies for wide shots. The joins between scenes
are hidden by divider trees of the kind old hangings use, drawn as sprites standing on each join.

Anything that moves is a sprite: `makeSprite(bb, draw, {record, sc, pad, seed, depth}) -> {c, x0, y0, w, h, rec, sc}`,
a canvas plus where it sits in world units. `figSprite(o)` and `sitSprite(o)` wrap `figure` and `sitter`. With
`record:true` the outline stitches are kept in `s.rec` instead of drawn, which is what sewing in needs; at load every
recorded sprite also gets `s.full`, its finished look.

### Skies and the far distance

Laid in the cloth (props.js, drawn through `S`, so the lab's looks draw them too):

- `mistSky(S, x0, x1, y0, y1, seed, {bands, masses})`: a sky of mist. Broad bands laid thin, lavender above, rose and
  gold toward the land, with softer masses drifting in them and wisps of running stitch. It lays at depth .1, where the
  wool is sparse and the linen shows through: that reads as unfinished on one flat colour, and as mist in soft bands of
  close colours. The ridge's dusk sky.
- `hangLand(S, x0, x1, yEdge, depth, seed, {lobes, peaks, houses, houseW})`: country hanging from the top of the sky.
  Its ground faces down, so its fields are seen from below, its trees and a mountain or two point down and its houses
  stand upside down with their windows lit. It returns `{edge, chimneys}`: the demo draws the chimneys' smoke live,
  falling "up" for the houses (down for us) before the wind carries it off, in `millBack`.
- `curlLand(S, cx, cy, R, th, a0, a1, depth, seed, {house, houseW})`: fields curling up at the edge of the world like
  the inside of a bowl, trees and a house standing square to its inner face.
- `stormLid(S, x0, x1, y, depth, seed, {drop})`: a bank of cloud come down low like a lid, its underside billowed as old
  hangings carve a cloud bank and rimmed with couched gold; it returns the rim, for a live shimmer along it.
- `iceCliffs` are banded like a glacier's face.

Drawn live over the cloth (engine.js):

- `drawGoldBands(region, bands, clock, yT, yB, a)`: broad bands of light drifting across a sky and the land under it,
  clipped to a polygon: a thin laid gold the cloth shows through, a warm wash, a thread couched along each edge, a sheen
  running down each. Over the ridge they ride a wind clock, so they hurry in the gusts:
  ```js
  const RIDGE_LIGHT={region:[[7220,70],[9580,70],[9580,610],[7220,610]],bands:[{off:0,speed:44,w:180,ang:.34},{off:900,speed:36,w:130,ang:.4}]};
  RIDGE_C=windClock(8400,.3,1);                                   // .3 + the wind at x 8400, summed at load
  drawGoldBands(RIDGE_LIGHT.region,RIDGE_LIGHT.bands,RIDGE_C(t),70,610,.7);
  ```
- `drawCurtains(sky, t, {rows, a})`: an aurora hung in curtains of running stitch that ripple and brighten along
  their length, clipped to a night region `{poly, x0, x1, y0, y1}`.
- `drawTintMotes(x0, x1, y0, y1, n, t, seed, {strings, glow, k, drift, flow, a})`: points of light as tinted knots
  (teal, green, violet, pale gold) with a soft glow, drifting, never rayed, the first few strung in short lines.
- `drawBolt(x, yBase, yTop, t0, t, seed)`: lightning going up from the land into a storm, a jagged stitched bolt with
  a branch and a glow, for half a second after `t0` (a drum hit).
- `windClock(x, base, k)` (shots.js) sums `base + k * windAt(x, t)` once at load, for anything that should move faster
  in a gust without jumping: the sails' angle and the ridge's bands of light both ride one.

The demo uses the mist, the hanging country (with its live smoke) and the bands of light; the curtains, motes, bolts,
the cloud lid and the curling land are ready for a night or a storm.

### Figures

`figure({x, y, h, face, pose, dress, hairStyle, hat, ear, wind, props, anchors, child, wings})`
builds a whole person standing on `(x, y)`, `h` tall, facing `face` (1 right, -1 left). The pose is angles in degrees
(`lean`, `head`, `hipF`, `kneeF`, `hipB`, `kneeB`, `sit`) and two arms, each either `{a, e}` (shoulder and elbow
angles) or `{t:[x, y], bend}`, a hand target in units of `h` from the feet, reached by two-bone IK. The dress is a
garment type (`tunic`, `coat`, `robe`, `dress`) and semantic colours; `wind` pushes the hem downwind. Props:
`pack`, `basketBack`, `lantern`, `staff`, `books`, `tool`, `saw`, `breadBasket`, `mallet`, `washBasket` and `cloak`
(`{type:'cloak', lift, wind, flap}`: lift 0 hangs down the back, 1 streams out level). Pass an object as `anchors`
and it comes back with the world positions of the neck, head, hip and hands, to hang a lantern or tie a kite string to.
Walks are four poses (`WALK`) shown at 8 frames a second by `walkAt()`, which steps the position with them: it reads as
stitched frames, not smooth animation. `CAST` and `POSE` in `world.js` hold the demo's people, so the video and the lab
pose the same cast.

### Shots, the camera and dissolves

```js
// 'But when the leaves hang trembling': the orchard, close; then on through it to the washing
{t:10.95,fade:.6,keys:[[10.95,2960,600,1.42],[15.0,3300,600,1.42],[17.0,4200,520,1.18],[19.2,4330,520,1.14]]},
```

A shot starts at `t` and, with `fade`, dissolves in over the one before (here from 10.95 to 11.55, around the line's
start at 11.25). Its keys are `[time, x, y, zoom, ease power]`: the camera centre in world units and the zoom. Zoom 1
shows the cloth's full height; below 1 the hall shows round it; a close shot is clamped so it never shows past the
cloth's top or bottom. Between keys the camera eases (`easeIO`, bent by the optional fifth value) and the zoom moves in
log space. During a dissolve `renderFrame` draws both shots and mixes them.

### What happens when

After the baked cloth, the engine calls three functions from `shots.js`: `contentBack(t, ta)` (sky, sails, crowns,
washing, bent trees), `contentFront(t, ta)` (people, the kite, blown leaves, gold wind lines) and, after the hall's
dimming, `contentLights(t, ta)` (lamps, so they glow through dusk). The tools they use:

- `drawSpr(s, x, y, alpha, rot, pivot)`, `drawFig(s, x, y, alpha)`, and `poseSeq([[time, sprite], ...], t)` for
  cross-fading poses.
- `stitchIn(s, t0, dur, t, out)`: sews a recorded sprite in on screen, outline first, then the wool row by row;
  `out: [t, dur]` unpicks it again.
- `drawBent(s, ax, root, up, ang, alpha, rot, n)`: bends a sprite along its length. It cuts the sprite into `n`
  strips, each drawn as two textured triangles on a bent centre line (`bendFrame` in `core.js`). Trees grow up from
  their root; washing hangs down from the line. `ang(u)` is the bend at `u` along it; `rot` is how far the strips turn
  with it (1 bends like a stem, 0 only shears, like cloth blown out sideways).
- `drawGust({pts, t0, lay, hold, keep}, t)`: a gold wind line, laid from tail to head (a glint at the needle), then
  unpicked from the tail as the wind passes; `keep` leaves it sewn.
- `drawBlown`, `drawGrass`, `drawBird`, `runStitches` (moving running stitches: smoke, water, a kite string),
  `drawBand` (a band of couched gold with a sheen: the light on the lake), `drawAurora` (rows of stitches whose
  brightness travels: the ridge's wind streaks), `drawLamps`, `lampGlow`, `lampRays`, `sparkle`. Unused by the demo
  but ready: `drawRays` (gold shafts laid one by one), `drawSnow`, `drawBees`, `drawMotes`, `shadeRect`, and the live
  skies above (`drawCurtains`, `drawTintMotes`, `drawBolt`).

The wind is one function, `windAt(x, t)`: a base that follows the tune's own swell of wind noise (it rises and falls
every 7.5 s), plus the `GUSTS`, each a bump moving along the cloth. Trees bend by it, washing lifts, leaves tremble,
the sails turn (their angle is summed from the wind once at load), smoke streams and lamp flames gutter, so one gust
moves everything it passes in turn.

### Lyrics and title

`LYRICS` is built from `SONG.lines`: each line shows from 0.45 s before its first word until the next line comes in
(or 2.6 s after its last word, if that's sooner), and each word lights up as it's sung. The band is drawn in screen
space under the picture, so camera moves never touch it. The intro shows `SONG.title` and `SONG.credit` there as the title card (0.3 to 3.3 s).

### Determinism and caching

The song time `t` is the only input: no `Math.random()`, and every random choice comes from a seeded generator or a
hash of fixed numbers. Nothing carries from one frame to the next, so `step(t)` and `renderAt(t)` draw the same
picture and frames can be drawn in any order. Baked at load: the scenes and their smaller copies, all sprites and their
finished looks, the hall's wall, the lyric band's paper, and the sails' angle table. Built on first use, then kept: a
laid tile for each wool and mode (`TILE_CACHE`), a stamp for each knot colour and size (`KNOT_CACHE`), the glow of
the gold band, and the resampled gold paths.

## Make your own video in this style

1. Copy the folder and follow [your-own-video.md](../../docs/your-own-video.md) to time your song:
   `cp -r styles/embroidery projects/my-song`, then make `projects/my-song/lyrics_data.js` with the pipeline in
   [timing.md](../../docs/timing.md) (it ends with `tools/audio/to_js.py`) and point the page's lyrics script at it.
   Change the page title and heading in `index.html`.
2. Keep `core.js`, `stitch.js`, `figures.js`, `props.js` and `engine.js`. Replace `world.js` and `shots.js`: they
   are the demo. Delete `lab/` unless you want to try other looks.
3. Lay out the cloth in `world.js`: set `WX1` and `SPAN`, write a painter for each scene (`drawMill` is a readable
   model: back to front, with `S.layer()` before each depth), add it to `buildWorld()`, and put a tree in `DIVIDERS`
   on each join. Leave room at the ends of a scene you'll frame closely, or the next scene shows.
4. Add what moves in `buildSprites()`: people with `figSprite(cast(...))`, props with `makeSprite(bb, S=>...)`, and
   `record:true` for anything to be sewn in on screen.
5. Write `SHOTS`: one shot per line or two, dissolving on line starts (`fade` .5 to .6, starting .3 s before).
6. Draw the moving things in `contentBack` and `contentFront`, and time them to the song, not to seconds you typed:
   ```js
   const KITE_UP=word(4,4);                              // line 5, word 5 ('wind?'): the kite goes up
   const CROWN_T=[.05,.3,.55,.8].map(d=>lineAt(2)+d);    // crowns sewn in one after another as line 3 starts
   const GOLD=[[21,2540,470,1100,1], ...];               // a gold wind line laid from beat 21 (13.125 s), kept
   ```
   `word(line, w)`, `lineAt(line)` and `beat(n)` are at the top of `shots.js`. Put hits on beats and changes on line
   starts. (Until you rewrite `shots.js`, a line or word your song doesn't have falls back to its last one, so the
   demo still plays under your lyrics.)
7. Check stills often (`tools/still.py ... --sheet`), then render.

Useful knobs:

- `SC` (world.js): the bake scale. Raise it if you zoom past about 1.3, at the cost of memory.
- `WOOL`, `SW`, `OUT` (stitch.js): the palette. Keep it small; semantic names keep scenes readable.
- Depth: anything under `.2` is sparse laid work. Good for far hills; a big sparse area of one colour (a sky) looks
  unfinished, but laid in soft bands of close colours it reads as mist (`mistSky`, and its `bands`).
- `LIGHT` (stitch.js): the direction of the light; every laid thread turns its highlit side toward it.
- `windAt`, `GUSTS`, `swell` (shots.js): how hard it blows, where and when. `treeBend` and the washing's `lift`
  turn wind into bend.
- `drawBent`'s `n`: more strips bend more smoothly and cost more.
- `walkAt(..., fps)`: 8 gives the stitched-frames feel; 6 is a trudge.
- `hallLight` and `roomDim`: the hall's light, and dimming the whole picture for dusk.
- `RIDGE_LIGHT` and `windClock(x, base, k)` (shots.js): where bands of light drift, how wide, how fast, and how much
  a gust hurries them; `drawGoldBands`' last argument is their strength.

## Lab

Open `http://localhost:8000/styles/embroidery/lab/index.html` and pick a scene and a look with the buttons, or link
straight to one with `?scene=ridge&style=paper`. Render all nine stills and a sheet:

```bash
python tools/lab_stills.py styles/embroidery/lab/index.html --all --out renders/lab --sheet
```

The lab loads the video's own `core.js`, `figures.js`, `props.js`, `stitch.js` and `world.js`. `lab/scenes.js` draws
the video's scene painters through `warpStyle(S, f)`, which moves every point before it reaches the style:
`shiftTo(ox)` brings a window of the cloth into the frame, and `bentStyle(S, B, ox)` bends shapes through a
`bendFrame`, the same geometry the video uses to bend baked pictures. Then it adds, held still, what moves in the
video: sails turned, the people, lifted washing, bowing trees, wind lines. A scene is `{line, lit, draw(S)}`: `line` is
the poem line shown in the band and `lit` how many of its words are lit.

- **Wool** (`StitchStyle` from `stitch.js`): as in the video. The lab adds the soft folds and vignette the video
  draws live.
- **Paper** (`lab/style_paper.js`): every `S.layer()` depth becomes its own canvas. Pieces are filled with a tinted
  paper texture and their cut edges catch the light on one side. At the finish each layer drops a blurred shadow on
  the layers behind, offset by the depth gap between them, and a warm lamp gradient goes over everything. Lamps and
  light are yellow tissue on an overlay. `PAPERC` maps semantic colours to papers.
- **Fresco** (`lab/style_fresco.js`): each fill is painted into a scratch canvas as a pigment wash with brush strokes
  along its direction (leafy dabs for foliage) and ragged edges, then laid on a plaster ground; distance is paled toward
  the haze. The finish lets the plaster show through, then adds worn patches, the joins between days' work, losses,
  cracks, grime and the red frame. Colours come from `PAPERC` with pigment overrides (`FRESCO_OVR`).

## Performance

- **Build:** 2 to 3 seconds (four scenes and 68 sprites), up to 9 when the machine was busy.
- **Frames:** 25 to 40 ms for a close shot and 60 to 70 ms for the widest, measured with a GPU sync on a Mac running
  other renders. A dissolve draws two pictures. The MP4 tool adds reading each frame back and encoding it.
- **Memory:** about 82 MB of baked cloth (four scenes at 1.3x, with their half and quarter copies), 46 MB of sprites
  and 22 MB of working canvases.
- **What costs:** bent sprites (each is `2n` clipped triangles; the ridge alone is 7 trees of 26 strips), hundreds of
  knot leaves a frame (stamped from the cache), wide shots with every scene in view, and dissolves. The skies cost
  little: the mist and the hanging country are baked into the cloth, and three bands of light are a few fills a frame.
- **The latest whole `--fast` render:** 900 frames in 70 s (about 78 ms each, with other renders running).
- **A slice:** `python tools/render_mp4.py styles/embroidery/index.html --start 26 --end 34 --fast`, or stills of
  just that stretch (`still.py ... 26:34:.5 --sheet`).

## Lessons and gotchas

- **Bending by rotating strips leaves a fan of gaps.** Rotated strips pull apart at their outer ends. Draw each strip
  as two textured triangles that share their corners with the next strip (`drawBent` does), clipped a hair wide so
  neighbours meet.
- **Overlapping masses with an outline each look tangled.** Outline one silhouette, and lay the darker and lighter wool
  inside it without outlines (`out:false`). A lobed edge reads as foliage.
- **Knot leaves vanish green-on-green.** Use lighter and yellower greens than the crown under them, and a few flowers.
- **Sparse laid work looks unfinished on big areas.** Anything under depth .2 is sewn sparse; keep that for distance,
  or for mist: laid in soft bands of close colours, with a few wisps of running stitch, the same thinness reads as a
  sky of mist.
- **Joins between baked scenes** show as hairlines and jumps in the landscape. Stand a divider tree on each join, as a
  sprite so it isn't cut in two, and fill a flat linen colour under the whole cloth first.
- **A close shot near the end of a scene shows the next scene.** Keep what you'll frame closely well inside its span,
  or widen the scene.
- **Draw order is depth.** A sprite drawn in `contentBack` goes behind anything drawn after it; if something must stand
  in front, draw it later or in `contentFront`. A chimney drawn before its roof has to rise above the ridge to show.
- **Poses read bluntly in wool.** A tool raised over another figure's head reads as a threat whatever you meant; keep
  tools low or reaching away from people. Small changes need to be obvious: move the camera in when one matters.
- **Dusk on one scene leaves a hard edge where the next begins.** Dim the whole picture (`roomDim`) instead.
- **Things that drift must stay on the cloth.** Clouds drifting past the ends of the hanging hang in the hall; clip
  moving sky to the cloth.
- **Long straight gold rays in open land read as poles or ladders.** Keep rays for light through an opening; show open
  light as a band on water or a field. Broad bands of light across a sky work when they're mostly the cloth seen
  through thin gold, with their couched edges faint and the whole band drifting; at full strength their edge threads
  read as panes or straps.
- **Never fade to a blank frame.** The end dims the hall but stops short of black.
- **Holds read as a frozen player.** Keep something moving in every shot: a slow camera drift, flickering lamps,
  folds in the cloth, clouds, the wind.
- **Test exact event times.** The MP4 tool samples mid-frame, so a bug at the exact start of an event (a gold line
  whose needle has no path yet) can hide until someone asks for a still at `#t13.125`.
- **`imageSmoothingQuality = 'high'` on sprites drawn from canvases** made wide shots eight times slower in Chrome.
  Leave it at the default; the baked cloth has its own smaller copies for wide shots.
- **Build everything at load.** A cache built on first use makes a hitch the first time a scene is seen; that's fine
  for knot stamps, not for whole scenes.
- **One bad value in a canvas gradient kills the whole frame.** Check the console after every change (`still.py`
  prints it).
- **`[hidden]` loses to `display: grid`.** The play overlay needs `.cover[hidden]{display:none}`.
- **A plain `python -m http.server` lets the browser run stale scripts.** Use `tools/serve.py`.
- **Everything baked into the sky sits behind every cloud.** The clouds are sprites drawn over the cloth, so far land
  laid into the sky (the hanging country) is hidden whenever a cloud drifts over it. Plan the clouds' paths clear of it.
- **On land that hangs upside down, everything obeys its own ground.** Its trees and a mountain point down, its houses
  stand on their heads with their roofs below them, and their smoke falls "up" for them, which is down for us, before
  the wind carries it off.
- **Points of light with rays read as stars.** Tinted knots with no rays, drifting slowly, a few strung in short
  lines, read as something stranger. And white knots of snow high on a dark sky read as stars too: keep the snow low
  when the sky is dark.
- **The lab's looks must know every call the painters make.** When a scene painter starts using a new `S` method (the
  mist's running stitches, `S.run`), add it to `warpStyle` in `lab/scenes.js`, or the lab draws it unshifted, off the
  frame, and give the paper and fresco styles their own version of it.
- **Live sky goes under what stands in front of it.** Bands of light, curtains and motes drawn over the cloth are drawn
  in `contentBack` before the divider trees and the figures, so they don't lay themselves over trees that stand in
  front of the sky.

