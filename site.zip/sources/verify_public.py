"""Verify anonymous access and deployed bytes without cookies or credentials."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib, json, time, urllib.request, urllib.parse
ROOT=Path(__file__).resolve().parent.parent
BASE=json.loads((ROOT/'publication.json').read_text(encoding='utf-8'))['siteUrl']
items=json.loads((ROOT/'styles.json').read_text(encoding='utf-8'))['styles']
files=['index.html','llms.txt','README.md','styles.json','prompts.json','publication.json','使用指南.md','AI使用说明.md','sources/gallery_ai.js','完整提示词总册.md','分享与外部访问.md','更新说明.md','ATTRIBUTION.md',items[0]['promptFile'],items[-1]['promptFile'],'images/'+items[0]['source']+'-'+items[0]['slug']+'.jpg','images/'+items[-1]['source']+'-'+items[-1]['slug']+'.jpg','sources/upstream/lemo/DIRECTOR.md','sources/upstream/handmade/CLAUDE.md']
sync=ROOT/'sources/last-sync.json'
if sync.exists():
    new_ids=set(json.loads(sync.read_text(encoding='utf-8')).get('newStyles',[]))
    for item in items:
        if item['id'] in new_ids:
            files.extend([item['promptFile'],item['localImage'],'sources/upstream/'+item['source']+'/styles/'+item['slug']+('/STYLE.md' if item['source']=='lemo' else '/README.md')])
manifest=ROOT/'可发布资料/.package-manifest.json'
if manifest.exists():
    files=json.loads(manifest.read_text(encoding='utf-8'))
files=list(dict.fromkeys(files))
def check(rel):
    req=urllib.request.Request(BASE+urllib.parse.quote(rel,safe='/')+'?verify='+datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S'),headers={'User-Agent':'OpusStyleLibrary-PublicCheck/1.0'})
    for attempt in range(3):
        try:
            with urllib.request.urlopen(req,timeout=60) as r:
                payload=r.read();status=r.status
            break
        except (OSError,TimeoutError):
            if attempt==2:raise
            time.sleep(attempt+1)
    expected=(ROOT/'可发布资料'/rel).read_bytes()
    assert status==200 and payload==expected,'Deployed bytes differ: '+rel
    return {'path':rel,'status':status,'bytes':len(payload),'sha256':hashlib.sha256(payload).hexdigest()}
with ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(check,files))
report={'checkedAt':datetime.now(timezone.utc).isoformat(),'siteUrl':BASE,'anonymousAccess':True,'allWhitelistedFilesChecked':manifest.exists(),'checkedFiles':results,'styleCount':len(items)}
(ROOT/'sources/public-verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'anonymousAccess':True,'verifiedFiles':len(results),'styles':len(items),'allBytesMatch':True,'siteUrl':BASE}))
