# 80 · 地铁线路图 / Transit Map

来源类型：官方风格原文 + 本库中文执行模板  
原作者：LemoLab  
上游原文：https://github.com/lemomo-ai/lemo-opuscar/blob/bebbbe1aa92a3cb4bb6f83500e61b23a17d1aa00/styles/transit-map/STYLE.md  
固定版本：bebbbe1aa92a3cb4bb6f83500e61b23a17d1aa00  
抓取核对日期：2026-11-03  
本库改动：中文任务模板、中文摘要与编排；原文全文保留。

## 使用前先看

- 重写 net.js 和 timeline.js；标签预先按完整网络排布，随缩放控制密度，先测 Canvas 到 WebGL 纹理在斜视时的清晰度。
- 真实站名、配色、日期与里程至少双源核对并留 FACTS.md；计数器只停在有据数值，不为凑密度编造线路。

- 这是代码渲染工作流；聊天文本本身不会自动产生 MP4，需有可执行的项目环境。
- 先看预览再做长片；不要把示例素材的许可自动套到自己的歌曲、照片、字体和品牌上。
- 下方复制区包含全部风格与公共规范，不要求 AI 另外从本机隐藏路径读取文件。

## 完整复制区

你是一位能写代码、检查画面并渲染成片的动画导演。请用“地铁线路图 / Transit Map”制作一个属于我的视频。

【我的需求；把花括号内容换成实际值】
主题与一句话故事：{{填写主题和结尾变化}}
用途与观众：{{例如面向普通观众的科普短片}}
内容依据或已有脚本：{{填写；没有则说明需要你写}}
音频、歌词、图片、数据、品牌素材路径：{{填写；没有写“无”}}
素材使用权限与需显示的署名：{{填写来源与许可；不清楚请列待确认项}}
目标时长：30 秒起步；MV 以实测歌曲时长为准
画幅与清晰度：默认横屏 16:9、1920×1080；帧率按本风格原文与引擎规范，未规定时24fps；竖屏须重新构图，不直接裁横屏
语言：简体中文；配音需求：{{有/无、声线与语速}}
必须出现的内容：{{填写}}
禁止出现的内容：{{填写}}
预算与速度：先做低成本验证，再渲染完整片
个人工程名：my-video（可改为英文短名）
确认方式：先给 3 张由真实渲染代码产出的样帧和 5–10 秒预览；我确认风格后再做完整成片

【本风格的核心实现】
在有纸纹和斜光的线路图上，以八方向圆角轨迹、发光笔尖、站点与换乘落章表现网络生长，透视镜头配合分级标签。
特别检查：
- 重写 net.js 和 timeline.js；标签预先按完整网络排布，随缩放控制密度，先测 Canvas 到 WebGL 纹理在斜视时的清晰度。
- 真实站名、配色、日期与里程至少双源核对并留 FACTS.md；计数器只停在有据数值，不为凑密度编造线路。

【工程与流程】
1. 在工作区单独克隆 https://github.com/lemomo-ai/lemo-opuscar ，检出 bebbbe1aa92a3cb4bb6f83500e61b23a17d1aa00，保留上游原目录供渲染工具和相对路径使用。图册只归档提示词文档，没有打包全部视频源代码。
在独立个人工程目录实现，参考 styles/transit-map/STYLE.md；不得把示例电影的故事、角色、文案、音轨当成我的需求。先读风格规范与 DIRECTOR.md、TECHNIQUE.md。
2. 先检查机器的 Python、Node/浏览器、FFmpeg、字体与 GPU 能力。Lemo 当前要求 FFmpeg 7+；先用 ffmpeg -version 核对。缺少工具或访问权限时明确报告缺什么，不能只描述完成、伪造文件或把截图称为已渲染视频。
3. 把我的需求写成 PLAN.md 或 TREATMENT.md：一句话故事、分镜、逐镜秒数、镜头运动、文字位置、音乐与声音 cue、所需素材、预计成本。涉及事实和数据时写 FACTS.md；没有来源的数字不填。
4. 按主题写旁白并实测音频时长；无需旁白时用画面和声音讲清楚。
5. 先完成 3 张代表开头、关键变化、结尾的样帧，逐张检查；再渲染 5–10 秒低清短段，检查字幕、运动、音画同步与控制台。复杂慢风格先计时，再估算整片。
6. 随机效果固定种子；有历史累积的媒介按顺序渲染。并行前先比较随机抽帧与连续渲染是否一致。
7. 正式导出使用项目文档中的工具与参数，不臆造命令。交付可播放 MP4、720p 预览、源代码、素材清单与许可、字幕（有台词时）、复现说明；保留最终片长、帧率、音频响度与实际渲染耗时。
8. 实际打开并检查成片开头、中间、转场、结尾及全片联系表，确认没有空帧、字体回退、遮挡、裁字、爆音或无意复制的作者片尾签名。交代尚未完成的检查。

下面是完整风格参考与公共制作规范。它们是上游参考资料，不代表我的主题或逐字台词；我的具体需求优先。风格中明确的声音、镜头和媒介限制优先于公共建议，例如无声电影不添加旁白或拟音。遇到 macOS/Linux 示例命令时按当前系统等价转换，不直接在 PowerShell 粘贴 bash 命令。相对资源路径以完整克隆的上游工程为准。


===== 完整风格原文：styles/transit-map/STYLE.md =====

# Transit Map — Style Prompt

> A metro schematic printed on a physical sheet: lines held to eight directions, white stops, black-outlined interchange capsules, water as a flat blue band. The network is drawn on by glowing pen tips while a real perspective camera moves over the paper: it rides a tip, drops low where a line dives under water, pulls back through levels of detail and sweeps across the densest knot at a low angle with a shallow focus.
> References (grammar only): the octilinear schematic tradition of metro diagrams (Beck's Underground diagram, Vignelli's New York map), the stamp of a printed cartouche, flatbed and macro photography of maps lying on a table. Copy none of their layouts, typefaces, icons or line bullets; never name them in the film.

## 1. Essence, and what it is not

- **Eight directions only.** Every line segment, river edge and coastline is horizontal, vertical or at 45°; every corner is one fillet radius. A line never wiggles.
- **Growth is drawing.** A line exists as far as its pen tip has travelled; stops light when the tip passes; an interchange appears only when the second line actually arrives, and it lands with weight.
- **Ink on a sheet.** The map is printed on paper with tooth and fibres, lit by one raking light, and the sheet lies on a dark table. The camera sees it as an object: in perspective, with depth of field, and with its edge in wide or low shots.
- **Words are printed.** Station names, callouts and cartouches are ink on the sheet; running numbers live on one small mechanical counter. Every text line holds one language.
- **One map, many scales.** The same sheet serves a single station and the whole network; detail appears and disappears with scale.

Not Data Storytelling (even a time chart is drawn as two lines with stops), not Blueprint (no white-on-blue linework), not Isometric Infographic (the map is flat; depth comes from the camera), not a 3D city map (no extruded buildings, no terrain), not a keynote (no slides, header bars, centred titles or page turns).

## 2. Materials & rendering

**The unit is the grid step, G.** Every coordinate and size on the sheet is given in G. Named stations sit on a 0.1 G lattice and at least 0.7 G apart along a line; a city network spans about 30 × 30 G and the sheet adds margins for the cartouche and any printed panel (about 45 × 47 G in our demo). The camera's zoom is read in screen pixels per G at the focus point (1080p).

| Mark | Geometry (G) |
|---|---|
| Line | 0.15 wide, round caps; corner fillet radius 0.34 |
| Thin line (a second rail mode; ferry thread) | 0.07 wide; fillet 0.30 |
| Parallel lines sharing a corridor | each offset ±0.10 from the shared axis (0.20 centre to centre, 0.05 of paper between); three or more: 0.20 steps |
| Stop | white disc r 0.085, ring 0.046 in the line colour |
| Terminus | an ordinary stop; when the end of a line matters (a destination, an end card) a white ring r 0.15 with a 0.06 ink outline |
| Minor stop (generated tick) | white disc r 0.065, ring 0.036; at most one per 0.78 G of track |
| Interchange capsule | the bounding box of every line point at the station, padded 0.13 on all sides; corner radius = half the shorter side (a stadium); white fill; ink outline 0.055 (0.07 for a major hub) |
| River | a band 0.76 wide (0.70–1.0 for a big river) with a darker edge 0.025 each side, round joins; creeks 0.15 with 0.02 edges |
| Sea, bay, harbour, lake | a closed outline on the eight directions, any size, filled with the water colour; the same darker edge, 0.025 outside the fill. Where a ferry runs, at least 0.5 G of open water so its lane keeps water on both sides |
| Tunnel under water | the line dashed 0.16 on / 0.11 off, plus two ink casing lines 0.02 at 55 % opacity, 0.05 outside each edge of the line |
| Pen tip | white core r 0.11, ring 0.05 in the line colour, soft halo r 0.8 in the line colour (45 % at the centre) |
| Line bullet | rail: disc r 0.25 in the line colour; bus and ferry: rounded square 0.48 with corner radius 0.12. Numeral 800 weight, 0.27 (one figure), 0.22 (two), 0.15 (a short word); opening year 0.17 bold ink, centred 0.30 below |
| Vehicle | white capsule 0.40 × 0.14, ink outline 0.026, three windows 0.064 × 0.056 in the line colour; trains and buses at about 2 G/s, boats at 0.85 size and about 1.2 G/s |

- **Interchange shape follows the station.** Points side by side make a horizontal stadium, stacked points a vertical one; lines that cross at one point make a circle r 0.13 with the ink outline, which reads as an interchange next to the 0.085 stop because of its black edge. A capsule never rotates to 45°; a diagonal spread becomes a rounded square.
- **Two passes.** A 2D canvas inks only the region the camera sees into a texture (about 1.35× the screen density at the focus, capped at 4096², mipmapped, anisotropic filtering), limited in depth to a few camera distances so low views don't starve; a WebGL pass intersects each pixel's ray with the sheet plane, prints the ink onto procedural paper and computes depth of field from the plane's known depth.
- **Paper**: warm off-white, procedural and tileable, sampled in world coordinates so it never slides. Three layers: a cloud of value at about 9 G period with detail down to 0.04 G, a tooth at about 2.4 G period, and short fibres 0.02–0.1 G long. Paper value varies by no more than ±3 % (fibres darken up to 3 % more); ink is multiplied by the tooth so flat colour varies 7–10 % and is never flat. Stronger than this and the sheet reads as plaster.
- **Light**: one raking light from one corner of the sheet (north-west in our demo), about 33° above the paper, neutral in colour and fixed for the whole film; it lifts that corner about 7 % above the opposite one. A specular sheen (up to +10 %, narrow lobe) appears only when the camera tilts more than about 30° from straight down and is full at 65°. Warmth comes from the paper and the table, never from a tinted light.
- **The sheet edge** sits on a near-black warm table (about #1B1918) with a contact shadow that fades over about 0.2 G. Far away the table goes into a warm dark haze so the horizon never aliases.
- **Grade**: a light vignette (up to −24 % in the corners), a 1.02 gamma, a light film grain at the master; no colour cast, no bloom except the pen-tip halo.
- **Screen space only for the instrument** (the counter) and objects near the lens (a station plate standing on the sheet, a tunnel before the map). Everything else is anchored to the sheet.

## 3. Colour logic

- Neutral ground: warm off-white paper; ink near-black for text and interchange outlines; secondary text in warm grey; water one pale blue with a darker edge, its labels in a mid blue.
- **Line colours carry identity and nothing else.** A real network uses its published colours; an invented one picks hues spaced around the wheel at similar weight, never two neighbours alike.
- **Mode is carried by line form, never by hue.** Each line keeps its colour whatever kind of vehicle runs on it:

| Mode | Line | Stops | Bullet |
|---|---|---|---|
| Metro, suburban rail | solid 0.15 G | stop disc | disc with a figure |
| Another rail mode (tram, light rail, maglev, people mover) | solid thin 0.07 G | stop disc; no generated ticks | disc with a short word |
| Bus, BRT | hollow: 0.15 G wide, the colour as two edges of max(0.04 G, 2.5 px), a paper core of at least 2.5 px; in wide shots the line widens on screen to keep that. Colours lighter than 0.4 relative luminance (yellow, sand, light green) get an ink rim of max(0.015 G, 1 px) | named stops only, stop discs | rounded square |
| Ferry, boat | a 0.07 G thread in the line colour on a paper lane 0.25 G wide (at least 10 px on screen), solid, over open water; it starts at a pier on the water's edge, with at most 0.5 G over land | pier: white rounded square 0.17 G, ring 0.04 G in the line colour | rounded square |
| Under water or underground | the line's own form, dashed, with the ink casing (§2) | none inside the tunnel | — |
| Walking transfer, in a station complex | a white bar 0.06 G wide with a 0.055 G ink outline outside it (0.17 G overall) from capsule centre to capsule centre, under the capsules; each station keeps its own capsule (one line: the r 0.13 circle) | — | — |
| Walking transfer, through the street | ink dots of radius 0.015 G every 0.08 G between the two stations' own markers, no capsule added; the shared name is printed once, at the station the story arrives at | — | — |

  Dashes mean "below": a ferry is never dashed, a tunnel always is. The ferry's paper lane is what tells it from a tram at any distance (10 px of paper on blue in a wide shot); a tram never runs on water without a bridge, which is drawn as ordinary track.
- **Paper inside a line is never painted.** The paper of a bus core or a ferry lane is erased out of the ink layer (canvas `destination-out`), so the procedural paper of the print pass shows through with its own tooth and light; a paper-coloured stroke never matches it. Erasing removes every ink beneath, so order the ink: water → surface lines (bus, ferry) → rail lines → stops and capsules → labels. A bus core over water then shows paper (correct for a printed map), and a rail line crossing a bus line stays whole on top.
- **Red (or the oldest line's colour) is the story's accent**: the first section, the "you are here" dot, the stamp of a verdict. When the accent sits on a line of the same colour, the dot is r 0.17 G (more than twice the line's width) with a 0.04 G white outline and a pulsing ring, so it never melts into the line. A second, dark neutral (navy) stands for anything compared against.
- Light colours (yellow, lilac, aqua, light green, sand) carry ink inside bullets; deep colours carry white.
- A paper wash (veil, 60 % paper over the sheet) fades the network back when one part must lead; stations under it keep about 20 %; never a dark overlay.

Example (our demo): paper #F2EEE5, ink #1B1C1E, secondary text #4A4740, river #BCD6EA / #8FB5D6, river labels #5F88AD, accent #E3002B, comparison navy #24346E.

## 4. Type & subtitles

- **Faces**: a neutral grotesk for Latin and figures (Inter in the demo) and a CJK sans of matching weight (Noto Sans SC, subset to the characters used). OFL, self-hosted. Native language above, second language below, one line each, never wrapped.
- **Sizes on the sheet**, in G (native / second language): hub label 0.30 / 0.17 bold; interchange 0.23 / 0.14 semibold; named stop 0.20 / 0.14 semibold; the second line in warm grey, 0.03 G below. Callout: date figures 0.58 heavy, native line 0.34, second line 0.24. Printed panel titles 0.58–0.60 / 0.36–0.38. Cartouche title 0.64 / 0.30, its note 0.24 in grey. Water names 0.22 / 0.17, set along the band.
- **Labels**: a paper-coloured halo (0.05 G stroke at 92 %) under every label. Placement is automatic: eight candidates around the station's edge (in order of preference: east, west, north-east and south-east, north and south, north-west and south-west), each scored against every line of the **finished** network and against labels already placed, hubs and interchanges first. It runs once, before the first frame, so a label never jumps while lines are drawn and lines that arrive later never cross it. A hand preference may override the score for a few stations.
- **Levels of detail by zoom**: minor stops fade in between 55 and 85 px per G, interchange names between 62 and 90, named-stop names between 100 and 130; hubs keep their names at every scale and grow when pulled out (× (85 / zoom)^0.6, at most 1.75), anchored to the station edge so they grow away from it without changing side. Which names show may also be chosen by shot, never flashed by time. While the camera rides a tip, names leave the frame before they can be read: show them in the held shots that follow, not during the ride.
- **Legibility is measured where the text lands**: font size on the sheet × the zoom at that point, foreshortened by the tilt. Text the viewer must read keeps the native line ≥ 20 px at 1080p and the second line ≥ 12 px (≥ 16 px on the counter); a two-line label counts only when its block is ≥ 26 px tall on screen. Below that, hide it by level of detail or move the camera.
- **Callouts** are printed on the paper: a bar 0.10 G wide in the accent (or the line being drawn), then the date in heavy figures, one native line, one second-language line; they wipe on from the bar in about 0.5 s. When a callout must sit over lines it gets a paper-coloured block with a soft shadow, no border.
- **Cartouche**: in one corner of the sheet, an ink bar, the map's name in both languages and a one-line note in grey. It is furniture: the camera finds it, it is not a title card.
- **The film's title is printed on the map.** At the start the title appears in the map's world: the cartouche (the map's name is the film's title), a line bullet, a station name plate by the lens, or a printed callout. Never a card or caption floating over the picture. It is bilingual like every printed text (native line above, second line below, one line each) and is held for its reading time where it lands (sizes and legibility above).
- **The film closes on the whole network.** The last shot shows the finished network entire, in top view or a gentle tilt, every line drawn; the end title and any credit are printed on the sheet (the cartouche, or a block in a margin, in the map's own type and ink), never laid over it. A detail the story ends on (a terminus, a first section) comes before this view, not instead of it.
- **The counter**: a dark enamel plate in the top-left corner (about 660 px wide, 86 px per row, rounded 14 px, four screws), rows with the native label above (24 px), the second label below (17 px), cream rolling drums (38 × 60 px, heavy figures), units at the right. Drums land only on sourced values; in between they spin blurred so no invented figure can be read.
- Reading time: hold every line ≥ (CJK characters ÷ 4.5 + other characters ÷ 15) + 1.5 s.

## 5. Motion quality

- 30 fps. Pen tips move on monotone keyframes; a tip may slow on a station and accelerate between them, never stop dead mid-segment.
- Stops pop from 0.6× with a small overshoot in about 0.28 s and a ring in the line colour that spreads from 0.10 to 0.42 G and fades in 0.6 s. Minor stops pop the same way at a smaller size.
- Interchanges scale down from 2× in 0.22 s with an ink ring spreading to 0.64 G. A major interchange falls from above in about 0.4 s (from 3.4× its size, its shadow offset and blurred, sharpening as it lands), then rings in ink and in the colours of the lines that met spread to 1.4–2.6 G in 0.9 s.
- Line bullets spring in with a back ease and carry the opening year; they fade when the story moves past their chapter.
- Vehicles (§2): white capsules at a constant speed, one per 4 G of track in each direction, only on finished track; boats slower than trains and buses.
- A line that starts from a station already on the map makes it an interchange the moment its tip leaves; start that tip at least 0.5 s after the first line has reached the station, so the capsule's fall reads as an arrival.
- What never moves: the geometry of anything already built, label positions, the paper and its light.
- A still of the style shows the medium in motion: at least one pen tip with its halo or trains on finished track, the counter landed, and a tilted view with depth of field.

## 6. Camera grammar

A pinhole camera with a 32° vertical field of view (about a 42 mm lens on full frame), aimed at a point on the sheet. **Tilt** is the angle from straight down (0° = top view); **heading** turns the view about the vertical; there is never any roll. Zoom is in px per G at the aim point; focus is always on the aim point. Depth of field is analytic: blur radius = aperture × |depth − focus depth| ÷ depth, in pixels at 1080p, capped at 26 px, so the far sheet blurs up to the aperture value and the near edge more.

| Move | Tilt / zoom / aperture | What it expresses | Can serve |
|---|---|---|---|
| ride the pen tip, aim about 1.5 G ahead of it | tilt 15–30°, heading within ±15°, 130–260 px/G for a tip at 1–3 G/s, aperture 16 | building, one step at a time | the first section; a single new line; a route described stop by stop |
| drop low where a line meets water | tilt ~60°, 185 px/G, aperture 26, eased in and out over ~0.5 s | crossing, risk, a threshold | a river or strait; a border; going underground |
| continuous pull-back with level-of-detail changes | tilt 12° → 0°, 80 → 50 px/G, aperture 6 → 0 | growth, scale arriving | years passing; a network filling in; "how big it became" |
| low oblique sweep with shallow focus | tilt 57–62°, heading swinging about 40°, ~100 px/G, aperture 24, inked depth extended | density, life, the present tense | the busiest core; everything running at once |
| glide across the sheet to another panel | tilt rises to ~25° mid-move and back to 0°, aperture up to 8 | changing the question, same object | a comparison chart; a legend; a timeline printed in the margin |
| rise until the sheet edge and the table show | tilt ~30°, ~40 px/G | the whole, the object | an overview; a chapter break |
| push in to one segment under a paper veil | tilt 4° → 0°, 60 → 140 px/G, aperture 3 → 0 | memory, origin | where it began; "you are here" |
| locked frame | tilt 0°, aperture 0 | reading, judging | any comparison or verdict (hold ≥ 2.5 s before the verdict) |

When riding a tip, keep tip speed × zoom at or under about 500 px/s on screen (a long, fast line means a wider zoom or a slower tip). The camera is never lower than about 25° above the paper (tilt ≤ 65°): lower, and the sheet stops reading as a map. Top views carry no blur; any tilt above 10° carries some.

Framing: the subject sits off-centre with room ahead of a moving tip; the counter owns the top-left corner and nothing important goes under it. Transitions: match cuts on round shapes (a headlight, a lamp, a coin becomes a station dot), glides across the sheet, hard cuts to a new panel. No page turns, no fades to black mid-film.

## 7. Sound palette

- **Tuned percussion** for drawing and stops: glockenspiel, marimba, vibraphone; a stop is a pluck, an interchange a pop with a low thump.
- **A two-note station chime** as the motif, returning at the turns of the story.
- **Layering by line**: each new line adds one voice to a running ostinato (flute, spiccato strings, xylophone, horn staccato, harp, trumpet, oboe…), so the arrangement grows with the network. Accelerate by adding voices, not by changing tempo; a groove written in film time never stretches when picture time is slowed.
- **Matter**: a felt-tip glide under every drawing tip; rail clacks in pairs for trains; ratchet ticks for the counter; a filtered, submerged mix while a line runs under water; a descending whistle and a low hit for a capsule that falls.
- **Silence**: one beat of near-silence before a verdict; the end thins to a pad and the chime.
- Mix: music under the effects, sub-bass shelved (< 50 Hz well below the rest), true peak ≤ −3 dBTP measured oversampled (ebur128 with peak=true; a sample-peak limiter misses the inter-sample peaks of short clicks and plucks, so soft-clip those first), about −16 LUFS before the master's −14.

## 8. Native moves

- **The pen tip.** A glowing tip draws a line at the camera's pace; stops light behind it. *Fits content like:* a product roadmap; a migration route; a career, job by job.
- **The interchange that falls.** When two lines meet for the first time (a second line arriving, or leaving from a station already drawn) the capsule drops onto the paper with its shadow, then shock rings in both colours. *Fits content like:* two teams merging; a treaty; two rivers joining.
- **The tunnel under the water.** Inside the water band a line turns dashed with a casing; the camera drops low to watch it cross. *Fits content like:* a cable under the sea; a deadline crossed; going public.
- **Time lines.** Two networks drawn as two lines over one year axis, stops at sourced milestones, brackets for the spans. *Fits content like:* two companies' growth; two countries' rollouts; a project against its plan.
- **Levels of detail.** Pulling back, minor stops and their names fade first, interchange names next, hubs stay. *Fits content like:* zooming from a street to a city; from a team to a company; from a gene to a genome map.
- **You are here.** The network fades under a paper veil, one segment stays lit, a red dot pulses. *Fits content like:* an origin story; a recap; a call to visit.
- **The odometer.** Rolling drums that land only on true values: a year, a running total, a time of day, a count. Each landed value must hold for its reading time (about 1.8 s for five characters), so plan about one landing per 2 s of film; more values than that go into printed callouts. *Fits content like:* kilometres, users, stores, sensors.
- **The plate by the lens.** A station name plate stands on the sheet near the camera, out of focus, as the low sweep passes it. *Fits content like:* a place that matters; a stop someone uses every day; a product's home.

## 9. Pitfalls of the medium

- **Off-grid geometry**: any segment not at 0/45/90° breaks the style. Route between points with an automatic bend (straight then diagonal, or the reverse) and validate every segment.
- **Labels over lines, or labels that jump**: give labels a paper halo and place them once against the finished network, before the first frame. Placing against what is drawn so far makes labels hop as lines arrive.
- **Parallel lines sharing a corridor** collide: offset each line by ±0.10 G and let one capsule enclose all points of the station.
- **Too much text in wide shots**: hide minor names by zoom, not by time.
- **A flat map**: a top view all the way through reads as a slideshow. Tilt, focus and the sheet edge are what make it an object; a still of the style should show at least one tilted view with depth of field.
- **Paper too loud**: tooth and fibres stronger than a few percent turn the sheet into plaster or canvas.
- **Mode by colour**: a ferry or bus line in a "ferry blue" breaks colour as identity. Use the line forms in §3.
- **Real networks**: published colours and station names are facts, logos and branded bullets are not; the film is an unofficial tribute and says so on screen. Check every date and length against official sources; encyclopaedia figures for opening sections are often for a different span, and stations are renamed (the data rule is in §11).
- **Counters that interpolate** invent numbers. Land only on sourced values; spin between them.
- **Texture resolution in tilted views**: limit the far distance of the inked region and let depth of field hide the softness.
- **Stale ink**: when the inked texture is reused, reset the 2D transform before clearing it, or last frame's ink ghosts every other frame.

## 10. Engine

The pipeline, independent of any code: (1) the network as data: stations with native and second-language names and a tier, lines as lists of stations, offsets and bends on the G lattice, water as bands and areas; (2) expand each route into an octilinear polyline, fillet the corners, measure arc length; (3) precompute everything time-dependent once: when each tip passes each station (by bisection on its keyframes), when a station becomes an interchange, label placement on the finished network; (4) per frame: camera → the region of the sheet it sees → ink that region into a texture (water, surface lines with their erased paper, rail lines, stops, capsules, labels) → lay it on the plane, print it on paper, light it, blur it by depth → draw the screen-space instrument.

In our demo (`demo/`), the engine is generic and the film lives in two data files:

- `gl.js`: `makePlane(canvas, paper)`: plane, paper, raking light, sheen, sheet edge, depth of field, vignette.
- `film.js`: the engine. Fillets and arc length (`rounded`, `pointAt`, `subPath`), water and tunnel intervals, generated minor stops, the four line forms (`MODES`, `surfaceLine`), piers, walking links, growth phases and light-up times, `placeLabels()`, bullets, the falling interchange, the camera (`basis`, `toScreen`, `toPlane`), the inked region (`regionFor`), events for the score, `window.TEXTS` for the reading-time check. It holds no network and no story.
- `net.js` → `window.NET = {G, ST, LINES, WATER, LINKS, pt, sid, expand}`. `ST`: `id: [x, y, native, second, tier]` (G; tier 1 hub, 2 interchange, 3 named stop, 4 unnamed). `LINES`: `{id, color, route, branch?, mode?: 'metro' | 'light' | 'bus' | 'ferry', bullet?, ink?, loop?}`; route items are a station id, `[id, dx, dy]` (an offset for parallels) or `[x, y]` (a bend), `'/'` puts the next bend diagonal-first. `WATER`: `{line, outer, inner, tunnel?}` bands and `{area, tunnel?}` outlines. `LINKS`: `{a, b, out?}`.
- `timeline.js` → `export const DATA` (and optionally `export const WARP`, film time ↔ story time). Required: `DUR`, `SHEET [x0, y0, x1, y1]` (world units, 100 per G), `PHASES` (`{path, a, b, t0, t1, year?, yearLabel?, keys?: [[t, station]...], lin?, bLast?, glow?}`), `camera(t) → {x, y, z, tilt, head, ap, focus?, far?, vig?, dim?}`. Optional hooks, each with a neutral default:

| Hook | Signature | Does |
|---|---|---|
| `LABEL_PREF`, `nameAt`, `labelOnly`, `forceLabel`, `hubLabelScale` | `{id: 'e'…}`, `(n, t) → [native, second]`, `t → ids \| null`, `(n, t) → 0..1`, `z → k` | label side, renamed stations, names per shot, forced names, hub growth |
| `noRoundel`, `roundelPos`, `roundelAlpha`, `roundelScale` | `[ids]`, `{id: [x, y]}` (G), `(t, id, z) → 0..1`, `z → k` | line bullets |
| `drops`, `dropRing` | `{id: true}`, `(c, n, k2, {capsule, INK})` | which interchanges fall; a custom landing |
| `veil`, `stationDim`, `highlight` | `t → 0..1`, `(n, t, veil) → alpha`, `(c, t, {PATHS, pointAt, subPath}, top)` | paper veil and the lit segment |
| `waterLabels` (or `riverLabels`), `furniture`, `annotations` | `(c, t, view, helpers)` on the sheet | water names, cartouche and panels, callouts |
| `trains` | `(c, t, {PATHS, PH, phaseHead, train, pointAt})` | vehicles |
| `overlay`, `tunnelOnly` | `(c, t, {b, toScreen, F, INK, view, regW, regS})` in 1920 × 1080 screen space, `t → bool` | the counter, objects by the lens, a screen-only opening |
| `cues`, `init` | `[{t, type}]` (story time), `(helpers)` | sound cues; access to the built network |

  Every text a hook prints that must be read is registered with `regW` (on the sheet) or `regS` (screen) for `window.TEXTS`.
- Minimal use, unlike the demo: an invented harbour town with one tram line (`mode: 'light'`), a ferry (`mode: 'ferry'`) across a bay `area`, a bus (`mode: 'bus'`) and an in-station `LINKS` pair, one phase per line and a `camera` in `timeline.js`: nothing else is needed for the shared stop to become a capsule, the ferry to get its lane and piers, and the bus its hollow line.

## 11. Variation space

The agent decides the network (real or invented), what a line stands for, the order of growth, the camera route, which comparison (if any) gets a printed panel, the accent colour and what the counter counts.

What does not vary, whatever the topic:

- **The network is real data, checked.** Use the user's own data first (lines, stations, opening dates, lengths, ridership). Without it, find it for the topic and cross-check every figure in at least two reliable sources, the operator and government open data first, the press next, encyclopaedias only in support. Keep `FACTS.md` in the project folder: on-screen claim, value, source URL, the quoted wording, date checked; plus the figures checked and not used, and why. A figure that cannot be confirmed, or whose sources disagree, never goes on the sheet as fact: drop it, or print it with the definition it depends on (route length with or without a maglev; a station's name before or after a renaming), or ask the user when the story rests on it. Station names and line colours are facts too (§9). An invented network is only for a topic that is itself fiction or a metaphor (a product roadmap, a career): it says so on screen, and any real fact inside it is checked the same way.
- **The map is full enough to carry the film.** One line on blank paper is not a map. The sheet carries enough lines, interchanges, geography and dated states that every shot has something new to show and the wide shots are network, not empty paper; roughly one new event (a line, an interchange, a landed value, a printed callout) every 3–5 s of film. Minimums, by kind of topic:

| Topic | Lines | Named stations | Interchanges | Geography and landmarks | Dated states |
|---|---|---|---|---|---|
| A whole network (a city, a region), 30–60 s | ≥ 5 | ≥ 40 | ≥ 8 | ≥ 1 water body, ≥ 3 named landmarks (a hub, a railway station, an airport, a printed mark) | ≥ 4 years or stages, each with a sourced value |
| One line or one route (a commute, a new line), up to about 20 s | the line + ≥ 3 lines it crosses, drawn with their interchanges | ≥ 8 on the line | ≥ 3 | as above | ≥ 2 (years, or times of day) |
| A topic drawn as a network (a roadmap, a career) | ≥ 4 | ≥ 20 | ≥ 4 | printed regions or bands standing for its domains | ≥ 3 |

  A longer film adds to these rather than holding the same picture longer. When the real network is smaller than the floor (a town with one tram line), draw what is real and widen the topic instead (its buses and ferries, the railway it meets, its history), never invent lines.

- **Structures**: a single line built stop by stop, ending on its terminus; two rival networks growing on one sheet, then compared; a network shrinking line by line (closures) and one survivor.
- **Openings** (the title is printed on the map, §4): a lamp or coin in close-up match-cut to a station dot; a blank sheet where the first tip starts at frame one, beside the cartouche; a low sweep over a finished map that rewinds to its first stop.
- **Endings** (every one closes on the whole network, §4): a terminus ring lands, then the camera rises to the full network with the end title printed in a margin; the camera rising until the sheet's edge and the table show; a train leaving the last station, then the full view.

---

How our demo was made (story, shots, score, end card, build): [DEMO.md](DEMO.md). Read it after your treatment exists.


===== 完整公共规范：DIRECTOR.md =====

# Directing a Lemo-Opuscar film

The directing method behind every film in this library. Pair it with one `styles/<slug>/STYLE.md` (the style) and [`TECHNIQUE.md`](TECHNIQUE.md) (how to build).

You are the director, not a tech demo. A film is judged in this order: **sound, rhythm, camera, directing** (performance, staging, emotional arc). Good-looking frames are only the starting point.

---

## 1. Take the brief

The user gives a style and a topic, sometimes more (length, language, voice, must-have shots, brand rules). Everything else is your decision. Ask once, in a single message (AGENTS.md, Workflow), then no more questions. Defaults:

- Length **30–60 s**; shorter and tight beats padded. Beyond two or three minutes multiplies time and token cost: tell the user.
- 1920×1080 at 24 fps by default; an output frame rate set in the style's `STYLE.md` (30 or 60 fps, for example) wins, and is what you pass to `--fps` and `mux.sh`; other sizes (vertical 1080×1920, for example) with `--size WxH` on the render tools.
- Voice and subtitles in the language the user writes in. Subtitles burned in and exported as `.srt`.
- Loudness −14 LUFS.

Say it in the questions when it matters: a good Chinese voice uses Microsoft's online service (edge-tts) and needs a connection; offline, Kokoro reads Chinese but sounds plain (TECHNIQUE.md §4).

Requests that only change the plan:

- **No voice, or no subtitles.** Drop those steps and say so in the treatment.
- **Their own voice recording.** Use it as it is; transcribe it with faster-whisper for word timings.
- **Their own material**: logos, photos, footage, and for styles built from real material (the Evidence Films) their own data, scans, imagery or CAD. Ask whether they have any; what they give comes first, and the sources in the `STYLE.md` are the fallback. Before you download from those sources, tell the user what you will fetch, from where and under which licence. Rights: section 12.

## 2. Find a benchmark first

Before writing anything, pick one or two reference works (films, title sequences, games, ads) that set the bar for this style **and this topic**. They are your choice, made for the user's film; don't borrow the demo's. Write down:

- **What to learn**: composition, pacing, camera grammar, colour logic, score structure.
- **What not to take**: characters, designs, melodies, specific shots, logos, fonts.

The benchmark lifts quality more than any rule below.

## 3. Shape the story

- **One subject, one goal, one turn.** A character (or a single object, product or idea) wants something, something changes, it ends differently from how it began.
- **Hook in the first 3 seconds.** No slow logo reveal before anything happens.
- **An ending that echoes.** Bookend the opening, reveal the scale, or let the character do the thing right the second time.
- **One native move**: a moment only this medium can do (a fold that becomes a transition, ink that blooms into the next scene, a type grid that snaps into the logo). Put it at the emotional peak. `STYLE.md` lists the medium's native moves; pick or invent the one your story needs.
- **Cut the extras.** One gag the audience reads at thumbnail size beats three they can't. If a beat needs explaining, remove it.

## 4. Write the treatment

Write `TREATMENT.md` before drawing anything, and before you open the style's `DEMO.md` or demo code (an Edit & Documentary style gathers its material first: AGENTS.md, "Treatment first"):

1. **Three candidate structures**, a few lines each (for example: a single journey, a before/after, a countdown, a list that turns), then the one you chose and why. Choose the opening image, the ending and the shape of the score from the topic too; the first idea that comes to mind for a style is usually its cliché.
2. **Logline and arc**: one sentence, then setup → turn → ending.
3. **Benchmark**: learn / don't learn (section 2).
4. **Shot list**: for every shot, the framing (wide / full / medium / close / insert), angle, camera move (push, pull, pan, track, crane, zoom), duration, and **why** it is shot that way.
5. **Beat sheet**, second by second.
6. **Cue map**: tempo, bar grid, instrumentation per section, and on which beat every cut, key action and subtitle lands.
7. **Sound design table**: for each section, the ambience bed, the main foley and the music state.
8. **Subtitle and title design**: the type is part of the style.

## 5. Prove the look

- **With characters**: draw a model sheet (turnaround, 3–4 expressions, 2–3 key poses, palette) plus two style frames.
- **Without characters**: three style frames from the film, one of them the signature shot.

Render them with the real drawing code, not a mock-up, and check them yourself against the `STYLE.md` before going on.

### The storyboard (only if the user asked for one)

Render 6–9 key shots with the real drawing code, tiled into one sheet (`core/render/sheet.py`) with shot number, framing, duration and line under each. Send it with the logline and what you are least sure about, and **wait for approval**. If the user didn't ask for one, don't stop.

## 6. Sound is half the film

- **Every visible action has a sound**: landings, page turns, cuts, drips, clicks, cloth. Match the material (paper, wood, metal, ink and glass all sound different).
- **Three layers**: ambience (room, wind, rain, city), foley (tied to actions) and music. Duck the music under dialogue and key foley.
- **At least two real silences**, or near-silences, before the turn or the emotional peak. The first sound after the silence should be one of the most important sounds in the film.
- **Use sound as a transition** at least twice: bring the next scene's sound in early (J-cut) or let the last scene's sound run over the cut (L-cut).
- **Avoid generic "piano and strings".** Score in the instruments of the style's sound palette.

## 7. Rhythm: the music grid comes first

- Write the cue map before animating. The picture locks to the grid, and a script checks every cue (TECHNIQUE.md §3).
- **Vary the pace**: alternate fast and slow, include one clear acceleration or deceleration, and give the audience one breath (a long take or a held pause). A film at one even speed has failed.
- One action, one sound, one cut, but don't cut on every beat. Leave time to see.
- **Pace for the viewer, not the clock**:
  - Hold every subtitle at least 1.8 s, and never shorter than the spoken line + 0.6 s.
  - After text finishes animating in, hold it for roughly (letters ÷ 15 + 1.5) s in English, (characters ÷ 4.5 + 1.5) s in Chinese; `readcheck.mjs` checks this for you.
  - Hold a title card at least 4 s.
  - Give failures and gags enough time to be understood.
  - Fast is fine; make it fast with fewer words per screen, not by cutting before people finish reading.

## 8. Camera: every shot needs a reason

- Use at least **four different camera moves** and real changes of framing. 2D has a camera too: push, pull, parallax, focus pulls, frames within frames.
- **One signature shot** people remember: a oner, a scale reveal, a transition made from the medium itself.
- **Design transitions inside the medium** (a page turn, a carved line growing, ink spreading), as one consistent grammar. Avoid default fades and hard cuts.
- At key moments the subject fills at least a third of the frame height, with clear staging and a readable silhouette.

## 9. Performance

- **Anticipation, action, follow-through** on every meaningful move. Characters change emotion. They do not just slide across the screen.
- **Motion continuity**, especially for characters built from code rigs:
  - Blend every pose with keyframes and easing; never switch poses inside an `if`. The only exception is a deliberate one-frame comic pop.
  - Check shoulders and arms on a large action test sheet (reach, raise, run, kneel) before shooting (TECHNIQUE.md §10).
  - Held props sit **between the palms**, at a depth between the two arms. A hand-over interpolates from one palm to the other. A rolling object turns by distance ÷ radius.
  - Step through key actions at 0.2 s intervals, enlarged.
- Check every expression at final size, especially eyebrow direction: "worried" and "angry" are one flip apart.

## 10. The failures we saw most

- Subject too small, too far away, or pushed against the frame edge.
- Too dark to read, or a colour laid on the same colour (red on red).
- Subtitles covering the subject.
- A gag or failure too fast to understand.
- Blank frames in transitions.
- A timed effect (iris, zoom, follow cam) that doesn't track the subject after the camera moves (one world → screen function, TECHNIQUE.md §2).

## 11. Before you deliver

- Run the review loop (TECHNIQUE.md §8): contact sheets, 0.2 s strips of key actions, one full-speed viewing with sound.
- **One fix round.** Fix everything the review and the checks below find in one round, then check once more. Small fixes that second check turns up (a level, a frame) belong to the same round; anything bigger, tell the user in one line when you deliver. The user's notes after delivery are new rounds: change only what they ask.
- **Not the demo again.** After the treatment, read `DEMO.md` and compare: structure, opening, signature shot, camera path, score shape, ending. At least four of the six must differ; rethink the ones that match. Before delivery, put your contact sheet next to the demo poster (`styles/<slug>/poster.jpg`) as a last check.
- Voice: every line transcribes back correctly (speech-to-text check). For Chinese, one misheard character in a short line is normal: listen, and if it is right, let the check expect what the model heard (TECHNIQUE.md §4).
- Loudness about −14 LUFS; no black frames, no NaN frames; subtitles in sync and not covering key action.
- Every row of the sound design table is actually in the mix.
- Every map, globe or satellite view passes section 13, checked enlarged.
- No LemoLab sign-off: `grep -rniE "lemo ?lab|opus 5\.5" <project folder>` finds nothing outside `LICENSE`, `CREDITS` and the library's path in `LIB=` lines, and you have watched the last seconds of the film (text drawn into an image can't be grepped).

**Deliver**, in the project folder (the complete list):

- `<name>.mp4` (24 fps unless `STYLE.md` sets another rate, about −14 LUFS) and `poster.jpg`;
- `<name>.srt`, when the film has narration, dialogue or subtitles;
- `TREATMENT.md`;
- `CREDITS`: every third-party asset in the film (sample libraries, music, fonts, images, the voice engine) with its source and licence (TECHNIQUE.md §11);
- the source, with a one-command `build.sh` (TECHNIQUE.md §2).

**Tell the user**, in their language: where the project folder and the film are; that `CREDITS` lists the third-party assets in the film and their licences; and that they are responsible for the materials they use in it.

## 12. Copyright red lines

- References teach grammar only. Don't copy characters, designs, melodies, shots, logos or type designs.
- No existing works, games, brands or events appear in the film unless the user owns them or has the right to use them. That includes the logos, photos and footage the user hands you: use them when they say they have the right, otherwise draw fictional stand-ins.
- Some of our demos are unofficial fan films of real events or characters. Keep the style, and never carry those names, marks or characters into a user's film.

## 13. Maps

These apply to every frame that shows a map, a globe or satellite imagery, in every style.

- **No borders unless the film is about them.** Draw coastlines, terrain, imagery or streets, without national or provincial borders. Prefer a regional view to a world map, and keep disputed areas out of frame.
- **When China is in frame, draw all of it.** Taiwan, Hainan, the South China Sea islands with the dashed line (in frame, or in an inset), and the Diaoyu Islands with Chiwei Yu. Taiwan and the mainland are one country, in the same colour and the same treatment. Zangnan and Aksai Chin are drawn as on China's standard map.
- **Default border data doesn't meet this.** The default boundaries of Natural Earth, world-atlas and OpenStreetMap can't be used to draw China. When the film needs borders, use China-view data (such as Natural Earth's `admin_0_countries_chn` layers, checked against the standard map) or China's standard map service (bzdt.ch.mnr.gov.cn).
- **Words follow the same map.** Taiwan, Hong Kong and Macao are never listed as countries: not in labels, legends, subtitles, the voice-over or data tables. A list that includes them is "countries and regions". Clean a dataset's country field before you chart it.
- **Other disputed areas**: the same; frame them out, or leave their borders undrawn.
- **Check and credit.** Before delivery, enlarge every map shot and check it against these rules. `CREDITS` names the map data, its source and its view (for example "Natural Earth 1:50m, China view").


===== 完整公共规范：TECHNIQUE.md =====

# Technique: how the films are built

Every film here is made from code: no video generation, no stock footage. This page explains the pipeline, to reproduce with our tools in `core/` or in your own stack. Pair it with [`DIRECTOR.md`](DIRECTOR.md) and one `styles/<slug>/STYLE.md`. Every command and flag is in [`core/README.md`](core/README.md).

```
timeline (single source of truth)
   ├─► picture:  web page with render(t) ──► headless Chrome, frame by frame ──► video.mp4
   ├─► voice:    TTS per line ──► speech-to-text check ──► word timings
   ├─► music:    score from the same timeline (samples + synthesis) ──► stems
   ├─► sound:    procedural foley at event times
   └─► subtitles: .srt + burned-in captions
mix (duck, compress, balance) ──► mux with ffmpeg, two-pass loudnorm −14 LUFS ──► film.mp4
```

## 1. Requirements and install

System tools, which the user installs: **Node 20+**, **ffmpeg 7+** (6.x under-reports audio length through `loudnorm`, and `mux.sh` then rejects the file as cut off), and **Python 3.11+** or [uv](https://docs.astral.sh/uv/). Developed on macOS (Apple silicon); Linux should work; on Windows use WSL. 3D and shader-heavy styles want a GPU.

Everything else installs in tiers, from the library root (`$LIB` in skill mode). Install a tier only when the film needs it:

| Command | Adds | Size |
|---|---|---|
| `sh plugin/skills/lemo-opuscar/scripts/setup.sh deps` | core: npm packages, headless browser, Python `.venv` (numpy, scipy, soundfile, soxr, pillow): render, synthesize sound, mux | ~350 MB |
| `… setup.sh deps voice` | Kokoro + model (English, offline), edge-tts (Chinese, online), faster-whisper (voice check) | ~0.55 GB + a Whisper model on first check (~145 MB for English, ~480 MB for Chinese) |
| `… setup.sh deps music` | numba, for plucked strings (`pluck.py`); the sampler itself needs only the core | ~140 MB |
| `sh tools/fetch.sh instruments <lib>` | a sample library: `freepats`, `karoryfer`, `salamander`, `vcsl`, `vsco2ce` or `all` | 70–400 MB each |
| `sh tools/fetch.sh hdri` | HDRIs for 3D styles | 12 MB |

Some styles need packages of their own (a LiDAR reader, a slide-scan decoder, a CAD importer); the style's `STYLE.md` lists them. They are packages, not system tools: install them yourself into a private venv or `node_modules` in the project folder, never into `$LIB/.venv`.

A synthesized score needs no big download; `sampler.py` names the library to fetch when an instrument is missing. A pack needs about twice its size free while it unpacks. Downloads come from npm, PyPI, GitHub Releases and Hugging Face (`HF_ENDPOINT` sets a mirror).

## 2. The picture is a function of time

Each film is a folder with an `index.html` (`<demo>` in the commands) that exposes:

```js
window.DUR = 54.2;                 // seconds
window.render = (t) => { ... };    // draw the frame at time t, deterministic
window.READY = true;               // set once fonts and images are loaded
window.EV = [{t, type, ...}];      // optional: sound / cue events for the mixer
window.TEXTS = (t) => [{id, text, x0, y0, x1, y1}];   // optional: every text visible at t, for readcheck
```

**Paths:** pages reach library files with absolute URLs (`/core/lib.js`, `/node_modules/three/build/three.module.js`); scripts and `build.sh` use `$LIB`. Never `../..`.

A `build.sh` that works in both modes (in skill mode, put `LIB=<path setup.sh printed>` at the top):

```sh
#!/bin/sh
set -e
HERE=$(cd "$(dirname "$0")" && pwd)
LIB=${LIB:-$(cd "$HERE/../.." && pwd)}          # clone mode: <repo>/films/<name>/
export LIB
[ -f "$LIB/core/render/video.mjs" ] || { echo "set LIB to the library folder"; exit 1; }
cd "$LIB"
node core/render/events.mjs "$HERE"
node core/render/video.mjs "$HERE" --fps 24 --out "$HERE/out/video.mp4"
"$LIB/.venv/bin/python" "$HERE/mix.py"                               # score, foley, voice → out/mix.wav
sh core/render/mux.sh "$HERE/out/video.mp4" "$HERE/out/mix.wav" "$HERE/<name>.mp4" 24
```

Rules that keep it reliable:

- **Deterministic.** No `Date.now()`, no `Math.random()` without a seed (`core/lib.js` has `mulberry` and `hash`), no state carried from the previous frame. Any frame can be rendered alone, in any order, by any worker.
- **Canvas 2D** for most 2D styles; **three.js** for 3D (§9); **WebGL2** shaders for post passes (film damage, CRT, ink redraw).
- **Animate on twos where the style wants it** (12 fps stepping for stop-motion, pixel or cel looks), but keep the camera and light smooth every frame. A stepped camera reads as lag.
- **One world → screen function.** Any effect that follows a subject (iris, zoom, spotlight) goes through it. Never hand-type screen coordinates.
- **Draw for the frame you render.** The default is 1920×1080; for another size pass `--size WxH` (e.g. `1080x1920`) to every render tool and lay the page out from `innerWidth` × `innerHeight`.

Capture (`core/render/`):

```sh
node core/render/still.mjs <demo> 1.5 12 --range 0:50:2   # review stills; exits on page errors
node core/render/video.mjs <demo> --fps 24 --workers 3     # all frames → <demo>/out/video.mp4
node core/render/events.mjs <demo>                         # export DUR + EV → events.json
node core/render/readcheck.mjs <demo>                      # every on-screen text stays long enough to read
```

To render a second version with other content, pass it to the page and give it its own output: `--q 'content=content_alt.json' --out …/alt.mp4` (the same for `events.mjs`).

Capture is fast because of **JPEG screenshots**, **one browser per worker** and **grain added in ffmpeg**: grain drawn in the page makes every frame incompressible and slow.

## 3. One timeline drives everything

Keep sections, tempo, beats and hit points in one file (`timeline.js`). Export it to JSON and let the score, the mixer, the subtitles and the checks read the same numbers:

```js
export const SECS = [{ id: 'chase', t: 12.0, bpm: 144, beats: 12 }, ...];
export const HIT  = { pratfall: ['chase', 6], ... };   // section + beat
```

A small script (`cuecheck.py`, in `styles/<slug>/demo/tools/` of several demos) compares every visual hit with the music cue it should land on. Aim for 0 ms.

## 4. Voice

- **TTS is only the default.** If the user brings a recording or names a voice, use that. Otherwise:
  - **English**: [Kokoro](https://github.com/thewh1teagle/kokoro-onnx), local, many voices (an unknown `voice` name makes `tts.py` print the full list; `af_` / `am_` are American, `bf_` / `bm_` British; cast the narrator for this film, not the demo's). `core/tts/tts.py lines.json out/` writes one WAV per line and a durations file. Its Chinese voices (`"lang": "cmn"`) work offline but sound plain.
  - **Chinese**: `core/tts/tts_zh.py lines.json out/` uses [edge-tts](https://github.com/rany2/edge-tts) with Microsoft's neural voices (`zh-CN-XiaoxiaoNeural`, `zh-CN-YunxiNeural`…), with the same outputs as `tts.py`, a rate per line and the silence trimmed. **It needs a network connection.**
- Spell numbers out in the TTS text and write them as digits in the subtitles.
- **Check every line**: `core/tts/asr_check.py` transcribes each WAV with faster-whisper and compares it with the script (`--lang zh`: numbers by value, so 十九 matches 19, and the rest character by character); re-generate until it exits 0. A misheard character in a short Chinese line is normal: listen, and if it is right, put what the model heard in the line's `asr` field. It also writes word timestamps for placing lines and subtitles.
- **Before mixing**: TTS has a high peak-to-average ratio. Compress the voice first, then balance by RMS: voice about 10 dB above the music.

## 5. Music

Write an original score from the cue map, in the instruments of the style's sound palette; no generic piano and strings.

- **Samples**: `core/audio/sampler.py` plays real instruments from free libraries (VSCO 2 CE, VCSL, FreePats, Karoryfer, Salamander Grand Piano; list and licences in `core/audio/INSTRUMENTS.md`). Write the score as events `(time, instrument, pitch, duration, velocity, pan)`. Long notes are extended seamlessly, and round-robins avoid the machine-gun effect.
- **Plucked and folk strings** (guqin, pipa, shamisen, banjo…): `core/audio/pluck.py`, physical modelling (Karplus–Strong) with bends and vibrato.
- **Synthesis** with numpy for chip tunes, drones and effects; no download needed.
- **Balance the low end.** Synthetic scores get bass-heavy quickly. Measure energy per band after mixing; keep 20–120 Hz around −3 dB relative to the rest, skip pad notes below MIDI 48, and give the bass some 2nd and 3rd harmonics so it speaks on small speakers.

## 6. Sound effects and mix

- `core/audio/sfx.py` synthesises foley procedurally (click, whoosh, thump, ding, paper, noise beds…) with filters, envelopes and `add(buffer, sound, at, gain, pan)`. Drive it from `window.EV`, so every sound sits exactly on its frame.
- **Master**: `sh core/render/mux.sh video.mp4 mix.wav out.mp4 24 [grain]` muxes, runs a two-pass loudnorm to −14 LUFS with a true-peak limit, adds grain in ffmpeg and prints the measured loudness; it exits non-zero on any failure. On light backgrounds use less grain; for pixel and vector styles, none.
- Films with grain baked into the picture compress badly; re-encode with `-tune grain` and a higher CRF.

## 7. Subtitles

- Export `.srt` with `core/render/srt.py cues.json out.srt` (cues = `[{t0, t1, text}]`), and burn styled captions into the page itself: the caption design is part of the style.
- Timing rules are in DIRECTOR.md §7.

## 8. Review loop

1. Contact sheets: a frame every 1–2 s with `still.mjs --range`, tiled with `core/render/sheet.py`. At least two full passes.
2. Frame strips at 0.2 s for every key action: hand-overs, falls, hits.
3. On the final file: `ffmpeg -af ebur128` (loudness), `blackdetect` (blank frames), whisper again on the final mix if it has voice.
4. Watch it once, at full speed, with sound.

## 9. 3D notes

- three.js r170 rendered headless through WebGL2 on the GPU; physical depth of field and GTAO from `core/three/post.js`, rendered at 2× and downsampled.
- Lighting: soft area lights plus a Poly Haven HDRI at low intensity reads more "real" than bright ambient light.
- `core/three/post.js` is written for a perspective camera. For an orthographic camera swap `perspectiveDepthToViewZ` for `orthographicDepthToViewZ` in its depth pass, or the depth of field silently breaks.

## 10. Characters drawn in code

- A 2.5D rig (torso, head, limbs solved per frame) is enough for pantomime.
- Order the shoulder rotation as abduction, then flexion; the reverse order crosses raised arms into an X.
- Let the shoulder girdle rise and move forward as the arm lifts, and don't outline the part of the arm that overlaps the torso: that line is what makes a joint look like a puppet seam.

## 11. Assets, credits and fonts

Only CC0, CC BY or OFL material, each listed in the film's `CREDITS` with its source and licence; `core/audio/sampler.py credits(names)` writes the lines for the instruments you used. Public-domain works count as CC0; "no known restrictions" does not. Data or images under other open licences (ODbL, CC BY-SA, open-hardware licences) only after you have named the licence and its terms (attribution, share-alike) to the user and they agree. The user's own material is fine as it is.

A film that states facts (the Evidence Films styles) keeps a `FACTS.md` in the project folder: each claim with its source URL and the quoted wording, or the measurement that produced it.

Fonts: Google Fonts (OFL), self-hosted in the project. The typefaces a `STYLE.md` names are not in the library; download them (`https://github.com/google/fonts/tree/main/ofl/<family>`) into the project's `fonts/`. `core/fonts/` holds a few Latin display fonts and a Chinese display font with only about 200 glyphs, not enough for running Chinese text. For Chinese, subset a CJK font to the characters you use: the Google Fonts CSS API with `&text=` returns just those glyphs (`https://fonts.googleapis.com/css2?family=Noto+Sans+SC:wght@700&text=<URL-encoded characters>`). Download the font file it points to into the project's `fonts/` and load it with `@font-face`; don't link Google Fonts at render time.

## 12. Where to look in our demos

| If you need… | Look at |
|---|---|
| 2D character animation and lip sync | `styles/scifi-toon/`, `styles/cel-anime-80s/` |
| a timeline-driven score with cue checking | `styles/microgame/`, `styles/silent-film/` |
| an image-to-ink redraw and film-damage post pass | `styles/silent-film/demo/engine/` |
| a brush or stroke engine | `styles/watercolor/`, `styles/ink-wash/`, `styles/impasto/` |
| 3D with depth of field and real materials | `styles/brick-toy/`, `styles/paper-popup/` |
| a CRT or VHS look | `core/post/crt.js`, `styles/ascii-crt/`, `styles/backrooms/` |

Each style's `DEMO.md` says how its demo was built. Open it and the code only after your treatment exists, to learn a technique, never to rebuild our film (an Edit & Documentary style's material tools in `demo/tools/` come first: AGENTS.md, "Treatment first"). In skill mode, get the source with `sh <skill folder>/scripts/setup.sh demo <slug>`. Copied demo code often reaches the library with `../..`: replace that with `$LIB` or absolute URLs.


## 原作者媒介陷阱与经验摘录

## 9. Pitfalls of the medium

- **Off-grid geometry**: any segment not at 0/45/90° breaks the style. Route between points with an automatic bend (straight then diagonal, or the reverse) and validate every segment.
- **Labels over lines, or labels that jump**: give labels a paper halo and place them once against the finished network, before the first frame. Placing against what is drawn so far makes labels hop as lines arrive.
- **Parallel lines sharing a corridor** collide: offset each line by ±0.10 G and let one capsule enclose all points of the station.
- **Too much text in wide shots**: hide minor names by zoom, not by time.
- **A flat map**: a top view all the way through reads as a slideshow. Tilt, focus and the sheet edge are what make it an object; a still of the style should show at least one tilted view with depth of field.
- **Paper too loud**: tooth and fibres stronger than a few percent turn the sheet into plaster or canvas.
- **Mode by colour**: a ferry or bus line in a "ferry blue" breaks colour as identity. Use the line forms in §3.
- **Real networks**: published colours and station names are facts, logos and branded bullets are not; the film is an unofficial tribute and says so on screen. Check every date and length against official sources; encyclopaedia figures for opening sections are often for a different span, and stations are renamed (the data rule is in §11).
- **Counters that interpolate** invent numbers. Land only on sourced values; spin between them.
- **Texture resolution in tilted views**: limit the far distance of the inked region and let depth of field hide the softness.
- **Stale ink**: when the inked texture is reused, reset the 2D transform before clearing it, or last frame's ink ghosts every other frame.


