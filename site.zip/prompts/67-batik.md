# 67 · 蜡染 / Batik

来源类型：根据作者引擎说明整理的使用模板；并非作者原始创作提示词  
原作者：Miranda Dixon-Luinenburg  
上游原文：https://github.com/cyborggirl963/opus-5.5-music-video-art-styles/tree/main/styles/batik  
固定版本：801b3548c54765ecf932ce8b7f3cf4b29fb7a8bf  
抓取核对日期：2026-10-27  
本库改动：中文任务模板、中文摘要与编排；原文全文保留。

## 使用前先看

- 灯色应按各自亮度归一后分配染色层，避免整片坡面在色档间跳变。
- 先试角色轮廓和染色分层，再叠裂纹；裂纹不能掩盖歌词、面部与关键动作。

- 这是代码渲染工作流；聊天文本本身不会自动产生 MP4，需有可执行的项目环境。
- 先看预览再做长片；不要把示例素材的许可自动套到自己的歌曲、照片、字体和品牌上。
- 下方复制区包含全部风格与公共规范，不要求 AI 另外从本机隐藏路径读取文件。

## 完整复制区

你是一位能写代码、检查画面并渲染成片的动画导演。请用“蜡染 / Batik”制作一个属于我的视频。

【我的需求；把花括号内容换成实际值】
主题与一句话故事：{{填写主题和结尾变化}}
用途与观众：{{例如面向普通观众的科普短片}}
内容依据或已有脚本：{{填写；没有则说明需要你写}}
音频、歌词、图片、数据、品牌素材路径：{{填写；没有写“无”}}
素材使用权限与需显示的署名：{{填写来源与许可；不清楚请列待确认项}}
目标时长：30 秒起步；MV 以实测歌曲时长为准
画幅与清晰度：默认横屏 16:9、1920×1080、24fps；竖屏须重新构图，不直接裁横屏
语言：简体中文；配音需求：{{有/无、声线与语速}}
必须出现的内容：{{填写}}
禁止出现的内容：{{填写}}
预算与速度：先做低成本验证，再渲染完整片
个人工程名：my-video（可改为英文短名）
确认方式：先给 3 张由真实渲染代码产出的样帧和 5–10 秒预览；我确认风格后再做完整成片

【本风格的核心实现】
把三维布景转成蜡封、分次染色与裂蜡纹理，轮廓和色阶来自材料工序。
特别检查：
- 灯色应按各自亮度归一后分配染色层，避免整片坡面在色档间跳变。
- 先试角色轮廓和染色分层，再叠裂纹；裂纹不能掩盖歌词、面部与关键动作。

【工程与流程】
1. 在工作区单独克隆 https://github.com/cyborggirl963/opus-5.5-music-video-art-styles ，检出 801b3548c54765ecf932ce8b7f3cf4b29fb7a8bf。将 styles/batik/ 复制到 projects/my-video/，保留引擎，按该风格 README 指定的文件替换示例场景。不要直接修改 styles/ 中的母版。
建立 Python 虚拟环境，阅读 requirements.txt 后安装渲染依赖；需分析音频时再安装 requirements-audio.txt。使用 Chrome 或项目支持的 Chromium。使用 python tools/serve.py 提供本地 HTTP，不用 file:// 打开渲染页面。
2. 先检查机器的 Python、Node/浏览器、FFmpeg、字体与 GPU 能力。缺少工具或访问权限时明确报告缺什么，不能只描述完成、伪造文件或把截图称为已渲染视频。
3. 把我的需求写成 PLAN.md 或 TREATMENT.md：一句话故事、分镜、逐镜秒数、镜头运动、文字位置、音乐与声音 cue、所需素材、预计成本。涉及事实和数据时写 FACTS.md；没有来源的数字不填。
4. 如果是 MV，先取得音频与实际演唱歌词，测量段落、停顿、节拍与词时间；不得沿用 37.5 秒示例诗的时间轴。未提供音乐时不要假装已经完成歌词对齐，可先制作无歌词短预览。
5. 先完成 3 张代表开头、关键变化、结尾的样帧，逐张检查；再渲染 5–10 秒低清短段，检查字幕、运动、音画同步与控制台。复杂慢风格先计时，再估算整片。
6. 随机效果固定种子；有历史累积的媒介按顺序渲染。并行前先比较随机抽帧与连续渲染是否一致。
7. 正式导出使用项目文档中的工具与参数，不臆造命令。交付可播放 MP4、720p 预览、源代码、素材清单与许可、字幕（有台词时）、复现说明；保留最终片长、帧率、音频响度与实际渲染耗时。
8. 实际打开并检查成片开头、中间、转场、结尾及全片联系表，确认没有空帧、字体回退、遮挡、裁字、爆音或无意复制的作者片尾签名。交代尚未完成的检查。

下面是完整风格参考与公共制作规范。它们是上游参考资料，不代表我的主题或逐字台词；我的具体需求优先。遇到 macOS/Linux 示例命令时按当前系统等价转换，不直接在 PowerShell 粘贴 bash 命令。相对资源路径以完整克隆的上游工程为准。


===== 完整风格原文：styles/batik/README.md =====

# Batik

A waxed and dyed cloth, worked out from a real 3D set (three.js). The set is built like a theatre model: white card,
dowel, and pieces meshed in the browser from signed-distance models, lit by just two lamps, a gold one and a blue one.
The batik comes from that light, the way dye takes on waxed cloth: where only the gold lamp reaches, the cloth is
dyed soga (a gold-brown); where only the blue reaches, indigo; where both reach, it's left cream; where neither
does, near black. Every silhouette and crease is a line of wax that resists the dye (cream on dyed ground, dark on
light), and the wax cracks, letting fine veins of indigo into the light parts. For busier scenes there's a full
palette: each thing is dyed its own colour, snapped to the nearest of nine dyes and then overdyed by the lamp that
reaches it, so its shadows still lean soga or indigo. Things carry batik patterns in their own space (parang, kawung,
dots, stripes, grass ticks), so a pattern stays on a skirt as it blows. A dye front sweeps one palette into the next
across the cloth; the cloth has a border of tumpal triangles and a band along the bottom where the lyrics are
written in, each word brightening as it's sung.

![A woman in a patterned indigo skirt and a man in a green coat meet on a dotted path by a big tree, in the full palette](img/hero.jpg)

*Good for:* songs with two voices or two sides (the two lamps are two dyes), day and night, weather, folk songs, and
songs that swing between busy verses and stark choruses (the full palette for the verses, two dyes for the high
points).

The demo sets Christina Rossetti's "Who Has Seen the Wind?" on a windy afternoon in open country, where the wind is
only seen through what it moves. The title comes up on the cloth in two dyes; on the first word a dye front carries
the full palette across the cloth with the wind. Two people meet on a path by a big tree, her skirt blown ahead of her,
his coat blown back; the tree's leaves, drawn as little shapes of wax, tremble and blow off; a gust runs along the
washing on the line. The second verse sweeps in an evening colourway while the camera climbs a kite string from a
child on a knoll to the kite; the two stand looking up; a row of trees on the ridge bows as a gust runs along it on
"bow down their heads". "The wind is passing by" is two dyes again, the whole field from the east with the lamps
swinging overhead, and in the last bars two round windows open in the cloth on the beats, onto two other looks of
the same set.

| | |
|---|---|
| ![The field in two dyes, soga and indigo fields in the sky, the title in the caption band](img/twodye.jpg) | ![A dye front sweeping the full palette across the cloth from the left](img/wipe.jpg) |
| ![A row of trees bowing on a ridge in the evening colourway, teal ground and a rose sky](img/trees.jpg) | ![Two round windows in the cloth, the left showing the lit card model and the right gold line on indigo](img/window.jpg) |

## Looks in this family

The [style lab](lab/index.html) draws the demo's set from three of its cameras in each look. All four are made from the
same lit set; only the last step changes.

- **Batik** (the demo): wax lines and dyes worked out from the two lamps' light, crackle, patterns, a tumpal border.
  ![The washing on the line in batik, the sheets patterned in kawung and parang](img/look-batik.jpg)
- **Two-lamp model box**: the set itself, white card under a gold lamp and a blue lamp, every object throwing two
  coloured shadows, on a curved backdrop, with ambient occlusion, a shallow lens and faint haze in the beams.
  ![The washing as a white card model lit gold and blue](img/look-box.jpg)
- **Gold line on indigo**: edges drawn in gold and silver on indigo paper, each in the metal of the lamp that lights
  it; where one lamp is blocked, the shadow is hatched in the other lamp's metal.
  ![The washing in gold and silver line on indigo](img/look-goldline.jpg)
- **Shop-window glass**: the scene painted on a shop window at night: people gilded in gold leaf, trunks and sheep
  etched, the land and the washing in stained glass, the lights of the shop blurred behind the sky, frost in the
  corners, a sign-writer's gilt border. It is the weakest of the four: over a whole scene it can read as a 3D render
  put through a filter. It holds up best with a few gilded figures and plenty of dark glass around them.
  ![The washing as a stained-glass window with bokeh behind](img/look-glass.jpg)

## Run the demo

```
python tools/serve.py
```

Then open http://localhost:8000/styles/batik/index.html and press Play (or Space). The page has to be served (ES
modules and module workers don't run from `file://`). It plays live, but not at full speed: a frame takes 60-110 ms
to draw on an Apple M4, so the player shows 9-16 frames a second, picking frames by the audio clock (it drops frames
rather than drifting). Render an MP4 to share it. The first load takes about 5 s while a pool of workers meshes the
pieces; the label in the corner says what it is building.

- `index.html#t12.5` shows a still at 12.5 s (the page around it is hidden).
- `index.html?look=box` (or `goldline`, `glass`) plays the whole demo in another look of the family (without the
  caption band).
- `index.html?buf=col` (or `id`, `nd`, `depth`, `gold`, `blue`) shows one of the buffers the looks are drawn from:
  the quickest way to see why something came out the wrong dye.
- `index.html?sets=field` builds only the named sets (this demo has one).

Stills, MP4 and the framing check (from the repository root):

```
python tools/still.py styles/batik/index.html 2 6 12.5 0:37.5:2.5 --sheet
python tools/render_mp4.py styles/batik/index.html --fast
python tools/probe.py styles/batik/index.html
```

A `--fast` 720p render of the 37.5-second demo takes about 80 s on a quiet Apple M4: a 5 s load, then 900 frames at
about 85 ms each, including reading the canvas back and encoding (3 minutes with other renders sharing the machine).
`probe.py` lists shots where something stands between the camera and its subject.

## How it works

`index.html` loads Alegreya (Google Fonts), an import map for three.js 0.170 from jsDelivr, the song timing
(`../../examples/poem/lyrics_data.js`, which sets `window.SONG`), and then `film.js` as a module; everything else is
imported from there. Units are feet throughout: a person stands about 5.6.

| File | Job |
|---|---|
| `film.js` | The player: builds the sets, draws song time t (sets up the shot, renders it, writes the caption band), playback on the audio clock, `window.__video`, `probe(t)` and `view(t, pos, look, fov)`. |
| `styles.js` | The four looks: `makeStyles(renderer)`, the buffer passes, and the composite shaders (batik, gold line, glass; the model box is three.js post-processing). The colourways (`WAYS`). |
| `stagekit.js` | The lamp rig: `stage()`, `lamp()`, `addLamp()`, haze cones, the tide (each colour's lamps faded over time), a bokeh backdrop for the glass. |
| `mats.js` | The card and figure materials, glowing bulbs, and the per-pass materials every mesh gets (`prepPasses`, `usePass`). |
| `props.js` | Card and dowel pieces: boxes, dowels, threads, sagging lines, cut shapes, leaves, flowers, plant clumps, a card house, a lantern, a cut cloud, the curved backdrop, card cut-out people for crowds. |
| `models.js` | Signed-distance models (no three.js, so the workers can import it): a person, and the countryside (trunk, crown, leaf, grass tuft, washing, line post, fence, kite, bow, smoke puff, cottage, sheep). The colour table. |
| `figures.js` | `makeFigures()`: meshed models as groups, and where a person's hands are (`handOf`). |
| `sdf.js`, `mesher.js`, `pieces.js` | Signed-distance modelling and meshing in a pool of module workers (`need()`). |
| `core.js` | Frame size, seeded random, canvas helpers, the GLSL noise, and the textures (paper fibre, gold leaf, frost). |
| `common.js` | Helpers for sets: dye tints `T`, `show`, `ground`, easing, `polyline`, props in hands, pose flips on twos, merging static meshes. |
| `shotkit.js` | Helpers for shots: `pal()`, `orbit()`, `word()`, `line()`, `beat()`. |
| `sets.js` | The sets a shot can name: `{ field }`. |
| `set_field.js` | The demo's set: the land, the wind (`GUSTS`, `wind()`), every piece, and `update(t)`. |
| `shots.js` | The shot list, `shotAt(t)`, `camAt(shot, t)`, and the windows of the outro. |

`sdf.js`, `mesher.js` and `pieces.js` are the diorama style's ([styles/diorama](../diorama)), with one change: the
mesher leaves out the diorama's darkening of hollows (see the lessons below). A point takes its material code from
whichever operation wins there rather than a blend of them, in both styles. `pieces.js` also has `needOne()` and
`assign()`, for figures re-meshed in a new pose on every step (the diorama's `Actor`); this demo doesn't use them. The
countryside models in `models.js` are the diorama's too, rescaled and recoloured to land on the dyes.

### A set and its lamps

A set is an async function that returns an object; `stage()` starts one with a scene, a camera and the two lamps:

```js
import { V, stage, applyTide } from './stagekit.js';
import { T, ground } from './common.js';
import * as PR from './props.js';
import { makeFigures } from './figures.js';

export async function yard(renderer) {
  const S = stage(renderer, { goldPos: V(-40, 44, 36), goldAim: V(0, 0, -4), bluePos: V(40, 44, 36), blueAim: V(0, 0, -4),
    goldO: { i: 1.3, angle: 0.6, far: 160 }, blueO: { i: 1.2, angle: 0.6, far: 160 } });
  S.scene.add(ground(200, 200, { tint: T.soga, pat: 5, patScale: 1.5 }));          // dotted soga ground
  const house = PR.tag(PR.house(8, 7, 6.5), { tint: T.cream }); house.position.set(0, 0, -12); S.scene.add(house);
  const F = await makeFigures({ reader: { pose: { dress: 'indigo', skirt: 'rose', skirtMat: 13, hair: 'bun' } } });
  F.reader.position.set(3, 0, -4); S.scene.add(F.reader);
  S.P = { reader: F.reader };                   // named parts a shot can show or hide
  S.tide = () => ({ g: 1, b: 1 });
  S.lref = 0.3; S.nearFar = [12, 60];
  S.update = (t) => { applyTide(S, t); F.reader.rotation.y = 0.3 * Math.sin(t); };
  return S;
}
```

Add it to `SETS` in `sets.js`. What the looks read from a set:

- `goldLights` and `blueLights` (from `stage()`, plus any `addLamp(S, warm, pos, aim, o)`), and `extraLights`
  (point lights with `userData.warm` true or false, counted as gold or blue).
- `lref`: the light level the dyes are measured against. A surface counts as lit when its light is over 15% of it.
  `?buf=gold` and `?buf=blue` show each lamp's light with `lref` as mid-grey.
- `tide(t)`: `{g, b}`, multipliers on the gold and blue lamps; `tideAt(t, [[time, gold, blue], ...])` eases between
  keys. Turning one colour down turns the cloth toward the other dye.
- `nearFar`: the depths (ft) over which lines thin out with distance; `crackle(t)`: how much the wax cracks.
- For the model box: `focus` (`{dist, aperture, maxblur}`; `film.js` sets `dist` from each shot's subject), `bloom`,
  `exposure`, `vignette`, `hazes`. For the glass: `glass` (`{bg, frost, frostT, growth(t), amount}`).
- For `film.js`: `update(t)` (pose everything for song time t), `P` (named parts, for `show`), `named` (for `probe`).

Lamp options (`goldO`, `blueO`, or `lamp(colour, pos, aim, o)`): `i` intensity, `angle`, `pen` penumbra, `map`
shadow-map size, `near`/`far` (keep the shadow camera tight round the set), `nb` normal bias, `soft`.

### Pieces

Card pieces are ordinary three.js meshes; signed-distance pieces are meshed in workers. Either way a mesh's `userData`
tells the looks how to treat it (`PR.tag(object, {...})` sets it on every mesh under an object):

| key | meaning |
|---|---|
| `tint` | the thing's own colour (card pieces; a meshed model multiplies it into its own colours). The full palette dyes it the nearest dye. `T` in `common.js` has a tint next to each dye. |
| `mat` | the material code, for meshes without one of their own: 0 plain, 1 metal, 2 glow, 3 cloth, 4 hair, 5 red dye (keeps its red in the two-dye picture), 6 leather, 7 lamp, 9 ground, 10 sky, 13 patterned cloth, 14 a glow that keeps its own dye, 15 wax resist (left cream in any palette). |
| `patKind`, `patScale` | a batik pattern drawn in the object's own space: 3 parang, 4 kawung, 5 dots, 6 stripes, 7 stone courses, 8 grass ticks, 9 water, 10 cross-hatch, 11 fine cracks; `patScale` in the object's units (feet). On a card piece it covers the whole piece; on a meshed model only its mat-13 parts (parang unless `patKind` says otherwise). |
| `side` | 0 neutral, 1 warm, 2 cool, 3 both: the gold line draws warm things in gold and cool ones in silver (neutral things take the metal of the lamp that lights them). |
| `finish` | the glass look: 1 gilt, 2 etched, 3 stained, 4 clear, 5 light, 6 faint etch, 7 painted dark. |
| `noPass`, `litOnly`, `passOnly`, `alphaCut`, `passAlpha` | no buffer materials (haze cones); only in the lit or only in the buffer passes; a cut-out's alpha. |

Meshed models are signed-distance models from `models.js`, requested by name, parameters and cell size:

```js
const G = await need({ tree: ['crown', { seed: 2, r: 5.4 }, 0.1], leaf: ['leafChip', { mat: 15 }, 0.012] });
const F = await makeFigures({
  her: { pose: { hgt: 5.4, dress: 'red', skirt: 'indigo', skirtMat: 13, hood: 'yellow', stride: 0.36, wind: [0, 0.75] }, patScale: 0.3 },
});
```

A model is an ordered list of operations on primitives (see [styles/diorama](../diorama) for `P.sphere`, `P.cone`,
`P.box`, `P.fn` and the rest) with a colour and a material code. The person (`personModel`) takes `hgt`, `build`,
`dress`, `skirt`, `skirtMat`, `hem` (0.55 a long skirt, about 2.3 a coat to the knee over trousers), `legs`, `hood`
(a colour for a headscarf), `hair` ('short', 'bun', 'long'), `cap`, `scarf`, `apron`, `bag`, `pack`, arms `armL` /
`armR` `{fwd, out, bend}`, `headYaw`, `headPitch`, `lean`, `stride`, `kneel`, `sit`, `face: 'full'`, and `wind: [x, z]`,
how far (ft, in the figure's own frame) the wind blows the hem, long hair, the scarf's end and a headscarf's knot, with
`flap` shifting the ripples round the hem. A walk is four meshes (stride +, 0, -, 0) swapped on twos. `handOf(req, 'L')`
gives a hand's position for putting something in it (`hold()` in `common.js`).

### The buffers and the batik

For the buffer looks, `styles.js` draws the set five times into buffers at twice the frame size (3840 x 2160): normal
and depth; ids (which object, its side and finish, its material code, its pattern); its local colour; the lit set with
only the gold lamps on; and with only the blue. The shadow maps are drawn once, in the gold pass. Then one full-screen
shader draws the look and the result is filtered down to 1920 x 1080. The batik shader, for each pixel:

1. Wobbles where it samples a little (the lines "boil" on twos), and reads the buffers there.
2. Measures each lamp's light by the luminance of the lamp's own colour, so the two balance: `lit` if the total is
   over 15% of `lref`, `onlyG` if the gold's share is over 0.7, `onlyB` if under 0.3.
3. Two dyes: cream where both lamps reach, soga or indigo where one does, near black where neither. The sky is a soga
   field on the gold lamp's side of the cloth, indigo on the blue's, cream between, each bounded by a line of wax.
4. Full palette: the local colour snapped to the nearest of nine dyes (cream, soga, indigo, near black, red, green,
   yellow, pale blue, rose) as the colourway dyes them, then overdyed: toward soga where only the gold reaches, toward
   indigo where only the blue does, toward black where neither. The sky is mega mendung, cloud bands in steps with wax
   between them, in the colourway's sky dyes.
5. Mixes the two by the palette, along the dye front.
6. Red dye (5) stays red in two dyes; lamps are bright wax; wax resist (15) is cream.
7. Patterns: the id buffer's pattern drawn as wax against the dye (dark on light, cream on dark).
8. Fillers in the two-dye picture: dots on the indigo, fine lines in the dark.
9. Wax lines along silhouettes (an id change or a jump in depth) and creases (a turn in the normal), found at one,
   two and (up close) three pixels; cream on dyed ground, dark where the ground was left light.
10. Crackle: two scales of Voronoi cracks, patchy, only where the wax is (the light parts).
11. The weave and uneven dye, the windows (below), the fade to bare cloth, a split screen's divider, the tumpal border
    and the caption band.

**The palette** is a function of song time returning an object; `pal()` in `shotkit.js` makes the usual ones:

```js
pal(a, b = a, w0 = 0, w1 = 0, dir = [1, 0], wayA = 'day', wayB = wayA, extra = {})
// a, b: how much of the full palette shows before and after the dye front (0 two dyes, 1 full)
// w0, w1: when the front starts and finishes its sweep across the cloth; dir: its direction on screen
// wayA, wayB: the colourway before and after it (WAYS in styles.js: 'day', 'dusk', 'sogan')
// extra: slip [x, y] (jolt the picture, as fractions of the frame), rain (streaks of wax, 0..2), cap (the caption
//   band's height in pixels, 0 for none), skyTop / skyBot (override the colourway's sky), and the windows (win, winR,
//   win2, looks)
```

A colourway is the same design dyed another way, the way one waxed cloth is dyed in several colourways: `WAYS` maps each
of the nine dyes to what it comes out as, and gives the sky's two dyes. The demo's second verse sweeps from `day` (the
dyes as they are) to `dusk` (greens to dark teal, yellows to orange, a rose sky); `sogan` is browns and indigo only.

**Windows** (the outro): two round windows in the cloth that show the same set in other looks, drawn from the same
buffers: 1 the lit model box, 2 gold line on indigo, and cruder takes on 3 wool embroidery, 4 a varnished painted
panel, 5 a halftone print, 6 backlit paper cut, 7 linocut, 8 an engraving thrown by a lantern. Each has a rim of wax,
and round them the dye can marble (two eddies turning opposite ways, one round each window). `win: [x, y, distance
between the centres, rim strength]` (pixels of a 1080-high frame, y up), `winR: [left radius, right radius]` (0 is
shut: grow them to open a window, on a beat), `win2: [height / width, turn, marbling, how far the windows show]`,
`looks: [left, right]`. See `windows()` in `shots.js`.

**Split screen**: a shot with `split: [panelA, panelB]` (each a `{set, cam}` like a shot) and `band: (t) => width`
draws two panels side by side, each into its half of the buffers (so both may use the same set), with an indigo
divider edged in tumpal; each panel's sky is its own lamp's dye.

### Shots and the camera

A shot is a plain object. From the demo:

```js
// the title, the cloth in two dyes; then "Who has seen the wind?": the colour comes in across the cloth with the
// wind, and the camera comes down over the field
{ t0: 0, t1: line(1), set: 'field', palette: pal(0, 1, line(0) - 0.05, line(0) + 1.3, [1, 0], DAY), breath: 0.8,
  cam: [[0, [36, 52, 176], [2, 6, -34], 36], [line(1), [26, 30, 118], [4, 8, -28], 36]] },
// "The wind is passing through.": the washing, the gust passing along the line
{ t0: line(3), t1: line(4), set: 'field', palette: pal(1, 1, 0, 0, [1, 0], DAY), breath: 0.3,
  cam: [[line(3), [-27, 7.5, 3], [-57, 4.8, -22], 36], [line(4), [-29, 7, 0], [-57, 4.8, -22], 36]] },
```

- `cam`: keys `[time, position, look-at, fov, roll?]`, eased between; or `camFn(S, t)` returning one key (the kite
  shot follows the kite this way). `breath` (ft) adds a slow drift so no shot sits dead still.
- `palette(t)`: above. `show`: the names of `S.P` parts to show (every other named part is hidden).
- `apply(S, t)`: anything the set's `update(t)` doesn't already do; `focus`: the subject, a point or a function of t
  (for `probe` and the model box's lens; default the look-at point).
- `shotAt(t)` takes the first shot whose `t0..t1` contains t, so keep them in order and covering the song.

The wind is one field in `set_field.js`: a breeze that changes by section, plus gust fronts, each `[time it passes
the origin, strength, width, direction [x, z], speed]`, timed with `word(i, k)`. Everything that moves reads it where
it stands: trees bow at the trunk's foot and again at the crown (the crown more), the leaves tremble harder and are
released in the gusts on flights worked out at load, grass leans, smoke lays over, the washing lifts and swaps between
three billow meshes, the kite climbs, and the walkers' hems blow. The gust along the washing travels north-east, from
the line's near end to its far end, so it fills the sheets one after another rather than all at once.

### The caption band

The batik shader leaves a band 112 px tall along the bottom of the cloth (indigo, small tumpal triangles on the outer
edge, a soga line on top), and `drawCaption` in `film.js` writes into it: during the intro `SONG.title` in italics and
`SONG.credit` in spaced capitals; then each line of `SONG.lines`, from just before it starts until the next begins (or
a second after it ends), each word going from dim to full as it's sung. A line with `voice: 'a'` or `'b'` is set in
that voice's colour (for duets). The font is Alegreya, from Google Fonts.

### Determinism and caching

Every frame is a function of the song time alone: pieces move on twos (`twos(t) = floor(12 t) / 12`), the lines boil
on twos, random numbers come from fixed seeds, and anything with a history (the leaves' flights) is worked out at load.
So `step(t)` and `renderAt(t)` are the same function and any slice of the film renders exactly. Meshes are made once
at load and shared between identical requests.

## Make your own video in this style

1. **Copy the folder**: `cp -r styles/batik projects/my-song`, and put your mp3 in it as `song.mp3` (the whole process
   is in [docs/your-own-video.md](../../docs/your-own-video.md)). The tools serve it at
   http://localhost:8000/projects/my-song/index.html.
2. **Your song**: time it with the pipeline in [docs/timing.md](../../docs/timing.md), which ends with
   `tools/audio/to_js.py` writing `lyrics_data.js`, then in `index.html` change `../../examples/poem/lyrics_data.js`
   to `lyrics_data.js`, and the title and heading. `SONG.audio` is the mp3's path relative to the page.
3. **Keep** `film.js`, `styles.js`, `stagekit.js`, `mats.js`, `props.js`, `figures.js`, `models.js`, `sdf.js`,
   `mesher.js`, `pieces.js`, `core.js`, `common.js` and `shotkit.js`. **Replace** `set_field.js` with your sets (the
   field is there to borrow from), `sets.js`, and the shots in `shots.js` (keep `shotAt` and `camAt`).
4. **A set**: a file exporting `async function mySet(renderer)` like the one above, added to `SETS`. Place the lamps as
   you would place dyes: the side of a thing that faces only the gold lamp comes out soga. Check with `?buf=gold` and
   `?buf=blue`, and keep the edges of the lamps' cones out of frame.
5. **A model**: a function in `models.js` returning `{model, bounds}`, added to `MODELS`; give each part a colour close
   to the dye you want and a material code. For something that changes shape (a walk, a sheet billowing), mesh a few
   poses and show one at a time, on twos.
6. **A shot**: an object in `SHOTS`. Cut on line starts (`line(i)`), put hits on beats (`beat(n)`) and words
   (`word(i, k)`). Keep a whole person 20 ft or more from the camera. Two dyes for the high points, the full palette
   for the busy verses; move between them with a dye front on a line start.
7. **Time a move to a word**: for a gust, set its time a little before the word so the front reaches the thing on the
   word; for a pose, `poseAt(S.P, [[word(2, 3), 'wave']], t)`; for a front, `pal(1, 0, word(7, 0), word(7, 0) + 1.2)`.
8. **Knobs**: the lamps (position, intensity, the tide), `lref` (how much light counts as lit), the palette and its
   colourway, `WAYS` (new colourways), `crackle`, `patScale` on each thing, the `GUSTS`, `breath` on each shot, and
   the dye thresholds in `BATIK_FS` (0.15 for lit, 0.3 and 0.7 for one lamp's share).

For a long song, render in stretches (see Performance).

## Lab

Open http://localhost:8000/styles/batik/lab/index.html and pick a scene (the meeting on the path, the washing, the
trees on the ridge) and a look; `?scene=washing&style=glass` opens on a pair. The lab builds the demo's set and draws it
from three of the demo's cameras, so a look is always compared on the same picture. To render every pair:

```
python tools/lab_stills.py styles/batik/lab/index.html --all --sheet
```

What each look's renderer does with the same set:

- **Batik** (`batik`): the buffers and the batik shader above. In the lab the meeting and the washing are in the full
  palette, the ridge in two dyes.
- **Two-lamp model box** (`box`): the lit set as it is, through three.js post-processing: GTAO ambient occlusion, a
  bokeh depth of field (the haze cones hidden from its depth, or everything behind them blurs), bloom and a grade.
  The set's curved backdrop and the two lamps' haze make it read as a model on a stage.
- **Gold line on indigo** (`goldline`): the same buffers, but only lines and hatching on indigo paper: silhouettes
  firm and creases lighter, both thinner with distance; lines in gold where the gold lamp lights a thing and silver
  where the blue does; shadows hatched in the other lamp's metal (crosshatched where neither reaches); patterns as fine
  metal; a gold rule and a silver rule round the frame.
- **Shop-window glass** (`glass`): the buffers plus a bokeh canvas behind (`S.glass.bg`, from `bokehCanvas()`), gold
  leaf and frost textures. Gilt is flat crinkled leaf reflecting a room we never see (bright bands that move); etched
  glass is frosted in three steps by the light; stained glass is the thing's colour lit from behind by the bokeh's
  brightness; clear glass shows the lights behind; lines are scratched through. Frost grows in from chosen edges.

## Performance

On an Apple M4 (the tools run headless Chrome with the GPU on):

- **Load**: about 5 s: 49 meshes, 1.4 million vertices, meshed in up to 8 workers; the big tree's crown and the
  cottage are the slowest.
- **Frames**: 60-110 ms to draw a frame (the first frame longer, compiling shaders); in an MP4 render about 85 ms a
  frame including reading the canvas back and encoding. A `--fast` render of the demo takes about 80 s, or 3 minutes
  when other renders share the GPU.
- **Memory**: about 100 MB of JavaScript heap; about 0.6 GB on the GPU, most of it the five buffers at 3840 x 2160
  (three in half-float) and their depth buffers, plus the two lamps' 4096-square shadow maps.
- **What makes it slow**: the buffers' size (`SS = 2` in `makeStyles`; 1 is four times cheaper and the lines get
  coarser), draw calls times five passes (merging static meshes with `mergeStatic` and drawing the shadow maps once
  took a set of thousands of small meshes from 3.3 s a frame to 0.2 s), shadow-map size, and the batik shader's edge
  search.
- **A slice**: `python tools/render_mp4.py styles/batik/index.html --start 15 --end 19 --fast`. Every frame depends
  only on its time, so a slice can be spliced into a full render with `tools/splice.py`.
- **A long song**: build only the sets a stretch needs, and render the song in stretches into one folder of frames,
  which picks up where it stopped if interrupted:
  ```
  python tools/render_frames.py projects/my-song/index.html --dir renders/frames/my-song --end 62 --query sets=street
  python tools/render_frames.py projects/my-song/index.html --dir renders/frames/my-song --start 62 --query sets=yard
  python tools/encode.py renders/frames/my-song --out "renders/My Song.mp4"
  ```
  Loading every set of a long video at once can exhaust the GPU and hang the render after a frame or two. Frames are
  numbered by song time, so the stretches meet exactly and the song goes on once, with no joins.

## Lessons and gotchas

- **Weigh each lamp by its own colour.** At the same intensity blue light has half the luminance of gold, so measured
  by luminance the gold's share of an evenly lit surface sits at about 0.67, just under the 0.7 threshold: whole slopes
  flipped between cream and soga. The shaders divide each light by the luminance of its lamp's colour.
- **Dye edges come from the light, so keep the lamps' own edges out of frame.** A spot's cone edge across the set made
  a soft soga blotch that no batik has. Put the lamps far enough off that both reach everything in view, with little
  penumbra; then the dyes follow what faces which lamp and what shadows what.
- **Material codes must not blend.** Blended where two materials meet, their codes passed through a third (a glow)
  and every such join lit up. `sdf.js` takes the winning operation's code, and the passes carry it as a `flat` varying.
- **Colours near a dye boundary flip dyes.** A bark brown landed on green; a pale skin went rose where it was darker.
  Choose each colour close to the dye you want (the table in `models.js` is checked against the nine), and don't
  darken hollows: the diorama's carved-wood patina changed the dye in every crease, so `mesher.js` turns it off.
- **No noise on the dye thresholds.** A noise meant to make dye edges wander, fixed to the screen, read as static
  wherever a surface's light sat near a threshold. The edges wander with the sampling wobble instead, which moves with
  the cloth.
- **Coplanar surfaces flicker in blocks**, and the edge finder outlines every block. Keep surfaces apart (a few inches
  at the set's scale).
- **Shadow acne** shows as dye speckle; a normal bias of 0.1 ft cures it at this scale.
- **Draw the shadow maps once.** Five passes each redrawing every lamp's shadow map cost more than everything else; the
  gold pass draws them and the blue reuses them.
- **Thousands of small meshes** (flowers, needles, bulbs) cost a draw call each in every pass. Merge the static ones
  (`mergeStatic`), and make any mesh that appears mid-shot at build time, only swapping its geometry, or it has no pass
  materials.
- **Instanced meshes need instancing in the pass shaders** (the grass and leaves here); `mats.js` applies
  `instanceMatrix` and `instanceColor`.
- **Things thinner than a few pixels become all wax line.** Grass blades come out as cream strokes: batik-like, but
  keep them sparse near the camera or they fill the frame.
- **Object-space patterns are sized in the object's units.** A pattern that reads in a close-up vanishes in a wide
  shot; give big things (the ground) bigger patterns.
- **The ambient light counts in both lamps' passes.** With one lamp turned off, faces away from the other still came
  out cream; turn the fill down with the lamp. Likewise a dark backing behind a lit cut-out must take no light at all,
  or both lamps dye it cream.
- **Faces in two dyes take the dye of their lamp, like everything else**, so a face can go soga or indigo; use the
  full palette for close-ups where a face should stay pale.
- **A box's back face mirrors its texture.** A board with shapes cut through it showed the wrong holes from behind;
  build a cut-out from a front face and a back face with the holes lined up.
- **Things held in hands float** unless they're children of the figure at the palm: `handOf()` repeats the model's arm
  maths.
- **A coat blown sideways, seen from the front, read as a kicked leg.** Check a figure's wind from the camera it's
  seen from, and ease it for the front view.
- **The camera's breath needs a start time.** A split screen's panels had none, the drift came out NaN and the panels
  rendered empty.
- **`show()` hides every named part not listed.** Keep pieces that are always there out of `S.P`, or list them in
  every shot.
- **Build only what a stretch needs.** With every set of a long video loaded at once, a render hung after one frame;
  `?sets=` builds only some, and a frame whose set isn't built is skipped at load rather than failing.
- **Nothing may sit still**: a hold longer than a beat or two reads as the player freezing. Keep the camera breathing,
  the lamps swinging and something in the wind.
- **Don't start or end on a blank frame.** The cloth fades in from half-dyed and back toward bare cloth, never all the
  way.
- **Judge colour at full size.** Thin lines and crackle average out in contact-sheet thumbnails.
- **three.js's ambient occlusion isn't repeatable on its own**: `GTAOPass` makes its denoising noise with
  `Math.random()`, so the model box came out a few levels different on every load (which matters when frames are
  rendered in several browsers, or a slice is spliced in). `styles.js` seeds `Math.random` while it builds the pass.
- **Load the page without waiting for `load`**: the tools wait with `wait_until='commit'` and poll `__video.ready`.



===== 完整公共规范：CLAUDE.md =====

# Instructions for Claude

This repository makes music videos in code: each style in `styles/` is an engine that draws every frame on an HTML
canvas (or WebGL / three.js) in a hand-made-looking medium, timed to a song, and `tools/` renders them to MP4. Read
`README.md` for the map, then the doc for whatever you're doing.

## When someone wants a video for their song

Follow [docs/workflow.md](docs/workflow.md). It's a conversation, not a build order to rush through:

1. **Get the inputs:** the song (mp3), the lyric sheet as sung, and ask whether they have stems and MIDI (Suno and
   stem splitters provide them) and any reference images.
2. **Ask the concept questions before building anything:** who is singing, who "you" is, whose voice the chorus is,
   what the key images (especially the ending) mean, how much the video may show, what stays out. Don't guess at
   these; an open question is better than a confident wrong answer. If the song belongs to a larger world, read
   whatever they give you about it, and keep a list of every detail the video invents, flagged as unconfirmed.
3. **Measure the song** ([docs/timing.md](docs/timing.md)): tempo, sections, stops and hits, and every word's time.
   Time to the audio, not to the lyric sheet's markings.
4. **Pitch three looks and recommend one:** the medium and why it suits this song, the organizing object, a small
   visual grammar and an arc, a section-by-section plan keyed to timestamps, and the open questions. The styles in
   `styles/` are the starting points (each README says what it's good at); a new medium is fine too
   ([docs/engine-patterns.md](docs/engine-patterns.md)).
5. **Style lab:** the same three or four moments drawn in each candidate look. Show the stills.
6. **Checkpoint:** build one section (20-90 s), render it (`--fast`), send it, get notes.
7. **Build the rest** section by section, then render the final MP4s. The MP4 is what gets shared.

Build a project in `projects/<song-slug>/`, copied from a style folder ([docs/your-own-video.md](docs/your-own-video.md)).
Don't change `styles/` for one person's video. Keep notes in `projects/<song-slug>/PLAN.md` as you go: their answers
and rulings, the measured sections and sync points, the shot list, the invented details, and their feedback on each
round. A later session should be able to pick up from that file alone.

## Working practices

- **Look at what you render.** Make stills and contact sheets (`tools/still.py ... --sheet`) and open the images.
  Check every frame on the sheet: edges, blank frames, the camera inside things, covered text, long freezes.
- **Read the console output** the tools print. A single bad canvas gradient value blanks a frame.
- **Preview slices with `--fast`**; render the full 1080p only at the end. Styles that carry state between frames
  must be rendered in order (the tools do this).
- **Keep it deterministic:** seeded randomness keyed to the frame, never `Math.random()` per frame.
- **Follow the page contract** in [docs/rendering.md](docs/rendering.md) (`window.__video`, `window.SONG`,
  `<canvas id="film">`, `#t<seconds>` stills) so the tools work.
- Apply the lessons in [docs/workflow.md](docs/workflow.md#what-the-notes-taught-true-for-every-style): busy
  enough, no long freezes, obvious changes, varied choruses, whole figures rather than close-up hands.
- The person's audio is git-ignored. If their lyrics or story are private, keep the project out of any public
  remote (add it to `.git/info/exclude`, or keep it outside the repo and pass `--root` to the tools).

## Setup

```bash
python3 -m venv .venv && .venv/bin/pip install -r requirements.txt -r requirements-audio.txt
```

Google Chrome must be installed (or `.venv/bin/python -m playwright install chromium`). To preview in the desktop
app's browser pane, create `.claude/launch.json` running `python3 tools/serve.py 8000` on port 8000 (git-ignored).
Use the server, never `file://`: module pages don't load from files and a plain server caches stale scripts.



===== 完整公共规范：docs/workflow.md =====

# How a video gets made

These videos were made in conversation: a person with a song and a clear sense of what it's about, and Claude
writing and rendering the code. The process below is what worked over a dozen songs. It suits working with Claude
Code (see [CLAUDE.md](../CLAUDE.md), which tells Claude to follow it), and it works just as well by hand.

The short version: **decide what the song is about, measure it, pitch three looks, test the look on a few scenes,
build one section, get notes, then build the rest.** Each step is cheap next to the one after it, so mistakes get
caught while they're still cheap.

## 1. Gather the inputs

- **The song** as an mp3 (or anything ffmpeg reads).
- **The lyric sheet** as plain text, one sung line per line, with `#section` markers (see
  [examples/poem/lyrics.txt](../examples/poem/lyrics.txt)). Write it the way it's sung: if the singer repeats a line
  that isn't on the sheet, add it.
- **Stems, if you have them.** An isolated vocal stem makes transcription far cleaner. Suno exports stems as audio
  and as MIDI per instrument; the MIDI's tempo map gives an exact beat grid, and the vocal MIDI gives note onsets to
  snap words to (see [timing.md](timing.md)).
- **Reference images, if any.** Mood boards and concept art are useful for content (what's in the world, what
  people wear, what the place looks like) even when the style will be different.

## 2. Decide what the song is about

Before any pictures, answer the questions that decide the concept. A video can't be good if these are guesses.

- **Who is singing,** and to whom? Who is "you"? It's often not who it seems, and it can change between verses.
- **Whose voice is the chorus?** The singer's, an imagined audience's, a crowd's, a custom's?
- **What do the key images mean?** Especially the closing one.
- **How much may the video show?** If the song belongs to a larger story, what would be a spoiler?
- **What stays out?** Eras, events, people, kinds of imagery.

If the song is part of a larger world (a novel, a game, a band's mythology), read up on it first, and **keep a list
of every detail the video invents**: a place's layout, what a prop says, who stands where. Show that list to
whoever owns the world, and treat nothing on it as settled until they say so.

## 3. Measure the song

Time the video to what the audio does, not to what the lyric sheet says. (AI song generators in particular ignore
markings like "quiet" or "almost unaccompanied".) With the tools in [timing.md](timing.md):

- tempo, and whether it changes;
- the sections and their loudness: which chorus is the big one, where it drops to almost nothing;
- **the stops and hits.** Musical stops, dropouts and the hit that ends a bridge make the best sync points: the
  place to freeze, cut, switch a light off, or change the whole picture;
- every word's time.

## 4. Pitch three looks

Offer three directions and recommend one. For each:

- **the medium** (paper cut, embroidery, marbled paper...) and why it suits this song. The strongest choices mean
  something: marbled paint for a song about water, where nothing stays put; a lantern lecture for a song sung by
  someone lecturing; a desk of files and stamps for a song about a record that doesn't add up;
- **the organizing object:** the one thing the whole video is, such as a desk under a lamp, a hanging read along
  its length, a printed sheet, a painted wagon's panels, a board of pasted-up photographs;
- **a small visual grammar:** a few rules that give the images meaning (stamps are the audience's verdicts, frost
  is the stillness, the camera's date flickers between years), and an **arc** over the song (clean to decayed,
  night to morning, empty to crowded);
- a **section-by-section plan** keyed to timestamps, giving each section one main image;
- the questions still open.

The [styles/](../styles) folder has eighteen engines to start from, and each one's README says what it's good at.
A new song can also want a new medium: the engines share their patterns ([engine-patterns.md](engine-patterns.md)),
so a new one is less work than it sounds.

## 5. Style lab

Draw the same three or four key moments in each candidate look, side by side, as stills (and a few seconds of motion
if the look depends on how it moves). Comparing like with like makes the choice easy, and it shows the problems
early: people who look like mannequins, faces that look ill, a palette that turns cute. Every family here with more
than one look has a lab page (`styles/<family>/lab/`) built this way.

Expect the first choice to be refined: "this look, but with the other one's colours", or "this, for the scenes in the
other world only". Mixing is fine.

## 6. Checkpoint

Build a real section before the whole song: 20-30 seconds of the section that carries the concept, or the first
90 seconds. Render it as an MP4 and get notes on the look, the pace, the figures, the text. This is where most of
the useful notes arrive, and they're cheap to act on now.

## 7. Build the whole song

Section by section. After each, render stills across it (`tools/still.py ... a:b:2 --sheet`) and look at every one:
frame edges, blank frames, things the camera cuts through, text that's unreadable or covered. Fix, then move on.
When it's all there, render the MP4, then scan it at one frame every two seconds.

## 8. Notes, and fixing a stretch

Notes on a full video are usually local: one stretch feels empty, one chorus repeats the last, a transition jerks.
Re-render only that slice and splice it in ([rendering.md](rendering.md#fixing-one-stretch)).

## 9. Deliver an MP4

Share the MP4, not the web page. A browser player's pause and scrub can feel unreliable, and people give up on it.
`tools/render_mp4.py` writes a 1080p file and a smaller 720p one for sending.

## 10. Revising a finished video

A second or third pass (new conventions, a list of fixes, a stretch that needs more going on) works best as: a short
written plan of every change; then before/after sheets, stills from the old render and the new build at the same song
times side by side; then the full render. The sheets let the notes land on exactly what changed. When picking stills
for review, catch short effects at their peak: a flash or a bolt that lasts half a second is easy to miss.

## What the notes taught (true for every style)

- **Busy enough.** Something new on nearly every beat, or at least every line. A stretch with nothing happening
  reads as a mistake, not a rest. When a stretch feels empty, fill it with callbacks (translucent overlays of earlier
  scenes) and background life (children, animals, people passing) rather than restaging it.
- **No long freezes.** A four-second still reads as the player stalling. Keep holds to a beat or two, or keep
  something drifting: a slow camera move, breathing light, smoke.
- **Make small changes obvious.** A face swapping for another face, a detail changing on a paper: if it matters,
  make it big and push the camera in on it. Subtle changes go unseen.
- **Too clean reads as dead.** A video that stays tidy all the way through can feel flat; give it an arc.
- **Vary the repeats.** The second chorus shouldn't replay the first. New scenes, with brief flashes back to the
  first chorus's pictures on key words, keep the echo without the repetition. A motif that does something different
  each chorus (ribbons that knot, then plait, then slip) works well.
- **Whole figures beat close-up hands.** Big silhouettes of hands and arms read as clubs, poles or chess pieces. A
  whole figure, even small and mostly still, carries a beat better.
- **Faces:** realistic halftone or heavy shading can make people look ill. Stylized faces (dot eyes, lowered lids
  when looking down) for close figures and blank faces for crowds read better.
- **What makes a look cute** (sometimes wanted, often not): flat candy fills, rounded sack-shaped figures with blob
  heads, even lighting, bobbing walks. For solemn songs, use weight, texture, uneven light and stillness instead.
- **Real texts make good props.** A period document, a real letter or hymn, an actual map give a scene weight even if nobody
  can read them.
- **Impossible places need ordinary things in them.** Floating or folded land only reads as land when it carries
  trees, lit windows, snow on its ground side, smoke going the "wrong" way.
- **Decide about text in the picture.** A lyric band under the picture is one choice; no readable text at all
  (squiggles for writing) is another; either way, be consistent. Captions that only repeat the lyric are redundant.
- **Fake text is worse than no text.** A card of invented glyphs that flickers reads as a screen of foreign writing.
  Use pictograms, squiggles, or nothing. Likewise on-screen read-outs (temperatures, timecodes) in a "technical"
  medium: keep them only if they mean something.
- **Show the medium working.** When a look risks feeling static (a photograph, a print, a drawing), let the viewer
  watch it being made: a plate exposing, inks printing in on the beats, stitches sewn in, a slide pushed into the
  lantern. It answers "static and unclear" without changing the look.
- **Vary what leads a scene.** In a medium with a life of its own (liquid light, marbling, sand), let some scenes be
  led by the pictures and some by the medium, rather than the same mix throughout.
- **Props must sit in hands.** A rope, a ring, a cloth or a cup that floats near a hand reads as broken. Anchor held
  things to the rig's hand points and check every one in stills.
- **Arms that move naturally:** pose them by where the hand and elbow should be, blend joint angles rather than
  positions, let the forearm trail the upper arm, and add breathing and small weight shifts. Arms that slide
  straight between poses look like a puppet's.
- **Bodies carry identity.** In silhouette, heat or other outline-first looks the outline is all a viewer gets: if
  someone is heavily built, or small and round, the shape must show it. Keep sizes consistent (an animal is as big in
  every shot).
- **Shapes read as other shapes.** A figure lying flat reads as a collapsed body (have them sit or doze upright unless
  a death is meant); a pyramid of sacks in a lit doorway reads as a hooded head; a fan of hair strands reads as a
  feathered headdress. Look at every silhouette as a stranger would.



===== 完整公共规范：docs/timing.md =====

# Timing a song

Everything in a video hangs off the song's clock: the lyric band lights each word as it's sung, pieces land on
beats, scenes change on line starts, the lamp goes out in a dropout. This page is how to get those times. The tools
are in [tools/audio/](../tools/audio); each prints its own help with `--help`.

Setup (once): `pip install -r requirements-audio.txt` (librosa, scipy, faster-whisper, mido). The Whisper model
downloads the first time it's used.

## The pipeline

```bash
# 1. the shape of the song: tempo, loudness, sections
python tools/audio/analyze.py song.mp3

# 2. words with timestamps, from the vocal stem if you have one
python tools/audio/transcribe.py vocals.mp3 --lyrics lyrics.txt --out whisper.json

# 3. your lyric sheet matched to Whisper's words
python tools/audio/align.py lyrics.txt whisper.json --out lines.json

# 4. snap each word to where the voice starts it (vocal MIDI and/or vocal audio)
python tools/audio/snap.py lines.json --midi vocals.mid --audio vocals.mp3 --out snapped.json

# 5. the page's data file
python tools/audio/to_js.py snapped.json --out projects/my-song/lyrics_data.js --title "My Song" \
    --audio song.mp3 --audio-file projects/my-song/song.mp3 --bpm 96 --beats-per-bar 4
```

Then open the video with the lyrics showing and listen through. Fix what's off by editing `lyrics_data.js`
directly: it's plain data.

## Step by step

### 1. The shape of the song

`analyze.py` prints the global tempo and the local tempo every 20 s, a table of loudness, brightness and rhythmic
busyness every few seconds, and guesses at section boundaries. Read it next to the lyric sheet. You're looking for:

- which sections are loud and which drop out: the video's big and quiet moments should follow them;
- tempo changes (a slow intro, a half-time bridge);
- **stops and hits.** `onsets.py song.mp3 --from 140 --to 155` zooms in on a stretch: the strongest onsets, the
  beats, and the loudness every quarter second, so a dropout shows as a run of low numbers. These are the best
  sync points a song offers: the place for everything to freeze, for a cut, for a light to go off.

`sections.py song.mp3 --lines lines.json` compares the sections' loudness, drums and tonal energy once you know
where they are.

### 2. Transcribe

`transcribe.py` runs faster-whisper with word timestamps. Give it the **vocal stem** if there is one; sung vocals
over a full mix transcribe much worse. The `small` model is usually enough and takes about a minute. `--lyrics`
passes the start of your lyric sheet as a prompt, so names and odd words come out spelled your way. `medium` can
rescue mumbled lines, but over a long song it can drift further than `small`.

Expect Whisper's times to run **early**, typically a few tenths of a second and sometimes by more than a second,
and to hear some words wrong, especially names and unusual words. Step 3 doesn't care about wrong words; steps 4 and
the listen-through fix the times.

### 3. Align

`align.py` lines your sheet up against Whisper's words (a sequence match, so misheard or missing words don't break
it; unmatched words get times interpolated from their neighbours). It prints each line with a match count like
`m7/9`. Low counts are where to listen first. Watch for:

- **numbers:** Whisper writes "1974" as one token for three sung words. The script spells out years and small
  numbers before matching, but check them;
- **hyphenated words** and contractions;
- **a misheard last line** ("Let it go" for "Letting go"): the end of a song, over a fade, is where Whisper guesses;
- **repeats and ad-libs** the singer added: put them on the sheet as sung, or they'll be squeezed between
  neighbours.

### 4. Snap to the voice

`snap.py` moves each word to the nearest sung-note onset within 0.32 s: note onsets from the **vocal MIDI** first
(if you have it), then onsets detected in the **vocal audio**. It first reports the median offset between the words
and the onsets; if Whisper ran early across the whole song, pass that back as `--shift` so everything moves before
snapping.

After snapping, some things still need a human ear:

- **line starts that land in silence** or on the tail of the previous word: move them to where the voice comes in;
- **choruses and held notes:** a melisma or a long held word confuses onsets;
- **MIDI quantization:** Suno's MIDI is quantized to sixteenth notes and can sit about 0.3 s off the voice.

For those, `onsets.py vocals.mp3 --from 25 --to 27 --pitch` prints the sung pitch and loudness every 50 ms: the
word starts where the pitch appears and the loudness jumps.

### 5. Write the page data

`to_js.py` writes `lyrics_data.js`, which sets `window.SONG`:

```js
window.SONG = {
  title: "My Song", credit: "", audio: "song.mp3", duration: 212.4,
  bpm: 96, beatsPerBar: 4, firstBeat: 0.35,
  sections: [["verse1", 12.3, 41.0], ...],
  beats: [0.35, 0.975, ...],            // only with --beats: exact beat times
  lines: [{section: "verse1", text: "Who has seen the wind?", t0: 12.3, t1: 14.9,
           words: [["Who", 12.3], ["has", 12.9], ...]}, ...],
};
SONG.beat(n)  // the time of beat n
```

Every style in this repo reads that shape (see [examples/poem/lyrics_data.js](../examples/poem/lyrics_data.js)).

## Beats

For a steady song, `--bpm` and `--first-beat` (the time of the first downbeat) are enough: `SONG.beat(n)` is
`firstBeat + n * 60 / bpm`. Find the first beat with `onsets.py` on the song's opening seconds.

If the tempo drifts or changes, use exact beat times instead:

- **from MIDI stems:** Suno writes a tempo event on every beat, so the tempo map is an exact beat grid.
  `midi.py drums.mid --beats-out beats.json` (any of the song's MIDI files will do);
- **from the audio:** `analyze.py song.mp3 --beats-out beats.json` (librosa's estimate; check it).

Pass the file to `to_js.py --beats beats.json`; `SONG.beat(n)` then reads from the list.

## Hits and loudness

Some styles pulse, flash or move with the music itself rather than the words: a lamp that breathes with the mix, a
ring on every drum hit, mouths that open with the voice. `pulses.py` measures those:

```bash
python tools/audio/pulses.py song.mp3 --percussion perc.mp3 --drums drums.mp3 --vocals vocals.mp3 --out projects/my-song/audio_data.js
```

It writes `window.AUDIO = {fps, ticks, kicks, env, venv, vdb}`: small hits (`ticks`) and big ones (`kicks`) as
`[time, strength]`, the mix's and the voice's loudness 24 times a second (`env`, `venv`, 0..1), and the voice's
loudness in decibels mapped to 0..1 (`vdb`, better for mouths). Stems give much cleaner hits than the mix; without
them everything comes from the mix. The liquid light show reads this file as it is; any style can read the arrays.

## Suno specifics

- The stem download gives an audio file and a MIDI file per instrument. The lead vocal stem transcribes cleanly.
- The MIDI files carry a key-signature event that the `mido` library can't decode (it raises
  `KeySignatureError`). `tools/audio/midi.py` patches mido to read it as C; import `load()` from it in your own
  scripts to get the fix.
- The MIDI tempo map has one event per beat: an exact beat grid, including tempo changes after an intro.
- Vocal MIDI notes are quantized and can sit up to ~0.3 s off the voice: good anchors for snapping, not ground truth.
- Suno ignores dynamics on the lyric sheet ("quiet", "spoken", "almost unaccompanied"). Measure.

## Checking by eye and ear

Open the page, play it with the sound on, and watch the lyric band. Words that light up early are the common
fault. For a close look, `#t25.3` on the page's URL shows the frame at 25.3 s with the band as it is then.



===== 完整公共规范：docs/rendering.md =====

# Previewing and rendering

Every video here is a web page that draws its frames on a canvas. You watch it in a browser while you work, and
when it's done a script steps through it frame by frame in headless Chrome and pipes the frames to ffmpeg. This
page covers the page contract the tools rely on, previewing, stills, MP4s, and fixing a stretch.

Setup (once): `pip install -r requirements.txt` (Playwright, imageio-ffmpeg, Pillow, numpy). The tools drive your
installed Google Chrome; if you don't have it, `python -m playwright install chromium` gets Playwright's own.
imageio-ffmpeg bundles an ffmpeg with x264 and AAC, so there's nothing else to install.

## The page contract

A video page (a style's `index.html`, or a copy of one for your song):

- draws into `<canvas id="film" width="1920" height="1080">`;
- loads its song data as `window.SONG` (see [timing.md](timing.md#5-write-the-page-data)) and plays `SONG.audio`
  in an `<audio>` element, falling back to a silent clock if the audio can't load;
- sets `window.__video`:
  - `ready`: true once everything is built;
  - `duration`: the song's length in seconds;
  - `step(t)`: draw song time `t` the way playback does. The MP4 renderer calls it at 24 fps, strictly in order;
  - `renderAt(t)`: draw a still of time `t` from a fresh state (catching up whatever the frames before it built);
  - either may return a Promise (a page that builds scenes asynchronously); the tools wait for it;
  - `error`: set this to the error text if building fails, and the tools stop and print it;
  - optionally `shots` and `probe(t)` for 3D pages (see `tools/probe.py`);
- shows a still when the URL ends in `#t<seconds>` (e.g. `index.html#t12.5`), with the page chrome hidden;
- draws only while playing: a paused player shouldn't keep redrawing its frame on every animation frame (the tools
  draw and read back each frame in one call, but a page that redraws on its own fights anything else that draws);
- is **deterministic**: all randomness comes from seeded generators keyed to the frame number, never
  `Math.random()` per frame, so a given moment always draws the same picture. An MP4 depends on it.

A style-lab page sets `window.__lab = { ready, scenes, styles, render(scene, style) }`, where `render` draws one
scene in one look and returns the canvas.

## Previewing

```bash
python tools/serve.py            # serves the repository at http://localhost:8000/ and lists the demo pages
```

Open a page from the list. Use this server rather than `python -m http.server` or opening the file directly:

- pages that use ES modules or load files **don't work from `file://`**;
- a plain server lets the browser **cache scripts**, so after an edit you can be looking at the old code. This
  server sends no-cache headers;
- audio and video only seek when the server answers **Range requests**; this one does.

**Stills in the browser:** add `#t<seconds>` to the URL. Changing only the `#` part doesn't reload the page, so
after editing code, reload with a new query (`index.html?r=2#t30`).

**Always check the console** after a load. One bad value in a canvas gradient (a NaN colour stop) throws, and the
whole frame goes blank.

**In Claude Code's desktop app**, the preview pane can run the server for you: create `.claude/launch.json` with
```json
{ "version": "0.0.1", "configurations": [
  { "name": "videos", "runtimeExecutable": "python3", "runtimeArgs": ["tools/serve.py", "8000"], "port": 8000 } ] }
```
(it's git-ignored).

## Stills and contact sheets

```bash
python tools/still.py styles/paper-cut/index.html 5 12.5 30          # three stills
python tools/still.py styles/paper-cut/index.html 0:37.5:2.5 --sheet # a frame every 2.5 s, tiled into one image
python tools/lab_stills.py styles/embroidery/lab/index.html --all --sheet
```

Output goes to `renders/` (git-ignored). The contact sheet is the fastest way to review a whole video: look at every
frame on it, not just the ones you changed. Things to look for: frame edges showing the end of the world, blank or
black frames, the camera inside an object, text covered or cut off, two scenes' seams, something frozen too long.

## MP4s

```bash
python tools/render_mp4.py styles/marbling/index.html                    # renders/marbling.mp4 and -720p.mp4
python tools/render_mp4.py projects/my-song/index.html --out "renders/My Song.mp4"
python tools/render_mp4.py projects/my-song/index.html --start 60 --end 90 --fast   # quick preview of a slice
```

- Two files: 1080p (x264 `slow`, CRF 23, AAC 192k: roughly 5 Mbps for a busy picture) and `-720p` (CRF 25: about
  1 Mbps, small enough to send).
- `--fast` writes only the 720p with the `veryfast` preset. Busy, grainy frames can take many times longer to
  encode with the slow preset than to draw, so use `--fast` for previews and the normal mode for the final.
- The audio comes from `SONG.audio` unless you pass `--audio`. A slice gets short audio fades.
- **Fonts:** the styles load their type from Google Fonts. If a font request fails (a flaky network), canvas text
  silently falls back to a default font, so `render_mp4.py` and `render_frames.py` check the page's fonts after it
  builds and stop if any failed. Run again, or pass `--allow-font-fallback` if you really mean it. The still tools
  print a warning instead.
- 24 fps. Frames are rendered **in order**: many styles draw each frame over the one before (frost that grows,
  ghosting, marbled paint that keeps its history), so a frame can't be drawn on its own.
- Speed depends on the style and on how much the machine is doing: from about 40 ms a frame (paper cut, painted
  enamel, archive desk) to 250 ms or more (sand, the pinscreen, screenprint's printing), including reading the frame
  back and encoding. Each style's README gives its numbers. A four-minute song is 5,760 frames: a few minutes for the
  fast styles, half an hour or more for the slow ones (see the next section for splitting a render across browsers).

## Long renders: frames on disk, resumable, in parallel

For a long song in a slow style, render the frames to a folder instead of straight into ffmpeg:

```bash
python tools/render_frames.py projects/my-song/index.html --dir renders/frames/my-song --jobs 3
python tools/encode.py renders/frames/my-song --out "renders/My Song.mp4"
```

- Frame `i` is `<dir>/<i:05d>.jpg` and shows song time `(i + 0.5) / 24`. Frames already on disk are skipped, so an
  interrupted render continues where it stopped when you run the same command again, and deleting a stretch's
  frames and re-running redoes just that stretch.
- `--jobs N` renders N runs of frames in N browsers at once. Each run starts with `renderAt()` at its first frame,
  which catches up styles whose frames depend on earlier ones, then steps in order. (Tested: a resumed run's frames
  match a straight-through render pixel for pixel.) GPU-heavy styles gain less, since the browsers share one GPU.
- `encode.py` takes the audio from the folder's `meta.json` (the page's `SONG.audio`), cuts it to the frames on
  disk, and writes the same 1080p and 720p files as `render_mp4.py`.
- **A render that sits before its first frame** is usually the machine, not the page: with other renders or heavy
  WebGL pages running, Chrome can take minutes to start or to build a page. `render_mp4.py` prints the page's URL when
  it's loaded and a progress line every 240 frames.
- **Heavy 3D pages:** building every set of a long WebGL video at once can hang the GPU. Render such a video in
  segments (`--start`/`--end` runs into the same frame folder, each run building only what its stretch needs), and
  on a machine that other renders are sharing, run one segment at a time.

## Fixing one stretch

A full render can take a while. To fix one stretch, render only that slice at full quality and splice it into the
finished file at whole frames:

```bash
python tools/render_mp4.py projects/my-song/index.html --start 120 --end 135 --out renders/fix.mp4
python tools/splice.py "renders/My Song.mp4" renders/fix.mp4 --at 120 --out "renders/My Song v2.mp4"
```

A slice opens with `renderAt(t)`, which catches up styles whose frames build on earlier ones, so its frames match the
full render's and the splice is seamless.

## Checking a 3D video's framing

`python tools/probe.py styles/diorama/index.html` asks the page, for the start, middle and end of every shot,
whether anything stands between the camera and its subject, or whether the camera is inside something. In a crowded
set it finds blocked views much faster than contact sheets.

## Sharing

Share the MP4. If you also want a review page (the video with notes around it), keep in mind that some hosts cap
file sizes: split a long 720p video into parts at scene changes and play them in sequence against the song, and
serve it from something that answers Range requests.



===== 完整公共规范：docs/your-own-video.md =====

# Making a video for your own song

The hands-on steps, from an mp3 to an MP4. For the creative side (what to decide before building, how to pick a
look) see [workflow.md](workflow.md). If you're working with Claude Code, you can just ask it to make a video for
your song: [CLAUDE.md](../CLAUDE.md) walks it through all of this.

## 1. Set up

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt            # rendering
pip install -r requirements-audio.txt      # timing a song (Whisper, librosa, MIDI)
```

You need Google Chrome installed (or run `python -m playwright install chromium`).

## 2. Start a project folder from a style

Pick a style from the [gallery](../README.md#the-styles) and copy its folder:

```bash
cp -r styles/paper-cut projects/my-song
cp ~/Music/my-song.mp3 projects/my-song/song.mp3
```

Audio files are git-ignored, so your song stays out of the repository.

In `projects/my-song/index.html`, change the lyrics script from the demo's
```html
<script src="../../examples/poem/lyrics_data.js"></script>
```
to your own
```html
<script src="lyrics_data.js"></script>
```
(Relative paths from `projects/my-song/` resolve just as they did from `styles/<style>/`, so anything else the
page loads from the repo keeps working.)

## 3. Time the lyrics

Write the lyric sheet (`projects/my-song/lyrics.txt`, one sung line per line, `#section` markers), then run the
pipeline in [timing.md](timing.md). It ends with `projects/my-song/lyrics_data.js`.

## 4. Look at it

```bash
python tools/serve.py
```

Open `http://localhost:8000/projects/my-song/index.html`. The demo's scenes now play under your lyrics for as long as
the demo lasts. That's the moment to decide the plan: which scene goes where, which line lands on which image.

## 5. Replace the demo's scenes with yours

Every style's README has a "Make your own video in this style" section that says which files are the demo (its
scenes, sets, shots or timeline) and which are the engine. Keep the engine; rewrite the demo files. Work a section
at a time:

```bash
python tools/still.py projects/my-song/index.html 30:60:2 --sheet   # stills every 2 s across 0:30-1:00
```

Look at every still on the sheet. Check the console output printed at the end.

## 6. Render

```bash
python tools/render_mp4.py projects/my-song/index.html --start 30 --end 60 --fast   # a quick 720p preview
python tools/render_mp4.py projects/my-song/index.html --out "renders/My Song.mp4"  # the final, 1080p + 720p
```

To fix one stretch later without re-rendering everything, see
[rendering.md](rendering.md#fixing-one-stretch).



===== 完整公共规范：docs/engine-patterns.md =====

# How the engines are built

The eighteen engines in [styles/](../styles) share no code at run time: each folder is self-contained, written for one
song in one medium (a few began as copies of another's files, such as the 3D pipeline or the ray-marched figure). But they
share a shape, and knowing it makes any of them easy to read and a new one quicker to write. This page is that
shape, plus the browser gotchas that cost the most time.

## Simulate the process, not the look

Each engine models how its medium is physically made, and the imperfections come out right on their own:

| medium | what the code does |
| --- | --- |
| screenprint | each ink is a stencil mask plus a halftone; inks are pulled one at a time and multiplied onto paper, each a little out of register, with squeegee streaks and pinholes |
| linocut | a block is a list of gouge cuts and inked areas; the key block prints black over watercolour washes |
| wool embroidery | wool is laid and couched from tiles, outlines are stem-stitched, light is couched gold thread |
| marbled paper | paint floats as closed outlines on a bath; drops, combs and swirls are exact maps applied to every point |
| magic lantern | slides are baked as tinted glass; a frame stacks glass by multiplying and throws it through a lens |
| painted enamel | two-colour bristle strokes with a highlight flick toward the light, then gold leaf |
| paper cut | cut shapes with a lit rim and a soft shadow, layered in depth and lit from behind |
| mosaic | tesserae are laid in rows along the outlines, then grouted |
| sand on a lightbox | sand thickness is a density field; the lamp shows through as `exp(-k * thickness)`; fingers clear lines |
| carved diorama | each piece is a signed-distance sculpture meshed in the browser; tool marks are a bump in the piece's own space |
| photomontage | photographs are painted in greys, then given a print's grain, halation and tone curve, and cut out with drifting scissors |
| pinscreen | a field of pins at different heights, lit from a low angle, each pin's shadow falling on the next |
| archive desk | every paper is pre-rendered with its shadow, grain, foxing and torn fibres; stamps are inked, then eroded |
| night poster | a shape's shadow is the band a shifted copy of it fails to cover; night mixes colours toward navy while lamps keep their brightness |
| batik | a real 3D set lit by two coloured lamps is rendered into buffers; wax resists where both lamps reach, each dye takes where only one does, and the wax cracks |
| long-exposure glass plate | each frame integrates many light drawings over the exposure, so whatever moved is a smear and whatever stood still is sharp; then halation, dust and the emulsion's edge |
| silverpoint | even hatching whose weight follows the tone; lines can't be erased, and tarnish from grey to brown with age |
| carved relief | the scene becomes a height field, shaded by a raking light with its own cast shadows |
| liquid light show | oil, water and dye in a dish on a projector: warped-noise dye bands, metaball oil drops with a meniscus, and drawn transparencies whose black ink really blocks the lamp |
| thermal camera | a scene rendered as temperatures and mapped through a camera palette, with a thin visible-light edge overlay, warm breath and fading heat prints |
| showboat stage | painted flats given brushwork by a sampled-stroke pass, lit by a light map in which the actors are lit through their own silhouettes |

A filter that makes a clean digital picture look like linocut never convinces for long. A few rules about how the
real thing is made go much further.

## One frame

Almost every engine's frame function looks like this:

```
renderFrame(t):
  shot = the shot covering t
  set  = shot.set, baked on first use           (the still layers: land, buildings, background)
  cam  = shot.cam(t)                            (keyframed, eased)
  draw the set's layers through the camera       (parallax: nearer layers move more)
  draw what moves at t                           (figures, props, light, weather)
  post: light (a multiplied lamp or light map), grain, vignette, the medium's texture
  if t is inside a transition: draw the next shot too and mix (dissolve, wipe, push)
  the lyric band / margin / caption for t
  fade in and out at the ends
```

The canvas is 1920x1080. Several styles keep the picture above a band for the lyrics (e.g. 1920x960 + 120).

## Sets, shots, cameras

- **Sets** (or scenes, worlds, plates) are places. Their still parts are drawn once into offscreen canvases the first
  time they're needed ("baked"), then only composited. Keep a memory budget: the whole song's sets rarely fit at
  once, so drop the least recently used. Bake at load what the first seconds need, so playback doesn't hitch.
- **Shots** are stretches of song time: `{t0, t1, set, cam, ...}` plus a function that poses what moves.
- **Camera keys** are `[time, x, y, zoom, ...]` with easing between them. Two useful rules:
  - push in with **lens zoom**, not by travelling into the layers: depth travel blows the nearest layer up (snow
    becomes moons);
  - **never let the camera see past the edge** of what's drawn. Check the frame corners on every new camera.
- **Transitions:** dissolves, drop wipes (a new picture spreading inside a drop), push and pull (from a room to the
  picture on its screen), panels (pull back to a page of panels, push into another), re-laying one medium as another
  past a moving line.

## Time: on twos, and in step with the song

- Hand-made animation moves **on twos**: pose changes at 12 fps inside 24 fps video. Several engines step motion at
  12 fps (`tm12 = Math.floor(t * 12) / 12`) while the camera moves at the full 24, which keeps the hand-made feel
  without a juddering camera. Texture "boil" (grain, ink noise) often changes at 8 fps.
- **Ease into fast moves**, or drive them with real time: a move that starts at full speed jumps at 12 fps.
- **Hits on beats, changes on lines.** `SONG.beat(n)` and each line's `t0` and word times are the anchors. A word
  lighting in the lyric band typically fades up over `[t - 0.04, t + 0.16]`.
- **Keep something moving.** A hold longer than a beat or two reads as the player freezing. A slow drift, a breathing
  light or drifting smoke keeps a still picture alive.

## Determinism and frame-to-frame state

- All randomness comes from seeded generators (`mulberry32(seed)`) and noise keyed to the frame number. Never call
  `Math.random()` while drawing a frame. The same `t` must give the same picture, or an MP4 won't match what you
  checked.
- Some styles **carry state from frame to frame**: frost that grows, ghosting of the previous frame, a charcoal
  drawing that's erased and redrawn, marbled paint whose outlines remember every comb. Those must be stepped in
  order. `renderAt(t)` then means "rebuild the state from the start of this scene up to t", and each engine's README
  says how it does that.
- When a view steps backwards in time (a camera effect that holds frames, a scrub), keep what's already baked rather
  than rebuilding it from scratch each step, or rendering crawls.

## Figures

- **Whole figures**, posed. Every engine has a rig: jointed silhouettes, contour-drawn people, ray-marched signed
  distance bodies, carved 3D pieces. Most use **two-bone IK** for arms (and often legs), so a hand can be put exactly
  on a rope, a cup or another hand. Each rig spells it its own way: `reachArm()` in paper cut, an arm given as
  `{t: [x, y]}` in embroidery or `{at: [x, y]}` in painted enamel; the style READMEs show how.
- Build **every figure of a kind from one model**, so its anatomy is the same in every shot; vary only pose,
  clothing and age.
- Things that make figures read wrong, all hit at least once: round heads read as teddy bears (give them a muzzle
  or a jaw); coats that hang along the body turn a crouching figure into a plank (hang them toward world-down);
  digitigrade legs with a long stride look like sitting on a stool; two figures leaving the same way merge into one
  blob; close-up arm silhouettes read as clubs or poles.

## Light

- A **lamp** is a radial gradient drawn with `multiply` (or a light map multiplied onto the whole picture). Its
  warmth and brightness carry most of a scene's mood.
- **Self-lit things** (flames, lit windows, glowing marks) go in their own layer drawn after the light map, plus a
  glow. A reflective shape in front should erase the self-lit layer behind it.
- On pale paper, `screen` adds almost nothing; `soft-light` plus a weaker `screen` shows coloured light.
- Glass only darkens: a moving piece has to pass over light glass, or it vanishes.

## Text in the picture

- Load fonts before drawing and wait for them (`document.fonts.load(...)` for each face and script you use), or text
  falls back to a default font. `document.fonts.load` resolves even when the font never arrived, so check the
  result (or `document.fonts.check(...)`) before building. Put `<meta charset="utf-8">` at the top of the page for
  any non-ASCII text.
- **Start building only when every script has loaded** (`DOMContentLoaded`, or put the start call at the end of the
  last script). A build started from a font promise plus a short timer can win the race against later scripts when
  the fonts come from cache, and the page fails to build only sometimes.
- Keep the lyrics readable: if the camera zooms, keep the text out of the zoom (a band or margin drawn in screen
  space).

## Browser gotchas that cost hours

- **One bad gradient value kills the frame.** `addColorStop` with a NaN or an out-of-range offset throws, and nothing
  after it draws. Check the console after every change.
- **`destination-out` uses the current fill's alpha.** A fill left translucent from the last wash only half-erases.
  Set `fillStyle = '#000'` before erasing.
- **`[hidden]` loses to `display: grid`.** Add `.gate[hidden] { display: none }` for overlay elements.
- **Globals collide.** Plain scripts share one global scope; a helper named like an existing function (`hand`,
  `line`) silently replaces it.
- **Tiling seams:** a texture tiled from a sampled corner shows seams on big pieces; downsample the whole texture.
- **WebGL:** GLSL has reserved words you'd never guess (`patch`); creating a texture while another is bound can
  overwrite a texture unit (create textures on a scratch unit such as TEXTURE15); a three.js `InstancedMesh` keeps the
  bounds of its first draw unless `frustumCulled = false`.
- **Headless loads:** wait for the page with `wait_until='commit'` and your own ready flag; a page that builds a lot
  at load can time out waiting for the load event.
- **Grain that changes every frame bloats the MP4.** Change it on twos.

## Starting a new engine

1. Copy the style closest to what you want. Keep its player (`index.html`, the playback and `window.__video` parts
   of its engine) and its lyric code.
2. Write the medium: the few functions that turn a shape into your medium's marks. Test them on stills first, on a
   page that just draws one scene (a lab page).
3. Draw the same key scenes in your medium and in one or two alternatives. Choose.
4. Then sets, shots and the song.



## 原作者媒介陷阱与经验摘录

## Lessons and gotchas

- **Weigh each lamp by its own colour.** At the same intensity blue light has half the luminance of gold, so measured
  by luminance the gold's share of an evenly lit surface sits at about 0.67, just under the 0.7 threshold: whole slopes
  flipped between cream and soga. The shaders divide each light by the luminance of its lamp's colour.
- **Dye edges come from the light, so keep the lamps' own edges out of frame.** A spot's cone edge across the set made
  a soft soga blotch that no batik has. Put the lamps far enough off that both reach everything in view, with little
  penumbra; then the dyes follow what faces which lamp and what shadows what.
- **Material codes must not blend.** Blended where two materials meet, their codes passed through a third (a glow)
  and every such join lit up. `sdf.js` takes the winning operation's code, and the passes carry it as a `flat` varying.
- **Colours near a dye boundary flip dyes.** A bark brown landed on green; a pale skin went rose where it was darker.
  Choose each colour close to the dye you want (the table in `models.js` is checked against the nine), and don't
  darken hollows: the diorama's carved-wood patina changed the dye in every crease, so `mesher.js` turns it off.
- **No noise on the dye thresholds.** A noise meant to make dye edges wander, fixed to the screen, read as static
  wherever a surface's light sat near a threshold. The edges wander with the sampling wobble instead, which moves with
  the cloth.
- **Coplanar surfaces flicker in blocks**, and the edge finder outlines every block. Keep surfaces apart (a few inches
  at the set's scale).
- **Shadow acne** shows as dye speckle; a normal bias of 0.1 ft cures it at this scale.
- **Draw the shadow maps once.** Five passes each redrawing every lamp's shadow map cost more than everything else; the
  gold pass draws them and the blue reuses them.
- **Thousands of small meshes** (flowers, needles, bulbs) cost a draw call each in every pass. Merge the static ones
  (`mergeStatic`), and make any mesh that appears mid-shot at build time, only swapping its geometry, or it has no pass
  materials.
- **Instanced meshes need instancing in the pass shaders** (the grass and leaves here); `mats.js` applies
  `instanceMatrix` and `instanceColor`.
- **Things thinner than a few pixels become all wax line.** Grass blades come out as cream strokes: batik-like, but
  keep them sparse near the camera or they fill the frame.
- **Object-space patterns are sized in the object's units.** A pattern that reads in a close-up vanishes in a wide
  shot; give big things (the ground) bigger patterns.
- **The ambient light counts in both lamps' passes.** With one lamp turned off, faces away from the other still came
  out cream; turn the fill down with the lamp. Likewise a dark backing behind a lit cut-out must take no light at all,
  or both lamps dye it cream.
- **Faces in two dyes take the dye of their lamp, like everything else**, so a face can go soga or indigo; use the
  full palette for close-ups where a face should stay pale.
- **A box's back face mirrors its texture.** A board with shapes cut through it showed the wrong holes from behind;
  build a cut-out from a front face and a back face with the holes lined up.
- **Things held in hands float** unless they're children of the figure at the palm: `handOf()` repeats the model's arm
  maths.
- **A coat blown sideways, seen from the front, read as a kicked leg.** Check a figure's wind from the camera it's
  seen from, and ease it for the front view.
- **The camera's breath needs a start time.** A split screen's panels had none, the drift came out NaN and the panels
  rendered empty.
- **`show()` hides every named part not listed.** Keep pieces that are always there out of `S.P`, or list them in
  every shot.
- **Build only what a stretch needs.** With every set of a long video loaded at once, a render hung after one frame;
  `?sets=` builds only some, and a frame whose set isn't built is skipped at load rather than failing.
- **Nothing may sit still**: a hold longer than a beat or two reads as the player freezing. Keep the camera breathing,
  the lamps swinging and something in the wind.
- **Don't start or end on a blank frame.** The cloth fades in from half-dyed and back toward bare cloth, never all the
  way.
- **Judge colour at full size.** Thin lines and crackle average out in contact-sheet thumbnails.
- **three.js's ambient occlusion isn't repeatable on its own**: `GTAOPass` makes its denoising noise with
  `Math.random()`, so the model box came out a few levels different on every load (which matters when frames are
  rendered in several browsers, or a slice is spliced in). `styles.js` seeds `Math.random` while it builds the pass.
- **Load the page without waiting for `load`**: the tools wait with `wait_until='commit'` and poll `__video.ready`.


