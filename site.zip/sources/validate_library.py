"""Validate complete prompts, provenance, images, UI bindings, and optional portable package."""
from pathlib import Path
import hashlib, json, re, zipfile
from PIL import Image
ROOT=Path(__file__).resolve().parent.parent
load=lambda p:json.loads((ROOT/p).read_text(encoding='utf-8'))
styles=load('sources/styles.json'); items=styles['primary']+styles['secondary']
library=load('prompts.json')['styles']; public=load('styles.json')['styles']
assert len(items)==len(library)==len(public)
assert len({x['key'] for x in library})==len(library)
assert len({x['id'] for x in library})==len(library)
inv=load('sources/source-inventory.json')
for f in inv:
    assert hashlib.sha256((ROOT/f['localPath']).read_bytes()).hexdigest()==f['sha256'],f['localPath']
for x in library:
    assert not x['reviewFlags'],(x['id'],x['reviewFlags'])
    assert len(x['notes'])>=2 and len(x['sourceCommit'])==40
    p=ROOT/x['promptFile'];text=p.read_text(encoding='utf-8')
    source=ROOT/'sources/upstream'/x['source']/'styles'/x['slug']/('STYLE.md' if x['source']=='lemo' else 'README.md')
    original=source.read_text(encoding='utf-8')
    assert original in x['promptText'],x['id']
    assert x['promptText'] in text and '{{填写' in text
    assert len(x['promptText'])>len(original)+1000
    common=['DIRECTOR.md','TECHNIQUE.md'] if x['source']=='lemo' else ['CLAUDE.md','docs/workflow.md','docs/timing.md','docs/rendering.md','docs/your-own-video.md','docs/engine-patterns.md']
    for fn in common:
        assert (ROOT/'sources/upstream'/x['source']/fn).read_text(encoding='utf-8') in x['promptText'],(x['id'],fn)
    image=ROOT/'images'/(x['source']+'-'+x['slug']+'.jpg')
    with Image.open(image) as im:im.verify()
gallery=(ROOT/'图册.html').read_text(encoding='utf-8')
assert len(re.findall(r'data-prompt="\d+"',gallery))==len(items)
assert len(re.findall(r'data-image="\d+"',gallery))==len(items)
assert '复制完整提示词' in gallery and '下载提示词 TXT' in gallery
assert all(x['promptFile'] in (ROOT/'完整提示词总册.md').read_text(encoding='utf-8') for x in library)
share=ROOT/'可发布资料'
if (share/'.package-manifest.json').exists():
    names=json.loads((share/'.package-manifest.json').read_text(encoding='utf-8'))
    for rel in names:assert (share/rel).is_file(),rel
    assert not any('我的提示词' in x or x.lower().endswith('.pdf') for x in names)
    for required in ['index.html','llms.txt','styles.json','prompts.json','ATTRIBUTION.md']:assert required in names
    with zipfile.ZipFile(ROOT/'Opus风格分享包.zip') as z:
        assert z.testzip() is None
        assert set(z.namelist())==set(names)
    for x in library:assert (share/x['promptFile']).is_file()
print(json.dumps({'validatedStyles':len(items),'completeOriginals':len(library),'sourceHashes':len(inv),'promptChars':sum(len(x['promptText']) for x in library),'portablePackageChecked':(share/'.package-manifest.json').exists(),'videoRenderingPerformed':False},ensure_ascii=False))

