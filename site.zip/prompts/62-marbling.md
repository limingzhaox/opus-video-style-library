# 62 · 大理石纹纸 / Marbled paper

来源类型：根据作者引擎说明整理的使用模板；并非作者原始创作提示词  
原作者：Miranda Dixon-Luinenburg  
上游原文：https://github.com/cyborggirl963/opus-5.5-music-video-art-styles/tree/main/styles/marbling  
固定版本：801b3548c54765ecf932ce8b7f3cf4b29fb7a8bf  
抓取核对日期：2026-11-03  
本库改动：中文任务模板、中文摘要与编排；原文全文保留。

## 使用前先看

- 这是有历史状态的流体轮廓效果，不能靠给成图盖滤镜；按时间顺序渲染。
- 持续单向流会让轮廓点数膨胀；需要回放的画面避免破坏性推开后再硬撤销。

- 这是代码渲染工作流；聊天文本本身不会自动产生 MP4，需有可执行的项目环境。
- 先看预览再做长片；不要把示例素材的许可自动套到自己的歌曲、照片、字体和品牌上。
- 下方复制区包含全部风格与公共规范，不要求 AI 另外从本机隐藏路径读取文件。

## 完整复制区

你是一位能写代码、检查画面并渲染成片的动画导演。请用“大理石纹纸 / Marbled paper”制作一个属于我的视频。

【我的需求；把花括号内容换成实际值】
主题与一句话故事：{{填写主题和结尾变化}}
用途与观众：{{例如面向普通观众的科普短片}}
内容依据或已有脚本：{{填写；没有则说明需要你写}}
音频、歌词、图片、数据、品牌素材路径：{{填写；没有写“无”}}
素材使用权限与需显示的署名：{{填写来源与许可；不清楚请列待确认项}}
目标时长：30 秒起步；MV 以实测歌曲时长为准
画幅与清晰度：默认横屏 16:9、1920×1080；帧率按本风格原文与引擎规范，未规定时24fps；竖屏须重新构图，不直接裁横屏
语言：简体中文；配音需求：{{有/无、声线与语速}}
必须出现的内容：{{填写}}
禁止出现的内容：{{填写}}
预算与速度：先做低成本验证，再渲染完整片
个人工程名：my-video（可改为英文短名）
确认方式：先给 3 张由真实渲染代码产出的样帧和 5–10 秒预览；我确认风格后再做完整成片

【本风格的核心实现】
让漂浮颜料、滴色、梳理和针划真的推动轮廓，形成湿法大理石纹纸。
特别检查：
- 这是有历史状态的流体轮廓效果，不能靠给成图盖滤镜；按时间顺序渲染。
- 持续单向流会让轮廓点数膨胀；需要回放的画面避免破坏性推开后再硬撤销。

【工程与流程】
1. 在工作区单独克隆 https://github.com/cyborggirl963/opus-5.5-music-video-art-styles ，检出 801b3548c54765ecf932ce8b7f3cf4b29fb7a8bf。将 styles/marbling/ 复制到 projects/my-video/，保留引擎，按该风格 README 指定的文件替换示例场景。不要直接修改 styles/ 中的母版。
建立 Python 虚拟环境，阅读 requirements.txt 后安装渲染依赖；需分析音频时再安装 requirements-audio.txt。使用 Chrome 或项目支持的 Chromium。使用 python tools/serve.py 提供本地 HTTP，不用 file:// 打开渲染页面。
2. 先检查机器的 Python、Node/浏览器、FFmpeg、字体与 GPU 能力。Lemo 当前要求 FFmpeg 7+；先用 ffmpeg -version 核对。缺少工具或访问权限时明确报告缺什么，不能只描述完成、伪造文件或把截图称为已渲染视频。
3. 把我的需求写成 PLAN.md 或 TREATMENT.md：一句话故事、分镜、逐镜秒数、镜头运动、文字位置、音乐与声音 cue、所需素材、预计成本。涉及事实和数据时写 FACTS.md；没有来源的数字不填。
4. 如果是 MV，先取得音频与实际演唱歌词，测量段落、停顿、节拍与词时间；不得沿用 37.5 秒示例诗的时间轴。未提供音乐时不要假装已经完成歌词对齐，可先制作无歌词短预览。
5. 先完成 3 张代表开头、关键变化、结尾的样帧，逐张检查；再渲染 5–10 秒低清短段，检查字幕、运动、音画同步与控制台。复杂慢风格先计时，再估算整片。
6. 随机效果固定种子；有历史累积的媒介按顺序渲染。并行前先比较随机抽帧与连续渲染是否一致。
7. 正式导出使用项目文档中的工具与参数，不臆造命令。交付可播放 MP4、720p 预览、源代码、素材清单与许可、字幕（有台词时）、复现说明；保留最终片长、帧率、音频响度与实际渲染耗时。
8. 实际打开并检查成片开头、中间、转场、结尾及全片联系表，确认没有空帧、字体回退、遮挡、裁字、爆音或无意复制的作者片尾签名。交代尚未完成的检查。

下面是完整风格参考与公共制作规范。它们是上游参考资料，不代表我的主题或逐字台词；我的具体需求优先。风格中明确的声音、镜头和媒介限制优先于公共建议，例如无声电影不添加旁白或拟音。遇到 macOS/Linux 示例命令时按当前系统等价转换，不直接在 PowerShell 粘贴 bash 命令。相对资源路径以完整克隆的上游工程为准。


===== 完整风格原文：styles/marbling/README.md =====

# Marbled paper

Paint floated on a bath of thickened water, moved with drops, a stylus, combs and a stir, the way a marbler works
before laying the paper down. Nothing here is a filter over a picture. Each colour is a closed outline of floating
paint, and every move (a drop landing, a comb pulled through, a swirl) is an exact mathematical map applied to every
point of every outline, so edges stay crisp at any zoom and paint never overlaps or leaves a gap. Newer paint always
sits where older paint was pushed away from, so drawing the outlines oldest-first shows every colour where it really
is. On top of that come what makes it look like paint rather than vector art: pigment grains that ride along with
their colour, a soft darker band and a fine dark vein where two colours meet, marbled insides (stone, woodgrain,
combed cloth) for objects, and a faint size texture, sheen and vignette over the whole tray. Almost every move can
run backwards exactly, so a picture can be combed apart and then rewound to almost where it was.

![A gust as a comb through the tray: feathered sky, bowing trees, a hat blowing away](img/hero.jpg)

This family has one look, so there's no style lab.

| | | |
| --- | --- | --- |
| ![Drops filling the tray under the title card](img/drops.jpg) | ![Leaves made of drops pulled with a stylus](img/leaves.jpg) | ![The wind as a comb passing through the leaves](img/comb.jpg) |
| drops fill the tray (0:02) | leaves: a drop, a drop inside it, a stylus pull (0:13) | the wind is a comb passing across the tray (0:16) |

![The drop wipe: the hill opening inside a drop that pushes the branch picture outward](img/wipe.jpg)

## Run the demo

```bash
python tools/serve.py        # then open http://localhost:8000/styles/marbling/index.html
```

`index.html#t12.5` shows the still at 12.5 s with the page furniture hidden. Space plays and pauses; the bar scrubs.

The page does play live, with the song, but it works every frame out as it goes (moves the paint, then draws it), and
a frame costs 20-150 ms here, so in a browser it runs slowly and stutters, and scrubbing backwards has to replay the
scene from its start. The MP4 is the way to watch it:

```bash
python tools/still.py styles/marbling/index.html 2.4 13 16.4 28.9            # stills into renders/stills/
python tools/still.py styles/marbling/index.html 0:37.5:2.5 --sheet --step  # a contact sheet of the whole demo
python tools/render_mp4.py styles/marbling/index.html --fast                # renders/marbling-720p.mp4
python tools/render_mp4.py styles/marbling/index.html                       # 1080p and 720p, slow encoder
```

The whole 37.5 s demo renders to 720p (`--fast`) in about a minute on an otherwise idle Apple M4 laptop (~70 ms a
frame including reading the canvas back and encoding); with other heavy work running it took four. Each still replays its scene from the scene's start, so a long list of stills
is faster with `--step`, which carries the paint on from one still to the next (the times must be in order).

## How it works

Plain canvas 2D, no libraries; fonts from Google Fonts (IM Fell English for the lyric band). The files load as plain
scripts sharing one global scope, in this order:

| file | job |
| --- | --- |
| `../../examples/poem/lyrics_data.js` | `window.SONG`: title, credit, audio, duration, beats, and every line's word times |
| `core.js` | frame size (`W,H` 1920x1080, picture `PW,PH` 1920x960 above a 120 px lyric band), math, seeded random (`mulberry32`), value noise (`fbm2`), colour helpers, outline helpers (`spline`, `resample`, `rect`, `ell`, `blob`), fonts |
| `marble.js` | the engine: `Bath`, `Film`, the marbling maps, timed moves, `Script`, rewinds, marbled insides, the sway, and all the drawing |
| `figures.js` | figures: traced from simple parts (`maskOutline`), or smooth tapered strokes along a spine (`strokeOutline`): `coatFigure`, `swimmer`, `swimmerTop`, `elder`, `walker` |
| `props.js` | builders shared by scenes: `sprinkle`, `Float`, `Breathe`, landscape pieces (`crownTree`, `treeOutline`, `spruce`, `islandPts`, `fishPts`), `houseFront`, moving figures (`walkerMoves`, `figureMoves`, `swimMoves`, `elderMoves`), running water (`flowRibbon`, `channelField`), `carried` |
| `scene_branch.js`, `scene_hill.js` | the demo's two scenes (replace these) |
| `timeline.js` | `SCENES` and `SEGS`: which scene plays when, and how each takes over from the last (replace this) |
| `video.js` | steps scenes frame by frame, draws drop wipes, fades and the lyric band, keeps cards, sets `window.__video`, runs the player |

### The paint

```js
new Bath(name, {bounds, dens, maxLen, minLen})   // one tray: films oldest first, plus pigment grains
new Film(points, colour, {tag, vein, va, vw, grain, alpha, glow, gold, lite, keep})   // one closed outline of paint
bath.add(film, rnd)       // float it (and sprinkle grains in it with the seeded generator rnd)
bath.map(fn, sel)         // apply a point map to every film passing sel (and their grains)
bath.tidy()               // resample outlines: split edges longer than maxLen, merge points closer than minLen
```

A film's options: `vein` is the edge colour (`null` for none; default a darker shade of the fill), `va`/`vw` its
alpha and width, `grain` how many pigment specks (0 for none; the bath's `dens` sets specks per pixel), `glow` a
soft light around it, `gold` a moving bronze-powder fill, `lite` a lift toward cream, `alpha`, `hidden`, and `keep`
(never resampled; for outlines you rebuild yourself every frame). Films can also be: frozen (`bath.freeze(f)`: no move
touches it again) and frosted (`f.ice` 0..1); a window onto another bath (`f.window = otherBath`: that bath's paint
shows inside this outline); left out of sways and pushes (`f.nosway`). `f.kids` is a film's marbled inside, made by
`marbleInside(film, kind, palette, seed, o)` with kind `'drops'` (stone), `'cloth'` (drops then a fine comb),
`'grain'` (wood: strips waved along `o.dir`, with knots) or `'bands'` (strips combed with alternating teeth).

### The moves

Each move is a closed-form map of the plane (after Jaffer and Lu's mathematical marbling) applied in small steps, so
it can be watched. Every one takes a song time `t0` and a duration, plus `{sel, ease}`: `sel(film)` limits it to some
films (the demo's `nb=f=>f.tag!=='base'` keeps the tray's ground out of pushes), `ease` is one of `E.lin`, `E.out`,
`E.io`, `E.sine`, `E.drop`.

```js
Drop(bath, cx, cy, r, colour, t0, dur, o)        // paint lands and spreads; everything moves outward
ShapeDrop(bath, pts, colour, t0, dur, o)         // paint spreading into an outline
Float(bath, pts, colour, t0, dur, {from, inside, ring, ringK})   // an object spreading out of its anchor `from`
                                                 //   (inside: a marbleInside spec; ring: baths below that bend round it)
Tine(bath, t0, dur, point, dir, z, lam, {teeth:{sp, alt}, front:[f0, f1, width]})   // a stylus, or a comb of teeth
Swirl(bath, t0, dur, centre, angle, sigma)       // a stylus stirred round
Wave(bath, t0, dur, dir, amp, k, phase)          // a comb wiggled as it is pulled
Bend(bath, t0, dur, root, angle, h, {p})         // a turn about a root, growing with distance: a stalk or tree bowing
Move(bath, t0, dur, (e0, e1) => pointMap)        // any map you write; e0..e1 is the eased progress of this step
Morph(bath, [[finder, fromPts, toPts]], t0, dur) // ease a film between two poses
StretchX / StretchY(bath, sel, anchor, s0, s1, t0, dur)
At(t, fn)                  // once, at t
During(t0, t1, (t, dt) => ...)   // every frame between t0 and t1
Rewind(moves, t0, dur)     // play these moves backwards, last first
TapeRewind(moves, tA, tB, t0, dur)   // over [t0, t0+dur], run the listed moves' clock from tB back to tA
```

`Tine` with `teeth` is a comb; `alt: true` flips every other tooth. With `front`, the comb crosses the tray from `f0`
to `f1` (measured along `dir`): a point moves only while the comb goes by it, so the feathering sweeps across the
picture and stays behind it. That's the wind in the demo. `Drop`, `ShapeDrop`, `Tine`, `Swirl`, `Wave`, `Bend` and
`Move` all run backwards exactly when stepped from a later progress to an earlier one, which is what the rewinds do.
`At` and `During` don't run backwards, which is how a rewind comes back "less something".

`Breathe(baths, amps, t0, t1, seed, period, {view, pauses})` keeps the paint alive: a smooth current that sways back
and forth (it reverses every `period` seconds, so outlines don't grow without limit), one amplitude per bath.

### A scene

A scene is a function that builds its baths and a list of timed moves, and returns:

```js
{name, baths /* bottom to top */, script: new Script(moves), ground /* colour behind all */, cam, segments,
 surface /* 0..1 texture, sheen, vignette */, post(inst), draw(g, t), over(g, t, view, zoom)}   // last three optional
```

`segments` are the stretches of song time the scene is stepped through (it can skip a gap and come back, e.g. for a
reprise). `cam` keys are `[t, cx, cy, zoom]` in the scene's own world coordinates, eased between (a fifth entry
`'lin'` makes a straight move). Here is the gust from `scene_hill.js`, line 7, and its rewind in line 8:

```js
const GT=26.3,GD=2.8,FR=[-400,2400,260];          // the comb crosses from x=-400 to 2400 in 2.8 s
const gust=[Tine(sky,GT,GD,[0,0],[1,0],120,10,{teeth:{sp:40},front:FR,ease:E.io,sel:nb}), /* far hills, land, crowns */];
TR.forEach((T,i)=>gust.push(Bend(trees,frontAt(T.x-160),1.0,[T.x,T.y],.26+.03*i,T.h,{sel:T.sel,p:1.4,ease:E.io})));
mv.push(...gust);
mv.push(TapeRewind(gust,26.2,30.0,30.0,2.5,{ease:E.io}));   // "The wind is passing by": the gust runs backwards
```

and a leaf from `scene_branch.js`, made the way a marbler makes one:

```js
mv.push(Drop(leaves,cx,cy,r,C(c1),t,.3,{tag,sel,vein:shade(C(c1),.5)}));      // a drop of green
mv.push(Drop(leaves,cx,cy,r*.52,C(c2),t+.1,.25,{tag,sel}));                   // a paler drop inside it
mv.push(Tine(leaves,t+.28,.4,[cx,cy],[dx,dy],r*1.25,r*.34,{sel,ease:E.io}));  // a stylus pulled through: a leaf
```

### The timeline

```js
const SCENES={branch:sceneBranch,hill:sceneHill};
const SEGS=[{scene:'branch',s0:0},
  {scene:'hill',s0:18.75,prev:'branch',wipe:{t:18.75,dur:1.8,c:[960,470],R:1250}}];
```

A segment opens with a drop wipe (`wipe`: a drop lands at `c` in the old scene's world and the new picture shows
inside it while it pushes the old paint outward; `push:false` leaves the old picture unpushed), an `unwipe` (the old
picture closes back in round the new one, `rad(t)` giving the circle's radius), or a `fade` of so many seconds.

**Cards** keep a picture for later. Define `const CARD_REQ=[{key, scene, t, reg:[x0,y0,x1,y1]}]` (in `timeline.js`):
when that scene passes `t`, its films and grains near `reg` are copied. Later, `cardBaths(req)` gives you live baths
rebuilt from the copy (or, if the song wasn't played through, runs the scene up to `t` first), to show again and comb
into the next picture. The demo doesn't use them.

### Figures

`walker(x, y, phase, k, o)` is a person side on, in a long coat and a hat, with a cloak streaming from the shoulders:
every part is a tapered stroke, so it's rebuilt every frame without tracing. `walkerMoves(bath, id, pos, t0, t1, o)`
moves one along `pos(t) -> [x, y]` with the stride tied to the distance walked, the coat's cloth carried with the
hips, the cloak's combed stripes laid along the cloak so they ripple with it, and options for the wind (`wind`,
`gustOf(t)`, `leanOf(t)`) and the hat (`hatUntil`). `coatFigure` is a stout figure traced from parts with poses
(`figureMoves` floats it in and eases between poses). `swimmer` is a swimmer side on, `swimmerTop` a swimmer seen from
above, and `elder` an old person resting in the water, easing from holding themselves up to lying back
(`swimMoves`, `elderMoves`). They have an ordinary skin tone by default (`skin`, or `skinPal` / `pal` for your own
colours); swimmers take `hairLen`, and `fins: true` puts swim fins on their feet.

### The lyric band

`video.js` turns `SONG.lines` into lyric groups: a line appears 0.45 s before its first word and leaves 0.45 s before
the next line starts; each word brightens from dim to lit over `[t - 0.04, t + 0.16]` of its sung time; a long line
shrinks to fit. `TITLE` shows `SONG.title` and `SONG.credit` in the band from 0.35 to 3.6 s. `LOOK` holds the band's
colours.

### Determinism and state

The paint's state is the history of every move, so a frame can't be drawn on its own: scenes are stepped forward in
order. Steps always land on the frame times `(k + 0.5) / 24` that the MP4 renderer uses, so `step(t)` (which carries
the live scenes on) and `renderAt(t)` (which rebuilds them and catches up from their start) produce identical
frames, and a slice rendered with `--start` splices into a full render exactly. Every random choice comes from a
seeded `mulberry32`; each drop seeds its own grain generator from its position; the sway is a function of time. A
scene is built the first time it's needed and dropped a second after its last segment. The grain colour table, the
size texture and the frost pattern are built on first use; the lyric band at load.

## Make your own video in this style

1. **Copy the folder and add your song:** `cp -r styles/marbling projects/my-song` and put your mp3 in it as
   `song.mp3` (see [docs/your-own-video.md](../../docs/your-own-video.md)).
2. **Time the lyrics** with the pipeline in [docs/timing.md](../../docs/timing.md), ending with
   `tools/audio/to_js.py`, which writes `projects/my-song/lyrics_data.js`. In `index.html`, change
   `<script src="../../examples/poem/lyrics_data.js">` to `<script src="lyrics_data.js">`. The next line already
   points the audio at `SONG.audio`.
3. **Keep** `core.js`, `marble.js`, `figures.js`, `props.js` and `video.js`. **Replace** `scene_branch.js` and
   `scene_hill.js` with your own scene files (and their `<script>` tags in `index.html`), and rewrite `timeline.js`.
   In `video.js`, `TITLE` (when the title card shows), `POSTER` (the frame the page shows before Play) and `LOOK`
   (the band's colours) are yours to change.
4. **Write a scene.** Start from this and grow it:

   ```js
   function sceneMine(){
     const sky=new Bath('sky',{dens:.0045,maxLen:5,minLen:2}),land=new Bath('land'),mv=[],nb=f=>f.tag!=='base',beat=SONG.beat;
     mv.push(At(0,()=>sky.add(new Film(rect(-300,-300,2520,1560),C('#c3d0d8'),{vein:null,tag:'base'}),mulberry32(3))));   // the tray
     mv.push(...sprinkle(sky,[-80,-80,2000,1040],120,['#b3c6d3','#dce4e4','#9fb7c9','#e9e5d9'],28,72,.1,2.8,11,{sel:nb})); // drops
     mv.push(Tine(sky,2.9,1.0,[0,0],[1,0],58,12,{teeth:{sp:44,alt:true},ease:E.io,sel:nb}));                             // combed
     mv.push(Float(land,myOutline /* your points */,'#8a9a62',beat(8),1.0,{from:[960,1000],ring:[sky],
       inside:{kind:'cloth',pal:['#8a9a62','#97a66c','#7b8b56'],size:28,dir:[1,.1],z:9,sp:20,seed:5}}));                // an object
     mv.push(Breathe([sky],[8],0,20));
     return{name:'mine',baths:[sky,land],script:new Script(mv),ground:'#c3d0d8',cam:[[0,960,480,1]],segments:[[0,20]]};}
   ```

   Add it to `SCENES` and `SEGS` in `timeline.js`. Build the tray's first picture in the scene's first frames, and
   if the scene opens inside a drop wipe, start its segment a little before the wipe (the demo's hill starts at
   18.55 for a wipe at 18.75) and build its world with near-instant moves (durations of .03-.05 s).
5. **Time moves to the song.** `SONG.beat(n)` is beat `n`; `SONG.lines[i].t0` is where line `i` starts;
   `SONG.lines[i].words[j][1]` is when word `j` is sung. Put drops and hits on beats and changes on line starts, e.g.
   `Drop(sky,x,y,120,C('#e9e5d9'),SONG.beat(4),.9,{sel:nb})`. Keep something moving: a hold longer than a beat or two
   reads as the player freezing.
6. **Look at it** with `python tools/still.py projects/my-song/index.html 0:30:1 --sheet --step`, fix, and preview
   slices with `render_mp4.py --start --end --fast`.

**Useful knobs.**

| where | knob | what it does |
| --- | --- | --- |
| `Bath` | `dens` | pigment specks per square pixel (.004-.01 reads as paint; 0 for none) |
| `Bath` | `maxLen`, `minLen` | outline spacing: 3/.8 for close-ups, 5/2 for wide or heavily combed layers (fewer points to draw) |
| `Film` | `vein`, `va`, `vw` | the edge line between colours: `null` for none |
| `Drop` / `sprinkle` | `sel` | what a drop pushes: `nb` to leave the tray's ground alone; a tag test so splashes only push each other |
| `Float` | `from`, `ease`, `ring`, `ringK` | where an object spreads from, how, and how much the paint below bends round it |
| `Float` | `inside.size` | the grain of a marbled inside: one film per drop over the object's bounding box, so bigger is cheaper |
| `Tine` | `z`, `lam`, `teeth.sp`, `alt` | how far paint moves, how fast that falls off, tooth spacing, alternating teeth |
| `Tine` | `front: [f0, f1, w]` | a comb passing across the tray; keep `z` below about two thirds of `w` |
| `Breathe` | amplitudes, `pauses`, `view` | sway per bath; no sway while a stretch will be rewound; sway only near the camera |
| scene | `surface` | 0..1: the size texture, sheen and vignette (lighter scenes look better around .75) |

## Performance

On an Apple M4 laptop, stepping and drawing a frame takes 20-60 ms for most of the demo, 90-150 ms while a drop wipe
draws both scenes, and about 0.6 s for the one frame where the second scene is built. A full `--fast` render of the
37.5 s demo takes about a minute on an idle machine. The page uses about 35 MB of JavaScript heap.

What costs time:

- **Strokes.** Each film is filled once and stroked twice (the soft band and the vein), and the two strokes cost
  several times the fill. The cost climbs steeply as outlines get long and folded, and combs do exactly that: the
  demo's sky draws in 10 ms at rest (54,000 points) and in 90-100 ms once the gust has combed it (130,000-210,000
  points). Coarser spacing on wide or heavily combed layers (`maxLen` 5, `minLen` 2 rather than 3 and .8) keeps the
  count down, and so does combing only the baths that need it.
- **Marbled insides.** An inside is one film per drop over the object's bounding box. A hill 2,400 px wide with
  `size: 30` is 1,500 films, and swaying it moves and resamples all of them every frame. Size insides to what the
  camera sees and use a larger `size` for big areas.
- **Sway on big baths.** Land barely shows a pixel of sway; leave it out and sway the sky, trees and grass.
- **Building a scene** (all its outlines, insides and first drops) happens on the first frame it's needed. Keep the
  first frames' drops few, or spread them over the opening seconds.

To render one stretch, use `render_mp4.py --start S --end E`: the page catches the scene up from its start (a few
seconds at most here) and the frames match the full render exactly, so `tools/splice.py` can drop the slice in.

## Lessons and gotchas

- **Outlines grow without limit under a steady current.** Anything that stirs the paint the same way every frame
  stretches outlines until they hold hundreds of thousands of points. The sway reverses every period instead.
- **Figures traced from overlapping parts look lumpy.** Tapered strokes along a spine (`strokeOutline`) give smooth,
  graceful figures. Seen from above, a swimmer needs its own outline (`swimmerTop`) or it reads as a stick.
- **Objects look pasted on** when they appear as clean geometric blocks. Bow their outlines slightly (`organic`),
  float each part in from its own anchor, let the paint underneath bend round them as they land (`ring`), and let
  everything sway a little.
- **Undoing a push can scar the paint.** While paint is pushed far out, resampling adds points along chords inside
  the opened disc, and when the push is undone they collapse to the centre as a star. Don't push a picture you mean
  to rewind or bring back later: use `wipe: {push: false}`.
- **Rewinds leave chevrons** where the paint also swayed during the comb they undo. Pause the sway (`Breathe`'s
  `pauses`) for any stretch you'll rewind.
- **Rewind only what should come back.** `TapeRewind` takes a list: pass just the comb and the bends, and anything
  else (leaves carried off by a `During`, a hat blown away) stays gone.
- **Concentric drops read as an eye or a target.** Use them only where that's wanted, or pull them into another shape
  straight away (the demo's leaves are concentric drops for a third of a second).
- **Drops push everything in their bath.** A stream of splashes inflates whatever it lands on unless the drops push
  only each other (`sel`) and fade.
- **A window squashed flat and stretched open later magnifies** any sway or push it took while flat, fifty or a
  hundred times. Mark such films `nosway`.
- **A full-frame ground film in a lower bath hides the baths above it** if anything pushes it. Size ground films to
  their region, tag them `'base'` and leave them out of pushes (`nb`).
- **A drop over paint in a lower bath that wasn't pushed** shows that paint through as a flat disc. Put such a drop in
  its own top bath, or push every bath it covers.
- **An object floated in with a slow-starting ease** (`E.io`) starts as a copy about 1% of its size; resampling it at
  that size merged its points, and it grew back as a crude polygon (twigs became thorns, a branch became a wedge).
  `ShapeDrop` now leaves an outline out of resampling while it grows or shrinks.
- **A path offset by more than its curve's radius** folds over itself: a stream whose bend is tighter than its
  half-width makes a cusp in the inner bank.
- **Water that is a round mouth of even width looks like a pipe.** Start a stream as a trickle and widen it as it
  falls.
- **A comb passing across the tray (`front`) folds the paint** if its shift `z` is more than about two thirds of the front's
  width: points outrun the front.
- **A figure rebuilt every frame jitters** if a comb or push passes through its bath: the move's per-frame increment
  shows before the next rebuild. Keep such figures in a bath the combs leave alone (the walker's films are also frozen).
- **Wide worlds are slow** unless the wide layers use coarser outlines, only paint near the camera sways
  (`Breathe`'s `view`), and moving specks are only added where they'll be seen.
- **A scene opening inside a drop wipe must already be built** at the wipe's first frame: start its segment a little
  before, and build its world with near-instant moves.
- **Build scenes before they're needed if playback hitches.** The first frame of a scene pays for building it.
- **One bad value in a canvas gradient blanks the whole frame.** Read the console output after every change.
- **Changing only the `#t` part of the address doesn't reload the page;** after editing code, reload with a new
  query (`index.html?r=2#t30`).
- **`display: grid` beats the `hidden` attribute,** so the play overlay never hid: `.gate[hidden]{display:none}`.



===== 完整公共规范：CLAUDE.md =====

# Instructions for Claude

This repository makes music videos in code: each style in `styles/` is an engine that draws every frame on an HTML
canvas (or WebGL / three.js) in a hand-made-looking medium, timed to a song, and `tools/` renders them to MP4. Read
`README.md` for the map, then the doc for whatever you're doing.

## When someone wants a video for their song

Follow [docs/workflow.md](docs/workflow.md). It's a conversation, not a build order to rush through:

1. **Get the inputs:** the song (mp3), the lyric sheet as sung, and ask whether they have stems and MIDI (Suno and
   stem splitters provide them) and any reference images.
2. **Ask the concept questions before building anything:** who is singing, who "you" is, whose voice the chorus is,
   what the key images (especially the ending) mean, how much the video may show, what stays out. Don't guess at
   these; an open question is better than a confident wrong answer. If the song belongs to a larger world, read
   whatever they give you about it, and keep a list of every detail the video invents, flagged as unconfirmed.
3. **Measure the song** ([docs/timing.md](docs/timing.md)): tempo, sections, stops and hits, and every word's time.
   Time to the audio, not to the lyric sheet's markings.
4. **Pitch three looks and recommend one:** the medium and why it suits this song, the organizing object, a small
   visual grammar and an arc, a section-by-section plan keyed to timestamps, and the open questions. The styles in
   `styles/` are the starting points (each README says what it's good at); a new medium is fine too
   ([docs/engine-patterns.md](docs/engine-patterns.md)).
5. **Style lab:** the same three or four moments drawn in each candidate look. Show the stills.
6. **Checkpoint:** build one section (20-90 s), render it (`--fast`), send it, get notes.
7. **Build the rest** section by section, then render the final MP4s. The MP4 is what gets shared.

Build a project in `projects/<song-slug>/`, copied from a style folder ([docs/your-own-video.md](docs/your-own-video.md)).
Don't change `styles/` for one person's video. Keep notes in `projects/<song-slug>/PLAN.md` as you go: their answers
and rulings, the measured sections and sync points, the shot list, the invented details, and their feedback on each
round. A later session should be able to pick up from that file alone.

## Working practices

- **Look at what you render.** Make stills and contact sheets (`tools/still.py ... --sheet`) and open the images.
  Check every frame on the sheet: edges, blank frames, the camera inside things, covered text, long freezes.
- **Read the console output** the tools print. A single bad canvas gradient value blanks a frame.
- **Preview slices with `--fast`**; render the full 1080p only at the end. Styles that carry state between frames
  must be rendered in order (the tools do this).
- **Keep it deterministic:** seeded randomness keyed to the frame, never `Math.random()` per frame.
- **Follow the page contract** in [docs/rendering.md](docs/rendering.md) (`window.__video`, `window.SONG`,
  `<canvas id="film">`, `#t<seconds>` stills) so the tools work.
- Apply the lessons in [docs/workflow.md](docs/workflow.md#what-the-notes-taught-true-for-every-style): busy
  enough, no long freezes, obvious changes, varied choruses, whole figures rather than close-up hands.
- The person's audio is git-ignored. If their lyrics or story are private, keep the project out of any public
  remote (add it to `.git/info/exclude`, or keep it outside the repo and pass `--root` to the tools).

## Setup

```bash
python3 -m venv .venv && .venv/bin/pip install -r requirements.txt -r requirements-audio.txt
```

Google Chrome must be installed (or `.venv/bin/python -m playwright install chromium`). To preview in the desktop
app's browser pane, create `.claude/launch.json` running `python3 tools/serve.py 8000` on port 8000 (git-ignored).
Use the server, never `file://`: module pages don't load from files and a plain server caches stale scripts.



===== 完整公共规范：docs/workflow.md =====

# How a video gets made

These videos were made in conversation: a person with a song and a clear sense of what it's about, and Claude
writing and rendering the code. The process below is what worked over a dozen songs. It suits working with Claude
Code (see [CLAUDE.md](../CLAUDE.md), which tells Claude to follow it), and it works just as well by hand.

The short version: **decide what the song is about, measure it, pitch three looks, test the look on a few scenes,
build one section, get notes, then build the rest.** Each step is cheap next to the one after it, so mistakes get
caught while they're still cheap.

## 1. Gather the inputs

- **The song** as an mp3 (or anything ffmpeg reads).
- **The lyric sheet** as plain text, one sung line per line, with `#section` markers (see
  [examples/poem/lyrics.txt](../examples/poem/lyrics.txt)). Write it the way it's sung: if the singer repeats a line
  that isn't on the sheet, add it.
- **Stems, if you have them.** An isolated vocal stem makes transcription far cleaner. Suno exports stems as audio
  and as MIDI per instrument; the MIDI's tempo map gives an exact beat grid, and the vocal MIDI gives note onsets to
  snap words to (see [timing.md](timing.md)).
- **Reference images, if any.** Mood boards and concept art are useful for content (what's in the world, what
  people wear, what the place looks like) even when the style will be different.

## 2. Decide what the song is about

Before any pictures, answer the questions that decide the concept. A video can't be good if these are guesses.

- **Who is singing,** and to whom? Who is "you"? It's often not who it seems, and it can change between verses.
- **Whose voice is the chorus?** The singer's, an imagined audience's, a crowd's, a custom's?
- **What do the key images mean?** Especially the closing one.
- **How much may the video show?** If the song belongs to a larger story, what would be a spoiler?
- **What stays out?** Eras, events, people, kinds of imagery.

If the song is part of a larger world (a novel, a game, a band's mythology), read up on it first, and **keep a list
of every detail the video invents**: a place's layout, what a prop says, who stands where. Show that list to
whoever owns the world, and treat nothing on it as settled until they say so.

## 3. Measure the song

Time the video to what the audio does, not to what the lyric sheet says. (AI song generators in particular ignore
markings like "quiet" or "almost unaccompanied".) With the tools in [timing.md](timing.md):

- tempo, and whether it changes;
- the sections and their loudness: which chorus is the big one, where it drops to almost nothing;
- **the stops and hits.** Musical stops, dropouts and the hit that ends a bridge make the best sync points: the
  place to freeze, cut, switch a light off, or change the whole picture;
- every word's time.

## 4. Pitch three looks

Offer three directions and recommend one. For each:

- **the medium** (paper cut, embroidery, marbled paper...) and why it suits this song. The strongest choices mean
  something: marbled paint for a song about water, where nothing stays put; a lantern lecture for a song sung by
  someone lecturing; a desk of files and stamps for a song about a record that doesn't add up;
- **the organizing object:** the one thing the whole video is, such as a desk under a lamp, a hanging read along
  its length, a printed sheet, a painted wagon's panels, a board of pasted-up photographs;
- **a small visual grammar:** a few rules that give the images meaning (stamps are the audience's verdicts, frost
  is the stillness, the camera's date flickers between years), and an **arc** over the song (clean to decayed,
  night to morning, empty to crowded);
- a **section-by-section plan** keyed to timestamps, giving each section one main image;
- the questions still open.

The [styles/](../styles) folder has eighteen engines to start from, and each one's README says what it's good at.
A new song can also want a new medium: the engines share their patterns ([engine-patterns.md](engine-patterns.md)),
so a new one is less work than it sounds.

## 5. Style lab

Draw the same three or four key moments in each candidate look, side by side, as stills (and a few seconds of motion
if the look depends on how it moves). Comparing like with like makes the choice easy, and it shows the problems
early: people who look like mannequins, faces that look ill, a palette that turns cute. Every family here with more
than one look has a lab page (`styles/<family>/lab/`) built this way.

Expect the first choice to be refined: "this look, but with the other one's colours", or "this, for the scenes in the
other world only". Mixing is fine.

## 6. Checkpoint

Build a real section before the whole song: 20-30 seconds of the section that carries the concept, or the first
90 seconds. Render it as an MP4 and get notes on the look, the pace, the figures, the text. This is where most of
the useful notes arrive, and they're cheap to act on now.

## 7. Build the whole song

Section by section. After each, render stills across it (`tools/still.py ... a:b:2 --sheet`) and look at every one:
frame edges, blank frames, things the camera cuts through, text that's unreadable or covered. Fix, then move on.
When it's all there, render the MP4, then scan it at one frame every two seconds.

## 8. Notes, and fixing a stretch

Notes on a full video are usually local: one stretch feels empty, one chorus repeats the last, a transition jerks.
Re-render only that slice and splice it in ([rendering.md](rendering.md#fixing-one-stretch)).

## 9. Deliver an MP4

Share the MP4, not the web page. A browser player's pause and scrub can feel unreliable, and people give up on it.
`tools/render_mp4.py` writes a 1080p file and a smaller 720p one for sending.

## 10. Revising a finished video

A second or third pass (new conventions, a list of fixes, a stretch that needs more going on) works best as: a short
written plan of every change; then before/after sheets, stills from the old render and the new build at the same song
times side by side; then the full render. The sheets let the notes land on exactly what changed. When picking stills
for review, catch short effects at their peak: a flash or a bolt that lasts half a second is easy to miss.

## What the notes taught (true for every style)

- **Busy enough.** Something new on nearly every beat, or at least every line. A stretch with nothing happening
  reads as a mistake, not a rest. When a stretch feels empty, fill it with callbacks (translucent overlays of earlier
  scenes) and background life (children, animals, people passing) rather than restaging it.
- **No long freezes.** A four-second still reads as the player stalling. Keep holds to a beat or two, or keep
  something drifting: a slow camera move, breathing light, smoke.
- **Make small changes obvious.** A face swapping for another face, a detail changing on a paper: if it matters,
  make it big and push the camera in on it. Subtle changes go unseen.
- **Too clean reads as dead.** A video that stays tidy all the way through can feel flat; give it an arc.
- **Vary the repeats.** The second chorus shouldn't replay the first. New scenes, with brief flashes back to the
  first chorus's pictures on key words, keep the echo without the repetition. A motif that does something different
  each chorus (ribbons that knot, then plait, then slip) works well.
- **Whole figures beat close-up hands.** Big silhouettes of hands and arms read as clubs, poles or chess pieces. A
  whole figure, even small and mostly still, carries a beat better.
- **Faces:** realistic halftone or heavy shading can make people look ill. Stylized faces (dot eyes, lowered lids
  when looking down) for close figures and blank faces for crowds read better.
- **What makes a look cute** (sometimes wanted, often not): flat candy fills, rounded sack-shaped figures with blob
  heads, even lighting, bobbing walks. For solemn songs, use weight, texture, uneven light and stillness instead.
- **Real texts make good props.** A period document, a real letter or hymn, an actual map give a scene weight even if nobody
  can read them.
- **Impossible places need ordinary things in them.** Floating or folded land only reads as land when it carries
  trees, lit windows, snow on its ground side, smoke going the "wrong" way.
- **Decide about text in the picture.** A lyric band under the picture is one choice; no readable text at all
  (squiggles for writing) is another; either way, be consistent. Captions that only repeat the lyric are redundant.
- **Fake text is worse than no text.** A card of invented glyphs that flickers reads as a screen of foreign writing.
  Use pictograms, squiggles, or nothing. Likewise on-screen read-outs (temperatures, timecodes) in a "technical"
  medium: keep them only if they mean something.
- **Show the medium working.** When a look risks feeling static (a photograph, a print, a drawing), let the viewer
  watch it being made: a plate exposing, inks printing in on the beats, stitches sewn in, a slide pushed into the
  lantern. It answers "static and unclear" without changing the look.
- **Vary what leads a scene.** In a medium with a life of its own (liquid light, marbling, sand), let some scenes be
  led by the pictures and some by the medium, rather than the same mix throughout.
- **Props must sit in hands.** A rope, a ring, a cloth or a cup that floats near a hand reads as broken. Anchor held
  things to the rig's hand points and check every one in stills.
- **Arms that move naturally:** pose them by where the hand and elbow should be, blend joint angles rather than
  positions, let the forearm trail the upper arm, and add breathing and small weight shifts. Arms that slide
  straight between poses look like a puppet's.
- **Bodies carry identity.** In silhouette, heat or other outline-first looks the outline is all a viewer gets: if
  someone is heavily built, or small and round, the shape must show it. Keep sizes consistent (an animal is as big in
  every shot).
- **Shapes read as other shapes.** A figure lying flat reads as a collapsed body (have them sit or doze upright unless
  a death is meant); a pyramid of sacks in a lit doorway reads as a hooded head; a fan of hair strands reads as a
  feathered headdress. Look at every silhouette as a stranger would.



===== 完整公共规范：docs/timing.md =====

# Timing a song

Everything in a video hangs off the song's clock: the lyric band lights each word as it's sung, pieces land on
beats, scenes change on line starts, the lamp goes out in a dropout. This page is how to get those times. The tools
are in [tools/audio/](../tools/audio); each prints its own help with `--help`.

Setup (once): `pip install -r requirements-audio.txt` (librosa, scipy, faster-whisper, mido). The Whisper model
downloads the first time it's used.

## The pipeline

```bash
# 1. the shape of the song: tempo, loudness, sections
python tools/audio/analyze.py song.mp3

# 2. words with timestamps, from the vocal stem if you have one
python tools/audio/transcribe.py vocals.mp3 --lyrics lyrics.txt --out whisper.json

# 3. your lyric sheet matched to Whisper's words
python tools/audio/align.py lyrics.txt whisper.json --out lines.json

# 4. snap each word to where the voice starts it (vocal MIDI and/or vocal audio)
python tools/audio/snap.py lines.json --midi vocals.mid --audio vocals.mp3 --out snapped.json

# 5. the page's data file
python tools/audio/to_js.py snapped.json --out projects/my-song/lyrics_data.js --title "My Song" \
    --audio song.mp3 --audio-file projects/my-song/song.mp3 --bpm 96 --beats-per-bar 4
```

Then open the video with the lyrics showing and listen through. Fix what's off by editing `lyrics_data.js`
directly: it's plain data.

## Step by step

### 1. The shape of the song

`analyze.py` prints the global tempo and the local tempo every 20 s, a table of loudness, brightness and rhythmic
busyness every few seconds, and guesses at section boundaries. Read it next to the lyric sheet. You're looking for:

- which sections are loud and which drop out: the video's big and quiet moments should follow them;
- tempo changes (a slow intro, a half-time bridge);
- **stops and hits.** `onsets.py song.mp3 --from 140 --to 155` zooms in on a stretch: the strongest onsets, the
  beats, and the loudness every quarter second, so a dropout shows as a run of low numbers. These are the best
  sync points a song offers: the place for everything to freeze, for a cut, for a light to go off.

`sections.py song.mp3 --lines lines.json` compares the sections' loudness, drums and tonal energy once you know
where they are.

### 2. Transcribe

`transcribe.py` runs faster-whisper with word timestamps. Give it the **vocal stem** if there is one; sung vocals
over a full mix transcribe much worse. The `small` model is usually enough and takes about a minute. `--lyrics`
passes the start of your lyric sheet as a prompt, so names and odd words come out spelled your way. `medium` can
rescue mumbled lines, but over a long song it can drift further than `small`.

Expect Whisper's times to run **early**, typically a few tenths of a second and sometimes by more than a second,
and to hear some words wrong, especially names and unusual words. Step 3 doesn't care about wrong words; steps 4 and
the listen-through fix the times.

### 3. Align

`align.py` lines your sheet up against Whisper's words (a sequence match, so misheard or missing words don't break
it; unmatched words get times interpolated from their neighbours). It prints each line with a match count like
`m7/9`. Low counts are where to listen first. Watch for:

- **numbers:** Whisper writes "1974" as one token for three sung words. The script spells out years and small
  numbers before matching, but check them;
- **hyphenated words** and contractions;
- **a misheard last line** ("Let it go" for "Letting go"): the end of a song, over a fade, is where Whisper guesses;
- **repeats and ad-libs** the singer added: put them on the sheet as sung, or they'll be squeezed between
  neighbours.

### 4. Snap to the voice

`snap.py` moves each word to the nearest sung-note onset within 0.32 s: note onsets from the **vocal MIDI** first
(if you have it), then onsets detected in the **vocal audio**. It first reports the median offset between the words
and the onsets; if Whisper ran early across the whole song, pass that back as `--shift` so everything moves before
snapping.

After snapping, some things still need a human ear:

- **line starts that land in silence** or on the tail of the previous word: move them to where the voice comes in;
- **choruses and held notes:** a melisma or a long held word confuses onsets;
- **MIDI quantization:** Suno's MIDI is quantized to sixteenth notes and can sit about 0.3 s off the voice.

For those, `onsets.py vocals.mp3 --from 25 --to 27 --pitch` prints the sung pitch and loudness every 50 ms: the
word starts where the pitch appears and the loudness jumps.

### 5. Write the page data

`to_js.py` writes `lyrics_data.js`, which sets `window.SONG`:

```js
window.SONG = {
  title: "My Song", credit: "", audio: "song.mp3", duration: 212.4,
  bpm: 96, beatsPerBar: 4, firstBeat: 0.35,
  sections: [["verse1", 12.3, 41.0], ...],
  beats: [0.35, 0.975, ...],            // only with --beats: exact beat times
  lines: [{section: "verse1", text: "Who has seen the wind?", t0: 12.3, t1: 14.9,
           words: [["Who", 12.3], ["has", 12.9], ...]}, ...],
};
SONG.beat(n)  // the time of beat n
```

Every style in this repo reads that shape (see [examples/poem/lyrics_data.js](../examples/poem/lyrics_data.js)).

## Beats

For a steady song, `--bpm` and `--first-beat` (the time of the first downbeat) are enough: `SONG.beat(n)` is
`firstBeat + n * 60 / bpm`. Find the first beat with `onsets.py` on the song's opening seconds.

If the tempo drifts or changes, use exact beat times instead:

- **from MIDI stems:** Suno writes a tempo event on every beat, so the tempo map is an exact beat grid.
  `midi.py drums.mid --beats-out beats.json` (any of the song's MIDI files will do);
- **from the audio:** `analyze.py song.mp3 --beats-out beats.json` (librosa's estimate; check it).

Pass the file to `to_js.py --beats beats.json`; `SONG.beat(n)` then reads from the list.

## Hits and loudness

Some styles pulse, flash or move with the music itself rather than the words: a lamp that breathes with the mix, a
ring on every drum hit, mouths that open with the voice. `pulses.py` measures those:

```bash
python tools/audio/pulses.py song.mp3 --percussion perc.mp3 --drums drums.mp3 --vocals vocals.mp3 --out projects/my-song/audio_data.js
```

It writes `window.AUDIO = {fps, ticks, kicks, env, venv, vdb}`: small hits (`ticks`) and big ones (`kicks`) as
`[time, strength]`, the mix's and the voice's loudness 24 times a second (`env`, `venv`, 0..1), and the voice's
loudness in decibels mapped to 0..1 (`vdb`, better for mouths). Stems give much cleaner hits than the mix; without
them everything comes from the mix. The liquid light show reads this file as it is; any style can read the arrays.

## Suno specifics

- The stem download gives an audio file and a MIDI file per instrument. The lead vocal stem transcribes cleanly.
- The MIDI files carry a key-signature event that the `mido` library can't decode (it raises
  `KeySignatureError`). `tools/audio/midi.py` patches mido to read it as C; import `load()` from it in your own
  scripts to get the fix.
- The MIDI tempo map has one event per beat: an exact beat grid, including tempo changes after an intro.
- Vocal MIDI notes are quantized and can sit up to ~0.3 s off the voice: good anchors for snapping, not ground truth.
- Suno ignores dynamics on the lyric sheet ("quiet", "spoken", "almost unaccompanied"). Measure.

## Checking by eye and ear

Open the page, play it with the sound on, and watch the lyric band. Words that light up early are the common
fault. For a close look, `#t25.3` on the page's URL shows the frame at 25.3 s with the band as it is then.



===== 完整公共规范：docs/rendering.md =====

# Previewing and rendering

Every video here is a web page that draws its frames on a canvas. You watch it in a browser while you work, and
when it's done a script steps through it frame by frame in headless Chrome and pipes the frames to ffmpeg. This
page covers the page contract the tools rely on, previewing, stills, MP4s, and fixing a stretch.

Setup (once): `pip install -r requirements.txt` (Playwright, imageio-ffmpeg, Pillow, numpy). The tools drive your
installed Google Chrome; if you don't have it, `python -m playwright install chromium` gets Playwright's own.
imageio-ffmpeg bundles an ffmpeg with x264 and AAC, so there's nothing else to install.

## The page contract

A video page (a style's `index.html`, or a copy of one for your song):

- draws into `<canvas id="film" width="1920" height="1080">`;
- loads its song data as `window.SONG` (see [timing.md](timing.md#5-write-the-page-data)) and plays `SONG.audio`
  in an `<audio>` element, falling back to a silent clock if the audio can't load;
- sets `window.__video`:
  - `ready`: true once everything is built;
  - `duration`: the song's length in seconds;
  - `step(t)`: draw song time `t` the way playback does. The MP4 renderer calls it at 24 fps, strictly in order;
  - `renderAt(t)`: draw a still of time `t` from a fresh state (catching up whatever the frames before it built);
  - either may return a Promise (a page that builds scenes asynchronously); the tools wait for it;
  - `error`: set this to the error text if building fails, and the tools stop and print it;
  - optionally `shots` and `probe(t)` for 3D pages (see `tools/probe.py`);
- shows a still when the URL ends in `#t<seconds>` (e.g. `index.html#t12.5`), with the page chrome hidden;
- draws only while playing: a paused player shouldn't keep redrawing its frame on every animation frame (the tools
  draw and read back each frame in one call, but a page that redraws on its own fights anything else that draws);
- is **deterministic**: all randomness comes from seeded generators keyed to the frame number, never
  `Math.random()` per frame, so a given moment always draws the same picture. An MP4 depends on it.

A style-lab page sets `window.__lab = { ready, scenes, styles, render(scene, style) }`, where `render` draws one
scene in one look and returns the canvas.

## Previewing

```bash
python tools/serve.py            # serves the repository at http://localhost:8000/ and lists the demo pages
```

Open a page from the list. Use this server rather than `python -m http.server` or opening the file directly:

- pages that use ES modules or load files **don't work from `file://`**;
- a plain server lets the browser **cache scripts**, so after an edit you can be looking at the old code. This
  server sends no-cache headers;
- audio and video only seek when the server answers **Range requests**; this one does.

**Stills in the browser:** add `#t<seconds>` to the URL. Changing only the `#` part doesn't reload the page, so
after editing code, reload with a new query (`index.html?r=2#t30`).

**Always check the console** after a load. One bad value in a canvas gradient (a NaN colour stop) throws, and the
whole frame goes blank.

**In Claude Code's desktop app**, the preview pane can run the server for you: create `.claude/launch.json` with
```json
{ "version": "0.0.1", "configurations": [
  { "name": "videos", "runtimeExecutable": "python3", "runtimeArgs": ["tools/serve.py", "8000"], "port": 8000 } ] }
```
(it's git-ignored).

## Stills and contact sheets

```bash
python tools/still.py styles/paper-cut/index.html 5 12.5 30          # three stills
python tools/still.py styles/paper-cut/index.html 0:37.5:2.5 --sheet # a frame every 2.5 s, tiled into one image
python tools/lab_stills.py styles/embroidery/lab/index.html --all --sheet
```

Output goes to `renders/` (git-ignored). The contact sheet is the fastest way to review a whole video: look at every
frame on it, not just the ones you changed. Things to look for: frame edges showing the end of the world, blank or
black frames, the camera inside an object, text covered or cut off, two scenes' seams, something frozen too long.

## MP4s

```bash
python tools/render_mp4.py styles/marbling/index.html                    # renders/marbling.mp4 and -720p.mp4
python tools/render_mp4.py projects/my-song/index.html --out "renders/My Song.mp4"
python tools/render_mp4.py projects/my-song/index.html --start 60 --end 90 --fast   # quick preview of a slice
```

- Two files: 1080p (x264 `slow`, CRF 23, AAC 192k: roughly 5 Mbps for a busy picture) and `-720p` (CRF 25: about
  1 Mbps, small enough to send).
- `--fast` writes only the 720p with the `veryfast` preset. Busy, grainy frames can take many times longer to
  encode with the slow preset than to draw, so use `--fast` for previews and the normal mode for the final.
- The audio comes from `SONG.audio` unless you pass `--audio`. A slice gets short audio fades.
- **Fonts:** the styles load their type from Google Fonts. If a font request fails (a flaky network), canvas text
  silently falls back to a default font, so `render_mp4.py` and `render_frames.py` check the page's fonts after it
  builds and stop if any failed. Run again, or pass `--allow-font-fallback` if you really mean it. The still tools
  print a warning instead.
- 24 fps. Frames are rendered **in order**: many styles draw each frame over the one before (frost that grows,
  ghosting, marbled paint that keeps its history), so a frame can't be drawn on its own.
- Speed depends on the style and on how much the machine is doing: from about 40 ms a frame (paper cut, painted
  enamel, archive desk) to 250 ms or more (sand, the pinscreen, screenprint's printing), including reading the frame
  back and encoding. Each style's README gives its numbers. A four-minute song is 5,760 frames: a few minutes for the
  fast styles, half an hour or more for the slow ones (see the next section for splitting a render across browsers).

## Long renders: frames on disk, resumable, in parallel

For a long song in a slow style, render the frames to a folder instead of straight into ffmpeg:

```bash
python tools/render_frames.py projects/my-song/index.html --dir renders/frames/my-song --jobs 3
python tools/encode.py renders/frames/my-song --out "renders/My Song.mp4"
```

- Frame `i` is `<dir>/<i:05d>.jpg` and shows song time `(i + 0.5) / 24`. Frames already on disk are skipped, so an
  interrupted render continues where it stopped when you run the same command again, and deleting a stretch's
  frames and re-running redoes just that stretch.
- `--jobs N` renders N runs of frames in N browsers at once. Each run starts with `renderAt()` at its first frame,
  which catches up styles whose frames depend on earlier ones, then steps in order. (Tested: a resumed run's frames
  match a straight-through render pixel for pixel.) GPU-heavy styles gain less, since the browsers share one GPU.
- `encode.py` takes the audio from the folder's `meta.json` (the page's `SONG.audio`), cuts it to the frames on
  disk, and writes the same 1080p and 720p files as `render_mp4.py`.
- **A render that sits before its first frame** is usually the machine, not the page: with other renders or heavy
  WebGL pages running, Chrome can take minutes to start or to build a page. `render_mp4.py` prints the page's URL when
  it's loaded and a progress line every 240 frames.
- **Heavy 3D pages:** building every set of a long WebGL video at once can hang the GPU. Render such a video in
  segments (`--start`/`--end` runs into the same frame folder, each run building only what its stretch needs), and
  on a machine that other renders are sharing, run one segment at a time.

## Fixing one stretch

A full render can take a while. To fix one stretch, render only that slice at full quality and splice it into the
finished file at whole frames:

```bash
python tools/render_mp4.py projects/my-song/index.html --start 120 --end 135 --out renders/fix.mp4
python tools/splice.py "renders/My Song.mp4" renders/fix.mp4 --at 120 --out "renders/My Song v2.mp4"
```

A slice opens with `renderAt(t)`, which catches up styles whose frames build on earlier ones, so its frames match the
full render's and the splice is seamless.

## Checking a 3D video's framing

`python tools/probe.py styles/diorama/index.html` asks the page, for the start, middle and end of every shot,
whether anything stands between the camera and its subject, or whether the camera is inside something. In a crowded
set it finds blocked views much faster than contact sheets.

## Sharing

Share the MP4. If you also want a review page (the video with notes around it), keep in mind that some hosts cap
file sizes: split a long 720p video into parts at scene changes and play them in sequence against the song, and
serve it from something that answers Range requests.



===== 完整公共规范：docs/your-own-video.md =====

# Making a video for your own song

The hands-on steps, from an mp3 to an MP4. For the creative side (what to decide before building, how to pick a
look) see [workflow.md](workflow.md). If you're working with Claude Code, you can just ask it to make a video for
your song: [CLAUDE.md](../CLAUDE.md) walks it through all of this.

## 1. Set up

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt            # rendering
pip install -r requirements-audio.txt      # timing a song (Whisper, librosa, MIDI)
```

You need Google Chrome installed (or run `python -m playwright install chromium`).

## 2. Start a project folder from a style

Pick a style from the [gallery](../README.md#the-styles) and copy its folder:

```bash
cp -r styles/paper-cut projects/my-song
cp ~/Music/my-song.mp3 projects/my-song/song.mp3
```

Audio files are git-ignored, so your song stays out of the repository.

In `projects/my-song/index.html`, change the lyrics script from the demo's
```html
<script src="../../examples/poem/lyrics_data.js"></script>
```
to your own
```html
<script src="lyrics_data.js"></script>
```
(Relative paths from `projects/my-song/` resolve just as they did from `styles/<style>/`, so anything else the
page loads from the repo keeps working.)

## 3. Time the lyrics

Write the lyric sheet (`projects/my-song/lyrics.txt`, one sung line per line, `#section` markers), then run the
pipeline in [timing.md](timing.md). It ends with `projects/my-song/lyrics_data.js`.

## 4. Look at it

```bash
python tools/serve.py
```

Open `http://localhost:8000/projects/my-song/index.html`. The demo's scenes now play under your lyrics for as long as
the demo lasts. That's the moment to decide the plan: which scene goes where, which line lands on which image.

## 5. Replace the demo's scenes with yours

Every style's README has a "Make your own video in this style" section that says which files are the demo (its
scenes, sets, shots or timeline) and which are the engine. Keep the engine; rewrite the demo files. Work a section
at a time:

```bash
python tools/still.py projects/my-song/index.html 30:60:2 --sheet   # stills every 2 s across 0:30-1:00
```

Look at every still on the sheet. Check the console output printed at the end.

## 6. Render

```bash
python tools/render_mp4.py projects/my-song/index.html --start 30 --end 60 --fast   # a quick 720p preview
python tools/render_mp4.py projects/my-song/index.html --out "renders/My Song.mp4"  # the final, 1080p + 720p
```

To fix one stretch later without re-rendering everything, see
[rendering.md](rendering.md#fixing-one-stretch).



===== 完整公共规范：docs/engine-patterns.md =====

# How the engines are built

The eighteen engines in [styles/](../styles) share no code at run time: each folder is self-contained, written for one
song in one medium (a few began as copies of another's files, such as the 3D pipeline or the ray-marched figure). But they
share a shape, and knowing it makes any of them easy to read and a new one quicker to write. This page is that
shape, plus the browser gotchas that cost the most time.

## Simulate the process, not the look

Each engine models how its medium is physically made, and the imperfections come out right on their own:

| medium | what the code does |
| --- | --- |
| screenprint | each ink is a stencil mask plus a halftone; inks are pulled one at a time and multiplied onto paper, each a little out of register, with squeegee streaks and pinholes |
| linocut | a block is a list of gouge cuts and inked areas; the key block prints black over watercolour washes |
| wool embroidery | wool is laid and couched from tiles, outlines are stem-stitched, light is couched gold thread |
| marbled paper | paint floats as closed outlines on a bath; drops, combs and swirls are exact maps applied to every point |
| magic lantern | slides are baked as tinted glass; a frame stacks glass by multiplying and throws it through a lens |
| painted enamel | two-colour bristle strokes with a highlight flick toward the light, then gold leaf |
| paper cut | cut shapes with a lit rim and a soft shadow, layered in depth and lit from behind |
| mosaic | tesserae are laid in rows along the outlines, then grouted |
| sand on a lightbox | sand thickness is a density field; the lamp shows through as `exp(-k * thickness)`; fingers clear lines |
| carved diorama | each piece is a signed-distance sculpture meshed in the browser; tool marks are a bump in the piece's own space |
| photomontage | photographs are painted in greys, then given a print's grain, halation and tone curve, and cut out with drifting scissors |
| pinscreen | a field of pins at different heights, lit from a low angle, each pin's shadow falling on the next |
| archive desk | every paper is pre-rendered with its shadow, grain, foxing and torn fibres; stamps are inked, then eroded |
| night poster | a shape's shadow is the band a shifted copy of it fails to cover; night mixes colours toward navy while lamps keep their brightness |
| batik | a real 3D set lit by two coloured lamps is rendered into buffers; wax resists where both lamps reach, each dye takes where only one does, and the wax cracks |
| long-exposure glass plate | each frame integrates many light drawings over the exposure, so whatever moved is a smear and whatever stood still is sharp; then halation, dust and the emulsion's edge |
| silverpoint | even hatching whose weight follows the tone; lines can't be erased, and tarnish from grey to brown with age |
| carved relief | the scene becomes a height field, shaded by a raking light with its own cast shadows |
| liquid light show | oil, water and dye in a dish on a projector: warped-noise dye bands, metaball oil drops with a meniscus, and drawn transparencies whose black ink really blocks the lamp |
| thermal camera | a scene rendered as temperatures and mapped through a camera palette, with a thin visible-light edge overlay, warm breath and fading heat prints |
| showboat stage | painted flats given brushwork by a sampled-stroke pass, lit by a light map in which the actors are lit through their own silhouettes |

A filter that makes a clean digital picture look like linocut never convinces for long. A few rules about how the
real thing is made go much further.

## One frame

Almost every engine's frame function looks like this:

```
renderFrame(t):
  shot = the shot covering t
  set  = shot.set, baked on first use           (the still layers: land, buildings, background)
  cam  = shot.cam(t)                            (keyframed, eased)
  draw the set's layers through the camera       (parallax: nearer layers move more)
  draw what moves at t                           (figures, props, light, weather)
  post: light (a multiplied lamp or light map), grain, vignette, the medium's texture
  if t is inside a transition: draw the next shot too and mix (dissolve, wipe, push)
  the lyric band / margin / caption for t
  fade in and out at the ends
```

The canvas is 1920x1080. Several styles keep the picture above a band for the lyrics (e.g. 1920x960 + 120).

## Sets, shots, cameras

- **Sets** (or scenes, worlds, plates) are places. Their still parts are drawn once into offscreen canvases the first
  time they're needed ("baked"), then only composited. Keep a memory budget: the whole song's sets rarely fit at
  once, so drop the least recently used. Bake at load what the first seconds need, so playback doesn't hitch.
- **Shots** are stretches of song time: `{t0, t1, set, cam, ...}` plus a function that poses what moves.
- **Camera keys** are `[time, x, y, zoom, ...]` with easing between them. Two useful rules:
  - push in with **lens zoom**, not by travelling into the layers: depth travel blows the nearest layer up (snow
    becomes moons);
  - **never let the camera see past the edge** of what's drawn. Check the frame corners on every new camera.
- **Transitions:** dissolves, drop wipes (a new picture spreading inside a drop), push and pull (from a room to the
  picture on its screen), panels (pull back to a page of panels, push into another), re-laying one medium as another
  past a moving line.

## Time: on twos, and in step with the song

- Hand-made animation moves **on twos**: pose changes at 12 fps inside 24 fps video. Several engines step motion at
  12 fps (`tm12 = Math.floor(t * 12) / 12`) while the camera moves at the full 24, which keeps the hand-made feel
  without a juddering camera. Texture "boil" (grain, ink noise) often changes at 8 fps.
- **Ease into fast moves**, or drive them with real time: a move that starts at full speed jumps at 12 fps.
- **Hits on beats, changes on lines.** `SONG.beat(n)` and each line's `t0` and word times are the anchors. A word
  lighting in the lyric band typically fades up over `[t - 0.04, t + 0.16]`.
- **Keep something moving.** A hold longer than a beat or two reads as the player freezing. A slow drift, a breathing
  light or drifting smoke keeps a still picture alive.

## Determinism and frame-to-frame state

- All randomness comes from seeded generators (`mulberry32(seed)`) and noise keyed to the frame number. Never call
  `Math.random()` while drawing a frame. The same `t` must give the same picture, or an MP4 won't match what you
  checked.
- Some styles **carry state from frame to frame**: frost that grows, ghosting of the previous frame, a charcoal
  drawing that's erased and redrawn, marbled paint whose outlines remember every comb. Those must be stepped in
  order. `renderAt(t)` then means "rebuild the state from the start of this scene up to t", and each engine's README
  says how it does that.
- When a view steps backwards in time (a camera effect that holds frames, a scrub), keep what's already baked rather
  than rebuilding it from scratch each step, or rendering crawls.

## Figures

- **Whole figures**, posed. Every engine has a rig: jointed silhouettes, contour-drawn people, ray-marched signed
  distance bodies, carved 3D pieces. Most use **two-bone IK** for arms (and often legs), so a hand can be put exactly
  on a rope, a cup or another hand. Each rig spells it its own way: `reachArm()` in paper cut, an arm given as
  `{t: [x, y]}` in embroidery or `{at: [x, y]}` in painted enamel; the style READMEs show how.
- Build **every figure of a kind from one model**, so its anatomy is the same in every shot; vary only pose,
  clothing and age.
- Things that make figures read wrong, all hit at least once: round heads read as teddy bears (give them a muzzle
  or a jaw); coats that hang along the body turn a crouching figure into a plank (hang them toward world-down);
  digitigrade legs with a long stride look like sitting on a stool; two figures leaving the same way merge into one
  blob; close-up arm silhouettes read as clubs or poles.

## Light

- A **lamp** is a radial gradient drawn with `multiply` (or a light map multiplied onto the whole picture). Its
  warmth and brightness carry most of a scene's mood.
- **Self-lit things** (flames, lit windows, glowing marks) go in their own layer drawn after the light map, plus a
  glow. A reflective shape in front should erase the self-lit layer behind it.
- On pale paper, `screen` adds almost nothing; `soft-light` plus a weaker `screen` shows coloured light.
- Glass only darkens: a moving piece has to pass over light glass, or it vanishes.

## Text in the picture

- Load fonts before drawing and wait for them (`document.fonts.load(...)` for each face and script you use), or text
  falls back to a default font. `document.fonts.load` resolves even when the font never arrived, so check the
  result (or `document.fonts.check(...)`) before building. Put `<meta charset="utf-8">` at the top of the page for
  any non-ASCII text.
- **Start building only when every script has loaded** (`DOMContentLoaded`, or put the start call at the end of the
  last script). A build started from a font promise plus a short timer can win the race against later scripts when
  the fonts come from cache, and the page fails to build only sometimes.
- Keep the lyrics readable: if the camera zooms, keep the text out of the zoom (a band or margin drawn in screen
  space).

## Browser gotchas that cost hours

- **One bad gradient value kills the frame.** `addColorStop` with a NaN or an out-of-range offset throws, and nothing
  after it draws. Check the console after every change.
- **`destination-out` uses the current fill's alpha.** A fill left translucent from the last wash only half-erases.
  Set `fillStyle = '#000'` before erasing.
- **`[hidden]` loses to `display: grid`.** Add `.gate[hidden] { display: none }` for overlay elements.
- **Globals collide.** Plain scripts share one global scope; a helper named like an existing function (`hand`,
  `line`) silently replaces it.
- **Tiling seams:** a texture tiled from a sampled corner shows seams on big pieces; downsample the whole texture.
- **WebGL:** GLSL has reserved words you'd never guess (`patch`); creating a texture while another is bound can
  overwrite a texture unit (create textures on a scratch unit such as TEXTURE15); a three.js `InstancedMesh` keeps the
  bounds of its first draw unless `frustumCulled = false`.
- **Headless loads:** wait for the page with `wait_until='commit'` and your own ready flag; a page that builds a lot
  at load can time out waiting for the load event.
- **Grain that changes every frame bloats the MP4.** Change it on twos.

## Starting a new engine

1. Copy the style closest to what you want. Keep its player (`index.html`, the playback and `window.__video` parts
   of its engine) and its lyric code.
2. Write the medium: the few functions that turn a shape into your medium's marks. Test them on stills first, on a
   page that just draws one scene (a lab page).
3. Draw the same key scenes in your medium and in one or two alternatives. Choose.
4. Then sets, shots and the song.



## 原作者媒介陷阱与经验摘录

## Lessons and gotchas

- **Outlines grow without limit under a steady current.** Anything that stirs the paint the same way every frame
  stretches outlines until they hold hundreds of thousands of points. The sway reverses every period instead.
- **Figures traced from overlapping parts look lumpy.** Tapered strokes along a spine (`strokeOutline`) give smooth,
  graceful figures. Seen from above, a swimmer needs its own outline (`swimmerTop`) or it reads as a stick.
- **Objects look pasted on** when they appear as clean geometric blocks. Bow their outlines slightly (`organic`),
  float each part in from its own anchor, let the paint underneath bend round them as they land (`ring`), and let
  everything sway a little.
- **Undoing a push can scar the paint.** While paint is pushed far out, resampling adds points along chords inside
  the opened disc, and when the push is undone they collapse to the centre as a star. Don't push a picture you mean
  to rewind or bring back later: use `wipe: {push: false}`.
- **Rewinds leave chevrons** where the paint also swayed during the comb they undo. Pause the sway (`Breathe`'s
  `pauses`) for any stretch you'll rewind.
- **Rewind only what should come back.** `TapeRewind` takes a list: pass just the comb and the bends, and anything
  else (leaves carried off by a `During`, a hat blown away) stays gone.
- **Concentric drops read as an eye or a target.** Use them only where that's wanted, or pull them into another shape
  straight away (the demo's leaves are concentric drops for a third of a second).
- **Drops push everything in their bath.** A stream of splashes inflates whatever it lands on unless the drops push
  only each other (`sel`) and fade.
- **A window squashed flat and stretched open later magnifies** any sway or push it took while flat, fifty or a
  hundred times. Mark such films `nosway`.
- **A full-frame ground film in a lower bath hides the baths above it** if anything pushes it. Size ground films to
  their region, tag them `'base'` and leave them out of pushes (`nb`).
- **A drop over paint in a lower bath that wasn't pushed** shows that paint through as a flat disc. Put such a drop in
  its own top bath, or push every bath it covers.
- **An object floated in with a slow-starting ease** (`E.io`) starts as a copy about 1% of its size; resampling it at
  that size merged its points, and it grew back as a crude polygon (twigs became thorns, a branch became a wedge).
  `ShapeDrop` now leaves an outline out of resampling while it grows or shrinks.
- **A path offset by more than its curve's radius** folds over itself: a stream whose bend is tighter than its
  half-width makes a cusp in the inner bank.
- **Water that is a round mouth of even width looks like a pipe.** Start a stream as a trickle and widen it as it
  falls.
- **A comb passing across the tray (`front`) folds the paint** if its shift `z` is more than about two thirds of the front's
  width: points outrun the front.
- **A figure rebuilt every frame jitters** if a comb or push passes through its bath: the move's per-frame increment
  shows before the next rebuild. Keep such figures in a bath the combs leave alone (the walker's films are also frozen).
- **Wide worlds are slow** unless the wide layers use coarser outlines, only paint near the camera sways
  (`Breathe`'s `view`), and moving specks are only added where they'll be seen.
- **A scene opening inside a drop wipe must already be built** at the wipe's first frame: start its segment a little
  before, and build its world with near-instant moves.
- **Build scenes before they're needed if playback hitches.** The first frame of a scene pays for building it.
- **One bad value in a canvas gradient blanks the whole frame.** Read the console output after every change.
- **Changing only the `#t` part of the address doesn't reload the page;** after editing code, reload with a new
  query (`index.html?r=2#t30`).
- **`display: grid` beats the `hidden` attribute,** so the play overlay never hid: `.gate[hidden]{display:none}`.


