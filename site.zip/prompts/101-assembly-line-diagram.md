# 101 · 流水线图解 / Assembly-Line Diagram

来源类型：官方风格原文 + 本库中文执行模板  
原作者：Lemo-Opuscar by Lemomo (LemoLab)  
上游原文：https://github.com/lemomo-ai/lemo-opuscar/blob/8ca0dd805e214bcc1d30714cd5b9d21cc02a454b/styles/assembly-line-diagram/STYLE.md  
固定版本：8ca0dd805e214bcc1d30714cd5b9d21cc02a454b  
抓取核对日期：2026-11-24  
本库改动：中文任务模板、中文摘要与编排；原文全文保留。

## 使用前先看

- 保持正面平面视图，货物到站才开机；输出颜色含义全片一致，远景用细节层级与线宽避免挤成一团。
- 24fps，先设计反转和结尾而非只画流程图；类比与真实过程的差别写入事实说明，主体与边界留清楚空隙。
- Lemo-Opuscar by Lemomo (LemoLab), https://github.com/lemomo-ai/lemo-opuscar 。风格原文、公共规范及其改编文档按 CC BY-NC 4.0（https://creativecommons.org/licenses/by-nc/4.0/）署名非商业共享；本库新增中文模板与编排。上游另允许为自己的影片（含商业及客户影片）读取、复制、改编文档并随该片项目交付，超出该范围的商业产品、服务或文档再发行需另获授权。代码 MIT、示例画面 CC BY 4.0 仅覆盖可授权部分，第三方素材、六项示例旁白和 Clawd 等另有例外。详见 ATTRIBUTION.md 与 sources/upstream/lemo/LICENSE。
- 案例图许可：CC-BY-4.0；署名与第三方资产详见 sources/upstream/lemo/styles/assembly-line-diagram/demo/CREDITS。六项示例配音的限制也适用于整段原影片，不能只凭画面许可转发音轨。

- 这是代码渲染工作流；聊天文本本身不会自动产生 MP4，需有可执行的项目环境。
- 先看预览再做长片；不要把示例素材的许可自动套到自己的歌曲、照片、字体和品牌上。
- 下方复制区包含全部风格与公共规范，不要求 AI 另外从本机隐藏路径读取文件。

## 完整复制区

【来源与许可】
Lemo-Opuscar by Lemomo (LemoLab), https://github.com/lemomo-ai/lemo-opuscar 。风格原文、公共规范及其改编文档按 CC BY-NC 4.0（https://creativecommons.org/licenses/by-nc/4.0/）署名非商业共享；本库新增中文模板与编排。上游另允许为自己的影片（含商业及客户影片）读取、复制、改编文档并随该片项目交付，超出该范围的商业产品、服务或文档再发行需另获授权。代码 MIT、示例画面 CC BY 4.0 仅覆盖可授权部分，第三方素材、六项示例旁白和 Clawd 等另有例外。详见 ATTRIBUTION.md 与 sources/upstream/lemo/LICENSE。

你是一位能写代码、检查画面并渲染成片的动画导演。请用“流水线图解 / Assembly-Line Diagram”制作一个属于我的视频。

【我的需求；把花括号内容换成实际值】
主题与一句话故事：{{填写主题和结尾变化}}
用途与观众：{{例如面向普通观众的科普短片}}
内容依据或已有脚本：{{填写；没有则说明需要你写}}
音频、歌词、图片、数据、品牌素材路径：{{填写；没有写“无”}}
素材使用权限与需显示的署名：{{填写来源与许可；不清楚请列待确认项}}
目标时长：30 秒起步；MV 以实测歌曲时长为准
画幅与清晰度：默认横屏 16:9、1920×1080；帧率按本风格原文与引擎规范，未规定时24fps；竖屏须重新构图，不直接裁横屏
语言：简体中文；配音需求：{{有/无、声线与语速}}
必须出现的内容：{{填写}}
禁止出现的内容：{{填写}}
预算与速度：先做低成本验证，再渲染完整片
个人工程名：my-video（可改为英文短名）
确认方式：先给 3 张由真实渲染代码产出的样帧和 5–10 秒预览；我确认风格后再做完整成片

【本风格的核心实现】
在一个扁平剖面工厂里跟随同一件货物，用固定颜色管道、工人和逐站启动解释连续流程。
特别检查：
- 保持正面平面视图，货物到站才开机；输出颜色含义全片一致，远景用细节层级与线宽避免挤成一团。
- 24fps，先设计反转和结尾而非只画流程图；类比与真实过程的差别写入事实说明，主体与边界留清楚空隙。

【工程与流程】
1. 在工作区单独克隆 https://github.com/lemomo-ai/lemo-opuscar ，检出 8ca0dd805e214bcc1d30714cd5b9d21cc02a454b，保留上游原目录供渲染工具和相对路径使用。图册只归档提示词文档，没有打包全部视频源代码。
在独立个人工程目录实现，参考 styles/assembly-line-diagram/STYLE.md；不得把示例电影的故事、角色、文案、音轨当成我的需求。先读风格规范与 DIRECTOR.md、TECHNIQUE.md。Windows 的 sh 命令在 Git Bash 或 WSL 执行。window.TEXTS(t) 的 pass: true 只用于无需完整阅读的路过文字，不能用于观众必须读懂的信息；字幕另按 SRT 检查。
2. 先检查机器的 Python、Node/浏览器、FFmpeg、字体与 GPU 能力。Lemo 当前要求 FFmpeg 7+；先用 ffmpeg -version 核对。缺少工具或访问权限时明确报告缺什么，不能只描述完成、伪造文件或把截图称为已渲染视频。
3. 把我的需求写成 PLAN.md 或 TREATMENT.md：一句话故事、分镜、逐镜秒数、镜头运动、文字位置、音乐与声音 cue、所需素材、预计成本。涉及事实和数据时写 FACTS.md；没有来源的数字不填。
4. 按主题写旁白并实测音频时长；无需旁白时用画面和声音讲清楚。
5. 先完成 3 张代表开头、关键变化、结尾的样帧，逐张检查；再渲染 5–10 秒低清短段，检查字幕、运动、音画同步与控制台。复杂慢风格先计时，再估算整片。
6. 随机效果固定种子；有历史累积的媒介按顺序渲染。并行前先比较随机抽帧与连续渲染是否一致。
7. 正式导出使用项目文档中的工具与参数，不臆造命令。交付可播放 MP4、720p 预览、源代码、素材清单与许可、字幕（有台词时）、复现说明；保留最终片长、帧率、音频响度与实际渲染耗时。
8. 实际打开并检查成片开头、中间、转场、结尾及全片联系表，确认没有空帧、字体回退、遮挡、裁字、爆音或无意复制的作者片尾签名。交代尚未完成的检查。

下面是完整风格参考与公共制作规范。它们是上游参考资料，不代表我的主题或逐字台词；我的具体需求优先。风格中明确的声音、镜头和媒介限制优先于公共建议，例如无声电影不添加旁白或拟音。遇到 macOS/Linux 示例命令时按当前系统等价转换，不直接在 PowerShell 粘贴 bash 命令。相对资源路径以完整克隆的上游工程为准。


===== 完整风格原文：styles/assembly-line-diagram/STYLE.md =====

# Assembly-Line Diagram — Style Prompt

> A process explained as a factory cut open in elevation: a silhouette (a body, a machine, a building, a city) is sliced like a doll's house into rooms on floors, each room a work station with a machine, a numbered plaque and tiny workers; coloured pipes carry the goods between them, and the colour of a pipe is the legend. The camera rides one piece of cargo through the whole line, and every station starts working the moment it arrives.
> References (grammar only): Fritz Kahn, *Der Mensch als Industriepalast* (1926: the body as a cut-away factory, rooms with coloured frames on a dark ground, numbered stations, pipes with highlights, workers in white coats); Nigel Holmes's explanation graphics for TIME (thick black outlines, flat colour, a flat offset shadow, the joke said straight, short bold labels with right-angle leaders). Copy neither: no traced plates, no aged paper, no period lettering.

## 1. Essence, and what it is not

- **One line, one direction.** The subject is a process that turns one thing into another in steps. The film is a single continuous production line the cargo travels; every shot is a station on it, in order.
- **Metaphor per station, said straight.** Each step is one machine everyone can read (a press, a sieve, a weighing scale, a crane, a loading dock, a paint booth). The plaque gives both names: the machine's in English, the real thing's in Chinese (`SIEVE | 沉砂池`). The humour comes from the metaphor being literal, never from cartoon faces.
- **Colour is the legend.** Each kind of output gets one spot colour; its pipe, its parts and its legend tag carry that colour for the rest of the film, so the viewer follows a colour instead of reading a label twice.
- **The cut-away is the frame.** Rooms sit inside a silhouette on a dark ground; the gap of dark between the rooms and the outer wall is what makes the silhouette read (a person, a machine) at every scale.
- **Workers are scale and action.** Tiny, faceless figures, each doing one legible thing (turning a valve, holding a sign, pushing a cart, dozing). They give the factory its size and the beats their comedy.

Not Isometric Infographic (no isometric or perspective view: everything is a flat front elevation), not Whiteboard Explainer (no hand, no drawing-on), not Exploded Teardown (no 3D parts flying apart), not Blueprint (full colour on paper, not white lines on blue), not a keynote (no slides, no centred title pages, no page headers).

## 2. Materials & rendering

- **All vector, drawn in code**: SVG built per frame from shapes and paths. Clean ink outlines with round caps and joins, flat fills, no gradients.
- **Print, lightly.** Every colour plate is shifted by its own 1–1.6 px misregistration, the same direction across the frame (ink, paper and walls stay put), and a faint paper grain and fibre sit on top (multiply). Nothing more: no aging, no torn edges, no yellow stains, no mottled ink.
- **Flat shadows.** A Holmes shadow is the same shape offset down-right in one pale flat colour (plaques 5–6 px, large shapes 14–18 px). No soft shadows, no blur except motion blur on whip moves.
- **The cut-away.** The silhouette is a dark ground with a thick body wall (a band about 56 px thick with ink on both sides); where goods enter (an intake, a hatch, a door) the wall breaks and both ends get an ink cap. Rooms have a coloured frame, a pale wall and a floor strip; floors between rooms are slabs with rivets; steel trestles and gantries hold the machines.
- **Pipes**: ink edge (width + 6 px), colour, then a highlight stripe (0.2 × width, offset up-left, masked inside the pipe); rounded elbows; flanges every so often. Width encodes importance (main duct, arteries, branches).
- **One printed sheet at every distance.** Line weight follows the camera (thinner when pulling back, roughly `z^-0.6`; only slightly heavier when pushing in), and below a set scale small workers, plaques and small text are not drawn while the big machines stay. The drawing never turns into a hairline mess or a blob of text.

## 3. Colour logic

- **Paper + ink + one ground + four spot colours.** Paper outside the silhouette; one dark ground inside the cut; pale walls for rooms; a body colour for walls and slabs; then three or four spot colours that are the legend. No other hues.
- **Spot colours have one meaning each for the whole film** (in a recycling plant, say: ochre = paper, vermilion = plastic, teal = glass). Room frames may rotate through the spot colours by station; the cargo's own colours stay fixed.
- **Ground dark enough to frame, never black**: a deep indigo or wine reads as "inside" and lets the spot colours sit on it. Check that every spot colour separates from the ground (cobalt on indigo does not).
- Numbered station circles are one colour (ochre fill, ink edge); a circle is an outline until its station is reached, then fills.
- Example (our demo, palette A "Night Shift"): paper #F2ECE0, ink #1D2030, ground #24345A, wall #FBF7EE, body #EE9F87, vermilion #E04A2F, ochre #F3B23A, teal #2E8D87. Two alternatives live in `demo/lib.js` (`PALS.B`: a daylight chart with a pale body-colour ground; `PALS.C`: a wine-red ground).

## 4. Type & subtitles

- **Three faces, three jobs** (all OFL): a condensed industrial display face for plaques, legend tags and the title (Big Shoulders Display 800–900, like letters painted on a factory wall); a grotesque for small labels, subtitles and credits (Archivo 600–800); a CJK sans for the one short Chinese line on each sign (Noto Sans SC 700, at least 34 px).
- **Plaques**: cream board, 2.6 px ink frame, 3 px corners, flat shadow; `[number circle] [ENGLISH METAPHOR | 中文名]`, stuck on the room's top edge or on the machine, never on a leader line.
- **Legend tags** hang above their line: a colour chip, then the English and Chinese name (`GLASS 玻璃`).
- **Leaders** (Holmes): dot → vertical → right angle → bold words, only for a moving hero, at most one per frame.
- **At most about seven pieces of text in a frame**, two to four words each.
- **The title is an object in the picture** (a gantry sign over the infeed, a machine's nameplate) hung on the thing it names, never in a page margin, never centred, never a header. The end card is the same object: a nameplate standing on the ground line.
- **Subtitles are work tickets**: a cream ticket with an ink frame, a stub on its left showing the current station number (a clock when there is none), Chinese 34 px over English 28–30 px, one line each, bottom left; move them bottom right in shots where the title or the end card holds the left. Compose every shot with that corner free.

## 5. Motion quality

- **The belt never stops moving**; cargo travels at constant speed and eases into stations.
- **A station starts on arrival.** Its machine starts on the beat the cargo lands (rollers turn, sprays fall, a press stamps), its worker does a two-frame action, its number circle fills and pops (scale 0.9 → 1 with overshoot).
- **Signs drop on chains** and bounce once; a second-language sign swings in half a beat later.
- **Repetition is the joke.** A gatekeeper raises STOP, lets one portion through, raises STOP again; machines repeat their cycle on the music's grid.
- **Time compresses on clocks and dials**: hands spin, lamps dim, workers doze; never a title card saying "later".
- **Big figures move by procedure, grounded**: a running figure plants its support foot on the ground line and moves with the ground, knees solved from two bones and always bending forward; nothing slides, floats or crosses scissor-wise on a held frame.
- **Frame rate and grain**: 24 fps.

## 6. Camera grammar

Always a flat front elevation: the camera pans, tilts, pushes and pulls in the plane of the drawing, never rotates into perspective.

| Move | What it expresses | Can serve |
|---|---|---|
| Truck with the cargo | the flow, one piece followed | an opening; moving between stations on one floor |
| Push through a door shape | entering the system | the intake; going inside a part |
| Tilt down a chute, slabs wiping past | going down a level | the next stage below |
| Pull back from a part to the whole floor | the parts working together | a sorting or splitting station; a held comparison |
| Follow one colour | one output's path | where one product goes while the others leave frame |
| Porthole POV (circular mask) | the outside world reaching in | a trigger, an alarm, a customer, an event |
| Whip down a pipe | urgency | a demand that must be met now |
| The great pull-back | the whole line at once | the ending: the full silhouette with every station lit |

Transitions happen inside the drawing: passing through a shape, floor slabs wiping the frame, a match cut on the same piece of cargo, a colour follow, a circular porthole mask, a whip along a pipe (directional motion blur from the camera's speed plus speed lines, rendered once, never stacked ghosts). No page turns, no fades to paper, no white flashes.

## 7. Sound palette

- **Score as a production line**: a march on a fixed figure (around 120 BPM) that the stations add to; each line or machine brings in its own voice (bassoon, clarinet, flute…); woodblock and bass drum on presses and stamps; glockenspiel or celesta when a station lights up.
- **The stop is a sound**: when a gate closes or an alarm goes, the whole band stops dead and restarts on the next release.
- **Foley from machines** on every visible action: hoppers, chains, sign bounce, roller shutters, presses, sprays, drums, whistles, ladles, clocks, alarm bells, ignition, doors. Procedural, short, on the frame.
- **Voice** (optional): a calm explainer, one idea per line, saying what the picture cannot (the reversal, what a part becomes, why it waits); leave arrivals, the big lighting-up and the end card without words. Compress it and set it about 9–10 dB over the music, carve the music's 300 Hz–4 kHz band under it, let the music rise between lines.
- **Mix**: −14 LUFS, true peak ≤ −1 dB; limit the transients of presses and ignitions.

## 8. Native moves

- **Station starts.** Cargo lands, the machine starts, the worker acts, the number fills. *Fits content like:* each step of a manufacturing process; each stage of a data pipeline; each department a request passes through.
- **Taking it apart into colours.** One lump enters a sorting floor and leaves as three streams of differently coloured parts, each into its own pipe, with legend tags dropping over them. *Fits content like:* a mail sack into postcodes; crude oil into fractions; revenue into costs; ore into metals.
- **Gatekeeper.** A worker with a STOP sign lets one portion through at a time. *Fits content like:* a valve, a rate limit, a queue, a customs desk, a dam.
- **Warehouse and clock.** Goods are shelved; the clock spins; the lights dim; workers doze until an alarm. *Fits content like:* energy storage, inventory, a battery, savings.
- **Porthole alarm.** A circular POV on the outside world shows the event that sets the line running. *Fits content like:* demand arriving, an order, a sensor trigger.
- **Follow the colour.** The camera picks one pipe by colour and rides it to its destination while the others turn away. *Fits content like:* where one product goes; one signal's route; one customer's journey.
- **Light the whole line.** The great pull-back to the full silhouette; a glow runs from intake to output and the numbers pop in order. *Fits content like:* the summary of any process; a product's whole life; an ending.

Our demo opens on an ordinary factory with the title sign dropping over the infeed, uses *taking it apart into colours* (entered on a match cut) as its turn and ends on *light the whole line*. A new film opens and ends another way: the outside event seen through the porthole first, a truck with one cargo already riding the belt, an ending that follows one colour to its output in the outside world, or the factory going dark station by station.

## 9. Pitfalls of the medium

- **Process diagram, not a story.** A station-by-station walk is a flowchart. Give it a hook (a reversal, a deadline, a question) and a payoff picture; let each station say one thing.
- **Text creep.** Plaques, tags, leaders and subtitles add up fast; keep to about seven pieces per frame and let colours carry meaning.
- **Hairlines and blobs at distance.** Without camera-dependent line weight and level of detail, the pull-back turns into a grey mesh of strokes and unreadable labels.
- **The silhouette disappears** when rooms fill the cut edge to edge: keep at least 30 px of dark ground between rooms and the outer wall.
- **Spot colours that vanish on the ground.** Test each against the dark ground and against the walls before committing.
- **Bodies that look like barrels.** When a figure has to hold a lot of rooms, its torso grows and its head shrinks; cross-fade to a schematic figure with human proportions for the full-body shot rather than inflating the cut-away.
- **Feet.** Procedural legs that swing on sine curves float, sink and slide; solve them against the ground line, and hold the final frame on a readable phase (one leg reaching, not crossed).
- **Metaphors that lie.** Every simplification the metaphor makes (one input → one output, a valve where there is really a gradient) goes into FACTS.md; the voice should not claim what the drawing only implies.
- **Leaders everywhere.** One leader per frame at most; everything else is a plaque on its object.

## 10. Engine

- `demo/lib.js`: palettes (`PALS`, `C`), misregistration per plate, `shape`, `txt` (with the far-camera cut-off), `pipe` (ink, colour, masked highlight, rounded polyline), `flange`, `num` (station circle), `plaque` (`[n] ENGLISH | 中文`), `tag` (legend chip), `callout` (Holmes leader), `worker` (faceless figure: arm angles, cap or coat, sit, walk, prop callback), `gear`, `gauge`, `lamp`, `slab`, `room`, `belt`, `trestle`, `sandwich` (the demo's cargo); easing and key interpolation (`steps`, `monotone`). `KS` scales ink width with the camera, `ZL` is the camera scale that hides small things.
- `demo/body.js`: the demo's cut-away world (its body wall, rooms per floor, pipes, sorting floor, warehouse, furnace room, limbs; your film builds its own silhouette and stations), `numOn` / `plaqueN` for stations that light up, `detail(lo, hi, fn)` to fade a group in by camera scale, `inView` culling.
- `demo/runner.js`: the demo's schematic running figure for its pull-back (two-bone IK legs, ground-locked support foot, arm swing, miniature stations inside).
- `demo/overlays.js`: screen-space layers (work-ticket subtitles, porthole POV, the light-up of the whole line, end nameplate, speed lines). `demo/film.js`: the camera path (`camera(t)`), one frame (`frame(t)`), paper grain, `window.render`, `window.TEXTS`.
- Minimal example of something new, a station of your own inside `drawBody` (world coordinates):
  ```js
  room(2400, 3000, 620, 360, C.teal);                                // a new room
  plaque(2420, 2970, 'FILTER', '过滤器', { n: 7 });                    // its plaque
  pipe([[2300, 3200], [2400, 3200], [2400, 3300]], 26, C.sun, C.sunL); // goods in
  worker(2600, 3340, { s: 1.3, front: [150, -20], cap: C.red });      // someone at work
  ```

## 11. Variation space

The agent decides the silhouette (a person, an animal, a phone, a car, a city block, a ship), the process and its stations, the metaphors, the cargo, the outputs and their colours, the palette within the paper + ground + spot rule, whether there is a voice, and the music.

- **Structures**: a reversal hook, then the line in order, then the payoff; one cargo followed from intake to output; two cargoes racing through the same factory; the same factory at two times of day.
- **Openings**: an ordinary factory doing the opposite; the cargo arriving on a belt under the title sign; the outside event seen through the porthole first.
- **Endings**: the great pull-back with the line lit; the output delivered into the outside world; the factory going dark station by station.

---

How our demo was made (story, shots, score, end card, build): [DEMO.md](DEMO.md). Read it after your treatment exists.


===== 完整公共规范：DIRECTOR.md =====

# Directing a Lemo-Opuscar film

The directing method behind every film in this library. Pair it with one `styles/<slug>/STYLE.md` (the style) and [`TECHNIQUE.md`](TECHNIQUE.md) (how to build).

You are the director, not a tech demo. A film is judged in this order: **sound, rhythm, camera, directing** (performance, staging, emotional arc). Good-looking frames are only the starting point.

---

## 1. Take the brief

The user gives a style and a topic, sometimes more (length, language, voice, must-have shots, brand rules). Everything else is your decision. Ask once, in a single message (AGENTS.md, Workflow), then no more questions. Defaults:

- Length **30–60 s**; shorter and tight beats padded. Beyond two or three minutes multiplies time and token cost: tell the user.
- 1920×1080 at 24 fps by default; an output frame rate set in the style's `STYLE.md` (30 or 60 fps, for example) wins, and is what you pass to `--fps` and `mux.sh`; other sizes (vertical 1080×1920, for example) with `--size WxH` on the render tools.
- Voice and subtitles in the language the user writes in. Subtitles burned in and exported as `.srt`.
- **The language on screen is the film's, not the demo's.** Many `STYLE.md` files set a Chinese line above an English line (subtitles, titles, labels): those are the two languages of our demos. A film in one language sets that line alone, in the upper line's place and size. A film in two keeps the stack, its main language on top. For another script, choose an openly licensed face of the same kind (weight, serif or sans, written or printed). The rest of the style's type stays: sizes, placement, how the text arrives.
- Loudness −14 LUFS.

Say it in the questions when it matters: a good Chinese voice uses Microsoft's online service (edge-tts) and needs a connection; offline, Kokoro reads Chinese but sounds plain (TECHNIQUE.md §4).

Requests that only change the plan:

- **No voice, or no subtitles.** Drop those steps and say so in the treatment.
- **Their own voice recording.** Use it as it is; transcribe it with faster-whisper for word timings.
- **Their own material**: logos, photos, footage, and for a style built from real data or scans (its `STYLE.md` says so) their own data, scans, imagery or CAD. Ask whether they have any; what they give comes first, and the sources in the `STYLE.md` are the fallback. Before you download from those sources, tell the user what you will fetch, from where and under which licence. Rights: section 12.

## 2. Find a benchmark first

Before writing anything, pick one or two reference works (films, title sequences, games, ads) that set the bar for this style **and this topic**. They are your choice, made for the user's film; don't borrow the demo's. Write down:

- **What to learn**: composition, pacing, camera grammar, colour logic, score structure.
- **What not to take**: characters, designs, melodies, specific shots, logos, fonts.

The benchmark lifts quality more than any rule below.

## 3. Shape the story

- **One subject, one goal, one turn.** A character (or a single object, product or idea) wants something, something changes, it ends differently from how it began.
- **Hook in the first 3 seconds.** No slow logo reveal before anything happens.
- **An ending that echoes.** Bookend the opening, reveal the scale, or let the character do the thing right the second time.
- **One native move**: a moment only this medium can do (a fold that becomes a transition, ink that blooms into the next scene, a type grid that snaps into the logo). Put it at the emotional peak. `STYLE.md` lists the medium's native moves; pick or invent the one your story needs.
- **Cut the extras.** One gag the audience reads at thumbnail size beats three they can't. If a beat needs explaining, remove it.

## 4. Write the treatment

Write `TREATMENT.md` before drawing anything, and before you open the style's `DEMO.md` or demo code (an Edit & Documentary style gathers its material first: AGENTS.md, "Treatment first"):

1. **Three candidate structures**, a few lines each (for example: a single journey, a before/after, a countdown, a list that turns), then the one you chose and why. Choose the opening image, the ending and the shape of the score from the topic too; the first idea that comes to mind for a style is usually its cliché.
2. **Logline and arc**: one sentence, then setup → turn → ending.
3. **Benchmark**: learn / don't learn (section 2).
4. **Shot list**: for every shot, the framing (wide / full / medium / close / insert), angle, camera move (push, pull, pan, track, crane, zoom), duration, and **why** it is shot that way.
5. **Beat sheet**, second by second.
6. **Cue map**: tempo, bar grid, instrumentation per section, and on which beat every cut, key action and subtitle lands.
7. **Sound design table**: for each section, the ambience bed, the main foley and the music state.
8. **Subtitle and title design**: the type is part of the style.

## 5. Prove the look

- **With characters**: draw a model sheet (turnaround, 3–4 expressions, 2–3 key poses, palette) plus two style frames.
- **Without characters**: three style frames from the film, one of them the signature shot.

Render them with the real drawing code, not a mock-up, and check them yourself against the `STYLE.md` before going on.

### The storyboard (only if the user asked for one)

Render 6–9 key shots with the real drawing code, tiled into one sheet (`core/render/sheet.py`) with shot number, framing, duration and line under each. Send it with the logline and what you are least sure about, and **wait for approval**. If the user didn't ask for one, don't stop.

## 6. Sound is half the film

- **Every visible action has a sound**: landings, page turns, cuts, drips, clicks, cloth. Match the material (paper, wood, metal, ink and glass all sound different).
- **Three layers**: ambience (room, wind, rain, city), foley (tied to actions) and music. Duck the music under dialogue and key foley.
- **At least two real silences**, or near-silences, before the turn or the emotional peak. The first sound after the silence should be one of the most important sounds in the film.
- **Use sound as a transition** at least twice: bring the next scene's sound in early (J-cut) or let the last scene's sound run over the cut (L-cut).
- **Avoid generic "piano and strings".** Score in the instruments of the style's sound palette.

## 7. Rhythm: the music grid comes first

- Write the cue map before animating. The picture locks to the grid, and a script checks every cue (TECHNIQUE.md §3).
- **Vary the pace**: alternate fast and slow, include one clear acceleration or deceleration, and give the audience one breath (a long take or a held pause). A film at one even speed has failed.
- One action, one sound, one cut, but don't cut on every beat. Leave time to see.
- **Pace for the viewer, not the clock**:
  - Hold every subtitle at least 1.8 s, and never shorter than the spoken line + 0.6 s.
  - After text finishes animating in, hold it for roughly (letters ÷ 15 + 1.5) s in English, (characters ÷ 4.5 + 1.5) s in Chinese; `readcheck.mjs` checks this for you.
  - Hold a title card at least 4 s.
  - Give failures and gags enough time to be understood.
  - Fast is fine; make it fast with fewer words per screen, not by cutting before people finish reading.

## 8. Camera: every shot needs a reason

- Use at least **four different camera moves** and real changes of framing. 2D has a camera too: push, pull, parallax, focus pulls, frames within frames.
- **One signature shot** people remember: a oner, a scale reveal, a transition made from the medium itself.
- **Design transitions inside the medium** (a page turn, a carved line growing, ink spreading), as one consistent grammar. Avoid default fades and hard cuts.
- At key moments the subject fills at least a third of the frame height, with clear staging and a readable silhouette.

## 9. Performance

- **Anticipation, action, follow-through** on every meaningful move. Characters change emotion. They do not just slide across the screen.
- **Motion continuity**, especially for characters built from code rigs:
  - Blend every pose with keyframes and easing; never switch poses inside an `if`. The only exception is a deliberate one-frame comic pop.
  - Check shoulders and arms on a large action test sheet (reach, raise, run, kneel) before shooting (TECHNIQUE.md §10).
  - Held props sit **between the palms**, at a depth between the two arms. A hand-over interpolates from one palm to the other. A rolling object turns by distance ÷ radius.
  - Step through key actions at 0.2 s intervals, enlarged.
- Check every expression at final size, especially eyebrow direction: "worried" and "angry" are one flip apart.

## 10. The failures we saw most

- Subject too small, too far away, or pushed against the frame edge.
- Too dark to read, or a colour laid on the same colour (red on red).
- Subtitles covering the subject.
- A gag or failure too fast to understand.
- Blank frames in transitions.
- A timed effect (iris, zoom, follow cam) that doesn't track the subject after the camera moves (one world → screen function, TECHNIQUE.md §2).

## 11. Before you deliver

- Run the review loop (TECHNIQUE.md §8): contact sheets, 0.2 s strips of key actions, one full-speed viewing with sound.
- **One fix round.** Fix everything the review and the checks below find in one round, then check once more. Small fixes that second check turns up (a level, a frame) belong to the same round; anything bigger, tell the user in one line when you deliver. The user's notes after delivery are new rounds: change only what they ask.
- **Not the demo again.** After the treatment, read `DEMO.md` and compare: structure, opening, signature shot, camera path, score shape, ending. At least four of the six must differ; rethink the ones that match. Before delivery, put your contact sheet next to the demo poster (`styles/<slug>/poster.jpg`) as a last check.
- Voice: every line transcribes back correctly (speech-to-text check). For Chinese, one misheard character in a short line is normal: listen, and if it is right, let the check expect what the model heard (TECHNIQUE.md §4).
- Loudness about −14 LUFS; no black frames, no NaN frames; subtitles in sync and not covering key action.
- Every row of the sound design table is actually in the mix.
- Every map, globe or satellite view passes section 13, checked enlarged.
- No LemoLab sign-off: `grep -rniE "lemo ?lab|opus 5\.5" <project folder>` finds nothing outside `LICENSE`, `CREDITS` and the library's path in `LIB=` lines, and you have watched the last seconds of the film (text drawn into an image can't be grepped).

**Deliver**, in the project folder (the complete list):

- `<name>.mp4` (24 fps unless `STYLE.md` sets another rate, about −14 LUFS) and `poster.jpg`;
- `<name>.srt`, when the film has narration, dialogue or subtitles; when the subtitles are burned into the picture, `subtitles_<lang>.srt` instead (desktop players load a `.srt` named like the video on top of the picture, so every line would show twice);
- `TREATMENT.md`;
- `CREDITS`: every third-party asset in the film (sample libraries, music, fonts, images, the voice engine) with its source and licence (TECHNIQUE.md §11);
- the source, with a one-command `build.sh` (TECHNIQUE.md §2).

**Tell the user**, in their language: where the project folder and the film are; that `CREDITS` lists the third-party assets in the film and their licences; and that they are responsible for the materials they use in it.

## 12. Copyright red lines

- References teach grammar only. Don't copy characters, designs, melodies, shots, logos or type designs.
- No existing works, games, brands or events appear in the film unless the user owns them or has the right to use them. That includes the logos, photos and footage the user hands you: use them when they say they have the right, otherwise draw fictional stand-ins.
- Some of our demos are unofficial fan films of real events or characters. Keep the style, and never carry those names, marks or characters into a user's film.

## 13. Maps

These apply to every frame that shows a map, a globe or satellite imagery, in every style.

- **No borders unless the film is about them.** Draw coastlines, terrain, imagery or streets, without national or provincial borders. Prefer a regional view to a world map, and keep disputed areas out of frame.
- **When China is in frame, draw all of it.** Taiwan, Hainan, the South China Sea islands with the dashed line (in frame, or in an inset), and the Diaoyu Islands with Chiwei Yu. Taiwan and the mainland are one country, in the same colour and the same treatment. Zangnan and Aksai Chin are drawn as on China's standard map.
- **Default border data doesn't meet this.** The default boundaries of Natural Earth, world-atlas and OpenStreetMap can't be used to draw China. When the film needs borders, use China-view data (such as Natural Earth's `admin_0_countries_chn` layers, checked against the standard map) or China's standard map service (bzdt.ch.mnr.gov.cn).
- **Words follow the same map.** Taiwan, Hong Kong and Macao are never listed as countries: not in labels, legends, subtitles, the voice-over or data tables. A list that includes them is "countries and regions". Clean a dataset's country field before you chart it.
- **Other disputed areas**: the same; frame them out, or leave their borders undrawn.
- **Check and credit.** Before delivery, enlarge every map shot and check it against these rules. `CREDITS` names the map data, its source and its view (for example "Natural Earth 1:50m, China view").


===== 完整公共规范：TECHNIQUE.md =====

# Technique: how the films are built

Every film here is made from code: no video generation, no stock footage. This page explains the pipeline, to reproduce with our tools in `core/` or in your own stack. Pair it with [`DIRECTOR.md`](DIRECTOR.md) and one `styles/<slug>/STYLE.md`. Every command and flag is in [`core/README.md`](core/README.md).

```
timeline (single source of truth)
   ├─► picture:  web page with render(t) ──► headless Chrome, frame by frame ──► video.mp4
   ├─► voice:    TTS per line ──► speech-to-text check ──► word timings
   ├─► music:    score from the same timeline (samples + synthesis) ──► stems
   ├─► sound:    procedural foley at event times
   └─► subtitles: .srt + burned-in captions
mix (duck, compress, balance) ──► mux with ffmpeg, two-pass loudnorm −14 LUFS ──► film.mp4
```

## 1. Requirements and install

System tools, which the user installs: **Node 20+**, **ffmpeg 7+** (6.x under-reports audio length through `loudnorm`, and `mux.sh` then rejects the file as cut off), and **Python 3.11+** or [uv](https://docs.astral.sh/uv/). Developed on macOS (Apple silicon); Linux should work. On Windows, Git Bash (part of Git for Windows) works: run the same `sh` commands there; WSL also works. 3D and shader-heavy styles want a GPU.

Everything else installs in tiers, from the library root (`$LIB` in skill mode). Install a tier only when the film needs it:

| Command | Adds | Size |
|---|---|---|
| `sh plugin/skills/lemo-opuscar/scripts/setup.sh deps` | core: npm packages, headless browser, Python `.venv` (numpy, scipy, soundfile, soxr, pillow): render, synthesize sound, mux | ~350 MB |
| `… setup.sh deps voice` | Kokoro + model (English, offline), edge-tts (Chinese, online), faster-whisper (voice check) | ~0.55 GB + a Whisper model on first check (~145 MB for English, ~480 MB for Chinese) |
| `… setup.sh deps music` | numba, for plucked strings (`pluck.py`); the sampler itself needs only the core | ~140 MB |
| `sh tools/fetch.sh instruments <lib>` | a sample library: `freepats`, `karoryfer`, `salamander`, `vcsl`, `vsco2ce` or `all` | 70–400 MB each |
| `sh tools/fetch.sh hdri` | HDRIs for 3D styles | 12 MB |

Some styles need packages of their own (a LiDAR reader, a slide-scan decoder, a CAD importer); the style's `STYLE.md` lists them. They are packages, not system tools: install them yourself into a private venv or `node_modules` in the project folder, never into `$LIB/.venv`.

The styles marked ✦ also draw with an image generator, which the library doesn't include and you don't install: the user's own Codex CLI, signed in (`core/image/gen_image.py`), or another image tool they have. Their prompts go to that service (core/README.md, "Image generation").

A synthesized score needs no big download. A sampled one needs the libraries its instruments live in: `sampler.py` downloads the missing ones itself, all at once, when the score is rendered (`LEMO_FETCH=0` turns that off and prints the `fetch.sh` commands instead). Put `"$LIB/.venv/bin/python" core/audio/sampler.py --need <your mix.py>` at the top of a `build.sh`, so they arrive before the long picture render, not after it. A pack needs about twice its size free while it unpacks. Downloads come from npm, PyPI, GitHub Releases and Hugging Face (`HF_ENDPOINT` sets a mirror).

## 2. The picture is a function of time

Each film is a folder with an `index.html` (`<demo>` in the commands) that exposes:

```js
window.DUR = 54.2;                 // seconds
window.render = (t) => { ... };    // draw the frame at time t, deterministic
window.READY = true;               // set once fonts and images are loaded
window.EV = [{t, type, ...}];      // optional: sound / cue events for the mixer
window.TEXTS = (t) => [{id, text, x0, y0, x1, y1}];   // optional: every text visible at t, for readcheck (pass: true = not meant to be read in full: a sign passed by, fine-print credits)
```

**Paths:** pages reach library files with absolute URLs (`/core/lib.js`, `/node_modules/three/build/three.module.js`); scripts and `build.sh` use `$LIB`. Never `../..`.

A `build.sh` that works in both modes (in skill mode, put `LIB=<path setup.sh printed>` at the top):

```sh
#!/bin/sh
set -e
HERE=$(cd "$(dirname "$0")" && pwd)
LIB=${LIB:-$(cd "$HERE/../.." && pwd)}          # clone mode: <repo>/films/<name>/
export LIB
[ -f "$LIB/core/render/video.mjs" ] || { echo "set LIB to the library folder"; exit 1; }
cd "$LIB"
node core/render/events.mjs "$HERE"
node core/render/video.mjs "$HERE" --fps 24 --out "$HERE/out/video.mp4"
"$LIB/.venv/bin/python" "$HERE/mix.py"                               # score, foley, voice → out/mix.wav
sh core/render/mux.sh "$HERE/out/video.mp4" "$HERE/out/mix.wav" "$HERE/<name>.mp4" 24
```

Rules that keep it reliable:

- **Deterministic.** No `Date.now()`, no `Math.random()` without a seed (`core/lib.js` has `mulberry` and `hash`), no state carried from the previous frame. Any frame can be rendered alone, in any order, by any worker.
- **Canvas 2D** for most 2D styles; **three.js** for 3D (§9); **WebGL2** shaders for post passes (film damage, CRT, ink redraw).
- **Animate on twos where the style wants it** (12 fps stepping for stop-motion, pixel or cel looks), but keep the camera and light smooth every frame. A stepped camera reads as lag.
- **One world → screen function.** Any effect that follows a subject (iris, zoom, spotlight) goes through it. Never hand-type screen coordinates.
- **Draw for the frame you render.** The default is 1920×1080; for another size pass `--size WxH` (e.g. `1080x1920`) to every render tool and lay the page out from `innerWidth` × `innerHeight`.

Capture (`core/render/`):

```sh
node core/render/still.mjs <demo> 1.5 12 --range 0:50:2   # review stills; exits on page errors
node core/render/video.mjs <demo> --fps 24 --workers 3     # all frames → <demo>/out/video.mp4
node core/render/events.mjs <demo>                         # export DUR + EV → events.json
node core/render/readcheck.mjs <demo>                      # every on-screen text stays long enough to read
```

To render a second version with other content, pass it to the page and give it its own output: `--q 'content=content_alt.json' --out …/alt.mp4` (the same for `events.mjs`).

Capture is fast because of **JPEG screenshots**, **one browser per worker** and **grain added in ffmpeg**: grain drawn in the page makes every frame incompressible and slow.

## 3. One timeline drives everything

Keep sections, tempo, beats and hit points in one file (`timeline.js`). Export it to JSON and let the score, the mixer, the subtitles and the checks read the same numbers:

```js
export const SECS = [{ id: 'chase', t: 12.0, bpm: 144, beats: 12 }, ...];
export const HIT  = { pratfall: ['chase', 6], ... };   // section + beat
```

A small script (`cuecheck.py`, in `styles/<slug>/demo/tools/` of several demos) compares every visual hit with the music cue it should land on. Aim for 0 ms.

## 4. Voice

- **TTS is only the default.** If the user brings a recording or names a voice, use that. Otherwise:
  - **English**: [Kokoro](https://github.com/thewh1teagle/kokoro-onnx), local, many voices (an unknown `voice` name makes `tts.py` print the full list; `af_` / `am_` are American, `bf_` / `bm_` British; cast the narrator for this film, not the demo's). `core/tts/tts.py lines.json out/` writes one WAV per line and a durations file. Its Chinese voices (`"lang": "cmn"`) work offline but sound plain.
  - **Chinese**: `core/tts/tts_zh.py lines.json out/` uses [edge-tts](https://github.com/rany2/edge-tts) with Microsoft's neural voices (`zh-CN-XiaoxiaoNeural`, `zh-CN-YunxiNeural`…), with the same outputs as `tts.py`, a rate per line and the silence trimmed. **It needs a network connection.**
- Spell numbers out in the TTS text and write them as digits in the subtitles.
- **Check every line**: `core/tts/asr_check.py` transcribes each WAV with faster-whisper and compares it with the script (`--lang zh`: numbers by value, so 十九 matches 19, and the rest character by character); re-generate until it exits 0. A misheard character in a short Chinese line is normal: listen, and if it is right, put what the model heard in the line's `asr` field. It also writes word timestamps for placing lines and subtitles.
- **Before mixing**: TTS has a high peak-to-average ratio. Compress the voice first, then balance by RMS: voice about 10 dB above the music.

## 5. Music

Write an original score from the cue map, in the instruments of the style's sound palette; no generic piano and strings.

- **Samples**: `core/audio/sampler.py` plays real instruments from free libraries (VSCO 2 CE, VCSL, FreePats, Karoryfer, Salamander Grand Piano; list and licences in `core/audio/INSTRUMENTS.md`). Write the score as events `(time, instrument, pitch, duration, velocity, pan)`. Long notes are extended seamlessly, and round-robins avoid the machine-gun effect.
- **Plucked and folk strings** (guqin, pipa, shamisen, banjo…): `core/audio/pluck.py`, physical modelling (Karplus–Strong) with bends and vibrato.
- **Synthesis** with numpy for chip tunes, drones and effects; no download needed.
- **Balance the low end.** Synthetic scores get bass-heavy quickly. Measure energy per band after mixing; keep 20–120 Hz around −3 dB relative to the rest, skip pad notes below MIDI 48, and give the bass some 2nd and 3rd harmonics so it speaks on small speakers.

## 6. Sound effects and mix

- `core/audio/sfx.py` synthesises foley procedurally (click, whoosh, thump, ding, paper, noise beds…) with filters, envelopes and `add(buffer, sound, at, gain, pan)`. Drive it from `window.EV`, so every sound sits exactly on its frame.
- **Master**: `sh core/render/mux.sh video.mp4 mix.wav out.mp4 24 [grain]` muxes, runs a two-pass loudnorm to −14 LUFS with a true-peak limit, adds grain in ffmpeg and prints the measured loudness; it exits non-zero on any failure. On light backgrounds use less grain; for pixel and vector styles, none.
- Films with grain baked into the picture compress badly; re-encode with `-tune grain` and a higher CRF.

## 7. Subtitles

- Export `.srt` with `core/render/srt.py cues.json out.srt` (cues = `[{t0, t1, text}]`), and burn styled captions into the page itself: the caption design is part of the style.
- Timing rules are in DIRECTOR.md §7.

## 8. Review loop

1. Contact sheets: a frame every 1–2 s with `still.mjs --range`, tiled with `core/render/sheet.py`. At least two full passes.
2. Frame strips at 0.2 s for every key action: hand-overs, falls, hits.
3. On the final file: `ffmpeg -af ebur128` (loudness), `blackdetect` (blank frames), whisper again on the final mix if it has voice.
4. Watch it once, at full speed, with sound.

## 9. 3D notes

- three.js r170 rendered headless through WebGL2 on the GPU; physical depth of field and GTAO from `core/three/post.js`, rendered at 2× and downsampled.
- Lighting: soft area lights plus a Poly Haven HDRI at low intensity reads more "real" than bright ambient light.
- `core/three/post.js` is written for a perspective camera. For an orthographic camera swap `perspectiveDepthToViewZ` for `orthographicDepthToViewZ` in its depth pass, or the depth of field silently breaks.

## 10. Characters drawn in code

- A 2.5D rig (torso, head, limbs solved per frame) is enough for pantomime.
- Order the shoulder rotation as abduction, then flexion; the reverse order crosses raised arms into an X.
- Let the shoulder girdle rise and move forward as the arm lifts, and don't outline the part of the arm that overlaps the torso: that line is what makes a joint look like a puppet seam.

## 11. Assets, credits and fonts

Only CC0, CC BY or OFL material, each listed in the film's `CREDITS` with its source and licence; `core/audio/sampler.py credits(names)` writes the lines for the instruments you used. Public-domain works count as CC0; "no known restrictions" does not. Data or images under other open licences (ODbL, CC BY-SA, open-hardware licences) only after you have named the licence and its terms (attribution, share-alike) to the user and they agree. The user's own material is fine as it is. Images from an image generator (the ✦ styles) are listed too: which tool and model made them, that they are generated, and where the prompts are kept; drawings the user made are credited to them.

A film that states facts (a style built from real data or scans: its `STYLE.md` says so) keeps a `FACTS.md` in the project folder: each claim with its source URL and the quoted wording, or the measurement that produced it.

Fonts: Google Fonts (OFL), self-hosted in the project. The typefaces a `STYLE.md` names are not in the library; download them (`https://github.com/google/fonts/tree/main/ofl/<family>`) into the project's `fonts/`. `core/fonts/` holds a few Latin display fonts and a Chinese display font with only about 200 glyphs, not enough for running Chinese text. For Chinese, subset a CJK font to the characters you use: the Google Fonts CSS API with `&text=` returns just those glyphs (`https://fonts.googleapis.com/css2?family=Noto+Sans+SC:wght@700&text=<URL-encoded characters>`). Download the font file it points to into the project's `fonts/` and load it with `@font-face`; don't link Google Fonts at render time.

## 12. Where to look in our demos

| If you need… | Look at |
|---|---|
| 2D character animation and lip sync | `styles/scifi-toon/`, `styles/cel-anime-80s/` |
| a timeline-driven score with cue checking | `styles/microgame/`, `styles/silent-film/` |
| an image-to-ink redraw and film-damage post pass | `styles/silent-film/demo/engine/` |
| a brush or stroke engine | `styles/watercolor/`, `styles/ink-wash/`, `styles/impasto/` |
| 3D with depth of field and real materials | `styles/brick-toy/`, `styles/paper-popup/` |
| a CRT or VHS look | `core/post/crt.js`, `styles/ascii-crt/`, `styles/backrooms/` |

Each style's `DEMO.md` says how its demo was built. Open it and the code only after your treatment exists, to learn a technique, never to rebuild our film (an Edit & Documentary style's material tools in `demo/tools/` come first: AGENTS.md, "Treatment first"). In skill mode, get the source with `sh <skill folder>/scripts/setup.sh demo <slug>`. Copied demo code often reaches the library with `../..`: replace that with `$LIB` or absolute URLs.


## 原作者媒介陷阱与经验摘录

## 9. Pitfalls of the medium

- **Process diagram, not a story.** A station-by-station walk is a flowchart. Give it a hook (a reversal, a deadline, a question) and a payoff picture; let each station say one thing.
- **Text creep.** Plaques, tags, leaders and subtitles add up fast; keep to about seven pieces per frame and let colours carry meaning.
- **Hairlines and blobs at distance.** Without camera-dependent line weight and level of detail, the pull-back turns into a grey mesh of strokes and unreadable labels.
- **The silhouette disappears** when rooms fill the cut edge to edge: keep at least 30 px of dark ground between rooms and the outer wall.
- **Spot colours that vanish on the ground.** Test each against the dark ground and against the walls before committing.
- **Bodies that look like barrels.** When a figure has to hold a lot of rooms, its torso grows and its head shrinks; cross-fade to a schematic figure with human proportions for the full-body shot rather than inflating the cut-away.
- **Feet.** Procedural legs that swing on sine curves float, sink and slide; solve them against the ground line, and hold the final frame on a readable phase (one leg reaching, not crossed).
- **Metaphors that lie.** Every simplification the metaphor makes (one input → one output, a valve where there is really a gradient) goes into FACTS.md; the voice should not claim what the drawing only implies.
- **Leaders everywhere.** One leader per frame at most; everything else is a plaque on its object.


