from pathlib import Path
import base64, concurrent.futures, html, io, json, math, time, urllib.error, urllib.request
from PIL import Image, ImageDraw, ImageFont, ImageOps

ROOT=Path(__file__).resolve().parent.parent
DATA=json.loads((ROOT/'sources/styles.json').read_text(encoding='utf-8'))
ITEMS=DATA['primary']+DATA['secondary']
ITEMS.sort(key=lambda x:int(x['key']))
PREVIOUS=json.loads((ROOT/'sources/manifest.json').read_text(encoding='utf-8'))
PREVIOUS_IMAGES={(x['source'],x['slug']):x['imageUrl'] for x in PREVIOUS}
IMG=ROOT/'images'
IMG.mkdir(exist_ok=True)

def acquire(pair):
    i,item=pair
    item['key']=item.get('key',f'{i+1:02d}')
    p=IMG/(item['source']+'-'+item['slug']+'.jpg')
    if not p.exists() or PREVIOUS_IMAGES.get((item['source'],item['slug']))!=item['imageUrl']:
        req=urllib.request.Request(item['imageUrl'],headers={'User-Agent':'Opus-style-reference/1.0'})
        for attempt in range(3):
            try:
                with urllib.request.urlopen(req,timeout=40) as response:raw=response.read()
                break
            except urllib.error.HTTPError as error:
                if error.code not in (408,429,500,502,503,504) or attempt==2:raise
            except (urllib.error.URLError,TimeoutError,ConnectionError):
                if attempt==2:raise
            time.sleep(2**attempt)
        image=Image.open(io.BytesIO(raw)).convert('RGB')
        temp=p.with_suffix('.jpg.tmp')
        image.save(temp,format='JPEG',quality=93)
        temp.replace(p)
    with Image.open(p) as im:
        im.verify()
    item['localImage']='images/'+p.name
    item['embeddedImage']='data:image/jpeg;base64,'+base64.b64encode(p.read_bytes()).decode()
    return item

with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
    ITEMS=list(pool.map(acquire,enumerate(ITEMS)))
assert len(ITEMS)==len({x['key'] for x in ITEMS})
LIBRARY=json.loads((ROOT/'prompts.json').read_text(encoding='utf-8')) if (ROOT/'prompts.json').exists() else {'styles':[]}
PROMPTS={x['key']:x for x in LIBRARY['styles']}
FAVORITES=[('lemo','watercolor'),('lemo','ink-wash'),('lemo','crayon-book'),('handmade','embroidery'),('lemo','ukiyoe'),('lemo','paper-lantern'),('lemo','cel-anime-80s'),('lemo','hd-2d'),('lemo','lowpoly-island'),('lemo','swiss-motion'),('handmade','marbling'),('lemo','glass-product')]
FAVORITE_KEYS=[x['key'] for x in ITEMS if (x['source'],x['slug']) in FAVORITES]

PROJECTS=[
 ('lemo-opuscar',f'{len(DATA["primary"])} 种影片风格，逐项有成片和 STYLE.md。','https://github.com/lemomo-ai/lemo-opuscar','原作者视频图鉴','https://lemomo-ai.github.io/lemo-opuscar/'),
 ('opus-5.5-music-video-art-styles','18 个手作材质引擎，同一首 37.5 秒短诗的风格比较。','https://github.com/cyborggirl963/opus-5.5-music-video-art-styles','18 种原图与说明','https://github.com/cyborggirl963/opus-5.5-music-video-art-styles#the-styles'),
 ('awesome-opus5-5-videos','热门案例与作者提示词，适合继续看动态图形、科普和三维演示。','https://github.com/yihui-dev/awesome-opus5-5-videos','案例浏览','https://skillry.dev/ai-videos/opus-5-5'),
 ('opus-video-prompts','18 份完整提示词、54 个公开案例；原 PDF 将两者数量混用了。','https://github.com/joeseesun/opus-video-prompts','中文案例目录','https://github.com/joeseesun/opus-video-prompts#-案例总览'),
 ('PDoomVideo','水彩笔刷与 Clawd 角色的完整 MV 工程。','https://github.com/JohnHeibel/PDoomVideo','观看原 MV','https://youtu.be/8j-hR4fJywU'),
 ('ClaudeAnimationBase','Clawd 角色、表情、动作及手绘动画模板。','https://github.com/JohnHeibel/ClaudeAnimationBase','角色表情示例','https://github.com/JohnHeibel/ClaudeAnimationBase/blob/main/docs/emotions.webp'),
 ('pdoom-video','黑白橙配色，精细线稿、动态图形、三维场景与逐字歌词同步。','https://github.com/mexicat/pdoom-video','观看 4K 案例','https://www.youtube.com/watch?v=5EoO5413dBY'),
]

def esc(s): return html.escape(str(s),quote=True)
def link(url,text):return f'<a href="{esc(url)}" target="_blank" rel="noopener noreferrer">{esc(text)} ↗</a>'

cards=[]
for x in ITEMS:
    n=esc(x['cn']); k=x['key']
    kind='短片案例' if x['source']=='lemo' else '同诗示范原图'
    src='Lemo · '+x['cat'] if x['source']=='lemo' else '手作 MV · 18 种'
    button=f'<button class="watch" data-video="{k}">▶ 播放案例</button>' if x.get('videoUrl') else ''
    button+=f'<button class="prompt" data-prompt="{k}">完整提示词 · 注意事项</button>' if k in PROMPTS else ''
    button+=f'<button class="handoff" data-handoff="{k}" aria-label="把{n}交给其他 AI">交给其他 AI</button>' if k in PROMPTS else ''
    caption=esc(x['film'])
    credit=(' · '+esc(x['by']['name'])) if x.get('by') else ''
    cards.append(f'''<article class="card" data-key="{k}" data-source="{x['source']}" data-cat="{esc(x['cat'])}" data-search="{esc(' '.join([x['cn'],x['en'],x['cat'],x['line_cn'],x['film']])).lower()}">
      <button class="picture" data-image="{k}" aria-label="放大 {n}"><img src="{x['embeddedImage']}" alt="{n}，原作者案例画面" width="640" height="360" loading="lazy"><span>放大原图 ↗</span></button>
      <div class="body"><div class="meta">{k} / {esc(src)}</div><h2>{n}</h2><p class="en">{esc(x['en'])}</p><p class="desc">{esc(x['line_cn'])}</p>
      <p class="film">{kind} · {caption} · {x['dur']:g}s{credit}</p><div class="actions">{button}{link(x['styleUrl'],'提示词 / 风格说明' if x['source']=='lemo' else '原图 / 引擎说明')}</div></div></article>''')

projects=''.join(f'<li><b>{esc(a)}</b><p>{esc(b)}</p>{link(c,"GitHub 项目")} · {link(e,d)}</li>' for a,b,c,d,e in PROJECTS)
categories=list(dict.fromkeys(x['cat'] for x in ITEMS))
catopts=''.join(f'<option>{esc(c)}</option>' for c in categories)
modalData={x['key']:{**{k:x[k] for k in ['cn','en','styleUrl','videoUrl'] if k in x},**{k:PROMPTS[x['key']][k] for k in ['id','promptFile','promptText','notes','promptType','sourceCommit','originalPitfalls'] if x['key'] in PROMPTS}} for x in ITEMS}
doc='''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Opus 视频风格图册 · 77 个案例</title>
<style>
:root{color-scheme:light;--ink:#192721;--muted:#617169;--paper:#f3f2ec;--accent:#23694a}*{box-sizing:border-box}body{margin:0;background:var(--paper);color:var(--ink);font:15px/1.6 "Microsoft YaHei",system-ui,sans-serif}a{color:var(--accent);text-underline-offset:4px}button,input,select{font:inherit}button,a,input,select{touch-action:manipulation}button{cursor:pointer}button:focus-visible,a:focus-visible,input:focus-visible,select:focus-visible{outline:3px solid #e89438;outline-offset:3px}header,main,footer{max-width:1480px;margin:auto;padding:0 32px}header{padding-top:44px;padding-bottom:24px}.kicker{font-size:12px;font-weight:700;letter-spacing:2px;color:var(--accent)}h1{font-size:clamp(30px,4vw,54px);line-height:1.25;letter-spacing:-1px;margin:12px 0}header p{max-width:960px;color:var(--muted);margin:12px 0}.stats{display:flex;gap:10px;flex-wrap:wrap}.stats span{padding:8px 14px;border:1px solid #ced8cd;border-radius:30px;background:#fff8}.stats b{color:var(--accent)}.filters{position:sticky;top:0;z-index:10;background:#f3f2ecf5;backdrop-filter:blur(12px);padding:16px 0;border-block:1px solid #d8ddd4;display:flex;gap:12px;flex-wrap:wrap;align-items:center}.filters input{min-width:220px;flex:1}input,select{background:white;border:1px solid #b8c4b8;border-radius:9px;padding:11px 12px;color:var(--ink)}.tabs{display:flex;gap:7px}.tabs button{border:1px solid #b8c4b8;border-radius:8px;padding:11px 14px;background:transparent;color:var(--ink)}.tabs button.active{background:var(--accent);border-color:var(--accent);color:white}.result{font-size:13px;color:var(--muted);padding:14px 0}.grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:22px}.card{min-width:0;border:1px solid #d4dbd0;background:white;border-radius:12px;overflow:hidden;display:flex;flex-direction:column}.card[hidden]{display:none}.picture{padding:0;border:0;position:relative;background:#e2e5dc;width:100%;aspect-ratio:16/9;overflow:hidden}.picture img{display:block;width:100%;height:100%;object-fit:contain}.picture span{position:absolute;bottom:10px;right:10px;background:#111b;padding:3px 9px;color:white;border-radius:5px;font-size:12px}.body{padding:19px;display:flex;flex:1;flex-direction:column}.meta{font-size:11px;color:var(--accent);letter-spacing:.5px}h2{font-size:22px;margin:6px 0 0;line-height:1.4}.en{font-size:12px;color:var(--muted);margin:2px 0 12px}.desc{font-size:14px;margin:0 0 15px;min-height:45px}.film{font-size:11px;color:var(--muted);margin:auto 0 15px}.actions{display:flex;align-items:center;gap:12px;flex-wrap:wrap}.actions a{font-size:12px}.watch{border:0;border-radius:6px;padding:8px 11px;background:var(--accent);color:white}.empty{padding:50px;text-align:center}.sources{margin:60px 0 30px;border-top:1px solid #ccd4c9;padding-top:25px}.sources h2{font-size:26px}.sources ul{list-style:none;padding:0;display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:20px}.sources li{padding:20px;background:#fff8;border:1px solid #d4dbd0;border-radius:10px;overflow-wrap:anywhere}.sources p{font-size:13px;color:var(--muted);margin:6px 0}.sources a{font-size:12px}.bonus{padding:20px;border:1px solid #c8d3c2;border-radius:12px;margin:30px 0}.bonus p{color:var(--muted);margin:7px 0}footer{padding-top:20px;padding-bottom:40px;color:var(--muted);font-size:12px}dialog{border:0;border-radius:12px;background:#fff;color:var(--ink);padding:20px;max-width:min(1100px,95vw);max-height:94vh;width:100%;overflow:auto}dialog::backdrop{background:#091710cc}.dialog-head{display:flex;justify-content:space-between;gap:20px;align-items:center}.dialog-head h2{margin:0;font-size:23px}#close{border:1px solid #bcc8bb;background:white;border-radius:6px;padding:6px 12px}#media{margin-top:15px;text-align:center}#media img,#media video{max-width:100%;max-height:70vh;display:block;margin:auto;background:#111}#dialoglinks{margin:15px 0 0;display:flex;gap:15px;flex-wrap:wrap;font-size:13px}@media(min-width:1700px){.grid{grid-template-columns:repeat(4,minmax(0,1fr))}}@media(max-width:1050px){.grid{grid-template-columns:repeat(2,minmax(0,1fr))}.filters{position:static}}@media(max-width:640px){header,main,footer{padding-left:16px;padding-right:16px}header{padding-top:28px}.grid,.sources ul{grid-template-columns:1fr}.tabs{width:100%}.tabs button{flex:1;padding:10px 5px}.filters input,.filters select{width:100%;min-width:0}.desc{min-height:0}}
</style></head><body><header><div class="kicker">VISUAL REFERENCE LIBRARY · 2026.10.27</div><h1>先看画面，再选风格。</h1><p>从你文件夹中的《Opus 5.5.pdf》找到 7 个 GitHub 项目，逐项整理两个风格库的 <b>77 个风格条目</b>。图片均来自原项目，不同库中的相近媒介保留各自案例。</p><div class="stats"><span><b>59</b> 种影片风格 · 有成片</span><span><b>18</b> 种手作 MV · 有原图</span><span><b>77</b> 张图片 · 可离线看</span></div><p>文中 Lemo 的 43 种现已更新为 59 种。点图片可放大，点“播放案例”联网看短片；18 种手作风格使用同一首短诗示范，便于比较。</p></header><main>
<div class="filters"><div class="tabs" aria-label="项目筛选"><button data-source="all" class="active" aria-pressed="true">全部 77</button><button data-source="lemo" aria-pressed="false">影片 59</button><button data-source="handmade" aria-pressed="false">手作 MV 18</button></div><input id="search" type="search" aria-label="搜索风格" placeholder="搜索：水墨、刺绣、像素、科技…"><select id="category" aria-label="选择分类"><option value="all">所有分类</option>__CATEGORIES__</select></div><div class="result" id="result" aria-live="polite">显示 77 / 77 个风格</div><section class="grid" aria-label="风格案例">__CARDS__</section><p id="empty" class="empty" hidden>没有找到匹配风格，试试其他关键词。</p>
<section class="sources" id="sources"><h2>PDF 中提到的 7 个项目</h2><p>前两个是本图册逐项展示的风格库，其余项目提供更多成片、提示词和完整工程。</p><ul>__PROJECTS__</ul></section><section class="bonus"><b>额外可看：OPUSCAR 98</b><p>一个 Clawd 走过 98 部奥斯卡最佳影片，整片 6 分 31 秒；另有按电影逐项展示的画风页面。这些是电影主题变体，未并入上面的 77 个风格库条目。</p><a href="https://lemomo-ai.github.io/lemo-opuscar/opuscar98/" target="_blank" rel="noopener">观看完整短片 ↗</a> · <a href="https://lemomo-ai.github.io/lemo-opuscar/opuscar98/#styles" target="_blank" rel="noopener">看 98 部电影的风格帧 ↗</a></section></main><footer>核对日期：2026-10-27（中国时间）。原图与案例归各项目作者；中文手作风格名和简述为本次整理。图册图片已内嵌，可离线看；视频与外部说明需联网。视频来源为作者发布链接，未逐段审看全部成片。</footer>
<dialog id="viewer" aria-labelledby="dialogtitle"><div class="dialog-head"><h2 id="dialogtitle"></h2><button id="close">关闭 ×</button></div><div id="media"></div><div id="dialoglinks"></div></dialog>
<script>
const data=__DATA__;const cards=[...document.querySelectorAll('.card')];let activeSource='all';const search=document.getElementById('search'),category=document.getElementById('category');
function filter(){const q=search.value.trim().toLowerCase();let n=0;for(const card of cards){const visible=(activeSource==='all'||card.dataset.source===activeSource)&&(category.value==='all'||card.dataset.cat===category.value)&&(!q||card.dataset.search.includes(q));card.hidden=!visible;if(visible)n++;}document.getElementById('result').textContent=`显示 ${n} / 77 个风格`;document.getElementById('empty').hidden=n!==0;}
document.querySelectorAll('.tabs button').forEach(b=>b.addEventListener('click',()=>{activeSource=b.dataset.source;category.value='all';document.querySelectorAll('.tabs button').forEach(x=>{const active=x===b;x.classList.toggle('active',active);x.setAttribute('aria-pressed',String(active));});filter();}));search.addEventListener('input',filter);category.addEventListener('change',filter);
const viewer=document.getElementById('viewer'),media=document.getElementById('media'),links=document.getElementById('dialoglinks');function addLink(href,text){const a=document.createElement('a');a.href=href;a.target='_blank';a.rel='noopener noreferrer';a.textContent=text;links.append(a);}function openItem(key,video){const d=data[key];document.getElementById('dialogtitle').textContent=key+' · '+d.cn+' / '+d.en;media.replaceChildren();links.replaceChildren();if(video&&d.videoUrl){const v=document.createElement('video');v.controls=true;v.playsInline=true;v.preload='metadata';v.src=d.videoUrl;v.poster=d.embeddedImage;media.append(v);addLink(d.videoUrl,'直接打开原视频 ↗');}else{const img=document.createElement('img');img.src=d.embeddedImage;img.alt=d.cn;media.append(img);}addLink(d.styleUrl,'原作者风格说明 ↗');viewer.showModal();}document.querySelector('.grid').addEventListener('click',e=>{const b=e.target.closest('[data-image],[data-video]');if(b)openItem(b.dataset.image||b.dataset.video,!!b.dataset.video);});document.getElementById('close').addEventListener('click',()=>viewer.close());viewer.addEventListener('close',()=>media.replaceChildren());viewer.addEventListener('click',e=>{if(e.target===viewer){const r=viewer.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)viewer.close();}});
</script></body></html>'''
doc=doc.replace('__CATEGORIES__',catopts).replace('__CARDS__','\n'.join(cards)).replace('__PROJECTS__',projects).replace('__DATA__',json.dumps(modalData,ensure_ascii=False).replace('</','<\\/'))
doc=doc.replace('d.embeddedImage', 'document.querySelector(`[data-key="${key}"] img`).src')
extra_css='''.prompt,.copy-prompt,.save-prompt{border:1px solid #a6b9a7;border-radius:6px;padding:8px 10px;background:#eef4ed;color:#1c573c}.prompt{font-size:12px}#media.prompt-view{text-align:left}.prompt-source{font-size:12px;color:#617169;overflow-wrap:anywhere}.notes{background:#f0f4ed;border-radius:8px;padding:14px 20px}.notes ul{padding-left:20px}.prompt-text{display:block;width:100%;height:42vh;resize:vertical;padding:14px;border:1px solid #b8c4b8;border-radius:8px;background:#fafbf7;color:#192721;font:13px/1.65 Consolas,'Microsoft YaHei',monospace}.prompt-tools{display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin:14px 0}details pre{font-size:12px;white-space:pre-wrap;overflow-wrap:anywhere}.reading-nav{padding:14px;background:#e5eee2;border-radius:9px;font-size:13px;display:flex;gap:16px;flex-wrap:wrap}'''
doc=doc.replace('</style>',extra_css+'</style>')
doc=doc.replace('</header>', '<nav class="reading-nav" aria-label="资料入口"><button class="handoff" id="ai-help">给其他 AI 用 · 复制指令</button><a href="AI使用说明.md">AI 使用说明</a><a href="完整提示词总册.md">完整提示词索引</a><a href="使用指南.md">使用指南</a><a href="llms.txt">AI 文本入口</a><a href="分享与外部访问.md">分享与外部访问</a><a href="ATTRIBUTION.md">作者与素材署名</a></nav></header>')
doc=doc.replace('<button data-source="all"', '<button data-source="picks" aria-pressed="false">精选 12</button><button data-source="all"',1)
doc=doc.replace("(activeSource==='all'||card.dataset.source===activeSource)","(activeSource==='all'||(activeSource==='picks'?favoriteKeys.includes(card.dataset.key):card.dataset.source===activeSource))")
doc=doc.replace('const data=', 'const favoriteKeys='+json.dumps(FAVORITE_KEYS)+';const data=',1)
prompt_js=r'''function openPrompt(key){
const d=data[key];media.classList.add('prompt-view');media.replaceChildren();links.replaceChildren();document.getElementById('dialogtitle').textContent=key+' · '+d.cn+' · 完整提示词';
const provenance=document.createElement('p');provenance.className='prompt-source';provenance.textContent=d.promptType+' | 固定版本 '+d.sourceCommit.slice(0,12);media.append(provenance);
const box=document.createElement('section');box.className='notes';const title=document.createElement('b');title.textContent='使用前先看';box.append(title);const ul=document.createElement('ul');for(const text of d.notes){const li=document.createElement('li');li.textContent=text;ul.append(li);}box.append(ul);media.append(box);
const tools=document.createElement('div');tools.className='prompt-tools';const copy=document.createElement('button');copy.className='copy-prompt';copy.textContent='复制完整提示词';const save=document.createElement('button');save.className='save-prompt';save.textContent='下载提示词 TXT';const status=document.createElement('span');status.setAttribute('role','status');tools.append(copy,save,status);media.append(tools);
const tip=document.createElement('p');tip.textContent='先填写需求区。复制内容已包含完整风格原文与公共制作规范，交给能执行代码的 AI；文件较长，建议一次只选一个风格。';tip.className='prompt-source';media.append(tip);
const area=document.createElement('textarea');area.className='prompt-text';area.readOnly=true;area.setAttribute('aria-label','完整可复制提示词');area.value=d.promptText;media.append(area);
copy.onclick=async()=>{try{await navigator.clipboard.writeText(d.promptText);status.textContent='已复制完整提示词';}catch{area.focus();area.select();try{status.textContent=document.execCommand('copy')?'已复制完整提示词':'已选中，请按 Ctrl+C 复制';}catch{status.textContent='已选中，请按 Ctrl+C 复制';}}};
save.onclick=()=>{const url=URL.createObjectURL(new Blob([d.promptText],{type:'text/plain;charset=utf-8'}));const a=document.createElement('a');a.href=url;a.download=key+'-'+d.cn+'-完整提示词.txt';a.click();setTimeout(()=>URL.revokeObjectURL(url),1500);};
if(d.originalPitfalls){const details=document.createElement('details');const summary=document.createElement('summary');summary.textContent='原作者媒介陷阱与经验（原文）';const pre=document.createElement('pre');pre.textContent=d.originalPitfalls;details.append(summary,pre);media.append(details);}
addLink(d.styleUrl,'原作者风格说明 ↗');viewer.showModal();
}
document.querySelector('.grid').addEventListener('click',e=>{const b=e.target.closest('[data-prompt]');if(b)openPrompt(b.dataset.prompt);});viewer.addEventListener('close',()=>media.classList.remove('prompt-view'));
'''
doc=doc.replace('</script>',prompt_js+'</script>')
doc=doc.replace('</script>',(ROOT/'sources/gallery_ai.js').read_text(encoding='utf-8')+'</script>')
doc=doc.replace('</style>','.handoff{border:1px solid #a6b9a7;border-radius:6px;padding:8px 10px;background:#fff;color:#1c573c;font-size:12px}.reading-nav{align-items:center}.tabs{flex-wrap:wrap}.ai-intro{text-align:left;background:#f0f4ed;padding:14px 18px;border-radius:9px}.ai-task{text-align:left;margin:22px 0}.ai-task h3{font-size:18px;margin-bottom:5px}.ai-task textarea{height:185px}.ai-task p{font-size:13px;color:var(--muted)}.ai-status{font-size:13px;color:var(--accent)}@media(max-width:640px){.tabs button{flex:1 1 42%}}'+'</style>')
doc=doc.replace('原图与案例归各项目作者；', '图册原图：LemoLab / Miranda Dixon-Luinenburg，已缩放与重新编排；Lemo 示例画面为 CC BY 4.0，代码和文档为 MIT。完整许可及第三方素材、三项示例语音例外见 ATTRIBUTION.md。原图与案例归各项目作者；')
doc=doc.replace('2026-10-27',DATA['checkedAt']).replace('2026.10.27',DATA['checkedAt'].replace('-','.'))
doc=doc.replace('文中 Lemo 的 43 种现已更新为 59 种。',f'文中 Lemo 的 43 种现已更新为 {len(DATA["primary"])} 种。')
doc=doc.replace('显示 77 /',f'显示 {len(ITEMS)} /')
for old,new in [('77 个案例',f'{len(ITEMS)} 个案例'),('77 个风格',f'{len(ITEMS)} 个风格'),('全部 77',f'全部 {len(ITEMS)}'),('/ 77 个',f'/ {len(ITEMS)} 个'),('<b>77</b>',f'<b>{len(ITEMS)}</b>'),('<b>59</b>',f'<b>{len(DATA["primary"])}</b>'),('影片 59',f'影片 {len(DATA["primary"])}'),('<b>18</b>',f'<b>{len(DATA["secondary"])}</b>'),('手作 MV 18',f'手作 MV {len(DATA["secondary"])}')]:
    doc=doc.replace(old,new)
(ROOT/'图册.html').write_text(doc,encoding='utf-8')

FONT='C:/Windows/Fonts/msyh.ttc';BOLD='C:/Windows/Fonts/msyhbd.ttc'
def font(n,bold=False):return ImageFont.truetype(BOLD if bold else FONT,n)
def fit(draw,text,maxwidth,size,bold=False):
    while draw.textlength(text,font=font(size,bold))>maxwidth and size>12:size-=1
    return font(size,bold)
def sheet(items,name,title,sub,cols=4):
    gap=20;cw=400;ih=225;ch=294;pad=32;top=140;rows=math.ceil(len(items)/cols)
    im=Image.new('RGB',(pad*2+cols*cw+(cols-1)*gap,top+rows*ch+40),'#f3f2ec');d=ImageDraw.Draw(im)
    d.text((pad,28),title,font=font(34,True),fill='#192721');d.text((pad,82),sub,font=font(18),fill='#617169')
    for i,x in enumerate(items):
        px=pad+(i%cols)*(cw+gap);py=top+(i//cols)*ch
        with Image.open(ROOT/x['localImage']) as original:
            thumb=ImageOps.contain(original,(cw,ih),Image.Resampling.LANCZOS)
        d.rectangle((px,py,px+cw,py+ih),fill='#e4e5dc');im.paste(thumb,(px+(cw-thumb.width)//2,py+(ih-thumb.height)//2))
        label=x['key']+'  '+x['cn'];d.text((px,py+ih+8),label,font=fit(d,label,cw,21,True),fill='#192721')
        d.text((px,py+ih+38),x['en'],font=fit(d,x['en'],cw,15),fill='#617169')
    im.save(ROOT/name,quality=94)
subsets=[ITEMS[i:i+20] for i in range(0,len(ITEMS),20)]
for i,subset in enumerate(subsets,1):
    sheet(subset,f'总览-{i}.jpg',f'Opus 视频风格 · 全部案例 {i}/{len(subsets)}',f'编号 {subset[0]["key"]}–{subset[-1]["key"]}  |  原作者案例图  |  完整图册附视频与风格说明')
favoriteSlugs=FAVORITES
favorites=[next(x for x in ITEMS if (x['source'],x['slug'])==key) for key in favoriteSlugs]
sheet(favorites,'先看这12种.jpg','Opus 视频风格 · 先看这 12 种',f'从 {len(ITEMS)} 个案例中挑出的视觉预览  |  图片来自原作者项目  |  {DATA["checkedAt"]}',cols=3)

md=['# Opus 视频风格案例索引','', f'核对日期：{DATA["checkedAt"]}。共 {len(ITEMS)} 个风格条目，{len(DATA["primary"])} 个附原作者视频发布链接，{len(DATA["secondary"])} 个附同诗示范原图。','', '[打开完整交互图册](图册.html)','', '## 找到的 7 个项目','']
for a,b,c,d,e in PROJECTS:md += [f'- [{a}]({c})：{b} [{d}]({e})']
md += ['', f'## {len(ITEMS)} 个风格逐项索引','','| 编号 | 风格 | 分类 | 原图 | 案例 / 说明 |','|---|---|---|---|---|']
for x in ITEMS:
    case=f'[播放案例]({x["videoUrl"]}) · ' if x.get('videoUrl') else ''
    md.append(f'| {x["key"]} | {x["cn"]} / {x["en"]} | {x["cat"]} | [看图]({x["imageUrl"]}) | {case}[风格说明]({x["styleUrl"]}) |')
md += ['', '## 总览图','','![总览 1](总览-1.jpg)','','![总览 2](总览-2.jpg)','','![总览 3](总览-3.jpg)','','![总览 4](总览-4.jpg)','','## 额外参考','','[OPUSCAR 98：98 部最佳影片的风格画面](https://lemomo-ai.github.io/lemo-opuscar/opuscar98/#styles)','','素材归原项目作者所有。17 个风格库条目与引擎可能使用相近媒介，本索引按两个项目的原始条目计数，不代表 77 种互不重叠的艺术流派。']
md[-1]=f'素材归原项目作者所有。不同项目可能使用相近媒介，本索引按两个项目的原始条目计数，不代表 {len(ITEMS)} 种互不重叠的艺术流派。'
md[md.index('## 总览图')+1:md.index('## 额外参考')]=['']+[line for i in range(1,len(subsets)+1) for line in [f'![总览 {i}](总览-{i}.jpg)','']]
(ROOT/'案例索引.md').write_text('\n'.join(md),encoding='utf-8')
manifest=[{k:v for k,v in x.items() if k!='embeddedImage'} for x in ITEMS]
(ROOT/'sources/manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'styles':len(ITEMS),'images':len(list(IMG.glob('*.jpg'))),'video_links':sum(bool(x.get('videoUrl')) for x in ITEMS),'gallery':str(ROOT/'图册.html'),'gallery_bytes':(ROOT/'图册.html').stat().st_size},ensure_ascii=False))
