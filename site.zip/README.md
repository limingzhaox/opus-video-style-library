# Opus 视频风格资料库

117 个风格条目：99 个 Lemo 影片风格 + 18 个手作 MV 引擎。每项提供案例入口、来源、完整可用任务模板与注意事项；115 项附作者画面，2 项因第三方权利限制使用明确标注的查看入口图。不同库的相近媒介保留各自条目，不意味着 117 种互不重叠的艺术流派。

## 给人

公网入口：[在线图册](https://limingzhaox.github.io/opus-video-style-library/) · [公开仓库](https://github.com/limingzhaox/opus-video-style-library)。无需登录。

打开 [图册](index.html) 看图、观看作者视频、复制完整提示词或下载 TXT。

- [完整提示词索引](完整提示词总册.md)
- [使用指南](使用指南.md)
- [让其他 AI 找案例和使用模板](AI使用说明.md)
- [案例索引](案例索引.md)
- [分享与外部访问](分享与外部访问.md)
- [更新说明](更新说明.md)
- [作者与素材署名](ATTRIBUTION.md)

## 给 AI

从 [llms.txt](llms.txt) 开始。用 [styles.json](styles.json) 查找风格及单项 promptFile，再读取对应 prompts/*.md。[prompts.json](prompts.json) 包含所有完整文本，体积较大，建议按项读取。

给能联网的 AI 复制这一段即可开始：

> 请读取 https://limingzhaox.github.io/opus-video-style-library/llms.txt 和同站点的 styles.json，围绕我的主题推荐3个风格。逐项读取对应 promptFile 全文，展示案例图、有则附原视频链接，并说明选择理由和注意事项。先让我看案例；实际制作前再核对执行环境、素材与许可。无法读取时请明确说明，不假装已访问。

三种完整用法及可复制指令见 [AI使用说明](AI使用说明.md)：联网选风格、编程 AI 制作、无网附件读取。联网 AI 使用上面的公开入口；无网 AI 或需要读取你手中指定版本的 AI，请发送完整 ZIP 或单项文件附件，不能只发本机路径。

Lemo 作者 STYLE.md 保留全文；手作库的中文使用模板根据引擎说明整理，并非作者原始对话。提示词包含代码渲染工作流，需要相应执行工具；本资料库本身不是生成视频的服务。

## 来源与维护

两个主要来源：[LemoLab](https://github.com/lemomo-ai/lemo-opuscar)、[Miranda Dixon-Luinenburg](https://github.com/cyborggirl963/opus-5.5-music-video-art-styles)。

固定提交见 sources/upstreams.json，文件哈希见 sources/source-inventory.json。遵守上游许可与署名，见 ATTRIBUTION.md。已通过 GitHub Pages 公开发布，站点信息见 publication.json。

每周二 10:00（Asia/Shanghai）由本地 Codex 任务核对两主库与五个参考仓库；审查、构建、验证后更新公开包并部署。维护需要本机和 Codex 运行；已部署网站的访问不依赖本机开机。保留自己的修改在「我的提示词/」。新风格需要补中文要点并校验后再交付。详情见更新说明。


## 当前许可与案例限制

Lemo 当前文档及改编文档按 CC BY-NC 4.0 非商业共享；上游另允许为自己的影片（包括商业、客户影片）读取、复制、改编文档并随该片项目交付。超出该范围的商业产品、服务或文档再发行需另获授权。代码仍为 MIT，第三方素材仍各按原许可。完整规则见 [ATTRIBUTION.md](ATTRIBUTION.md)。

吉祥物录屏、流场风线两项保留作者案例链接，本地图片为查看入口，非作者风格样帧。前者涉及 Clawd 与第三方界面，后者涉及另行适用来源条款的 IBTrACS/CMA 数据。已保存 99 份案例 CREDITS、REUSE.toml 与对应许可文本，供逐项核对。
