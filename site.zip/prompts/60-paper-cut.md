# 60 · 背光剪纸 / Backlit paper cut

来源类型：根据作者引擎说明整理的使用模板；并非作者原始创作提示词  
原作者：Miranda Dixon-Luinenburg  
上游原文：https://github.com/cyborggirl963/opus-5.5-music-video-art-styles/tree/main/styles/paper-cut  
固定版本：801b3548c54765ecf932ce8b7f3cf4b29fb7a8bf  
抓取核对日期：2026-10-27  
本库改动：中文任务模板、中文摘要与编排；原文全文保留。

## 使用前先看

- 脚本与字体全部就绪后再建场景；大纸片使用完整可平铺纸纹，避免接缝。
- 待机遮罩需真正隐藏；每次修改检查控制台，避免着色器保留字或非法渐变值造成黑屏。

- 这是代码渲染工作流；聊天文本本身不会自动产生 MP4，需有可执行的项目环境。
- 先看预览再做长片；不要把示例素材的许可自动套到自己的歌曲、照片、字体和品牌上。
- 下方复制区包含全部风格与公共规范，不要求 AI 另外从本机隐藏路径读取文件。

## 完整复制区

你是一位能写代码、检查画面并渲染成片的动画导演。请用“背光剪纸 / Backlit paper cut”制作一个属于我的视频。

【我的需求；把花括号内容换成实际值】
主题与一句话故事：{{填写主题和结尾变化}}
用途与观众：{{例如面向普通观众的科普短片}}
内容依据或已有脚本：{{填写；没有则说明需要你写}}
音频、歌词、图片、数据、品牌素材路径：{{填写；没有写“无”}}
素材使用权限与需显示的署名：{{填写来源与许可；不清楚请列待确认项}}
目标时长：30 秒起步；MV 以实测歌曲时长为准
画幅与清晰度：默认横屏 16:9、1920×1080、24fps；竖屏须重新构图，不直接裁横屏
语言：简体中文；配音需求：{{有/无、声线与语速}}
必须出现的内容：{{填写}}
禁止出现的内容：{{填写}}
预算与速度：先做低成本验证，再渲染完整片
个人工程名：my-video（可改为英文短名）
确认方式：先给 3 张由真实渲染代码产出的样帧和 5–10 秒预览；我确认风格后再做完整成片

【本风格的核心实现】
用背光染色纸、层间深度、可见切边和分层视差表现剪纸影戏。
特别检查：
- 脚本与字体全部就绪后再建场景；大纸片使用完整可平铺纸纹，避免接缝。
- 待机遮罩需真正隐藏；每次修改检查控制台，避免着色器保留字或非法渐变值造成黑屏。

【工程与流程】
1. 在工作区单独克隆 https://github.com/cyborggirl963/opus-5.5-music-video-art-styles ，检出 801b3548c54765ecf932ce8b7f3cf4b29fb7a8bf。将 styles/paper-cut/ 复制到 projects/my-video/，保留引擎，按该风格 README 指定的文件替换示例场景。不要直接修改 styles/ 中的母版。
建立 Python 虚拟环境，阅读 requirements.txt 后安装渲染依赖；需分析音频时再安装 requirements-audio.txt。使用 Chrome 或项目支持的 Chromium。使用 python tools/serve.py 提供本地 HTTP，不用 file:// 打开渲染页面。
2. 先检查机器的 Python、Node/浏览器、FFmpeg、字体与 GPU 能力。缺少工具或访问权限时明确报告缺什么，不能只描述完成、伪造文件或把截图称为已渲染视频。
3. 把我的需求写成 PLAN.md 或 TREATMENT.md：一句话故事、分镜、逐镜秒数、镜头运动、文字位置、音乐与声音 cue、所需素材、预计成本。涉及事实和数据时写 FACTS.md；没有来源的数字不填。
4. 如果是 MV，先取得音频与实际演唱歌词，测量段落、停顿、节拍与词时间；不得沿用 37.5 秒示例诗的时间轴。未提供音乐时不要假装已经完成歌词对齐，可先制作无歌词短预览。
5. 先完成 3 张代表开头、关键变化、结尾的样帧，逐张检查；再渲染 5–10 秒低清短段，检查字幕、运动、音画同步与控制台。复杂慢风格先计时，再估算整片。
6. 随机效果固定种子；有历史累积的媒介按顺序渲染。并行前先比较随机抽帧与连续渲染是否一致。
7. 正式导出使用项目文档中的工具与参数，不臆造命令。交付可播放 MP4、720p 预览、源代码、素材清单与许可、字幕（有台词时）、复现说明；保留最终片长、帧率、音频响度与实际渲染耗时。
8. 实际打开并检查成片开头、中间、转场、结尾及全片联系表，确认没有空帧、字体回退、遮挡、裁字、爆音或无意复制的作者片尾签名。交代尚未完成的检查。

下面是完整风格参考与公共制作规范。它们是上游参考资料，不代表我的主题或逐字台词；我的具体需求优先。遇到 macOS/Linux 示例命令时按当前系统等价转换，不直接在 PowerShell 粘贴 bash 命令。相对资源路径以完整克隆的上游工程为准。


===== 完整风格原文：styles/paper-cut/README.md =====

# Backlit paper cut

Shadow theatre in layers. Every shape is cut from tinted paper and lit from behind, and each layer sits at its own
depth, so when the camera moves the layers slide past each other. What makes it read as paper rather than flat
colour: every piece carries the same fibrous paper texture, a thin bright rim where the light catches its upward
edges (with a soft halo soaking into the paper), a band of mist near its base where light leaks between the layers,
and a soft shadow on the layer behind. The sky is a WebGL shader: aurora curtains stepped into a few layers of tissue,
with stars pricked through as pinholes (or tinted motes in their place). Figures are jointed silhouette puppets on
two-bone IK. The land doesn't have to behave: it floats, curls overhead or stands on its edge, and the helpers keep
trees, houses and smoke square to whatever ground they stand on. A place can also grow: its land is baked bare and
what stands on it is a list of sites with the eras they stand in, so a later shot shows it built up, the new houses and
mills set down one by one on the beats. The lyrics sit in a dark paper band under the picture and light up word by word.

The demo is Christina Rossetti's "Who Has Seen the Wind?", so everything in it is about wind you only see in what it
moves: smoke bent over, washing snapping on a line, dry leaves trembling and tearing loose, a walker leaning into it,
another with the wind behind and long hair blown forward over a swinging rope bridge, a row of poplars bowing and
springing back while someone down the road digs it out of a drift, a shovelful on every beat. At the end the valley of
the opening shot has grown: new houses and windmills are set down on the beats, and a windmill hangs under the overhang.

![A village lane at night under an aurora: dry leaves stream off a young tree, washing blows flat on a line, a
walker leans into the wind with a lantern, and a hut on a floating rock strains at its tie ropes](img/hero.jpg)

| | |
|---|---|
| ![The title card under a valley wall that curls overhead, with houses hanging upside down from it](img/valley.jpg) | ![A walker holds the hand-rope of a swinging rope bridge between floating strips of land](img/strips.jpg) |
| ![A row of tall poplars bowing in a gust over a road where two figures brace, hand in hand, while further on someone digs the road out of a drift](img/grove.jpg) | ![The valley at the end, grown: new windmills turning on its floors among more houses](img/grown.jpg) |

Good for: landscapes, weather and night skies; small figures in big places; journeys; places that can't exist. Less
good for faces, close-ups of hands, or anything that has to be read as text (signs here are pictograms and runes).

This family has one look, so there's no style lab.

## Run the demo

```bash
python tools/serve.py
```

Then open `http://localhost:8000/styles/paper-cut/index.html`. It plays live in the browser (built and tested in
Chrome; the aurora needs WebGL2, and without it the sky falls back to a plain gradient). Space plays and pauses,
the bar scrubs. If the audio can't load, it plays on a silent clock. Add `#t12.5` to the address for a still of
12.5 seconds with the page furniture hidden (after editing a script, reload with a new query, e.g. `?r=2#t12.5`,
since changing only the hash doesn't reload).

Stills and a contact sheet, and an MP4 (both from the repository root):

```bash
python tools/still.py styles/paper-cut/index.html 2 14.3 28.3 0:37.5:2.5 --out renders/stills --sheet
python tools/render_mp4.py styles/paper-cut/index.html --fast          # 720p preview
python tools/render_mp4.py styles/paper-cut/index.html                 # 1080p and 720p
```

A `--fast` render of the whole 37.5 s demo (900 frames) took from about one to four minutes here, 66 to 240 ms a
frame depending on what else the machine (an Apple M-series Mac) was running; most of that is reading each frame back
and encoding it, not drawing it. The full-quality encode is slower.

## How it works

### Files, in load order

| File | Job |
|---|---|
| `../../examples/poem/lyrics_data.js` | The song: `window.SONG` (title, credit, audio, duration, bpm, lines with word times). |
| `core.js` | Frame size (a 1920x960 picture over a 120 px lyric band), the song's time range, easing, seeded random, value noise, fonts, and the paper: one tileable grey texture (`makePaper`) and `tint(col)` / `tintPattern(g,col,k,scale)` to make coloured paper from it. |
| `paper.js` | Baking cut pieces (`bakePiece`) and drawing them (`drawPiece`, `glowPiece`, `drawBent`, `bentPoint`); shape helpers (`ridgeShape`, `ridgePoints`, `taper`, `leaf`, `leafPath`, `polyFill`, `ellipseFill`). |
| `sky.js` | The aurora shader (`initSky`, `renderSky(uniforms)`), with white pinhole stars or tinted motes, and a 2D fallback. |
| `puppets.js` | Body plans (`BODY`), forward kinematics (`pfk`), drawing (`pdraw`), long hair that the wind blows (`phair`), two-bone IK (`ik2`), walk and sit cycles, and two things that walk with the figures: a pack beast and a sledge. |
| `shared.js` | Palette, tree generators (`genTree`, `genPoplar`), storm billows and lightning going up (`boltsUp`), snow, blowing snow, the wind (`wind`, `sway`, `swayTree`), integrated clocks, helpers for figures (`armTo`, `reachArm`, `mixLimbs`, `scarf`, and work on the beat: `strokePhase`, `keyPose`, `digPose`, `shovel`), and the sky's uniforms (`sky()`). |
| `props.js` | Pictograms and runes, buildings (longhouses, sheds, wells, shelters, a manor), ropes, snow and ice (with a path dug through a drift, `snowTrench`, and snow thrown off a shovel, `thrownSnow`), lanterns and fires, terrain, impossible ground, and things the wind moves: washing, pennants, a weathervane, a windmill, grass. |
| `engine.js` | Sets, shots and the camera, puppet compositing (`drawPuppet`, `standPuppet`), glow, bloom and vignette, the lyric band and title card, the player, and `window.__video`. |
| `eras.js` | A place that grows: sites with the eras they stand in (`SITE_KINDS`, `bakeSites`, `drawSites`), set down on the beats. |
| `set_valley.js`, `set_lane.js`, `set_strips.js`, `set_grove.js` | The demo's four sets (places). |
| `choreo.js` | The demo's figures: a pose for each one as a function of song time. |
| `timeline.js` | The demo's wind (breeze and gusts), the sky's pulse, and the shot list. |

These are plain scripts sharing global names, so each file's top-level names must be unique (the demo sets use
prefixes: `VDEP`, `LN`, `SDEP`, `GV`).

### A cut piece

```js
const hill=bakePiece({
  x:-300,y:500,w:2520,h:500,          // where it sits in the 1920x960 frame with the camera at rest
  s:1.05,                             // bake resolution: a little over 1 for near layers, which the zoom enlarges
  color:[40,70,82],tex:.3,            // paper colour, and how strongly the texture shows
  rimA:.5,rimW:1.6,rim:[196,236,226], // the lit edge along upward-facing cuts
  fog:{y0:760,y1:600,c:PAL.fog,a:.4}, // mist: none at y1, alpha a at y0 and below
  shadow:{blur:10,a:.4,dy:5},         // a soft shadow on whatever is behind
  shape:g=>ridgeShape(g,ridgePoints(-300,2220,8,x=>620+fbm2(x*.004,3,3)*60),1000),   // the silhouette, filled black
  after:g=>{/* coloured details painted on top, not clipped: lit windows, snow along an edge */}});
drawPiece(g,hill);                    // in a set's draw step
```

`bakePiece` returns `{img, sh, shadow, x, y, w, h, s}`: the tinted, rimmed, misted piece and its shadow sprite.
Everything drawn in `shape()` is one sheet of paper, so detail only shows where it changes the outline. Small trees
drawn inside a filled field vanish; they have to stick up past the edge, be their own piece, or be painted in
`after()`.

`drawBent(g,p,bx,by,A,n)` draws a piece bent about its base point, the way a tree bends: the top moves `A` px
sideways, each height moves in proportion to its square, and the piece is drawn in `n` sheared slices that meet
without gaps. `bentPoint(p,bx,by,A,x,y)` tells you where any point of it went, so leaves and blown snow stay on
their twigs. `glowPiece(g,p,k)` brightens a piece as if the light behind it grew (for flares).

### Sets

A set is a place: pieces baked once, then drawn in depth steps.

```js
defineSet('hill',{
  build:function*(){const P=this.P={};      // bake into this.P; yield between big pieces so baking can spread over frames
    P.hill=bakePiece({/* as above */});yield;
    const T=genTree(7,{x:900,y:700,h:320,tw:18,spread:1,leaf:0,dens:0,fruitP:0,fr:0,cutP:0,n:4});
    P.tree={p:bakeTree(T,[16,28,36],1.1),x:900,y:700,h:320,ph:0,give:.2};},
  sky:(t,cam,sh)=>nightSky(t,cam,sh),       // the aurora's uniforms, or null for a flat `bg` colour
  steps:[                                   // drawn in this order, each through its own layer matrix
    {d:12,draw:(g,t,M,cam,sh,S)=>drawPiece(g,S.P.hill)},
    {d:5,draw:(g,t,M,cam,sh,S)=>swayTree(g,t,S.P.tree)}],
  post:(g,t,cam,sh,S)=>{}});                // optional: a screen-space overlay after the layers
```

`d` is the layer's depth. `layerMatrix(d,cam)` moves a layer by `cam.x * 2.5/d` px for a camera move of `cam.x`, so a
layer at `d=2.5` moves one for one, and one at `d=25` a tenth as much. That difference is all the depth there is:
every layer is drawn at the same scale, so draw far things small. Useful depths: far peaks 50-70, middle distance
15-35, the stage 5-10, the foreground 2.5-3. Make each piece wider than the frame by the camera's travel times
`2.5/d` on each side, or the camera will see its edge.

Draw code gets `g` with the layer matrix already set, `t` (song time), `M` (that matrix), `cam`, `sh` (the shot, whose
`v` holds per-shot options) and `S` (the set). For things that span layers (a rope bridge from a near cliff to a far
strip), map each end with `layerMatrix(d,cam).transformPoint(...)` and draw in screen space: see `stripBridges()`.

### Shots and the camera

A shot puts one set on screen from its time until the next shot's:

```js
{t:7.5,set:'lane',cam:[[7.5,330,0,0,0,0,1],[11.25,170,0,0,0,-120,1.06],[15,40,-10,0,0,-352,1.3]],v:{walker:laneWalker}},
```

A camera key is `[t, x, y, z, ty, tx, zm]`, eased (`easeSine`) from key to key:

- `x`, `y`: dolly. Nearer layers move more (parallax).
- `z`: travel into the layers. Avoid it: the nearest layers blow up.
- `ty`, `tx`: shift every layer the same (a tilt or pan with no parallax). The sky follows `ty`.
- `zm`: lens zoom about the centre, the same for every layer. Push in with this.

To put a point at layer x `p` (depth `d`) at screen x `X` with zoom `zm` and dolly `x`: `tx = (X-960)/zm - p + 960 + x*2.5/d`.
Other shot fields: `fade` (dissolve in from the previous shot, seconds), `shake:[[t,amp,decay]]` (a jolt on a hit),
`ease` (another easing), `v` (anything the set's draw code reads, like `walker` above).

### Figures

Body plans in `BODY`: `stocky` (short limbs, fur-hemmed coat, pointed ears), `hooded`, `bare` (the same build
bare-headed, for long hair), `child` and `elder`. Legs are `kind:'plant'` (flat feet) or `kind:'digi'` (walking on the
toes, with an extra ankle joint, for animals and creatures built that way). A pose is a plain object:

```js
const B=BODY.hooded,q={x,face:-1,             // x on the layer; facing left
  lean:.35,look:-.04,                         // lean forward (radians); tilt the head
  legs:walkLegs(B,ph,.72),                    // ph counts strides
  arms:[{s:.5,e:.35},{s:.3,e:.3}],            // shoulder angle, and the elbow relative to the upper arm
  coatSwing:-.26,                             // hem angle: + swings it forward, - blows it back
  after:(g,j)=>scarf(g,j,t,w)};               // extra shapes cut in the same silhouette
q.arms[1]=reachArm(B,q,Y,sc,[hx,hy],-1);      // or bend the near arm so its hand lands on a point of the layer
```

Angles are measured from straight down, positive toward the way the figure faces. `walkLegs`, `walkArms` and
`sitLegs` give limb sets; `mixLimbs(a,b,k)` blends two, so a walk can ease into a braced stance.
`armTo(B,q,T,side,bend)` and `reachArm(...)` bend an arm so the hand lands on a point (a rope, a rail, someone
else's hand: in the grove, the adult and the child both reach for the same point, so their hands meet).
`drawPuppet(g,M,B,q,col,rimA,sc)` draws a near figure cut from paper with a lit edge and a soft shadow;
`drawFigure(g,B,q,col,sc)` draws a flat silhouette for distant ones. Both return the joints (`j.arms[0].Hd` is a
hand, for `drawLanternAt`). `standPuppet(g,M,q,Y,t)` does the bookkeeping for a figure on the ground: it works out the
pelvis height from the pose so the feet land on `Y` (or `q.seated` above it), scales the figure by `q.sc` about its
feet, and draws `q.hold(g,joints,t)` (something carried, in its own colour) after it. Two more pose fields for
`drawPuppet`: `rot` lays the figure over (it is drawn upright, turned about the pelvis, and its lit edge is cut to face
up after the turn) and `alpha` fades it, for someone going in at a lit door.

Long hair: give a pose `hair:{w, t}` (the wind at the figure, and time) and `phair` cuts filled locks from the crown
and the back of the head. In a calm they hang down the back; as the wind rises they stream downwind, to the right on
screen whichever way the figure faces, turning over the top of the head (never under the chin), each lock waving along
its length. With the wind behind, a breeze is enough to blow it forward past the face. Options: `n` locks (8), `len`
in head radii (2.6). The strips' walker wears it (`choreo.js`).

Work on the beat, like digging, is a stroke that lands on each beat of a list: `strokePhase(t,beats,dur,at)` gives the
phase 0..1 of the stroke round the nearest beat (the landing, a throw or a blow, `at` of the way through), and
`keyPose(u,keys)` eases a pose between keyed poses (numbers, and numbers inside arrays and objects, blend). `digPose`
uses `DIG_KEYS` (rest, scoop, toss, rest): the near hand holds the shaft at an angle `tool`, and the far hand reaches
the end of the handle by IK. `shovel(g,j,q)` cuts the shovel in the figure's silhouette (the pose's `after`) and
`shovelLoad` puts snow on the blade (its `hold`). With the props `snowTrench` (the drift still ahead of the digger,
the dug trough, a bank that grows) and `thrownSnow` (each shovelful arcs off the blade and breaks up, and a gust
carries it away downwind), that is the grove's digger, whole:

```js
const ROAD_DIG={x0:1520,x1:1760,beats:[43,44,45,46,47,48,49,50,51,52,53].map(b=>SONG.beat(b)),sc:.58};
const u=strokePhase(t,ROAD_DIG.beats),q=digPose(BODY.hooded,{b:BODY.hooded,x,face:1,sc:.58,legs:[{h:.42,k:-.55},{h:-.28,k:-.12}]},u);
q.after=(g,j)=>shovel(g,j,q);                                       // then standPuppet(g,M,q,Y,t) in the set's step
```

### The wind

`timeline.js` sets a steady `BREEZE` (keyframes) and a list of `GUSTS`, each `[peak time, strength, rise, hold,
release]`. A gust peaks at `WIND_X0` at its time and travels right at `WIND_C` px a second, so a row of trees bows one
after another.

- `wind(t,x)` is the air: smoke, snow, washing, pennants and grass follow it.
- `sway(t,x)` is what springy things do: they lean with the gust, then spring back past upright and settle.
- `windClock(t)` is how far the air has moved (the wind integrated over time); `windClk(t)` is the clock smoke puffs
  ride, and `windDrift(t,k)` feeds `drawFlakes`, so gusts push snow and smoke along without anything jumping.
- `swayTree(g,t,T)` draws a tree baked as its own piece, bent by `sway`: `T = {p, x, y, h, ph, give, fq, n}`, where
  `give` is how far the top goes per unit of sway (a share of `h`). It returns the bend, for `bentPoint`.

The props that respond: `clothShape` (washing pegged at two points), `flagShape` (pennants and swallow-tailed
banners), `weathervane`, `windmill` + `windmillSails`, `grassBlades`, `plume` (chimney smoke leaving "up" for its
house, then bent downwind, for houses at any angle), `windStreaks` (strips of blowing snow), `spindrift` (snow blown
off tree tops). The live ones return a path; fill it with `litFill(g,shape,col,rim)`, which cuts it in paper with a
lit top edge.

### Impossible land

- `floatLand(g,y,x0,x1,depth,seed,o)` / `floatRock(...)`: land hanging in the air, with a ragged underside, roots and
  icicles. Rotate the canvas a quarter turn first and it stands on its edge (`set_strips.js`).
- `smoothPts`, `curveFrames(C,step)`, `onFrame(g,F,f)`: frames along any curve, so trees, houses and posts stand
  square to it, sideways on a wall or upside down under an overhang. `snowOnCurve` lays snow on the ground side.
  The ground is the curve's left-hand side, so list a curve's points in the direction that puts the left on the
  ground (`set_valley.js` lists its curling wall from the tip back to the foot).
- `ropeBridge` (at one depth), `spanBridge` (between depths, in screen space, with sag and sway), `ropeLadder`,
  `portal` (a tunnel mouth), `plume` (smoke that goes "up" for each house, whichever way that is).
- On such land everything obeys its own ground: smoke leaves "up" for its house before the wind takes it, icicles and
  pennants hang toward the house's ground (so under an overhang they point up at the rock), snow lies on the roof's
  own top, and anything being set down drops along the frame's own "down". Draw it all inside the frame (`onFrame`, or
  `atSite` for a site), and only the wind keeps the screen's direction.

### A place that grows (eras.js)

A set can show one place at several times. Bake its terrain bare, and list what is built on it as sites, each with
the eras it stands in:

```js
const VSITES=[
  {at:'L3',era:[0,1],kind:'house',x:560,o:{gw:30,len:70,wh:16,rh:19,wins:3,chimney:true}},   // stands from the first view
  {at:'L3',era:[1,1],kind:'windmill',x:700,h:70,rise:0},                                    // only later; lands on riseAt[0]
  {at:'fold',era:[1,1],kind:'windmill',u:.385,h:58},                                        // part way along the fold's curve: under the overhang
];
yield* bakeSites(P,VSITES,{                                  // in the set's build: each site becomes its own small piece
  L3:{y:P.L3y,col:[39,66,79],s:1.06,fog:{y0:560,y1:470,c:PAL.fog,a:.42}},                     // a layer: its ground y(x) and its paper
  fold:{frameAt:u=>P.foldF.at(P.foldF.L*u),col:[38,66,79],snow:[196,220,220],smoke:1.2}});   // a curve: frames along it
{d:VDEP.L3,draw:(g,t,M,c,sh,S)=>{drawPiece(g,S.P.L3);drawSites(g,t,sh,S,'L3');}}              // in the layer's step
```

A shot picks the era with `v.era`; with `v.rising` and `v.riseAt` (times, usually beats), each site that has a `rise`
number drops into place over the 0.3 s before its time, so it lands on the beat. A site stands at `x` on the layer's
ground (`y(x)` plus `dy`, default 4), or at `u` of the way along the layer's curve (`frameAt`), turned to stand square
to it, sideways or upside down. The kinds in `SITE_KINDS`: `house` (a longhouse: `o` as for `longhouse`), `windmill`
(`h`; its sails turn with the wind), `shelter` (`sh`: `'tent'`, `'lean'`, `'sledge'` stood on end, or `'dome'` of snow
blocks, with a small fire at its mouth), `manor` (`s`, `dir`; a pennant flies from its tower) and `bridge` (`a`, `b`,
`sag`). Add a kind by writing `SITE_KINDS.name=(s,L,oncurve)=>({box, shape(g), after(g), wins, fires, smokes, sails,
flags})`, drawn at its own foot. `drawSites` lights the windows and fires (`v.lit(t,i)` sets each one, counted across
all the sites), bends the chimney smoke with the wind, turns the sails and flies the pennants.

In the demo the valley is era 0 in the opening shot and era 1 at the end: two houses and three windmills are set down
on beats 55 to 57, and a house and a windmill hang from the fold. The trees and the rope line on the fold keep clear
of the later sites only as far as each one needs, so the first view is still wooded round them.

### The sky

A set's `sky()` returns `sky({t, ta, storm, hit, flare, panY, poster, motes})`:

- `ta`: the aurora's own clock (`auroraClock(t)`). Its speed is `skySpeed(t)` in `timeline.js`, summed at build, so
  speeding up never makes the curtains jump.
- `storm` 0..1: the curtains drop toward the horizon, brighten and pale. The demo ties it to the wind.
- `hit` 0..1: a storm front; the low sky goes pale and the stars go out.
- `flare` 0..1: a brief flare. `skyFlare(t)` puts one on every bar line and a bigger one where each sung line starts.
- `panY`: the camera's tilt (`cam.ty/PH`). `poster`: 0 smooth, 1 fully stepped tissue layers (default 0.72).
- `motes` 0..1: 0 pricks white stars through the sheet; 1 puts motes in their place, points of light tinted in the
  aurora's colours (teal, green, violet, a little pale gold), drifting slowly, a few strung in short lines of four,
  as faint as the stars. The strips set uses them (`nightSky(t,cam,sh,{motes:1})`), for the one place that plainly
  isn't the sky we know.

`boltsUp(g,t,t0,list,seed)` (in `shared.js`) is weather that isn't: violet-white lightning going up from a ridge into
the storm for half a second after a hit at `t0`, jagged with a branch or two, from each `[x, yBase, height]` of the
list. Draw it in the storm's step, and put `t0` on the hit. (The demo has no storm; it's ready for one.)

### Lyrics and title

`engine.js` turns `SONG.lines` into `LYRICS`: a line fades in 0.4 s before its first word and gives way to the next
line; each word lights with a warm glow over `[t-0.04, t+0.16]` of its time; long lines shrink to fit. The title card
(`SONG.title` in italics, `SONG.credit` beside it) shows from 0.25 s until the first line.

### Determinism and caching

- Every frame is a function of song time. Nothing carries from one frame to the next, so `renderAt(t)` and `step(t)`
  draw the same picture (`step` only skips a redraw within the same 1/24 s). Randomness comes from seeded
  `mulberry32` generators and `hashi(x,y)` keyed to indices, never `Math.random()`.
- Sets are baked on first use, one piece per `yield`. After the page loads, the remaining sets bake in the
  background; during playback the sets of the next 9 seconds bake a piece per frame. At most `MAX_LIVE` (7) sets stay
  baked; the least recently used is dropped.
- Paper tiles are cached per colour. Colours given to `tint`, `tintPattern` and `litFill` must be fixed values: a
  colour computed each frame bakes a new 512 px tile every frame.

## Make your own video in this style

1. **Copy the folder**: `cp -r styles/paper-cut projects/my-song` and put your `song.mp3` beside it (see
   [docs/your-own-video.md](../../docs/your-own-video.md)).
2. **Time the song**: [docs/timing.md](../../docs/timing.md) ends with `tools/audio/to_js.py` writing your
   `lyrics_data.js`. In `index.html`, change the first script from `../../examples/poem/lyrics_data.js` to
   `lyrics_data.js`, and change the `<title>`, heading, subtitle and the canvas's `aria-label`. The engine reads the
   duration, lyrics, title and credit from `SONG`; the demo's shots keep playing until you replace them.
3. **Keep** `core.js`, `paper.js`, `sky.js`, `puppets.js`, `shared.js`, `props.js`, `engine.js` and `eras.js`. **Replace**
   `set_*.js`, `choreo.js` and `timeline.js` (and list your set files in `index.html`, before `choreo.js`).
   The demo's sets are good starting points: a wide landscape (`set_valley.js`), a street-level stage with figures
   (`set_lane.js`), floating land (`set_strips.js`), a row of trees (`set_grove.js`).
4. **Add a set** with `defineSet` (above). Build back to front: far ridges, middle layers, the stage, the foreground.
   Give anything that moves its own piece (or draw it live); keep the rest baked.
5. **Add shots** to `SHOTS`, in time order, one per stretch of song. Cut on line starts (`SONG.lines[i].t0`).
6. **Time a move to a word or a beat**: word times are `SONG.lines[i].words[j][1]`, beats `SONG.beat(n)`. For example
   a gust that peaks on the fifth word of the first line, and a figure who stops on beat 44:

   ```js
   const word=(i,j)=>SONG.lines[i].words[j][1];
   GUSTS.push([word(0,4),.55,1.3,.3,1.0]);
   const stopAt=SONG.beat(44);   // then in the figure's pose: walking before stopAt, braced after
   ```

7. **Check** with stills every second or two across each new stretch (`tools/still.py ... a:b:1 --sheet`), then
   render.

Useful knobs:

| Knob | Where | What it does |
|---|---|---|
| `BREEZE`, `GUSTS`, `WIND_C` | `timeline.js` | The wind's steady level, its gusts, and how fast a gust crosses the picture. |
| `give`, `fq` on a tree | set files | How far a tree bows, and how fast it quivers. |
| `skySpeed`, `skyStir`, `skyFlare` | `timeline.js` | How fast the aurora moves, how much it stirs, how hard it flares. |
| `poster` (sky uniform) | `sky()` in `shared.js` | 0 smooth aurora, 1 fully stepped tissue layers. |
| `PAL` | `shared.js` | Colours. Layer tones run from far and pale to near and dark. |
| `rimA`, `rimW`, `rim`, `fog`, `shadow` | each `bakePiece` | How lit the cut edges are, the mist between layers, the shadow. |
| `PUP_S` | `engine.js` | Resolution of the puppet buffer (raise it for very large figures). |
| `FADE_IN`, `FADE_OUT`, `POSTER_T` | `timeline.js` | Fades at the ends of the film, and the frame shown before Play. |
| `MAX_LIVE` | `engine.js` | How many sets stay baked at once (memory against re-baking). |
| `VSITES`, `v.era`, `v.riseAt` | `set_valley.js`, `timeline.js` | What stands in the valley in each era, and when each new thing lands. |
| `motes` (sky uniform) | a set's `sky()` | White pinhole stars (0) or tinted, drifting motes (1). |
| `DIG_KEYS` | `shared.js` | The digging stroke's poses (rest, scoop, toss) and the shovel's angle in each. |

## Performance

- Drawing a frame takes about 13 ms (median, measured in Chrome on an Apple M-series Mac), up to about 50 ms during
  a dissolve (two shots drawn). The first frame of a set pays for uploading its pieces, up to about 180 ms; the page
  bakes every set in the background after load, so live playback rarely sees it.
- Memory: 55-90 MB of canvases per set, about 285 MB for the demo's four. A site (eras.js) is a small piece with its
  shadow, a few hundred KB; the valley's 15 add a few MB and well under a millisecond a frame.
- What costs: large pieces (every layer is about 2500 px wide), bent pieces (each drawn in 12-20 slices, twice with its
  shadow), live paper paths (grass, leaves, washing), the bloom pass, and dissolves.
- Rendering: 66-240 ms a frame with `tools/render_mp4.py --fast`, most of it spent reading the frame back and
  encoding (the latest whole render: 900 frames in 68 s, about 76 ms each, with other renders running). Frames don't
  depend on each other, so a slice renders the same as the whole.
- To render only a stretch: `python tools/render_mp4.py styles/paper-cut/index.html --start 26 --end 34 --fast`.

## Lessons and gotchas

- **Start building only when every script has loaded.** The engine file loads before the sets and the timeline;
  wait for `DOMContentLoaded` before building, or a cached (fast) font load lets the build start before the later
  scripts have run.
- **Texture joins:** tinting a quarter of the paper texture showed repeat lines on big pieces. Tint the whole
  (tileable) texture, downsampled, and scale the pattern up.
- **GLSL reserved words** (such as `patch`) as variable names break the shader. The error only shows in the console.
- **A single bad value in a canvas gradient kills the whole frame.** Read the console after every change.
- **Load the fonts with the text they'll draw** (`fontsReady()` in `core.js`), or the title and first lines fall back
  to a default face for a frame or two.
- **The play overlay is `display:grid`, which beats the `hidden` attribute**, so it never hid until the page's CSS
  got `.gate[hidden]{display:none}`.
- **Storms:** a storm read as a flat white band until it was built from overlapping scalloped billows, each with its
  own lit top edge. Snow spilling over a ridge showed rectangular blocks until it became a lobed curtain. A flare
  went pink until the violet in the aurora was reduced.
- **A valley of flat bands reads as a layered cake.** Steep U-shaped cross-sections at receding depths, trees on the
  steep parts, and a foreground ledge fix it. Anything that fills a valley (ice, water, mist) should fill each layer up
  to a level rather than sit in it as a box.
- **Floating land exposes the bottom of the sky**, which is bright. A dark gradient behind the strips turns it into a
  deep gulf.
- **Impossible land needs land on it.** A curling wall read as a pale wave with thorns, and land on its edge as a
  plain cliff, until they had things at a readable size: trees in stands, houses with lit windows, a rope line with
  lanterns, snow on the ground side, a ragged underside with ice pointing the "wrong" way, smoke going the "wrong"
  way.
- **Push in with `zm`, not `z`.** Depth travel blows up the nearest layer: snowflakes become moons.
- **Effects that belong to a layer must be drawn in its frame.** Light from an open door drawn at the wrong depth split
  into two or three pale panels when the camera moved. Draw it with that layer's `layerMatrix(d,cam)`.
- **Figures:** a very thin figure looked like a stick insect until it was given a deep chest; round heads read as
  teddy bears until they had a small muzzle; a walk on the toes (`'digi'` legs) looked like sitting on a stool until
  its stride was shortened; two figures leaving the same way merged into one blob.
- **Pale objects with glowing marks read as lanterns.** Make them pale with a dark stamped mark instead.
- **Big close-up silhouettes of hands and arms read as clubs, poles or chess pawns.** Show whole figures; a mostly
  still figure holding a rope carries a moment fine.
- **Guide ropes at knee height are too low to hold.** Put them at about hip height for the figures that use them.
- **A figure that changes how it's drawn** (on a layer, then on a screen-space bridge, then on a far strip) must keep
  the same stride phase, scale and draw order across the change, or it pops for a frame.
- **Reaching hands must stay in reach.** When two figures hold hands by reaching for one point, check every pose: a
  crouch lowers the shoulder, and the hands part.
- **Anything that bends must be its own piece**, and `bentPoint` must use the same bend as `drawBent` (measured from
  the piece's top, padding included), or attached leaves drift off their twigs. Bake a row of small trees in groups of
  three: one piece per row can only shear as a block, so no gust can travel along it.
- **Slices must overlap, but a shadow can't.** A bent piece is drawn in slices that overlap by a pixel so no gap
  shows; its soft shadow, drawn the same way, darkened into faint horizontal lines where the slices doubled up. Only
  the opaque piece overlaps its slices.
- **Drive speeds with integrated clocks** (`makeClock`), never `t * speed(t)`: when the speed changes, everything
  riding it jumps.
- **Blowing-snow streaks across the sky read as searchlights**; keep them below the horizon. Snow blown off tree tops
  drawn as round soft dots reads as a row of bokeh; stretch the puffs along the wind and thin them out.
- **Keep something moving.** Every shot here has a camera drift, snow, and the wind working on something; a hold of
  more than a beat or two looks like the player froze.
- **A place that grows keeps its sites.** Bake the land bare and list every building as a site with its eras, so each
  later view keeps the earlier houses where they stood; a view built separately for each era drifts. Clear the land
  (trees, posts) round a later site only as far as it needs, or the first view has bare patches where nothing stands
  yet. Set new things down so they land on the beat, over the 0.3 s before it, not after it.
- **On hanging land, everything obeys its own ground** except the wind: smoke, icicles, pennants and snow on roofs
  are drawn in the frame of their bit of curve, and things being set down there drop along that frame's "down". A
  pennant's streaming is the one thing that keeps the screen's direction (to the right with the wind), so it's
  mirrored on land that is turned over.
- **A shovel raised over the head reads as an axe or a hammer.** Toss at shoulder height. Aim the shaft by an angle
  held in the near hand and bring the far hand to its end by IK: a shaft laid through two hands placed by their own
  angles points wherever they happen to be, often straight up.
- **A figure with no height is never drawn.** Stand every figure on the ground from its pose (`standPuppet` works out
  the pelvis height from where the feet land) instead of giving each one a `y`.
- **Hair:** single strands read as antennae or a spiky crest, and locks that end in rounded tips read as the fingers
  of a mitten; filled, tapering, wavy locks read as hair. Turned from hanging to streaming by blending their direction,
  locks swept under the chin read as a beard: turn them over the top of the head. With the wind behind a figure, even a
  breeze blows hair forward; halfway there, it stands up like a crest.
- **A GLSL name that clashes breaks the whole sky.** Adding the motes with a variable already declared in the shader
  (a `vec2` used by the curtains) made it fail to compile, and the page fell back to a flat gradient. Give new shader
  code its own names, and read the console.
- **Infinity poisons smoothstep.** A helper that returns `Infinity` for "none" (the top of a fill level on a layer
  that has none) gave `sstep(a,b,Infinity)`, which is NaN, and a NaN alpha blanks what it touches. Guard such values.
- **Short effects need the right instant for a still.** The rising bolts fade within a quarter of a second, so a still
  0.3 s after the hit shows nothing; ask for a few hundredths of a second after it.
- **A figure lying down outdoors reads as a collapsed body.** One asleep on its feet, head down, reads as dozing.
- **Loads read by how they're held.** Sacks hugged against the chest at a walking pace read as carried; a sack held
  over the head with a leaping stride didn't, and sacks stacked upright in a lit doorway read as a hooded head until they
  were laid flat like sandbags. Snow on a head drawn as a row of dots read as pearls, then as a skullcap: a lumpy cap
  clipped to the head's outline, with loose flakes on the shoulders, reads as snow.
- **Bring people in from the cut.** A figure that pops into the middle of the frame mid-shot is a glitch; have them in
  the shot from its first frame, or walk them in from an edge, and fade them (`alpha`) where they go in at a door.
- **A shot's figures must last through the dissolve out of it.** The next shot's `fade` draws this one for a while
  longer; a pose function that returns nothing from the moment its shot ends makes its figures vanish while the picture
  is still nearly fully visible. Keep them until the fade is done.



===== 完整公共规范：CLAUDE.md =====

# Instructions for Claude

This repository makes music videos in code: each style in `styles/` is an engine that draws every frame on an HTML
canvas (or WebGL / three.js) in a hand-made-looking medium, timed to a song, and `tools/` renders them to MP4. Read
`README.md` for the map, then the doc for whatever you're doing.

## When someone wants a video for their song

Follow [docs/workflow.md](docs/workflow.md). It's a conversation, not a build order to rush through:

1. **Get the inputs:** the song (mp3), the lyric sheet as sung, and ask whether they have stems and MIDI (Suno and
   stem splitters provide them) and any reference images.
2. **Ask the concept questions before building anything:** who is singing, who "you" is, whose voice the chorus is,
   what the key images (especially the ending) mean, how much the video may show, what stays out. Don't guess at
   these; an open question is better than a confident wrong answer. If the song belongs to a larger world, read
   whatever they give you about it, and keep a list of every detail the video invents, flagged as unconfirmed.
3. **Measure the song** ([docs/timing.md](docs/timing.md)): tempo, sections, stops and hits, and every word's time.
   Time to the audio, not to the lyric sheet's markings.
4. **Pitch three looks and recommend one:** the medium and why it suits this song, the organizing object, a small
   visual grammar and an arc, a section-by-section plan keyed to timestamps, and the open questions. The styles in
   `styles/` are the starting points (each README says what it's good at); a new medium is fine too
   ([docs/engine-patterns.md](docs/engine-patterns.md)).
5. **Style lab:** the same three or four moments drawn in each candidate look. Show the stills.
6. **Checkpoint:** build one section (20-90 s), render it (`--fast`), send it, get notes.
7. **Build the rest** section by section, then render the final MP4s. The MP4 is what gets shared.

Build a project in `projects/<song-slug>/`, copied from a style folder ([docs/your-own-video.md](docs/your-own-video.md)).
Don't change `styles/` for one person's video. Keep notes in `projects/<song-slug>/PLAN.md` as you go: their answers
and rulings, the measured sections and sync points, the shot list, the invented details, and their feedback on each
round. A later session should be able to pick up from that file alone.

## Working practices

- **Look at what you render.** Make stills and contact sheets (`tools/still.py ... --sheet`) and open the images.
  Check every frame on the sheet: edges, blank frames, the camera inside things, covered text, long freezes.
- **Read the console output** the tools print. A single bad canvas gradient value blanks a frame.
- **Preview slices with `--fast`**; render the full 1080p only at the end. Styles that carry state between frames
  must be rendered in order (the tools do this).
- **Keep it deterministic:** seeded randomness keyed to the frame, never `Math.random()` per frame.
- **Follow the page contract** in [docs/rendering.md](docs/rendering.md) (`window.__video`, `window.SONG`,
  `<canvas id="film">`, `#t<seconds>` stills) so the tools work.
- Apply the lessons in [docs/workflow.md](docs/workflow.md#what-the-notes-taught-true-for-every-style): busy
  enough, no long freezes, obvious changes, varied choruses, whole figures rather than close-up hands.
- The person's audio is git-ignored. If their lyrics or story are private, keep the project out of any public
  remote (add it to `.git/info/exclude`, or keep it outside the repo and pass `--root` to the tools).

## Setup

```bash
python3 -m venv .venv && .venv/bin/pip install -r requirements.txt -r requirements-audio.txt
```

Google Chrome must be installed (or `.venv/bin/python -m playwright install chromium`). To preview in the desktop
app's browser pane, create `.claude/launch.json` running `python3 tools/serve.py 8000` on port 8000 (git-ignored).
Use the server, never `file://`: module pages don't load from files and a plain server caches stale scripts.



===== 完整公共规范：docs/workflow.md =====

# How a video gets made

These videos were made in conversation: a person with a song and a clear sense of what it's about, and Claude
writing and rendering the code. The process below is what worked over a dozen songs. It suits working with Claude
Code (see [CLAUDE.md](../CLAUDE.md), which tells Claude to follow it), and it works just as well by hand.

The short version: **decide what the song is about, measure it, pitch three looks, test the look on a few scenes,
build one section, get notes, then build the rest.** Each step is cheap next to the one after it, so mistakes get
caught while they're still cheap.

## 1. Gather the inputs

- **The song** as an mp3 (or anything ffmpeg reads).
- **The lyric sheet** as plain text, one sung line per line, with `#section` markers (see
  [examples/poem/lyrics.txt](../examples/poem/lyrics.txt)). Write it the way it's sung: if the singer repeats a line
  that isn't on the sheet, add it.
- **Stems, if you have them.** An isolated vocal stem makes transcription far cleaner. Suno exports stems as audio
  and as MIDI per instrument; the MIDI's tempo map gives an exact beat grid, and the vocal MIDI gives note onsets to
  snap words to (see [timing.md](timing.md)).
- **Reference images, if any.** Mood boards and concept art are useful for content (what's in the world, what
  people wear, what the place looks like) even when the style will be different.

## 2. Decide what the song is about

Before any pictures, answer the questions that decide the concept. A video can't be good if these are guesses.

- **Who is singing,** and to whom? Who is "you"? It's often not who it seems, and it can change between verses.
- **Whose voice is the chorus?** The singer's, an imagined audience's, a crowd's, a custom's?
- **What do the key images mean?** Especially the closing one.
- **How much may the video show?** If the song belongs to a larger story, what would be a spoiler?
- **What stays out?** Eras, events, people, kinds of imagery.

If the song is part of a larger world (a novel, a game, a band's mythology), read up on it first, and **keep a list
of every detail the video invents**: a place's layout, what a prop says, who stands where. Show that list to
whoever owns the world, and treat nothing on it as settled until they say so.

## 3. Measure the song

Time the video to what the audio does, not to what the lyric sheet says. (AI song generators in particular ignore
markings like "quiet" or "almost unaccompanied".) With the tools in [timing.md](timing.md):

- tempo, and whether it changes;
- the sections and their loudness: which chorus is the big one, where it drops to almost nothing;
- **the stops and hits.** Musical stops, dropouts and the hit that ends a bridge make the best sync points: the
  place to freeze, cut, switch a light off, or change the whole picture;
- every word's time.

## 4. Pitch three looks

Offer three directions and recommend one. For each:

- **the medium** (paper cut, embroidery, marbled paper...) and why it suits this song. The strongest choices mean
  something: marbled paint for a song about water, where nothing stays put; a lantern lecture for a song sung by
  someone lecturing; a desk of files and stamps for a song about a record that doesn't add up;
- **the organizing object:** the one thing the whole video is, such as a desk under a lamp, a hanging read along
  its length, a printed sheet, a painted wagon's panels, a board of pasted-up photographs;
- **a small visual grammar:** a few rules that give the images meaning (stamps are the audience's verdicts, frost
  is the stillness, the camera's date flickers between years), and an **arc** over the song (clean to decayed,
  night to morning, empty to crowded);
- a **section-by-section plan** keyed to timestamps, giving each section one main image;
- the questions still open.

The [styles/](../styles) folder has eighteen engines to start from, and each one's README says what it's good at.
A new song can also want a new medium: the engines share their patterns ([engine-patterns.md](engine-patterns.md)),
so a new one is less work than it sounds.

## 5. Style lab

Draw the same three or four key moments in each candidate look, side by side, as stills (and a few seconds of motion
if the look depends on how it moves). Comparing like with like makes the choice easy, and it shows the problems
early: people who look like mannequins, faces that look ill, a palette that turns cute. Every family here with more
than one look has a lab page (`styles/<family>/lab/`) built this way.

Expect the first choice to be refined: "this look, but with the other one's colours", or "this, for the scenes in the
other world only". Mixing is fine.

## 6. Checkpoint

Build a real section before the whole song: 20-30 seconds of the section that carries the concept, or the first
90 seconds. Render it as an MP4 and get notes on the look, the pace, the figures, the text. This is where most of
the useful notes arrive, and they're cheap to act on now.

## 7. Build the whole song

Section by section. After each, render stills across it (`tools/still.py ... a:b:2 --sheet`) and look at every one:
frame edges, blank frames, things the camera cuts through, text that's unreadable or covered. Fix, then move on.
When it's all there, render the MP4, then scan it at one frame every two seconds.

## 8. Notes, and fixing a stretch

Notes on a full video are usually local: one stretch feels empty, one chorus repeats the last, a transition jerks.
Re-render only that slice and splice it in ([rendering.md](rendering.md#fixing-one-stretch)).

## 9. Deliver an MP4

Share the MP4, not the web page. A browser player's pause and scrub can feel unreliable, and people give up on it.
`tools/render_mp4.py` writes a 1080p file and a smaller 720p one for sending.

## 10. Revising a finished video

A second or third pass (new conventions, a list of fixes, a stretch that needs more going on) works best as: a short
written plan of every change; then before/after sheets, stills from the old render and the new build at the same song
times side by side; then the full render. The sheets let the notes land on exactly what changed. When picking stills
for review, catch short effects at their peak: a flash or a bolt that lasts half a second is easy to miss.

## What the notes taught (true for every style)

- **Busy enough.** Something new on nearly every beat, or at least every line. A stretch with nothing happening
  reads as a mistake, not a rest. When a stretch feels empty, fill it with callbacks (translucent overlays of earlier
  scenes) and background life (children, animals, people passing) rather than restaging it.
- **No long freezes.** A four-second still reads as the player stalling. Keep holds to a beat or two, or keep
  something drifting: a slow camera move, breathing light, smoke.
- **Make small changes obvious.** A face swapping for another face, a detail changing on a paper: if it matters,
  make it big and push the camera in on it. Subtle changes go unseen.
- **Too clean reads as dead.** A video that stays tidy all the way through can feel flat; give it an arc.
- **Vary the repeats.** The second chorus shouldn't replay the first. New scenes, with brief flashes back to the
  first chorus's pictures on key words, keep the echo without the repetition. A motif that does something different
  each chorus (ribbons that knot, then plait, then slip) works well.
- **Whole figures beat close-up hands.** Big silhouettes of hands and arms read as clubs, poles or chess pieces. A
  whole figure, even small and mostly still, carries a beat better.
- **Faces:** realistic halftone or heavy shading can make people look ill. Stylized faces (dot eyes, lowered lids
  when looking down) for close figures and blank faces for crowds read better.
- **What makes a look cute** (sometimes wanted, often not): flat candy fills, rounded sack-shaped figures with blob
  heads, even lighting, bobbing walks. For solemn songs, use weight, texture, uneven light and stillness instead.
- **Real texts make good props.** A period document, a real letter or hymn, an actual map give a scene weight even if nobody
  can read them.
- **Impossible places need ordinary things in them.** Floating or folded land only reads as land when it carries
  trees, lit windows, snow on its ground side, smoke going the "wrong" way.
- **Decide about text in the picture.** A lyric band under the picture is one choice; no readable text at all
  (squiggles for writing) is another; either way, be consistent. Captions that only repeat the lyric are redundant.
- **Fake text is worse than no text.** A card of invented glyphs that flickers reads as a screen of foreign writing.
  Use pictograms, squiggles, or nothing. Likewise on-screen read-outs (temperatures, timecodes) in a "technical"
  medium: keep them only if they mean something.
- **Show the medium working.** When a look risks feeling static (a photograph, a print, a drawing), let the viewer
  watch it being made: a plate exposing, inks printing in on the beats, stitches sewn in, a slide pushed into the
  lantern. It answers "static and unclear" without changing the look.
- **Vary what leads a scene.** In a medium with a life of its own (liquid light, marbling, sand), let some scenes be
  led by the pictures and some by the medium, rather than the same mix throughout.
- **Props must sit in hands.** A rope, a ring, a cloth or a cup that floats near a hand reads as broken. Anchor held
  things to the rig's hand points and check every one in stills.
- **Arms that move naturally:** pose them by where the hand and elbow should be, blend joint angles rather than
  positions, let the forearm trail the upper arm, and add breathing and small weight shifts. Arms that slide
  straight between poses look like a puppet's.
- **Bodies carry identity.** In silhouette, heat or other outline-first looks the outline is all a viewer gets: if
  someone is heavily built, or small and round, the shape must show it. Keep sizes consistent (an animal is as big in
  every shot).
- **Shapes read as other shapes.** A figure lying flat reads as a collapsed body (have them sit or doze upright unless
  a death is meant); a pyramid of sacks in a lit doorway reads as a hooded head; a fan of hair strands reads as a
  feathered headdress. Look at every silhouette as a stranger would.



===== 完整公共规范：docs/timing.md =====

# Timing a song

Everything in a video hangs off the song's clock: the lyric band lights each word as it's sung, pieces land on
beats, scenes change on line starts, the lamp goes out in a dropout. This page is how to get those times. The tools
are in [tools/audio/](../tools/audio); each prints its own help with `--help`.

Setup (once): `pip install -r requirements-audio.txt` (librosa, scipy, faster-whisper, mido). The Whisper model
downloads the first time it's used.

## The pipeline

```bash
# 1. the shape of the song: tempo, loudness, sections
python tools/audio/analyze.py song.mp3

# 2. words with timestamps, from the vocal stem if you have one
python tools/audio/transcribe.py vocals.mp3 --lyrics lyrics.txt --out whisper.json

# 3. your lyric sheet matched to Whisper's words
python tools/audio/align.py lyrics.txt whisper.json --out lines.json

# 4. snap each word to where the voice starts it (vocal MIDI and/or vocal audio)
python tools/audio/snap.py lines.json --midi vocals.mid --audio vocals.mp3 --out snapped.json

# 5. the page's data file
python tools/audio/to_js.py snapped.json --out projects/my-song/lyrics_data.js --title "My Song" \
    --audio song.mp3 --audio-file projects/my-song/song.mp3 --bpm 96 --beats-per-bar 4
```

Then open the video with the lyrics showing and listen through. Fix what's off by editing `lyrics_data.js`
directly: it's plain data.

## Step by step

### 1. The shape of the song

`analyze.py` prints the global tempo and the local tempo every 20 s, a table of loudness, brightness and rhythmic
busyness every few seconds, and guesses at section boundaries. Read it next to the lyric sheet. You're looking for:

- which sections are loud and which drop out: the video's big and quiet moments should follow them;
- tempo changes (a slow intro, a half-time bridge);
- **stops and hits.** `onsets.py song.mp3 --from 140 --to 155` zooms in on a stretch: the strongest onsets, the
  beats, and the loudness every quarter second, so a dropout shows as a run of low numbers. These are the best
  sync points a song offers: the place for everything to freeze, for a cut, for a light to go off.

`sections.py song.mp3 --lines lines.json` compares the sections' loudness, drums and tonal energy once you know
where they are.

### 2. Transcribe

`transcribe.py` runs faster-whisper with word timestamps. Give it the **vocal stem** if there is one; sung vocals
over a full mix transcribe much worse. The `small` model is usually enough and takes about a minute. `--lyrics`
passes the start of your lyric sheet as a prompt, so names and odd words come out spelled your way. `medium` can
rescue mumbled lines, but over a long song it can drift further than `small`.

Expect Whisper's times to run **early**, typically a few tenths of a second and sometimes by more than a second,
and to hear some words wrong, especially names and unusual words. Step 3 doesn't care about wrong words; steps 4 and
the listen-through fix the times.

### 3. Align

`align.py` lines your sheet up against Whisper's words (a sequence match, so misheard or missing words don't break
it; unmatched words get times interpolated from their neighbours). It prints each line with a match count like
`m7/9`. Low counts are where to listen first. Watch for:

- **numbers:** Whisper writes "1974" as one token for three sung words. The script spells out years and small
  numbers before matching, but check them;
- **hyphenated words** and contractions;
- **a misheard last line** ("Let it go" for "Letting go"): the end of a song, over a fade, is where Whisper guesses;
- **repeats and ad-libs** the singer added: put them on the sheet as sung, or they'll be squeezed between
  neighbours.

### 4. Snap to the voice

`snap.py` moves each word to the nearest sung-note onset within 0.32 s: note onsets from the **vocal MIDI** first
(if you have it), then onsets detected in the **vocal audio**. It first reports the median offset between the words
and the onsets; if Whisper ran early across the whole song, pass that back as `--shift` so everything moves before
snapping.

After snapping, some things still need a human ear:

- **line starts that land in silence** or on the tail of the previous word: move them to where the voice comes in;
- **choruses and held notes:** a melisma or a long held word confuses onsets;
- **MIDI quantization:** Suno's MIDI is quantized to sixteenth notes and can sit about 0.3 s off the voice.

For those, `onsets.py vocals.mp3 --from 25 --to 27 --pitch` prints the sung pitch and loudness every 50 ms: the
word starts where the pitch appears and the loudness jumps.

### 5. Write the page data

`to_js.py` writes `lyrics_data.js`, which sets `window.SONG`:

```js
window.SONG = {
  title: "My Song", credit: "", audio: "song.mp3", duration: 212.4,
  bpm: 96, beatsPerBar: 4, firstBeat: 0.35,
  sections: [["verse1", 12.3, 41.0], ...],
  beats: [0.35, 0.975, ...],            // only with --beats: exact beat times
  lines: [{section: "verse1", text: "Who has seen the wind?", t0: 12.3, t1: 14.9,
           words: [["Who", 12.3], ["has", 12.9], ...]}, ...],
};
SONG.beat(n)  // the time of beat n
```

Every style in this repo reads that shape (see [examples/poem/lyrics_data.js](../examples/poem/lyrics_data.js)).

## Beats

For a steady song, `--bpm` and `--first-beat` (the time of the first downbeat) are enough: `SONG.beat(n)` is
`firstBeat + n * 60 / bpm`. Find the first beat with `onsets.py` on the song's opening seconds.

If the tempo drifts or changes, use exact beat times instead:

- **from MIDI stems:** Suno writes a tempo event on every beat, so the tempo map is an exact beat grid.
  `midi.py drums.mid --beats-out beats.json` (any of the song's MIDI files will do);
- **from the audio:** `analyze.py song.mp3 --beats-out beats.json` (librosa's estimate; check it).

Pass the file to `to_js.py --beats beats.json`; `SONG.beat(n)` then reads from the list.

## Hits and loudness

Some styles pulse, flash or move with the music itself rather than the words: a lamp that breathes with the mix, a
ring on every drum hit, mouths that open with the voice. `pulses.py` measures those:

```bash
python tools/audio/pulses.py song.mp3 --percussion perc.mp3 --drums drums.mp3 --vocals vocals.mp3 --out projects/my-song/audio_data.js
```

It writes `window.AUDIO = {fps, ticks, kicks, env, venv, vdb}`: small hits (`ticks`) and big ones (`kicks`) as
`[time, strength]`, the mix's and the voice's loudness 24 times a second (`env`, `venv`, 0..1), and the voice's
loudness in decibels mapped to 0..1 (`vdb`, better for mouths). Stems give much cleaner hits than the mix; without
them everything comes from the mix. The liquid light show reads this file as it is; any style can read the arrays.

## Suno specifics

- The stem download gives an audio file and a MIDI file per instrument. The lead vocal stem transcribes cleanly.
- The MIDI files carry a key-signature event that the `mido` library can't decode (it raises
  `KeySignatureError`). `tools/audio/midi.py` patches mido to read it as C; import `load()` from it in your own
  scripts to get the fix.
- The MIDI tempo map has one event per beat: an exact beat grid, including tempo changes after an intro.
- Vocal MIDI notes are quantized and can sit up to ~0.3 s off the voice: good anchors for snapping, not ground truth.
- Suno ignores dynamics on the lyric sheet ("quiet", "spoken", "almost unaccompanied"). Measure.

## Checking by eye and ear

Open the page, play it with the sound on, and watch the lyric band. Words that light up early are the common
fault. For a close look, `#t25.3` on the page's URL shows the frame at 25.3 s with the band as it is then.



===== 完整公共规范：docs/rendering.md =====

# Previewing and rendering

Every video here is a web page that draws its frames on a canvas. You watch it in a browser while you work, and
when it's done a script steps through it frame by frame in headless Chrome and pipes the frames to ffmpeg. This
page covers the page contract the tools rely on, previewing, stills, MP4s, and fixing a stretch.

Setup (once): `pip install -r requirements.txt` (Playwright, imageio-ffmpeg, Pillow, numpy). The tools drive your
installed Google Chrome; if you don't have it, `python -m playwright install chromium` gets Playwright's own.
imageio-ffmpeg bundles an ffmpeg with x264 and AAC, so there's nothing else to install.

## The page contract

A video page (a style's `index.html`, or a copy of one for your song):

- draws into `<canvas id="film" width="1920" height="1080">`;
- loads its song data as `window.SONG` (see [timing.md](timing.md#5-write-the-page-data)) and plays `SONG.audio`
  in an `<audio>` element, falling back to a silent clock if the audio can't load;
- sets `window.__video`:
  - `ready`: true once everything is built;
  - `duration`: the song's length in seconds;
  - `step(t)`: draw song time `t` the way playback does. The MP4 renderer calls it at 24 fps, strictly in order;
  - `renderAt(t)`: draw a still of time `t` from a fresh state (catching up whatever the frames before it built);
  - either may return a Promise (a page that builds scenes asynchronously); the tools wait for it;
  - `error`: set this to the error text if building fails, and the tools stop and print it;
  - optionally `shots` and `probe(t)` for 3D pages (see `tools/probe.py`);
- shows a still when the URL ends in `#t<seconds>` (e.g. `index.html#t12.5`), with the page chrome hidden;
- draws only while playing: a paused player shouldn't keep redrawing its frame on every animation frame (the tools
  draw and read back each frame in one call, but a page that redraws on its own fights anything else that draws);
- is **deterministic**: all randomness comes from seeded generators keyed to the frame number, never
  `Math.random()` per frame, so a given moment always draws the same picture. An MP4 depends on it.

A style-lab page sets `window.__lab = { ready, scenes, styles, render(scene, style) }`, where `render` draws one
scene in one look and returns the canvas.

## Previewing

```bash
python tools/serve.py            # serves the repository at http://localhost:8000/ and lists the demo pages
```

Open a page from the list. Use this server rather than `python -m http.server` or opening the file directly:

- pages that use ES modules or load files **don't work from `file://`**;
- a plain server lets the browser **cache scripts**, so after an edit you can be looking at the old code. This
  server sends no-cache headers;
- audio and video only seek when the server answers **Range requests**; this one does.

**Stills in the browser:** add `#t<seconds>` to the URL. Changing only the `#` part doesn't reload the page, so
after editing code, reload with a new query (`index.html?r=2#t30`).

**Always check the console** after a load. One bad value in a canvas gradient (a NaN colour stop) throws, and the
whole frame goes blank.

**In Claude Code's desktop app**, the preview pane can run the server for you: create `.claude/launch.json` with
```json
{ "version": "0.0.1", "configurations": [
  { "name": "videos", "runtimeExecutable": "python3", "runtimeArgs": ["tools/serve.py", "8000"], "port": 8000 } ] }
```
(it's git-ignored).

## Stills and contact sheets

```bash
python tools/still.py styles/paper-cut/index.html 5 12.5 30          # three stills
python tools/still.py styles/paper-cut/index.html 0:37.5:2.5 --sheet # a frame every 2.5 s, tiled into one image
python tools/lab_stills.py styles/embroidery/lab/index.html --all --sheet
```

Output goes to `renders/` (git-ignored). The contact sheet is the fastest way to review a whole video: look at every
frame on it, not just the ones you changed. Things to look for: frame edges showing the end of the world, blank or
black frames, the camera inside an object, text covered or cut off, two scenes' seams, something frozen too long.

## MP4s

```bash
python tools/render_mp4.py styles/marbling/index.html                    # renders/marbling.mp4 and -720p.mp4
python tools/render_mp4.py projects/my-song/index.html --out "renders/My Song.mp4"
python tools/render_mp4.py projects/my-song/index.html --start 60 --end 90 --fast   # quick preview of a slice
```

- Two files: 1080p (x264 `slow`, CRF 23, AAC 192k: roughly 5 Mbps for a busy picture) and `-720p` (CRF 25: about
  1 Mbps, small enough to send).
- `--fast` writes only the 720p with the `veryfast` preset. Busy, grainy frames can take many times longer to
  encode with the slow preset than to draw, so use `--fast` for previews and the normal mode for the final.
- The audio comes from `SONG.audio` unless you pass `--audio`. A slice gets short audio fades.
- **Fonts:** the styles load their type from Google Fonts. If a font request fails (a flaky network), canvas text
  silently falls back to a default font, so `render_mp4.py` and `render_frames.py` check the page's fonts after it
  builds and stop if any failed. Run again, or pass `--allow-font-fallback` if you really mean it. The still tools
  print a warning instead.
- 24 fps. Frames are rendered **in order**: many styles draw each frame over the one before (frost that grows,
  ghosting, marbled paint that keeps its history), so a frame can't be drawn on its own.
- Speed depends on the style and on how much the machine is doing: from about 40 ms a frame (paper cut, painted
  enamel, archive desk) to 250 ms or more (sand, the pinscreen, screenprint's printing), including reading the frame
  back and encoding. Each style's README gives its numbers. A four-minute song is 5,760 frames: a few minutes for the
  fast styles, half an hour or more for the slow ones (see the next section for splitting a render across browsers).

## Long renders: frames on disk, resumable, in parallel

For a long song in a slow style, render the frames to a folder instead of straight into ffmpeg:

```bash
python tools/render_frames.py projects/my-song/index.html --dir renders/frames/my-song --jobs 3
python tools/encode.py renders/frames/my-song --out "renders/My Song.mp4"
```

- Frame `i` is `<dir>/<i:05d>.jpg` and shows song time `(i + 0.5) / 24`. Frames already on disk are skipped, so an
  interrupted render continues where it stopped when you run the same command again, and deleting a stretch's
  frames and re-running redoes just that stretch.
- `--jobs N` renders N runs of frames in N browsers at once. Each run starts with `renderAt()` at its first frame,
  which catches up styles whose frames depend on earlier ones, then steps in order. (Tested: a resumed run's frames
  match a straight-through render pixel for pixel.) GPU-heavy styles gain less, since the browsers share one GPU.
- `encode.py` takes the audio from the folder's `meta.json` (the page's `SONG.audio`), cuts it to the frames on
  disk, and writes the same 1080p and 720p files as `render_mp4.py`.
- **A render that sits before its first frame** is usually the machine, not the page: with other renders or heavy
  WebGL pages running, Chrome can take minutes to start or to build a page. `render_mp4.py` prints the page's URL when
  it's loaded and a progress line every 240 frames.
- **Heavy 3D pages:** building every set of a long WebGL video at once can hang the GPU. Render such a video in
  segments (`--start`/`--end` runs into the same frame folder, each run building only what its stretch needs), and
  on a machine that other renders are sharing, run one segment at a time.

## Fixing one stretch

A full render can take a while. To fix one stretch, render only that slice at full quality and splice it into the
finished file at whole frames:

```bash
python tools/render_mp4.py projects/my-song/index.html --start 120 --end 135 --out renders/fix.mp4
python tools/splice.py "renders/My Song.mp4" renders/fix.mp4 --at 120 --out "renders/My Song v2.mp4"
```

A slice opens with `renderAt(t)`, which catches up styles whose frames build on earlier ones, so its frames match the
full render's and the splice is seamless.

## Checking a 3D video's framing

`python tools/probe.py styles/diorama/index.html` asks the page, for the start, middle and end of every shot,
whether anything stands between the camera and its subject, or whether the camera is inside something. In a crowded
set it finds blocked views much faster than contact sheets.

## Sharing

Share the MP4. If you also want a review page (the video with notes around it), keep in mind that some hosts cap
file sizes: split a long 720p video into parts at scene changes and play them in sequence against the song, and
serve it from something that answers Range requests.



===== 完整公共规范：docs/your-own-video.md =====

# Making a video for your own song

The hands-on steps, from an mp3 to an MP4. For the creative side (what to decide before building, how to pick a
look) see [workflow.md](workflow.md). If you're working with Claude Code, you can just ask it to make a video for
your song: [CLAUDE.md](../CLAUDE.md) walks it through all of this.

## 1. Set up

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt            # rendering
pip install -r requirements-audio.txt      # timing a song (Whisper, librosa, MIDI)
```

You need Google Chrome installed (or run `python -m playwright install chromium`).

## 2. Start a project folder from a style

Pick a style from the [gallery](../README.md#the-styles) and copy its folder:

```bash
cp -r styles/paper-cut projects/my-song
cp ~/Music/my-song.mp3 projects/my-song/song.mp3
```

Audio files are git-ignored, so your song stays out of the repository.

In `projects/my-song/index.html`, change the lyrics script from the demo's
```html
<script src="../../examples/poem/lyrics_data.js"></script>
```
to your own
```html
<script src="lyrics_data.js"></script>
```
(Relative paths from `projects/my-song/` resolve just as they did from `styles/<style>/`, so anything else the
page loads from the repo keeps working.)

## 3. Time the lyrics

Write the lyric sheet (`projects/my-song/lyrics.txt`, one sung line per line, `#section` markers), then run the
pipeline in [timing.md](timing.md). It ends with `projects/my-song/lyrics_data.js`.

## 4. Look at it

```bash
python tools/serve.py
```

Open `http://localhost:8000/projects/my-song/index.html`. The demo's scenes now play under your lyrics for as long as
the demo lasts. That's the moment to decide the plan: which scene goes where, which line lands on which image.

## 5. Replace the demo's scenes with yours

Every style's README has a "Make your own video in this style" section that says which files are the demo (its
scenes, sets, shots or timeline) and which are the engine. Keep the engine; rewrite the demo files. Work a section
at a time:

```bash
python tools/still.py projects/my-song/index.html 30:60:2 --sheet   # stills every 2 s across 0:30-1:00
```

Look at every still on the sheet. Check the console output printed at the end.

## 6. Render

```bash
python tools/render_mp4.py projects/my-song/index.html --start 30 --end 60 --fast   # a quick 720p preview
python tools/render_mp4.py projects/my-song/index.html --out "renders/My Song.mp4"  # the final, 1080p + 720p
```

To fix one stretch later without re-rendering everything, see
[rendering.md](rendering.md#fixing-one-stretch).



===== 完整公共规范：docs/engine-patterns.md =====

# How the engines are built

The eighteen engines in [styles/](../styles) share no code at run time: each folder is self-contained, written for one
song in one medium (a few began as copies of another's files, such as the 3D pipeline or the ray-marched figure). But they
share a shape, and knowing it makes any of them easy to read and a new one quicker to write. This page is that
shape, plus the browser gotchas that cost the most time.

## Simulate the process, not the look

Each engine models how its medium is physically made, and the imperfections come out right on their own:

| medium | what the code does |
| --- | --- |
| screenprint | each ink is a stencil mask plus a halftone; inks are pulled one at a time and multiplied onto paper, each a little out of register, with squeegee streaks and pinholes |
| linocut | a block is a list of gouge cuts and inked areas; the key block prints black over watercolour washes |
| wool embroidery | wool is laid and couched from tiles, outlines are stem-stitched, light is couched gold thread |
| marbled paper | paint floats as closed outlines on a bath; drops, combs and swirls are exact maps applied to every point |
| magic lantern | slides are baked as tinted glass; a frame stacks glass by multiplying and throws it through a lens |
| painted enamel | two-colour bristle strokes with a highlight flick toward the light, then gold leaf |
| paper cut | cut shapes with a lit rim and a soft shadow, layered in depth and lit from behind |
| mosaic | tesserae are laid in rows along the outlines, then grouted |
| sand on a lightbox | sand thickness is a density field; the lamp shows through as `exp(-k * thickness)`; fingers clear lines |
| carved diorama | each piece is a signed-distance sculpture meshed in the browser; tool marks are a bump in the piece's own space |
| photomontage | photographs are painted in greys, then given a print's grain, halation and tone curve, and cut out with drifting scissors |
| pinscreen | a field of pins at different heights, lit from a low angle, each pin's shadow falling on the next |
| archive desk | every paper is pre-rendered with its shadow, grain, foxing and torn fibres; stamps are inked, then eroded |
| night poster | a shape's shadow is the band a shifted copy of it fails to cover; night mixes colours toward navy while lamps keep their brightness |
| batik | a real 3D set lit by two coloured lamps is rendered into buffers; wax resists where both lamps reach, each dye takes where only one does, and the wax cracks |
| long-exposure glass plate | each frame integrates many light drawings over the exposure, so whatever moved is a smear and whatever stood still is sharp; then halation, dust and the emulsion's edge |
| silverpoint | even hatching whose weight follows the tone; lines can't be erased, and tarnish from grey to brown with age |
| carved relief | the scene becomes a height field, shaded by a raking light with its own cast shadows |
| liquid light show | oil, water and dye in a dish on a projector: warped-noise dye bands, metaball oil drops with a meniscus, and drawn transparencies whose black ink really blocks the lamp |
| thermal camera | a scene rendered as temperatures and mapped through a camera palette, with a thin visible-light edge overlay, warm breath and fading heat prints |
| showboat stage | painted flats given brushwork by a sampled-stroke pass, lit by a light map in which the actors are lit through their own silhouettes |

A filter that makes a clean digital picture look like linocut never convinces for long. A few rules about how the
real thing is made go much further.

## One frame

Almost every engine's frame function looks like this:

```
renderFrame(t):
  shot = the shot covering t
  set  = shot.set, baked on first use           (the still layers: land, buildings, background)
  cam  = shot.cam(t)                            (keyframed, eased)
  draw the set's layers through the camera       (parallax: nearer layers move more)
  draw what moves at t                           (figures, props, light, weather)
  post: light (a multiplied lamp or light map), grain, vignette, the medium's texture
  if t is inside a transition: draw the next shot too and mix (dissolve, wipe, push)
  the lyric band / margin / caption for t
  fade in and out at the ends
```

The canvas is 1920x1080. Several styles keep the picture above a band for the lyrics (e.g. 1920x960 + 120).

## Sets, shots, cameras

- **Sets** (or scenes, worlds, plates) are places. Their still parts are drawn once into offscreen canvases the first
  time they're needed ("baked"), then only composited. Keep a memory budget: the whole song's sets rarely fit at
  once, so drop the least recently used. Bake at load what the first seconds need, so playback doesn't hitch.
- **Shots** are stretches of song time: `{t0, t1, set, cam, ...}` plus a function that poses what moves.
- **Camera keys** are `[time, x, y, zoom, ...]` with easing between them. Two useful rules:
  - push in with **lens zoom**, not by travelling into the layers: depth travel blows the nearest layer up (snow
    becomes moons);
  - **never let the camera see past the edge** of what's drawn. Check the frame corners on every new camera.
- **Transitions:** dissolves, drop wipes (a new picture spreading inside a drop), push and pull (from a room to the
  picture on its screen), panels (pull back to a page of panels, push into another), re-laying one medium as another
  past a moving line.

## Time: on twos, and in step with the song

- Hand-made animation moves **on twos**: pose changes at 12 fps inside 24 fps video. Several engines step motion at
  12 fps (`tm12 = Math.floor(t * 12) / 12`) while the camera moves at the full 24, which keeps the hand-made feel
  without a juddering camera. Texture "boil" (grain, ink noise) often changes at 8 fps.
- **Ease into fast moves**, or drive them with real time: a move that starts at full speed jumps at 12 fps.
- **Hits on beats, changes on lines.** `SONG.beat(n)` and each line's `t0` and word times are the anchors. A word
  lighting in the lyric band typically fades up over `[t - 0.04, t + 0.16]`.
- **Keep something moving.** A hold longer than a beat or two reads as the player freezing. A slow drift, a breathing
  light or drifting smoke keeps a still picture alive.

## Determinism and frame-to-frame state

- All randomness comes from seeded generators (`mulberry32(seed)`) and noise keyed to the frame number. Never call
  `Math.random()` while drawing a frame. The same `t` must give the same picture, or an MP4 won't match what you
  checked.
- Some styles **carry state from frame to frame**: frost that grows, ghosting of the previous frame, a charcoal
  drawing that's erased and redrawn, marbled paint whose outlines remember every comb. Those must be stepped in
  order. `renderAt(t)` then means "rebuild the state from the start of this scene up to t", and each engine's README
  says how it does that.
- When a view steps backwards in time (a camera effect that holds frames, a scrub), keep what's already baked rather
  than rebuilding it from scratch each step, or rendering crawls.

## Figures

- **Whole figures**, posed. Every engine has a rig: jointed silhouettes, contour-drawn people, ray-marched signed
  distance bodies, carved 3D pieces. Most use **two-bone IK** for arms (and often legs), so a hand can be put exactly
  on a rope, a cup or another hand. Each rig spells it its own way: `reachArm()` in paper cut, an arm given as
  `{t: [x, y]}` in embroidery or `{at: [x, y]}` in painted enamel; the style READMEs show how.
- Build **every figure of a kind from one model**, so its anatomy is the same in every shot; vary only pose,
  clothing and age.
- Things that make figures read wrong, all hit at least once: round heads read as teddy bears (give them a muzzle
  or a jaw); coats that hang along the body turn a crouching figure into a plank (hang them toward world-down);
  digitigrade legs with a long stride look like sitting on a stool; two figures leaving the same way merge into one
  blob; close-up arm silhouettes read as clubs or poles.

## Light

- A **lamp** is a radial gradient drawn with `multiply` (or a light map multiplied onto the whole picture). Its
  warmth and brightness carry most of a scene's mood.
- **Self-lit things** (flames, lit windows, glowing marks) go in their own layer drawn after the light map, plus a
  glow. A reflective shape in front should erase the self-lit layer behind it.
- On pale paper, `screen` adds almost nothing; `soft-light` plus a weaker `screen` shows coloured light.
- Glass only darkens: a moving piece has to pass over light glass, or it vanishes.

## Text in the picture

- Load fonts before drawing and wait for them (`document.fonts.load(...)` for each face and script you use), or text
  falls back to a default font. `document.fonts.load` resolves even when the font never arrived, so check the
  result (or `document.fonts.check(...)`) before building. Put `<meta charset="utf-8">` at the top of the page for
  any non-ASCII text.
- **Start building only when every script has loaded** (`DOMContentLoaded`, or put the start call at the end of the
  last script). A build started from a font promise plus a short timer can win the race against later scripts when
  the fonts come from cache, and the page fails to build only sometimes.
- Keep the lyrics readable: if the camera zooms, keep the text out of the zoom (a band or margin drawn in screen
  space).

## Browser gotchas that cost hours

- **One bad gradient value kills the frame.** `addColorStop` with a NaN or an out-of-range offset throws, and nothing
  after it draws. Check the console after every change.
- **`destination-out` uses the current fill's alpha.** A fill left translucent from the last wash only half-erases.
  Set `fillStyle = '#000'` before erasing.
- **`[hidden]` loses to `display: grid`.** Add `.gate[hidden] { display: none }` for overlay elements.
- **Globals collide.** Plain scripts share one global scope; a helper named like an existing function (`hand`,
  `line`) silently replaces it.
- **Tiling seams:** a texture tiled from a sampled corner shows seams on big pieces; downsample the whole texture.
- **WebGL:** GLSL has reserved words you'd never guess (`patch`); creating a texture while another is bound can
  overwrite a texture unit (create textures on a scratch unit such as TEXTURE15); a three.js `InstancedMesh` keeps the
  bounds of its first draw unless `frustumCulled = false`.
- **Headless loads:** wait for the page with `wait_until='commit'` and your own ready flag; a page that builds a lot
  at load can time out waiting for the load event.
- **Grain that changes every frame bloats the MP4.** Change it on twos.

## Starting a new engine

1. Copy the style closest to what you want. Keep its player (`index.html`, the playback and `window.__video` parts
   of its engine) and its lyric code.
2. Write the medium: the few functions that turn a shape into your medium's marks. Test them on stills first, on a
   page that just draws one scene (a lab page).
3. Draw the same key scenes in your medium and in one or two alternatives. Choose.
4. Then sets, shots and the song.



## 原作者媒介陷阱与经验摘录

## Lessons and gotchas

- **Start building only when every script has loaded.** The engine file loads before the sets and the timeline;
  wait for `DOMContentLoaded` before building, or a cached (fast) font load lets the build start before the later
  scripts have run.
- **Texture joins:** tinting a quarter of the paper texture showed repeat lines on big pieces. Tint the whole
  (tileable) texture, downsampled, and scale the pattern up.
- **GLSL reserved words** (such as `patch`) as variable names break the shader. The error only shows in the console.
- **A single bad value in a canvas gradient kills the whole frame.** Read the console after every change.
- **Load the fonts with the text they'll draw** (`fontsReady()` in `core.js`), or the title and first lines fall back
  to a default face for a frame or two.
- **The play overlay is `display:grid`, which beats the `hidden` attribute**, so it never hid until the page's CSS
  got `.gate[hidden]{display:none}`.
- **Storms:** a storm read as a flat white band until it was built from overlapping scalloped billows, each with its
  own lit top edge. Snow spilling over a ridge showed rectangular blocks until it became a lobed curtain. A flare
  went pink until the violet in the aurora was reduced.
- **A valley of flat bands reads as a layered cake.** Steep U-shaped cross-sections at receding depths, trees on the
  steep parts, and a foreground ledge fix it. Anything that fills a valley (ice, water, mist) should fill each layer up
  to a level rather than sit in it as a box.
- **Floating land exposes the bottom of the sky**, which is bright. A dark gradient behind the strips turns it into a
  deep gulf.
- **Impossible land needs land on it.** A curling wall read as a pale wave with thorns, and land on its edge as a
  plain cliff, until they had things at a readable size: trees in stands, houses with lit windows, a rope line with
  lanterns, snow on the ground side, a ragged underside with ice pointing the "wrong" way, smoke going the "wrong"
  way.
- **Push in with `zm`, not `z`.** Depth travel blows up the nearest layer: snowflakes become moons.
- **Effects that belong to a layer must be drawn in its frame.** Light from an open door drawn at the wrong depth split
  into two or three pale panels when the camera moved. Draw it with that layer's `layerMatrix(d,cam)`.
- **Figures:** a very thin figure looked like a stick insect until it was given a deep chest; round heads read as
  teddy bears until they had a small muzzle; a walk on the toes (`'digi'` legs) looked like sitting on a stool until
  its stride was shortened; two figures leaving the same way merged into one blob.
- **Pale objects with glowing marks read as lanterns.** Make them pale with a dark stamped mark instead.
- **Big close-up silhouettes of hands and arms read as clubs, poles or chess pawns.** Show whole figures; a mostly
  still figure holding a rope carries a moment fine.
- **Guide ropes at knee height are too low to hold.** Put them at about hip height for the figures that use them.
- **A figure that changes how it's drawn** (on a layer, then on a screen-space bridge, then on a far strip) must keep
  the same stride phase, scale and draw order across the change, or it pops for a frame.
- **Reaching hands must stay in reach.** When two figures hold hands by reaching for one point, check every pose: a
  crouch lowers the shoulder, and the hands part.
- **Anything that bends must be its own piece**, and `bentPoint` must use the same bend as `drawBent` (measured from
  the piece's top, padding included), or attached leaves drift off their twigs. Bake a row of small trees in groups of
  three: one piece per row can only shear as a block, so no gust can travel along it.
- **Slices must overlap, but a shadow can't.** A bent piece is drawn in slices that overlap by a pixel so no gap
  shows; its soft shadow, drawn the same way, darkened into faint horizontal lines where the slices doubled up. Only
  the opaque piece overlaps its slices.
- **Drive speeds with integrated clocks** (`makeClock`), never `t * speed(t)`: when the speed changes, everything
  riding it jumps.
- **Blowing-snow streaks across the sky read as searchlights**; keep them below the horizon. Snow blown off tree tops
  drawn as round soft dots reads as a row of bokeh; stretch the puffs along the wind and thin them out.
- **Keep something moving.** Every shot here has a camera drift, snow, and the wind working on something; a hold of
  more than a beat or two looks like the player froze.
- **A place that grows keeps its sites.** Bake the land bare and list every building as a site with its eras, so each
  later view keeps the earlier houses where they stood; a view built separately for each era drifts. Clear the land
  (trees, posts) round a later site only as far as it needs, or the first view has bare patches where nothing stands
  yet. Set new things down so they land on the beat, over the 0.3 s before it, not after it.
- **On hanging land, everything obeys its own ground** except the wind: smoke, icicles, pennants and snow on roofs
  are drawn in the frame of their bit of curve, and things being set down there drop along that frame's "down". A
  pennant's streaming is the one thing that keeps the screen's direction (to the right with the wind), so it's
  mirrored on land that is turned over.
- **A shovel raised over the head reads as an axe or a hammer.** Toss at shoulder height. Aim the shaft by an angle
  held in the near hand and bring the far hand to its end by IK: a shaft laid through two hands placed by their own
  angles points wherever they happen to be, often straight up.
- **A figure with no height is never drawn.** Stand every figure on the ground from its pose (`standPuppet` works out
  the pelvis height from where the feet land) instead of giving each one a `y`.
- **Hair:** single strands read as antennae or a spiky crest, and locks that end in rounded tips read as the fingers
  of a mitten; filled, tapering, wavy locks read as hair. Turned from hanging to streaming by blending their direction,
  locks swept under the chin read as a beard: turn them over the top of the head. With the wind behind a figure, even a
  breeze blows hair forward; halfway there, it stands up like a crest.
- **A GLSL name that clashes breaks the whole sky.** Adding the motes with a variable already declared in the shader
  (a `vec2` used by the curtains) made it fail to compile, and the page fell back to a flat gradient. Give new shader
  code its own names, and read the console.
- **Infinity poisons smoothstep.** A helper that returns `Infinity` for "none" (the top of a fill level on a layer
  that has none) gave `sstep(a,b,Infinity)`, which is NaN, and a NaN alpha blanks what it touches. Guard such values.
- **Short effects need the right instant for a still.** The rising bolts fade within a quarter of a second, so a still
  0.3 s after the hit shows nothing; ask for a few hundredths of a second after it.
- **A figure lying down outdoors reads as a collapsed body.** One asleep on its feet, head down, reads as dozing.
- **Loads read by how they're held.** Sacks hugged against the chest at a walking pace read as carried; a sack held
  over the head with a leaping stride didn't, and sacks stacked upright in a lit doorway read as a hooded head until they
  were laid flat like sandbags. Snow on a head drawn as a row of dots read as pearls, then as a skullcap: a lumpy cap
  clipped to the head's outline, with loose flakes on the shoulders, reads as snow.
- **Bring people in from the cut.** A figure that pops into the middle of the frame mid-shot is a glitch; have them in
  the shot from its first frame, or walk them in from an edge, and fade them (`alpha`) where they go in at a door.
- **A shot's figures must last through the dissolve out of it.** The next shot's `fade` draws this one for a while
  longer; a pose function that returns nothing from the moment its shot ends makes its figures vanish while the picture
  is still nearly fully visible. Keep them until the fade is done.


